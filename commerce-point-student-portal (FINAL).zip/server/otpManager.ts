import crypto from 'crypto';

export interface StoredOtpRecord {
  id: string;
  type: 'email' | 'mobile';
  target: string; // normalized email or phone
  purpose: 'admin_verify' | 'recovery';
  hashedCode: string; // SHA-256(code + salt)
  salt: string;
  expiresAt: number; // Date.now() + 5 minutes
  attempts: number; // max 5 attempts
  createdAt: number;
}

export interface StoredResetToken {
  token: string;
  target: string;
  role: 'admin' | 'student';
  expiresAt: number; // 15 minutes
  createdAt: number;
}

export interface RateLimitEntry {
  target: string;
  lastRequestTime: number;
  requestCount10m: number;
  cooldownUntil?: number;
}

// In-memory server-authoritative stores
const otpRecords = new Map<string, StoredOtpRecord>();
const resetTokens = new Map<string, StoredResetToken>();
const rateLimits = new Map<string, RateLimitEntry>();

// Keep simulation hint in memory for dev/fallback when real SMS/SMTP is unconfigured
const lastSimulationCodes = new Map<string, { code: string; expiresAt: number }>();

function hashOtpCode(code: string, salt: string): string {
  return crypto.createHash('sha256').update(`${code}:::${salt}`).digest('hex');
}

/**
 * Check and update rate limiting for an email or phone target
 * Rules:
 * - 60 seconds cooldown between requests
 * - Max 4 requests in 10 minutes
 * - Temporary 15-minute lockout if excessive requests
 */
export function checkRateLimit(target: string): { allowed: boolean; waitSeconds?: number; reason?: string } {
  const now = Date.now();
  const key = target.toLowerCase().trim();
  const entry = rateLimits.get(key);

  if (!entry) {
    rateLimits.set(key, {
      target: key,
      lastRequestTime: now,
      requestCount10m: 1,
    });
    return { allowed: true };
  }

  // Check active cooldown lockout
  if (entry.cooldownUntil && entry.cooldownUntil > now) {
    const remainingSecs = Math.ceil((entry.cooldownUntil - now) / 1000);
    return {
      allowed: false,
      waitSeconds: remainingSecs,
      reason: `অতিরিক্ত ওটিপি অনুরোধের কারণে সাময়িক বিরতি চলছে। অনুগ্রহ করে ${remainingSecs} সেকেন্ড পরে চেষ্টা করুন।`,
    };
  }

  // Check 60-second restriction
  const elapsedFromLast = (now - entry.lastRequestTime) / 1000;
  if (elapsedFromLast < 60) {
    const wait = Math.ceil(60 - elapsedFromLast);
    return {
      allowed: false,
      waitSeconds: wait,
      reason: `নতুন কোড অনুরোধ করার পূর্বে ${wait} সেকেন্ড অপেক্ষা করুন।`,
    };
  }

  // Clean up 10m window if older than 10 mins
  if (now - entry.lastRequestTime > 10 * 60 * 1000) {
    entry.requestCount10m = 0;
  }

  // Check excessive requests
  if (entry.requestCount10m >= 4) {
    entry.cooldownUntil = now + 15 * 60 * 1000; // 15 mins cooldown
    return {
      allowed: false,
      waitSeconds: 900,
      reason: '১০ মিনিটের মধ্যে সর্বোচ্চ অনুরোধের সীমা অতিক্রম করেছে। ১৫ মিনিট বিরতির পর চেষ্টা করুন।',
    };
  }

  entry.lastRequestTime = now;
  entry.requestCount10m += 1;
  return { allowed: true };
}

/**
 * Generate cryptographically secure 6-digit OTP and store hashed version with 5 min validity
 */
export function generateAndStoreOtp(
  type: 'email' | 'mobile',
  target: string,
  purpose: 'admin_verify' | 'recovery'
): { code: string; expiresAt: number; target: string } {
  const normTarget = target.toLowerCase().trim();
  const code = crypto.randomInt(100000, 1000000).toString();
  const salt = crypto.randomBytes(16).toString('hex');
  const hashedCode = hashOtpCode(code, salt);
  const now = Date.now();
  const expiresAt = now + 5 * 60 * 1000; // Exactly 5 minutes

  const recordId = `${type}_${normTarget}_${purpose}`;
  const record: StoredOtpRecord = {
    id: recordId,
    type,
    target: normTarget,
    purpose,
    hashedCode,
    salt,
    expiresAt,
    attempts: 0,
    createdAt: now,
  };

  otpRecords.set(recordId, record);

  // Store simulation hint
  lastSimulationCodes.set(normTarget, { code, expiresAt });

  return { code, expiresAt, target: normTarget };
}

/**
 * Verify OTP:
 * - Checks expiry
 * - Verifies SHA-256 hash
 * - Max 5 attempts
 * - Immediately invalidates on success
 */
export function verifyOtp(
  type: 'email' | 'mobile',
  target: string,
  inputCode: string,
  purpose: 'admin_verify' | 'recovery'
): {
  success: boolean;
  message: string;
  resetToken?: string;
  verifiedToken?: string;
  remainingAttempts?: number;
} {
  const normTarget = target.toLowerCase().trim();
  const cleanCode = (inputCode || '').trim();
  const recordId = `${type}_${normTarget}_${purpose}`;
  const record = otpRecords.get(recordId);

  if (!record) {
    return {
      success: false,
      message: 'কোনো সক্রিয় ভেরিফিকেশন কোড পাওয়া যায়নি বা ৫ মিনিটের মেয়াদ শেষ হয়েছে। পুনরায় কোড পাঠান।',
    };
  }

  const now = Date.now();
  if (record.expiresAt < now) {
    otpRecords.delete(recordId);
    lastSimulationCodes.delete(normTarget);
    return {
      success: false,
      message: 'ভেরিফিকেশন কোডের ৫ মিনিটের মেয়াদ শেষ হয়েছে। নতুন কোডের অনুরোধ করুন।',
    };
  }

  if (record.attempts >= 5) {
    otpRecords.delete(recordId);
    lastSimulationCodes.delete(normTarget);
    return {
      success: false,
      message: 'অতিরিক্ত ভুল কোড প্রবেশের কারণে কোডটি বাতিল করা হয়েছে। পুনরায় কোড পাঠান।',
    };
  }

  const computedHash = hashOtpCode(cleanCode, record.salt);
  if (computedHash !== record.hashedCode) {
    record.attempts += 1;
    const remaining = 5 - record.attempts;
    if (remaining <= 0) {
      otpRecords.delete(recordId);
      lastSimulationCodes.delete(normTarget);
      return {
        success: false,
        message: 'অতিরিক্ত ভুল কোড প্রবেশের কারণে কোডটি বাতিল হয়েছে। নতুন কোডের অনুরোধ করুন।',
        remainingAttempts: 0,
      };
    }
    return {
      success: false,
      message: `ভুল ভেরিফিকেশন কোড! আর ${remaining} বার চেষ্টা বাকি রয়েছে।`,
      remainingAttempts: remaining,
    };
  }

  // SUCCESS: immediately invalidate the OTP (one-time use)
  otpRecords.delete(recordId);
  lastSimulationCodes.delete(normTarget);

  if (purpose === 'recovery') {
    // Generate secure short-lived reset token (15 mins)
    const resetToken = `rst_${crypto.randomBytes(32).toString('hex')}_${now}`;
    resetTokens.set(resetToken, {
      token: resetToken,
      target: normTarget,
      role: 'admin',
      expiresAt: now + 15 * 60 * 1000,
      createdAt: now,
    });

    return {
      success: true,
      message: '✓ ওটিপি সফলভাবে যাচাই হয়েছে। এবার নতুন পাসওয়ার্ড নির্ধারণ করুন।',
      resetToken,
    };
  } else {
    // Admin contact verification
    const verifiedToken = `vfd_${crypto.randomBytes(24).toString('hex')}`;
    return {
      success: true,
      message: `✓ ${type === 'email' ? 'ইমেইল' : 'মোবাইল নম্বর'} সফলভাবে ভেরিফাই ও সুরক্ষিত হয়েছে।`,
      verifiedToken,
    };
  }
}

/**
 * Validate and consume a reset token
 */
export function validateAndConsumeResetToken(token: string): {
  valid: boolean;
  target?: string;
  role?: 'admin' | 'student';
  error?: string;
} {
  const record = resetTokens.get(token);
  if (!record) {
    return { valid: false, error: 'পাসওয়ার্ড রিসেট টোকেনটি অবৈধ বা ইতিমধ্যে ব্যবহৃত হয়েছে।' };
  }

  if (record.expiresAt < Date.now()) {
    resetTokens.delete(token);
    return { valid: false, error: 'পাসওয়ার্ড রিসেট টোকেনের মেয়াদ উত্তীর্ণ হয়েছে। পুনরায় ওটিপি সংগ্রহ করুন।' };
  }

  // Consume token (one-time use)
  resetTokens.delete(token);
  return {
    valid: true,
    target: record.target,
    role: record.role,
  };
}

/**
 * Retrieves the active simulation code if exists (for test helper)
 */
export function getSimulationCode(target: string): string | null {
  const norm = target.toLowerCase().trim();
  const entry = lastSimulationCodes.get(norm);
  if (entry && entry.expiresAt > Date.now()) {
    return entry.code;
  }
  return null;
}
