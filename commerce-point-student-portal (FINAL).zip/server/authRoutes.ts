import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import {
  sendSMS,
  getSmsConfig,
  updateSmsConfig,
  formatBdPhoneForGateway,
  SmsProviderConfig,
} from './smsProvider.js';
import {
  sendVerificationEmail,
  getEmailConfig,
  updateEmailConfig,
  isEmailConfigured,
  EmailProviderConfig,
} from './emailProvider.js';
import {
  generateAndStoreOtp,
  verifyOtp,
  checkRateLimit,
  validateAndConsumeResetToken,
  getSimulationCode,
} from './otpManager.js';

export const authRouter = Router();

// In-memory or file-backed admin account store on server
interface ServerAdminAccount {
  username: string;
  name: string;
  phone: string;
  email: string;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  phoneVerifiedAt?: number;
  emailVerifiedAt?: number;
  passwordHash: string;
  salt: string;
  passwordChangedAt: number;
  updatedAt: number;
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function hashPassword(password: string, salt: string): string {
  return crypto.createHash('sha256').update(`${password}:::${salt}`).digest('hex');
}

// Initial admin account state
const initialSalt = generateSalt();
let serverAdmin: ServerAdminAccount = {
  username: 'admin',
  name: 'আইসিটি শিক্ষক / Admin',
  phone: '',
  email: '',
  isPhoneVerified: false,
  isEmailVerified: false,
  passwordHash: hashPassword('admin123', initialSalt),
  salt: initialSalt,
  passwordChangedAt: Date.now(),
  updatedAt: Date.now(),
};

/**
 * Validate password security requirements (Section 11)
 * - Minimum 8 characters
 * - Uppercase letter (A-Z)
 * - Lowercase letter (a-z)
 * - Number (0-9)
 * - Special character (!@#$%^&*...)
 */
export function validatePasswordSecurity(password: string): { isValid: boolean; error?: string } {
  if (!password || password.length < 8) {
    return { isValid: false, error: 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।' };
  }
  if (!/[A-Z]/.test(password)) {
    return { isValid: false, error: 'পাসওয়ার্ডে কমপক্ষে একটি বড় হাতের অক্ষর (Uppercase: A-Z) থাকতে হবে।' };
  }
  if (!/[a-z]/.test(password)) {
    return { isValid: false, error: 'পাসওয়ার্ডে কমপক্ষে একটি ছোট হাতের অক্ষর (Lowercase: a-z) থাকতে হবে।' };
  }
  if (!/[0-9]/.test(password)) {
    return { isValid: false, error: 'পাসওয়ার্ডে কমপক্ষে একটি সংখ্যা (0-9) থাকতে হবে।' };
  }
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    return { isValid: false, error: 'পাসওয়ার্ডে কমপক্ষে একটি বিশেষ চিহ্ন/স্পেশাল ক্যারেক্টার (!@#$%^&*) থাকতে হবে।' };
  }
  return { isValid: true };
}

/**
 * GET /api/auth/status
 * Returns current provider statuses without leaking secret keys
 */
authRouter.get('/status', (_req: Request, res: Response) => {
  const sms = getSmsConfig();
  const email = getEmailConfig();

  res.json({
    success: true,
    providers: {
      sms: {
        provider: sms.provider,
        hasApiKey: !!sms.apiKey,
        senderId: sms.senderId || 'COMMERCE PT',
        isConfigured: sms.provider !== 'simulation' && !!sms.apiKey,
      },
      email: {
        host: email.host,
        port: email.port,
        secure: email.secure,
        user: email.user,
        from: email.from,
        hasPassword: !!email.password,
        isConfigured: isEmailConfigured(),
      },
    },
    adminProfile: {
      username: serverAdmin.username,
      name: serverAdmin.name,
      phone: serverAdmin.phone,
      email: serverAdmin.email,
      isPhoneVerified: serverAdmin.isPhoneVerified,
      isEmailVerified: serverAdmin.isEmailVerified,
      phoneVerifiedAt: serverAdmin.phoneVerifiedAt,
      emailVerifiedAt: serverAdmin.emailVerifiedAt,
      passwordChangedAt: serverAdmin.passwordChangedAt,
      updatedAt: serverAdmin.updatedAt,
    },
  });
});

/**
 * POST /api/auth/send-otp
 * Body: { type: 'email' | 'mobile', target: string, purpose: 'admin_verify' | 'recovery' }
 */
authRouter.post('/send-otp', async (req: Request, res: Response) => {
  try {
    const { type, target, purpose = 'admin_verify' } = req.body;

    if (!type || !['email', 'mobile'].includes(type)) {
      return res.status(400).json({ success: false, message: 'সঠিক টাইপ (email অথবা mobile) প্রদান করুন।' });
    }
    if (!target || typeof target !== 'string' || !target.trim()) {
      return res.status(400).json({ success: false, message: 'মোবাইল নম্বর বা ইমেইল ঠিকানা প্রদান করুন।' });
    }

    const cleanTarget = target.trim();

    // Section 10: Security - Account Enumeration
    // For password recovery, check if account matches. If not, do NOT disclose; return generic success.
    if (purpose === 'recovery') {
      const targetLower = cleanTarget.toLowerCase();
      const adminPhoneDigits = serverAdmin.phone.replace(/\D/g, '');
      const inputDigits = cleanTarget.replace(/\D/g, '');

      const isMatch =
        (type === 'email' && serverAdmin.email && serverAdmin.email.toLowerCase() === targetLower) ||
        (type === 'mobile' && serverAdmin.phone && adminPhoneDigits.endsWith(inputDigits.slice(-10)));

      if (!isMatch) {
        // Enforce slight delay to prevent timing attacks, then return generic message
        await new Promise((resolve) => setTimeout(resolve, 600));
        return res.json({
          success: true,
          message: 'যদি এই তথ্যের সাথে কোনো অ্যাকাউন্ট যুক্ত থাকে, তাহলে ভেরিফিকেশন কোড পাঠানো হয়েছে।',
          genericMessage: true,
        });
      }
    }

    // Section 8: Rate Limiting & Cooldown
    const rateCheck = checkRateLimit(cleanTarget);
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        message: rateCheck.reason || 'দয়া করে অপেক্ষা করুন।',
        waitSeconds: rateCheck.waitSeconds,
      });
    }

    // Section 6 & 7: Generate 6-digit OTP, store hashed, 5 min validity
    const { code, expiresAt } = generateAndStoreOtp(type, cleanTarget, purpose);

    // Section 4 & 5: Dispatch real SMS or Email
    let dispatchResult: { success: boolean; isSimulated?: boolean; error?: string };

    if (type === 'mobile') {
      const smsText = `COMMERCE POINT: আপনার ভেরিফিকেশন ওটিপি ${code}। মেয়াদ ৫ মিনিট। কারও সাথে শেয়ার করবেন না।`;
      dispatchResult = await sendSMS(cleanTarget, smsText);
    } else {
      dispatchResult = await sendVerificationEmail(cleanTarget, code, purpose);
    }

    // Get simulation code if active (for local developer ease / testing when unconfigured)
    const simulationCode = dispatchResult.isSimulated ? code : undefined;

    return res.json({
      success: true,
      message: purpose === 'recovery'
        ? 'যদি এই তথ্যের সাথে কোনো অ্যাকাউন্ট যুক্ত থাকে, তাহলে ভেরিফিকেশন কোড পাঠানো হয়েছে।'
        : `✓ ভেরিফিকেশন কোড পাঠানো হয়েছে। কোডটির মেয়াদ ৫ মিনিট।`,
      expiresAt,
      isSimulated: !!dispatchResult.isSimulated,
      simulationCode,
      providerError: dispatchResult.error,
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'ওটিপি পাঠাতে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/verify-otp
 * Body: { type: 'email' | 'mobile', target: string, code: string, purpose: 'admin_verify' | 'recovery' }
 */
authRouter.post('/verify-otp', (req: Request, res: Response) => {
  try {
    const { type, target, code, purpose = 'admin_verify' } = req.body;

    if (!type || !target || !code) {
      return res.status(400).json({ success: false, message: 'প্রয়োজনীয় তথ্য প্রদান করুন।' });
    }

    const result = verifyOtp(type, target.trim(), code.toString().trim(), purpose);

    if (!result.success) {
      return res.status(400).json(result);
    }

    // If verified for admin contact update, mark in serverAdmin state
    if (purpose === 'admin_verify') {
      const cleanTarget = target.trim();
      if (type === 'mobile') {
        serverAdmin.phone = cleanTarget;
        serverAdmin.isPhoneVerified = true;
        serverAdmin.phoneVerifiedAt = Date.now();
        serverAdmin.updatedAt = Date.now();
      } else if (type === 'email') {
        serverAdmin.email = cleanTarget.toLowerCase();
        serverAdmin.isEmailVerified = true;
        serverAdmin.emailVerifiedAt = Date.now();
        serverAdmin.updatedAt = Date.now();
      }
    }

    return res.json({
      ...result,
      adminProfile: {
        phone: serverAdmin.phone,
        email: serverAdmin.email,
        isPhoneVerified: serverAdmin.isPhoneVerified,
        isEmailVerified: serverAdmin.isEmailVerified,
        phoneVerifiedAt: serverAdmin.phoneVerifiedAt,
        emailVerifiedAt: serverAdmin.emailVerifiedAt,
      },
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'যাচাইকরণে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/reset-password
 * Body: { resetToken: string, newPassword: string }
 * Section 9 & 12: Server-side short-lived one-time reset authorization
 */
authRouter.post('/reset-password', (req: Request, res: Response) => {
  try {
    const { resetToken, newPassword } = req.body;

    if (!resetToken || typeof resetToken !== 'string') {
      return res.status(400).json({ success: false, message: 'পাসওয়ার্ড রিসেট টোকেন প্রদান করুন।' });
    }

    // Section 11: Validate password security requirements first
    const passCheck = validatePasswordSecurity(newPassword);
    if (!passCheck.isValid) {
      return res.status(400).json({ success: false, message: passCheck.error });
    }

    // Validate token and immediately consume it once password is verified valid
    const tokenCheck = validateAndConsumeResetToken(resetToken);
    if (!tokenCheck.valid) {
      return res.status(400).json({ success: false, message: tokenCheck.error });
    }

    // Overwrite old password with secure salted hash
    const newSalt = generateSalt();
    serverAdmin.salt = newSalt;
    serverAdmin.passwordHash = hashPassword(newPassword, newSalt);
    serverAdmin.passwordChangedAt = Date.now();
    serverAdmin.updatedAt = Date.now();

    return res.json({
      success: true,
      message: '✓ এডমিন পাসওয়ার্ড সফলভাবে রিসেট সম্পন্ন হয়েছে। অনুগ্রহ করে লগইন করুন।',
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'পাসওয়ার্ড রিসেটে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/change-password
 * Body: { currentPassword: string, newPassword: string }
 */
authRouter.post('/change-password', (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword) {
      return res.status(400).json({ success: false, message: 'বর্তমান পাসওয়ার্ড প্রদান করুন।' });
    }

    const currentHash = hashPassword(currentPassword, serverAdmin.salt);
    if (currentHash !== serverAdmin.passwordHash) {
      return res.status(401).json({ success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়।' });
    }

    if (currentPassword === newPassword) {
      return res.status(400).json({ success: false, message: 'নতুন পাসওয়ার্ড অবশ্যই বর্তমান পাসওয়ার্ড থেকে ভিন্ন হতে হবে।' });
    }

    const passCheck = validatePasswordSecurity(newPassword);
    if (!passCheck.isValid) {
      return res.status(400).json({ success: false, message: passCheck.error });
    }

    const newSalt = generateSalt();
    serverAdmin.salt = newSalt;
    serverAdmin.passwordHash = hashPassword(newPassword, newSalt);
    serverAdmin.passwordChangedAt = Date.now();
    serverAdmin.updatedAt = Date.now();

    return res.json({
      success: true,
      message: '✓ এডমিন পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে।',
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'পাসওয়ার্ড পরিবর্তনে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/update-profile
 * Body: { name, username, phone, email }
 * Section 1 & 13: If existing verified email or phone is changed, reset verification status!
 */
authRouter.post('/update-profile', (req: Request, res: Response) => {
  try {
    const { name, username, phone, email } = req.body;

    if (name) serverAdmin.name = name.trim();
    if (username) serverAdmin.username = username.trim();

    const newPhone = (phone || '').trim();
    const newEmail = (email || '').trim().toLowerCase();

    // Section 13: Email/Mobile Change Security
    if (newPhone !== serverAdmin.phone) {
      serverAdmin.phone = newPhone;
      serverAdmin.isPhoneVerified = false; // Reset to unverified!
      serverAdmin.phoneVerifiedAt = undefined;
    }

    if (newEmail !== serverAdmin.email) {
      serverAdmin.email = newEmail;
      serverAdmin.isEmailVerified = false; // Reset to unverified!
      serverAdmin.emailVerifiedAt = undefined;
    }

    serverAdmin.updatedAt = Date.now();

    return res.json({
      success: true,
      message: '✓ তথ্য সফলভাবে আপডেট হয়েছে। নতুন বা পরিবর্তিত তথ্যের জন্য ভেরিফিকেশন প্রয়োজন।',
      adminProfile: {
        username: serverAdmin.username,
        name: serverAdmin.name,
        phone: serverAdmin.phone,
        email: serverAdmin.email,
        isPhoneVerified: serverAdmin.isPhoneVerified,
        isEmailVerified: serverAdmin.isEmailVerified,
        phoneVerifiedAt: serverAdmin.phoneVerifiedAt,
        emailVerifiedAt: serverAdmin.emailVerifiedAt,
        passwordChangedAt: serverAdmin.passwordChangedAt,
        updatedAt: serverAdmin.updatedAt,
      },
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'প্রোফাইল আপডেটে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/config-providers
 * Admin Settings for SMS & SMTP Gateways
 */
authRouter.post('/config-providers', (req: Request, res: Response) => {
  try {
    const { sms, email } = req.body;

    if (sms) {
      updateSmsConfig(sms as Partial<SmsProviderConfig>);
    }
    if (email) {
      updateEmailConfig(email as Partial<EmailProviderConfig>);
    }

    return res.json({
      success: true,
      message: '✓ প্রোভাইডার সেটিংস সফলভাবে সংরক্ষিত হয়েছে।',
      status: {
        sms: getSmsConfig(),
        email: getEmailConfig(),
      },
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'প্রোভাইডার কনফিগারেশনে ত্রুটি।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});

/**
 * POST /api/auth/test-provider
 * Sends test SMS or test Email to verify admin credentials
 */
authRouter.post('/test-provider', async (req: Request, res: Response) => {
  try {
    const { type, target } = req.body;

    if (!target) {
      return res.status(400).json({ success: false, message: 'টেস্ট প্রাপকের তথ্য প্রদান করুন।' });
    }

    if (type === 'mobile') {
      const result = await sendSMS(
        target,
        'COMMERCE POINT: এটি একটি সিস্টেম টেস্ট এসএমএস (SMS Gateway Test Success)।'
      );
      return res.json(result);
    } else if (type === 'email') {
      const result = await sendVerificationEmail(target, '123456', 'admin_verify');
      return res.json(result);
    }

    return res.status(400).json({ success: false, message: 'অকার্যকর টেস্ট টাইপ।' });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'টেস্ট পাঠাতে ত্রুটি হয়েছে।';
    return res.status(500).json({ success: false, message: errorMsg });
  }
});
