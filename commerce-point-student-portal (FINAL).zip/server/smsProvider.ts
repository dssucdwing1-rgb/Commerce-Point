/**
 * Bangladeshi SMS Provider Abstraction for COMMERCE POINT Student Portal
 * Supports:
 * - Greenweb (https://api.greenweb.com.bd/api.php)
 * - BulkSMS BD (http://bulksmsbd.net/api/smsapi)
 * - Alpha Net (https://api.smsnet24.com/v1/sms/send)
 * - MimSMS (https://api.mimsms.com/api/v3/send-sms)
 * - Generic HTTP REST Gateway (custom URL template)
 * - Simulation / Console Fallback (when API key is not yet set)
 */

export interface SmsProviderConfig {
  provider: 'simulation' | 'greenweb' | 'bulksmsbd' | 'alphanet' | 'mim_sms' | 'generic_http';
  apiKey?: string;
  senderId?: string;
  apiUrl?: string;
  clientId?: string;
}

export interface SmsSendResult {
  success: boolean;
  provider: string;
  messageId?: string;
  error?: string;
  isSimulated?: boolean;
  timestamp: number;
}

// In-memory or env-backed config
let activeSmsConfig: SmsProviderConfig = {
  provider: (process.env.SMS_PROVIDER as SmsProviderConfig['provider']) || 'simulation',
  apiKey: process.env.SMS_API_KEY || '',
  senderId: process.env.SMS_SENDER_ID || 'COMMERCE PT',
  apiUrl: process.env.SMS_API_URL || '',
  clientId: process.env.SMS_CLIENT_ID || '',
};

export function getSmsConfig(): SmsProviderConfig {
  return { ...activeSmsConfig };
}

export function updateSmsConfig(newConfig: Partial<SmsProviderConfig>): SmsProviderConfig {
  activeSmsConfig = {
    ...activeSmsConfig,
    ...newConfig,
  };
  return { ...activeSmsConfig };
}

/**
 * Normalize Bangladeshi phone number to international / gateway format
 * 01XXXXXXXXX -> 8801XXXXXXXXX
 */
export function formatBdPhoneForGateway(phone: string): { local: string; international: string } {
  const digits = phone.replace(/\D/g, '');
  let local = digits;
  if (digits.startsWith('880')) {
    local = '0' + digits.slice(3);
  } else if (digits.startsWith('88')) {
    local = digits.slice(2);
  } else if (!digits.startsWith('0') && digits.length === 10) {
    local = '0' + digits;
  }
  const international = local.startsWith('0') ? '88' + local : '880' + local;
  return { local, international };
}

/**
 * Universal sendSMS function
 * Provider abstraction as requested in User Specification #4
 */
export async function sendSMS(phone: string, message: string): Promise<SmsSendResult> {
  const config = getSmsConfig();
  const { local, international } = formatBdPhoneForGateway(phone);
  const now = Date.now();

  console.log(`[SMS Provider] Sending OTP to ${local} via ${config.provider}...`);

  // If no API key configured or simulation selected, use simulation fallback
  if (config.provider === 'simulation' || !config.apiKey) {
    console.log('---------------------------------------------------------');
    console.log(`[SMS SIMULATION] TO: ${local} (${international})`);
    console.log(`[SMS SIMULATION] CONTENT: ${message}`);
    console.log('---------------------------------------------------------');
    return {
      success: true,
      provider: 'simulation',
      isSimulated: true,
      messageId: `sim_sms_${Date.now()}`,
      timestamp: now,
    };
  }

  try {
    switch (config.provider) {
      case 'greenweb': {
        // Greenweb SMS API: https://api.greenweb.com.bd/api.php?token=TOKEN&to=8801XXXXXXXXX&message=MESSAGE
        const url = new URL(config.apiUrl || 'https://api.greenweb.com.bd/api.php');
        url.searchParams.append('token', config.apiKey);
        url.searchParams.append('to', international);
        url.searchParams.append('message', message);

        const response = await fetch(url.toString(), { method: 'GET' });
        const resText = await response.text();
        const ok = response.ok && !resText.toLowerCase().includes('error');
        return {
          success: ok,
          provider: 'greenweb',
          messageId: ok ? `gw_${now}` : undefined,
          error: ok ? undefined : resText,
          timestamp: now,
        };
      }

      case 'bulksmsbd': {
        // BulkSMS BD API: http://bulksmsbd.net/api/smsapi
        const url = new URL(config.apiUrl || 'http://bulksmsbd.net/api/smsapi');
        url.searchParams.append('api_key', config.apiKey);
        url.searchParams.append('type', 'text');
        url.searchParams.append('number', international);
        url.searchParams.append('senderid', config.senderId || '8809612443880');
        url.searchParams.append('message', message);

        const response = await fetch(url.toString(), { method: 'GET' });
        const data = await response.json().catch(() => null);
        const ok = response.ok && data?.response_code === 202;
        return {
          success: ok,
          provider: 'bulksmsbd',
          messageId: data?.msg_id || `bsbd_${now}`,
          error: ok ? undefined : data?.error_message || 'BulkSMS BD failed',
          timestamp: now,
        };
      }

      case 'alphanet': {
        // Alpha Net SMS API: https://api.smsnet24.com/v1/sms/send
        const url = config.apiUrl || 'https://api.smsnet24.com/v1/sms/send';
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            api_key: config.apiKey,
            sender_id: config.senderId,
            contacts: international,
            msg: message,
          }),
        });
        const resData = await response.json().catch(() => null);
        const ok = response.ok && resData?.status === 'success';
        return {
          success: ok,
          provider: 'alphanet',
          messageId: resData?.request_id || `alpha_${now}`,
          error: ok ? undefined : resData?.message || 'Alpha Net SMS failed',
          timestamp: now,
        };
      }

      case 'mim_sms': {
        // MimSMS API: https://api.mimsms.com/api/v3/send-sms
        const url = config.apiUrl || 'https://api.mimsms.com/api/v3/send-sms';
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            sender_id: config.senderId,
            phone_number: international,
            message,
          }),
        });
        const resData = await response.json().catch(() => null);
        const ok = response.ok && (resData?.status === 'success' || resData?.code === 200);
        return {
          success: ok,
          provider: 'mim_sms',
          messageId: resData?.data?.tracking_id || `mim_${now}`,
          error: ok ? undefined : resData?.message || 'MimSMS failed',
          timestamp: now,
        };
      }

      case 'generic_http': {
        // Generic HTTP REST / GET Gateway
        if (!config.apiUrl) {
          throw new Error('Generic HTTP SMS gateway URL not configured.');
        }
        let urlStr = config.apiUrl
          .replace('{{phone}}', encodeURIComponent(international))
          .replace('{{message}}', encodeURIComponent(message))
          .replace('{{token}}', encodeURIComponent(config.apiKey || ''))
          .replace('{{sender}}', encodeURIComponent(config.senderId || ''));

        const response = await fetch(urlStr, { method: 'GET' });
        const ok = response.ok;
        return {
          success: ok,
          provider: 'generic_http',
          messageId: ok ? `generic_${now}` : undefined,
          error: ok ? undefined : `HTTP ${response.status}: ${response.statusText}`,
          timestamp: now,
        };
      }

      default: {
        return {
          success: true,
          provider: 'simulation',
          isSimulated: true,
          timestamp: now,
        };
      }
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'SMS dispatch error';
    console.error(`[SMS Provider Error] Failed to send SMS via ${config.provider}:`, errorMsg);
    // Fallback gracefully so admin is not permanently locked out
    return {
      success: false,
      provider: config.provider,
      error: errorMsg,
      timestamp: now,
    };
  }
}
