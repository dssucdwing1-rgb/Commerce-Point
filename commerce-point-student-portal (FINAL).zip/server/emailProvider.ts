import nodemailer from 'nodemailer';

export interface EmailProviderConfig {
  host?: string;
  port?: number;
  secure?: boolean;
  user?: string;
  password?: string;
  from?: string;
}

export interface EmailSendResult {
  success: boolean;
  messageId?: string;
  error?: string;
  isSimulated?: boolean;
  timestamp: number;
}

let activeEmailConfig: EmailProviderConfig = {
  host: process.env.EMAIL_HOST || '',
  port: Number(process.env.EMAIL_PORT) || 587,
  secure: process.env.EMAIL_SECURE === 'true',
  user: process.env.EMAIL_USER || '',
  password: process.env.EMAIL_PASSWORD || '',
  from: process.env.EMAIL_FROM || 'COMMERCE POINT <noreply@commercepoint.edu.bd>',
};

export function getEmailConfig(): EmailProviderConfig {
  return {
    ...activeEmailConfig,
    // Do not return actual password to client for security
    password: activeEmailConfig.password ? '********' : '',
  };
}

export function updateEmailConfig(newConfig: Partial<EmailProviderConfig>): EmailProviderConfig {
  activeEmailConfig = {
    ...activeEmailConfig,
    ...newConfig,
    // Keep existing password if not provided
    password: newConfig.password !== undefined && newConfig.password !== '********'
      ? newConfig.password
      : activeEmailConfig.password,
  };
  return getEmailConfig();
}

/**
 * Checks whether real SMTP credentials are provided
 */
export function isEmailConfigured(): boolean {
  return !!(
    activeEmailConfig.host &&
    activeEmailConfig.user &&
    activeEmailConfig.password
  );
}

/**
 * Sends a real verification code email via SMTP (or simulation if unconfigured)
 */
export async function sendVerificationEmail(
  toEmail: string,
  code: string,
  purpose: 'admin_verify' | 'recovery' = 'admin_verify'
): Promise<EmailSendResult> {
  const now = Date.now();
  const isRecovery = purpose === 'recovery';
  const subject = isRecovery
    ? `COMMERCE POINT - পাসওয়ার্ড রিকভারি ওটিপি: ${code}`
    : `COMMERCE POINT - ইমেইল ভেরিফিকেশন কোড: ${code}`;

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="bn">
    <head>
      <meta charset="utf-8">
      <title>${subject}</title>
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #1e293b; }
        .card { max-width: 540px; margin: 0 auto; background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); }
        .header { background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #1e3a8a 100%); color: #ffffff; padding: 28px 24px; text-align: center; }
        .title { font-size: 22px; font-weight: 800; letter-spacing: 0.5px; margin: 0; }
        .subtitle { font-size: 13px; color: #93c5fd; margin-top: 4px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
        .body { padding: 32px 28px; }
        .greeting { font-size: 15px; font-weight: 600; color: #0f172a; margin-bottom: 12px; }
        .text { font-size: 14px; line-height: 1.6; color: #475569; margin-bottom: 24px; }
        .otp-container { text-align: center; margin: 28px 0; }
        .otp-box { display: inline-block; background: #f8fafc; border: 2px dashed #6366f1; border-radius: 12px; padding: 16px 36px; }
        .otp-code { font-family: 'Courier New', Courier, monospace; font-size: 34px; font-weight: 800; letter-spacing: 8px; color: #4338ca; }
        .expiry-badge { display: inline-block; margin-top: 8px; font-size: 12px; font-weight: 700; color: #dc2626; background: #fee2e2; padding: 4px 12px; border-radius: 9999px; }
        .security-note { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 4px; font-size: 12px; color: #92400e; margin-top: 24px; line-height: 1.5; }
        .footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 16px 24px; text-align: center; font-size: 11px; color: #94a3b8; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="header">
          <h1 class="title">COMMERCE POINT</h1>
          <div class="subtitle">Student Portal & Admin Authentication</div>
        </div>
        <div class="body">
          <div class="greeting">সম্মানিত অ্যাডমিন / শিক্ষক,</div>
          <p class="text">
            ${isRecovery
              ? 'আপনার COMMERCE POINT অ্যাকাউন্টের পাসওয়ার্ড রিকভারি/রিসেটের অনুরোধ পাওয়া গেছে। পাসওয়ার্ড পরিবর্তনের জন্য নিচের ৬-ডিজিটের ওটিপি ব্যবহার করুন:'
              : 'আপনার COMMERCE POINT অ্যাকাউন্টে নতুন ইমেইল ভেরিফিকেশনের জন্য নিচের ৬-ডিজিটের ওটিপি কোডটি ব্যবহার করুন:'}
          </p>

          <div class="otp-container">
            <div class="otp-box">
              <div class="otp-code">${code}</div>
            </div>
            <div>
              <span class="expiry-badge">⏱️ মেয়াদ: সর্বোচ্চ ৫ মিনিট</span>
            </div>
          </div>

          <div class="security-note">
            ⚠️ <strong>নিরাপত্তা সতর্কতা:</strong> এই ওটিপি কোডটি অত্যন্ত সংবেদনশীল ও ওয়ান-টাইম। এই কোডটি অন্য কারও সাথে শেয়ার করবেন না। আপনি যদি এই অনুরোধ না করে থাকেন, তবে অবিলম্বে আপনার পাসওয়ার্ড পরিবর্তন করুন।
          </div>
        </div>
        <div class="footer">
          COMMERCE POINT ICT Coaching & Student Progress System • ঢাকা, বাংলাদেশ<br>
          এটি একটি স্বয়ংক্রিয় সিস্টেম ইমেইল, এর উত্তরে রিপ্লাই করবেন না।
        </div>
      </div>
    </body>
    </html>
  `;

  // If SMTP not fully configured, log clearly and return simulation
  if (!isEmailConfigured()) {
    console.log('---------------------------------------------------------');
    console.log(`[EMAIL SIMULATION] TO: ${toEmail}`);
    console.log(`[EMAIL SIMULATION] SUBJECT: ${subject}`);
    console.log(`[EMAIL SIMULATION] OTP CODE: ${code}`);
    console.log('---------------------------------------------------------');
    return {
      success: true,
      isSimulated: true,
      messageId: `sim_email_${now}`,
      timestamp: now,
    };
  }

  try {
    const transporter = nodemailer.createTransport({
      host: activeEmailConfig.host,
      port: activeEmailConfig.port || 587,
      secure: activeEmailConfig.secure || false,
      auth: {
        user: activeEmailConfig.user,
        pass: activeEmailConfig.password,
      },
    });

    const info = await transporter.sendMail({
      from: activeEmailConfig.from || `"COMMERCE POINT" <${activeEmailConfig.user}>`,
      to: toEmail,
      subject,
      html: htmlContent,
      text: `${subject}\n\nআপনার ৬-ডিজিটের ভেরিফিকেশন ওটিপি: ${code}\nএই কোডটির মেয়াদ ৫ মিনিট।\nনিরাপত্তার স্বার্থে এটি কারও সাথে শেয়ার করবেন না।\n\nCOMMERCE POINT Student Portal`,
    });

    console.log(`[Email Provider] Successfully sent OTP to ${toEmail}, MessageId: ${info.messageId}`);
    return {
      success: true,
      messageId: info.messageId,
      timestamp: now,
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'SMTP dispatch error';
    console.error(`[Email Provider Error] Failed to send email to ${toEmail}:`, errorMsg);
    return {
      success: false,
      error: errorMsg,
      timestamp: now,
    };
  }
}
