import { supabase } from '../supabase';
import { studentIdToDummyEmail } from '../utils/authHelpers';
import { loadStudents, normalizeStudentId } from './storage';
import { adminResetStudentPassword } from './authService';
import { mapDatabaseRowToStudent } from './supabaseDataService';
import { AuthSession, AuthUser, Student } from '../types';
import { checkStaffIsActive } from './staffService';

export interface SupabaseAuthResult {
  success: boolean;
  message?: string;
  session?: AuthSession;
  dummyEmailUsed?: string;
}

/**
 * Maps a Supabase Auth user to application AuthSession
 */
export function mapSupabaseUserToAuthSession(
  user: any,
  accessToken?: string
): AuthSession {
  const userMeta = user.user_metadata || {};
  const email = (user.email || '').toLowerCase();
  const isEmailAdmin =
    email.startsWith('admin@') ||
    userMeta.role === 'admin' ||
    userMeta.username?.toLowerCase() === 'admin';

  // Role Identification: If email starts with "staff" (e.g., staff1@student.commercepoint.app), set user role to 'staff'
  const isEmailStaff =
    email.startsWith('staff') ||
    userMeta.role === 'staff' ||
    userMeta.username?.toLowerCase()?.startsWith('staff');

  const students = loadStudents();

  if (isEmailAdmin) {
    const authUser: AuthUser = {
      id: user.id || 'admin_user',
      name: userMeta.name || userMeta.full_name || 'আইসিটি শিক্ষক / Admin',
      role: 'admin',
      username: userMeta.username || 'admin',
    };
    return {
      user: authUser,
      token: accessToken || `sb_token_${user.id}`,
      rememberMe: true,
      loggedInAt: Date.now(),
    };
  }

  if (isEmailStaff) {
    const rawUsername = userMeta.username || email.split('@')[0] || 'staff';
    const authUser: AuthUser = {
      id: user.id || `staff_${rawUsername}`,
      name: userMeta.name || userMeta.full_name || `অপারেটর (${rawUsername})`,
      role: 'staff',
      username: rawUsername,
    };
    return {
      user: authUser,
      token: accessToken || `sb_token_${user.id}`,
      rememberMe: true,
      loggedInAt: Date.now(),
    };
  }

  // Student matching by email, studentIdCode, customStudentId, or roll
  const matchingStudent = students.find((s) => {
    if (user.email && studentIdToDummyEmail(s.studentIdCode) === user.email.toLowerCase()) return true;
    if (userMeta.studentIdCode && normalizeStudentId(s.studentIdCode) === normalizeStudentId(userMeta.studentIdCode)) return true;
    if (userMeta.customStudentId && normalizeStudentId(s.studentIdCode) === normalizeStudentId(userMeta.customStudentId)) return true;
    if (s.email && s.email.toLowerCase() === user.email?.toLowerCase()) return true;
    if (userMeta.roll && s.roll === userMeta.roll) return true;
    return false;
  });

  const studentObj: Student = matchingStudent || {
    id: user.id,
    roll: userMeta.roll || 1,
    name: userMeta.name || userMeta.full_name || 'শিক্ষার্থী',
    studentIdCode: userMeta.studentIdCode || userMeta.customStudentId || '',
    batchId: userMeta.batchId || 'class-11-a',
    academicClass: userMeta.academicClass || 'XI',
    group: userMeta.group || 'B-A',
    subject: 'ICT',
    session: '2026',
  };

  const authUser: AuthUser = {
    id: studentObj.id,
    name: studentObj.name,
    role: 'student',
    customStudentId: studentObj.studentIdCode,
    batchId:
      studentObj.batchId ||
      (studentObj.academicClass === 'XII'
        ? studentObj.group === 'B-B'
          ? 'class-12-b'
          : 'class-12-a'
        : 'class-11-a'),
    student: studentObj,
  };

  return {
    user: authUser,
    token: accessToken || `sb_token_${user.id}`,
    rememberMe: true,
    loggedInAt: Date.now(),
  };
}

/**
 * Asynchronously builds AuthSession for a student by querying Supabase RLS:
 * supabase.from('students').select('*').single()
 */
export async function buildAuthSessionWithRLS(
  user: any,
  accessToken?: string
): Promise<AuthSession> {
  const baseSession = mapSupabaseUserToAuthSession(user, accessToken);

  if (baseSession.user.role === 'admin' || baseSession.user.role === 'staff') {
    return baseSession;
  }

  // When a Student logs in:
  // Fetch the logged-in student's record from `students` using supabase.from('students').select('*').single()
  try {
    const { data: dbStudent, error } = await supabase
      .from('students')
      .select('*')
      .single();

    if (!error && dbStudent) {
      const studentObj = mapDatabaseRowToStudent(dbStudent, baseSession.user.student);
      return {
        ...baseSession,
        user: {
          ...baseSession.user,
          id: studentObj.id,
          name: studentObj.name,
          customStudentId: studentObj.studentIdCode,
          batchId: studentObj.batchId,
          student: studentObj,
        },
      };
    }
  } catch (err) {
    console.warn('buildAuthSessionWithRLS query error:', err);
  }

  return baseSession;
}

/**
 * Signs in a user using their Student ID or Admin username via Supabase Auth
 * Converts the entered Student ID into a dummy email behind the scenes
 * Exclusively uses supabase.auth.signInWithPassword({ email: dummyEmail, password })
 * No hardcoded admin or student fallbacks are allowed.
 */
export async function signInWithStudentIdOrAdmin(
  identifier: string,
  plainPassword: string,
  rememberMe: boolean = true
): Promise<SupabaseAuthResult> {
  const cleanInput = (identifier || '').trim();
  const password = plainPassword || '';

  if (!cleanInput || !password.trim()) {
    return {
      success: false,
      message: 'Student ID / Admin User এবং Password লিখুন।',
    };
  }

  // 1. Convert to dummy email behind the scenes
  const dummyEmail = studentIdToDummyEmail(cleanInput);

  try {
    // 2. Exclusively call Supabase Auth signInWithPassword
    const { data, error } = await supabase.auth.signInWithPassword({
      email: dummyEmail,
      password: password,
    });

    // If signIn succeeds
    if (!error && data.user) {
      const userEmail = (data.user.email || dummyEmail).toLowerCase();
      if (userEmail.startsWith('staff') || cleanInput.toLowerCase().startsWith('staff')) {
        const activeCheck = await checkStaffIsActive(userEmail);
        if (!activeCheck.isActive) {
          await logoutUser();
          return {
            success: false,
            message: activeCheck.reason || 'আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।',
            dummyEmailUsed: dummyEmail,
          };
        }
      }

      const session = await buildAuthSessionWithRLS(data.user, data.session?.access_token);
      return {
        success: true,
        session,
        dummyEmailUsed: dummyEmail,
      };
    }

    // Handle signIn error
    const errorMsg = (error?.message || '').toLowerCase();
    const errorCode = (error as any)?.code || '';
    const status = (error as any)?.status;

    // Network errors
    if (
      errorMsg.includes('fetch') ||
      errorMsg.includes('network') ||
      errorMsg.includes('failed to fetch') ||
      status === 0
    ) {
      return {
        success: false,
        message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।',
        dummyEmailUsed: dummyEmail,
      };
    }

    // Auto-Provisioning Flow for Students:
    // If sign in fails because user does not exist (e.g., "Invalid login credentials"),
    // immediately call supabase.auth.signUp to register them on the fly.
    const isUserNotFoundOrInvalidCredentials =
      errorCode === 'invalid_credentials' ||
      errorCode === 'user_not_found' ||
      errorMsg.includes('invalid login credentials') ||
      errorMsg.includes('invalid credentials') ||
      errorMsg.includes('user not found');

    if (isUserNotFoundOrInvalidCredentials) {
      const students = loadStudents();
      const matchedStudent = students.find((s) => {
        if (studentIdToDummyEmail(s.studentIdCode) === dummyEmail.toLowerCase()) return true;
        if (normalizeStudentId(s.studentIdCode) === normalizeStudentId(cleanInput)) return true;
        return false;
      });

      const userMetadata: Record<string, any> = {
        studentIdCode: cleanInput,
        role: cleanInput.toLowerCase() === 'admin' ? 'admin' : 'student',
      };
      if (matchedStudent) {
        userMetadata.name = matchedStudent.name;
        userMetadata.roll = matchedStudent.roll;
        userMetadata.batchId = matchedStudent.batchId;
        userMetadata.academicClass = matchedStudent.academicClass;
        userMetadata.group = matchedStudent.group;
      }

      try {
        const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
          email: dummyEmail,
          password: password,
          options: {
            data: userMetadata,
          },
        });

        if (signUpError) {
          const signUpMsg = (signUpError.message || '').toLowerCase();
          // If already registered, it means user exists but entered wrong password during signIn
          if (signUpMsg.includes('already registered') || signUpMsg.includes('already exists')) {
            return {
              success: false,
              message: 'Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।',
              dummyEmailUsed: dummyEmail,
            };
          }
          if (signUpMsg.includes('fetch') || signUpMsg.includes('network')) {
            return {
              success: false,
              message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।',
              dummyEmailUsed: dummyEmail,
            };
          }
          return {
            success: false,
            message: signUpError.message || 'নিবন্ধন বা লগইন প্রক্রিয়ায় সমস্যা দেখা দিয়েছে।',
            dummyEmailUsed: dummyEmail,
          };
        }

        // When user already exists and email confirmation is on, Supabase returns empty identities array
        if (signUpData?.user && signUpData.user.identities && signUpData.user.identities.length === 0) {
          return {
            success: false,
            message: 'Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।',
            dummyEmailUsed: dummyEmail,
          };
        }

        // If signUp succeeds, the student is successfully logged in and their account is created
        if (signUpData?.user) {
          let activeAccessToken = signUpData.session?.access_token;
          if (!activeAccessToken) {
            // Attempt follow-up signIn to grab active session token
            const { data: retrySignIn } = await supabase.auth.signInWithPassword({
              email: dummyEmail,
              password: password,
            });
            activeAccessToken = retrySignIn?.session?.access_token;
          }

          const session = await buildAuthSessionWithRLS(signUpData.user, activeAccessToken);
          return {
            success: true,
            session,
            dummyEmailUsed: dummyEmail,
          };
        }
      } catch (signUpException: any) {
        console.error('Auto-provisioning signUp error:', signUpException);
        if (signUpException?.message?.includes('fetch')) {
          return {
            success: false,
            message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।',
            dummyEmailUsed: dummyEmail,
          };
        }
      }
    }

    if (errorMsg.includes('email not confirmed')) {
      return {
        success: false,
        message: 'অ্যাকাউন্টের ইমেইল এখনও নিশ্চিত বা সক্রিয় (Confirm) করা হয়নি। শিক্ষকের সাথে যোগাযোগ করুন।',
        dummyEmailUsed: dummyEmail,
      };
    }

    if (status === 429 || errorMsg.includes('rate limit') || errorMsg.includes('too many')) {
      return {
        success: false,
        message: 'অতিরিক্ত বার ভুল চেষ্টা করা হয়েছে। অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন।',
        dummyEmailUsed: dummyEmail,
      };
    }

    return {
      success: false,
      message: error?.message || 'Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় সঠিক তথ্য দিয়ে চেষ্টা করুন।',
      dummyEmailUsed: dummyEmail,
    };
  } catch (err: any) {
    console.error('Supabase signIn exception:', err);
    if (err?.message?.includes('fetch') || err?.name === 'TypeError') {
      return {
        success: false,
        message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। দয়া করে আপনার নেটওয়ার্ক কানেকশন পরীক্ষা করুন।',
        dummyEmailUsed: dummyEmail,
      };
    }
    return {
      success: false,
      message: 'লগইন প্রক্রিয়ায় সমস্যা দেখা দিয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
      dummyEmailUsed: dummyEmail,
    };
  }
}

/**
 * Fetches the active Supabase session directly via supabase.auth.getSession()
 */
export async function getSupabaseAuthSession(): Promise<AuthSession | null> {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session || !session.user) {
      return null;
    }
    return mapSupabaseUserToAuthSession(session.user, session.access_token);
  } catch (err) {
    console.error('Error in getSupabaseAuthSession:', err);
    return null;
  }
}

/**
 * Signs out strictly via supabase.auth.signOut() and clears residual storage
 */
export async function logoutUser(): Promise<void> {
  try {
    await supabase.auth.signOut();
  } catch (err) {
    console.warn('Supabase signOut error:', err);
  } finally {
    try {
      localStorage.removeItem('cp_auth_session_v1');
      sessionStorage.removeItem('cp_auth_session_v1');
      localStorage.removeItem('isAuthenticated');
      sessionStorage.removeItem('isAuthenticated');
      localStorage.removeItem('currentUser');
      sessionStorage.removeItem('currentUser');
      sessionStorage.clear();
    } catch {
      // ignore
    }
  }
}

/**
 * Changes password for the currently logged-in user (Admin or Student)
 * Exclusively uses supabase.auth.updateUser({ password: newPassword }).
 */
export async function updateCurrentUserPassword(
  currentPassword: string,
  newPassword: string,
  confirmPassword: string
): Promise<{ success: boolean; message: string }> {
  const current = (currentPassword || '').trim();
  const next = (newPassword || '').trim();
  const confirm = (confirmPassword || '').trim();

  if (!current || !next || !confirm) {
    return {
      success: false,
      message: 'বর্তমান পাসওয়ার্ড, নতুন পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড প্রদান করুন।',
    };
  }

  if (next.length < 6) {
    return {
      success: false,
      message: 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।',
    };
  }

  if (next !== confirm) {
    return {
      success: false,
      message: 'নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না। পুনরায় যাচাই করুন।',
    };
  }

  if (next === current) {
    return {
      success: false,
      message: 'নতুন পাসওয়ার্ডটি বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।',
    };
  }

  const { data: { session: sbSession }, error: sessErr } = await supabase.auth.getSession();
  if (sessErr || !sbSession || !sbSession.user || !sbSession.user.email) {
    return {
      success: false,
      message: 'আপনার সেশন সমাপ্ত হয়েছে বা পাওয়া যায়নি। অনুগ্রহ করে পুনরায় লগইন করুন।',
    };
  }

  // 1. Verify current password with Supabase
  const { error: testErr } = await supabase.auth.signInWithPassword({
    email: sbSession.user.email,
    password: current,
  });

  if (testErr) {
    return {
      success: false,
      message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়। অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।',
    };
  }

  // 2. Call supabase.auth.updateUser to update the password securely
  try {
    const { error: updateError } = await supabase.auth.updateUser({
      password: next,
    });

    if (updateError) {
      const errMsg = (updateError.message || '').toLowerCase();
      if (errMsg.includes('fetch') || errMsg.includes('network')) {
        return {
          success: false,
          message: 'নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট সংযোগ চেক করে আবার চেষ্টা করুন।',
        };
      }
      if (errMsg.includes('jwt') || errMsg.includes('session') || errMsg.includes('expired')) {
        return {
          success: false,
          message: 'লগইন সেশনের মেয়াদ শেষ হয়েছে। অনুগ্রহ করে আবার লগইন করুন।',
        };
      }
      return {
        success: false,
        message: updateError.message || 'পাসওয়ার্ড আপডেট করতে সমস্যা হয়েছে।',
      };
    }
  } catch (err: any) {
    if (err?.message?.includes('fetch')) {
      return {
        success: false,
        message: 'ইন্টারনেট সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে সংযোগ নিশ্চিত করে আবার চেষ্টা করুন।',
      };
    }
  }

  return {
    success: true,
    message: 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!',
  };
}

/**
 * Admin-assisted Reset feature:
 * Admin can select any student and set a new password for them directly,
 * without needing any OTP, SMS, or the student's current password.
 */
export async function adminAssistedResetStudentPassword(
  studentId: string,
  newPassword: string = '123456'
): Promise<{ success: boolean; message: string }> {
  const cleanPass = (newPassword || '').trim();
  if (!cleanPass) {
    return {
      success: false,
      message: 'পাসওয়ার্ড খালি হতে পারবে না। একটি নতুন পাসওয়ার্ড দিন।',
    };
  }
  if (cleanPass.length < 4) {
    return {
      success: false,
      message: 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।',
    };
  }

  // Directly resets the student's password in the system without requiring OTP, SMS or old password
  const res = await adminResetStudentPassword(studentId, cleanPass);
  return res;
}
