import { Student, StudentAccount, AuthSession, AuthUser } from '../types';
import {
  generateSuggestedStudentId,
  loadStudents,
  normalizeStudentId,
  saveStudents,
} from './storage';

const ACCOUNTS_KEY = 'cp_student_accounts_v1';
const ADMIN_ACCOUNT_KEY = 'cp_admin_account_v1';
const SESSION_KEY = 'cp_auth_session_v1';

// Default initial credentials
export const DEFAULT_STUDENT_PASSWORD = '123456';
export const DEFAULT_ADMIN_USERNAME = 'admin';
export const DEFAULT_ADMIN_PASSWORD = 'admin123';

// Generate cryptographic salt or random string
function generateSalt(): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Secure SHA-256 hash with fallback
export async function hashPassword(password: string, salt: string): Promise<string> {
  const combined = `${password}:::${salt}`;
  if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
    try {
      const msgBuffer = new TextEncoder().encode(combined);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    } catch {
      // Fallback below
    }
  }
  // Robust algorithmic fallback
  let hash = 5381;
  for (let i = 0; i < combined.length; i++) {
    hash = (hash * 33) ^ combined.charCodeAt(i);
  }
  return Math.abs(hash).toString(16).padStart(16, '0');
}

// Generate uniform Student ID format
export function formatStudentIdCode(roll: number, academicClass = 'XI', group = 'B-A'): string {
  return generateSuggestedStudentId(roll, academicClass, group);
}

// Load all student accounts from storage
export function loadStudentAccounts(): StudentAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.error('Failed to load student accounts', err);
  }
  return [];
}

// Save student accounts to storage
export function saveStudentAccounts(accounts: StudentAccount[]): void {
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save student accounts', err);
  }
}

// Ensure every existing student in system has a corresponding account with their admin-controlled ID
export async function syncAndInitializeAccounts(): Promise<StudentAccount[]> {
  const students = loadStudents();
  let accounts = loadStudentAccounts();
  let studentsUpdated = false;
  let accountsUpdated = false;

  const updatedStudents = [...students];

  for (let i = 0; i < updatedStudents.length; i++) {
    const student = updatedStudents[i];
    const effectiveCode = (student.studentIdCode || '').trim() || formatStudentIdCode(student.roll, student.academicClass, student.group);

    if (student.studentIdCode !== effectiveCode) {
      updatedStudents[i] = { ...student, studentIdCode: effectiveCode };
      studentsUpdated = true;
    }

    const existingAcc = accounts.find((a) => a.studentId === student.id);
    if (!existingAcc) {
      const salt = generateSalt();
      const passwordHash = await hashPassword(DEFAULT_STUDENT_PASSWORD, salt);
      const newAcc: StudentAccount = {
        studentId: student.id,
        customStudentId: effectiveCode,
        username: effectiveCode,
        passwordHash,
        salt,
        status: 'active',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      accounts.push(newAcc);
      accountsUpdated = true;
    } else if (existingAcc.customStudentId !== effectiveCode || existingAcc.username !== effectiveCode) {
      existingAcc.customStudentId = effectiveCode;
      existingAcc.username = effectiveCode;
      existingAcc.updatedAt = Date.now();
      accountsUpdated = true;
    }
  }

  // Remove orphan accounts if any students were permanently deleted
  const validIds = new Set(updatedStudents.map((s) => s.id));
  const filteredAccounts = accounts.filter((a) => validIds.has(a.studentId));
  if (filteredAccounts.length !== accounts.length) {
    accounts = filteredAccounts;
    accountsUpdated = true;
  }

  if (studentsUpdated) {
    saveStudents(updatedStudents);
  }
  if (accountsUpdated) {
    saveStudentAccounts(accounts);
  }

  return accounts;
}

// Synchronize student ID change with login credentials & active session
export function syncStudentIdAccount(studentInternalId: string, newStudentIdCode: string): void {
  const cleanNewId = newStudentIdCode.trim();
  const accounts = loadStudentAccounts();
  const acc = accounts.find((a) => a.studentId === studentInternalId);
  if (acc) {
    acc.customStudentId = cleanNewId;
    acc.username = cleanNewId;
    acc.updatedAt = Date.now();
    saveStudentAccounts(accounts);
  }

  // If currently active session belongs to this student, update session in-place
  const currentSess = getCurrentSession();
  if (currentSess && currentSess.user.role === 'student' && currentSess.user.id === studentInternalId) {
    currentSess.user.customStudentId = cleanNewId;
    if (currentSess.user.student) {
      currentSess.user.student.studentIdCode = cleanNewId;
    }
    saveSession(currentSess, currentSess.rememberMe);
  }
}

// Load or initialize admin credentials
export interface AdminConfig {
  username: string;
  name?: string;
  phone?: string;
  email?: string;
  isPhoneVerified?: boolean;
  isEmailVerified?: boolean;
  phoneVerifiedAt?: number;
  emailVerifiedAt?: number;
  recoveryEmail?: string;
  recoveryPhone?: string;
  securityPinHash?: string;
  securityPinSalt?: string;
  twoFactorEnabled?: boolean;
  avatarColor?: string;
  passwordHash: string;
  salt: string;
  updatedAt?: number;
  passwordChangedAt?: number;
}

export interface AdminProfileData {
  username: string;
  name: string;
  phone: string;
  email: string;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  phoneVerifiedAt?: number;
  emailVerifiedAt?: number;
  recoveryEmail: string;
  recoveryPhone: string;
  hasSecurityPin: boolean;
  twoFactorEnabled: boolean;
  avatarColor: string;
  updatedAt?: number;
  passwordChangedAt?: number;
}

// Evaluate Password Strength (Section 11)
export interface PasswordStrengthReport {
  score: number; // 0 - 100
  isValid: boolean;
  errors: string[];
  rules: {
    minLength: boolean;
    hasUpper: boolean;
    hasLower: boolean;
    hasNumber: boolean;
    hasSpecial: boolean;
  };
}

export function evaluatePasswordStrength(password: string): PasswordStrengthReport {
  const p = password || '';
  const minLength = p.length >= 8;
  const hasUpper = /[A-Z]/.test(p);
  const hasLower = /[a-z]/.test(p);
  const hasNumber = /[0-9]/.test(p);
  const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(p);

  const errors: string[] = [];
  if (!minLength) errors.push('কমপক্ষে ৮ অক্ষরের হতে হবে');
  if (!hasUpper) errors.push('কমপক্ষে ১টি বড় হাতের অক্ষর (A-Z) থাকতে হবে');
  if (!hasLower) errors.push('কমপক্ষে ১টি ছোট হাতের অক্ষর (a-z) থাকতে হবে');
  if (!hasNumber) errors.push('কমপক্ষে ১টি সংখ্যা (0-9) থাকতে হবে');
  if (!hasSpecial) errors.push('কমপক্ষে ১টি বিশেষ চিহ্ন (!@#$%^&*) থাকতে হবে');

  const count = [minLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  const score = Math.round((count / 5) * 100);

  return {
    score,
    isValid: count === 5,
    errors,
    rules: { minLength, hasUpper, hasLower, hasNumber, hasSpecial },
  };
}

// Universal API helper for Netlify standalone static SPA mode
// (Express server routes /api/auth/* are removed so the frontend compiles cleanly as 100% standalone SPA)
async function callAuthApi<T = any>(_endpoint: string, _options?: RequestInit): Promise<T | null> {
  return null;
}

// Server Provider Config and Test Helpers
export async function getServerProviderStatus(): Promise<any> {
  return await callAuthApi('/status');
}

export async function updateServerProviderConfig(config: { sms?: any; email?: any }): Promise<any> {
  return await callAuthApi('/config-providers', {
    method: 'POST',
    body: JSON.stringify(config),
  });
}

export async function testServerProvider(type: 'mobile' | 'email', target: string): Promise<any> {
  return await callAuthApi('/test-provider', {
    method: 'POST',
    body: JSON.stringify({ type, target }),
  });
}

// Phone & Email Validation Helpers
export function normalizeBangladeshiPhone(input: string): string {
  if (!input) return '';
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let converted = input.trim();
  for (let i = 0; i < 10; i++) {
    converted = converted.replaceAll(bengaliDigits[i], i.toString());
  }
  let cleaned = converted.replace(/[\s\-()]/g, '');
  if (cleaned.startsWith('+880')) {
    cleaned = cleaned.slice(3);
  } else if (cleaned.startsWith('+88')) {
    cleaned = cleaned.slice(3);
  } else if (cleaned.startsWith('880')) {
    cleaned = cleaned.slice(2);
  }
  return cleaned;
}

export function validateBangladeshiPhone(phone: string): { isValid: boolean; normalized: string; error?: string } {
  const trimmed = (phone || '').trim();
  if (!trimmed) {
    return { isValid: false, normalized: '', error: 'মোবাইল নম্বর লিখুন।' };
  }
  const normalized = normalizeBangladeshiPhone(trimmed);
  // Valid Bangladeshi format: 11 digits starting with 013, 014, 015, 016, 017, 018, 019
  const bdRegex = /^01[3-9]\d{8}$/;
  if (!bdRegex.test(normalized)) {
    return {
      isValid: false,
      normalized,
      error: 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX, 018XXXXXXXX, মোট ১১ ডিজিট)।',
    };
  }
  return { isValid: true, normalized };
}

export function validateEmailAddress(email: string): { isValid: boolean; normalized: string; error?: string } {
  const normalized = (email || '').trim().toLowerCase();
  if (!normalized) {
    return { isValid: false, normalized: '', error: 'ইমেইল ঠিকানা লিখুন।' };
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(normalized)) {
    return { isValid: false, normalized, error: 'সঠিক ইমেইল ফরম্যাট দিন (যেমন: user@example.com)।' };
  }
  return { isValid: true, normalized };
}

export async function getAdminConfig(): Promise<AdminConfig> {
  try {
    const raw = localStorage.getItem(ADMIN_ACCOUNT_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.username && parsed.passwordHash && parsed.salt) {
        return parsed;
      }
    }
  } catch {
    // fallback
  }
  const salt = generateSalt();
  const passwordHash = await hashPassword(DEFAULT_ADMIN_PASSWORD, salt);
  const config: AdminConfig = {
    username: DEFAULT_ADMIN_USERNAME,
    name: 'আইসিটি শিক্ষক / Admin',
    phone: '',
    email: '',
    isPhoneVerified: false,
    isEmailVerified: false,
    recoveryEmail: '',
    recoveryPhone: '',
    twoFactorEnabled: false,
    avatarColor: 'indigo',
    passwordHash,
    salt,
    updatedAt: Date.now(),
    passwordChangedAt: Date.now(),
  };
  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));
  return config;
}

// Get admin profile for UI
export async function getAdminProfile(): Promise<AdminProfileData> {
  const config = await getAdminConfig();
  return {
    username: config.username || DEFAULT_ADMIN_USERNAME,
    name: config.name || 'আইসিটি শিক্ষক / Admin',
    phone: config.phone || '',
    email: config.email || '',
    isPhoneVerified: !!config.isPhoneVerified,
    isEmailVerified: !!config.isEmailVerified,
    phoneVerifiedAt: config.phoneVerifiedAt,
    emailVerifiedAt: config.emailVerifiedAt,
    recoveryEmail: config.recoveryEmail || '',
    recoveryPhone: config.recoveryPhone || '',
    hasSecurityPin: !!config.securityPinHash,
    twoFactorEnabled: !!config.twoFactorEnabled,
    avatarColor: config.avatarColor || 'indigo',
    updatedAt: config.updatedAt,
    passwordChangedAt: config.passwordChangedAt,
  };
}

// Admin / Teacher change own password
export async function changeAdminPassword(
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; message: string }> {
  if (!currentPassword || !currentPassword.trim()) {
    return { success: false, message: 'অনুগ্রহ করে বর্তমান পাসওয়ার্ডটি প্রদান করুন।' };
  }

  // Section 11: Password Security Requirements
  const strength = evaluatePasswordStrength(newPassword);
  if (!strength.isValid) {
    return {
      success: false,
      message: `নতুন পাসওয়ার্ড শর্তাবলী পূরণ করেনি: ${strength.errors.join(', ')}`,
    };
  }

  if (newPassword === currentPassword) {
    return { success: false, message: 'নতুন পাসওয়ার্ড অবশ্যই বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।' };
  }

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{ success: boolean; message: string }>('/change-password', {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newPassword }),
  });

  const config = await getAdminConfig();
  const currentComputed = await hashPassword(currentPassword, config.salt);
  if (currentComputed !== config.passwordHash) {
    return { success: false, message: 'বর্তমান পাসওয়ার্ডটি সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।' };
  }

  const newSalt = generateSalt();
  const newHash = await hashPassword(newPassword, newSalt);

  config.passwordHash = newHash;
  config.salt = newSalt;
  config.passwordChangedAt = Date.now();
  config.updatedAt = Date.now();

  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

  // Refresh active session token for security
  const sess = getCurrentSession();
  if (sess && sess.user.role === 'admin') {
    sess.token = `adm_sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    saveSession(sess, sess.rememberMe);
  }

  return {
    success: true,
    message: apiRes?.message || '✓ এডমিন পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে।',
  };
}

// Admin / Teacher update profile and username
export async function updateAdminProfile(data: {
  username: string;
  name: string;
  phone?: string;
  email?: string;
  recoveryEmail?: string;
  recoveryPhone?: string;
  avatarColor?: string;
  twoFactorEnabled?: boolean;
}): Promise<{ success: boolean; message: string; updatedUser?: AuthUser }> {
  const cleanUsername = (data.username || '').trim();
  const cleanName = (data.name || '').trim();

  if (!cleanUsername || cleanUsername.length < 3) {
    return { success: false, message: 'লগইন ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে।' };
  }
  if (!cleanName) {
    return { success: false, message: 'শিক্ষকের নাম খালি রাখা যাবে না।' };
  }

  let validatedPhone = '';
  if (data.phone && data.phone.trim()) {
    const phoneCheck = validateBangladeshiPhone(data.phone);
    if (!phoneCheck.isValid) {
      return { success: false, message: phoneCheck.error || 'ভুল মোবাইল নম্বর ফরম্যাট।' };
    }
    validatedPhone = phoneCheck.normalized;
  }

  let validatedEmail = '';
  if (data.email && data.email.trim()) {
    const emailCheck = validateEmailAddress(data.email);
    if (!emailCheck.isValid) {
      return { success: false, message: emailCheck.error || 'ভুল ইমেইল ফরম্যাট।' };
    }
    validatedEmail = emailCheck.normalized;
  }

  let validatedRecoveryPhone = '';
  if (data.recoveryPhone && data.recoveryPhone.trim()) {
    const recPhoneCheck = validateBangladeshiPhone(data.recoveryPhone);
    if (!recPhoneCheck.isValid) {
      return { success: false, message: 'রিকভারি মোবাইল: ' + (recPhoneCheck.error || 'ভুল ফরম্যাট।') };
    }
    validatedRecoveryPhone = recPhoneCheck.normalized;
  }

  let validatedRecoveryEmail = '';
  if (data.recoveryEmail && data.recoveryEmail.trim()) {
    const recEmailCheck = validateEmailAddress(data.recoveryEmail);
    if (!recEmailCheck.isValid) {
      return { success: false, message: 'রিকভারি ইমেইল: ' + (recEmailCheck.error || 'ভুল ফরম্যাট।') };
    }
    validatedRecoveryEmail = recEmailCheck.normalized;
  }

  const config = await getAdminConfig();

  // If phone changed, reset phone verification status
  if (validatedPhone && validatedPhone !== config.phone) {
    config.isPhoneVerified = false;
    config.phoneVerifiedAt = undefined;
  }
  // If email changed, reset email verification status
  if (validatedEmail && validatedEmail !== config.email) {
    config.isEmailVerified = false;
    config.emailVerifiedAt = undefined;
  }

  config.username = cleanUsername;
  config.name = cleanName;
  config.phone = validatedPhone;
  config.email = validatedEmail;
  config.recoveryEmail = validatedRecoveryEmail;
  config.recoveryPhone = validatedRecoveryPhone;
  if (data.avatarColor) config.avatarColor = data.avatarColor;
  if (data.twoFactorEnabled !== undefined) config.twoFactorEnabled = data.twoFactorEnabled;
  config.updatedAt = Date.now();

  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

  // Update session if currently logged in as admin
  const sess = getCurrentSession();
  let updatedUser: AuthUser | undefined;
  if (sess && sess.user.role === 'admin') {
    sess.user.name = cleanName;
    sess.user.username = cleanUsername;
    saveSession(sess, sess.rememberMe);
    updatedUser = sess.user;
  }

  // Call server API to keep serverAdmin state synced
  callAuthApi('/update-profile', {
    method: 'POST',
    body: JSON.stringify({
      name: cleanName,
      username: cleanUsername,
      phone: validatedPhone,
      email: validatedEmail,
    }),
  }).catch(() => null);

  return {
    success: true,
    message: '✓ প্রোফাইল ও অ্যাকাউন্ট তথ্য সফলভাবে ডেটাবেজে সংরক্ষিত হয়েছে।',
    updatedUser,
  };
}

// Reset admin credentials to factory default (admin / admin123)
export async function resetAdminAccountToDefault(): Promise<{ success: boolean; message: string }> {
  const salt = generateSalt();
  const passwordHash = await hashPassword(DEFAULT_ADMIN_PASSWORD, salt);
  const config: AdminConfig = {
    username: DEFAULT_ADMIN_USERNAME,
    name: 'আইসিটি শিক্ষক / Admin',
    phone: '',
    email: '',
    passwordHash,
    salt,
    updatedAt: Date.now(),
    passwordChangedAt: Date.now(),
  };
  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

  // Update session if currently active
  const sess = getCurrentSession();
  if (sess && sess.user.role === 'admin') {
    sess.user.name = config.name || 'আইসিটি শিক্ষক / Admin';
    saveSession(sess, sess.rememberMe);
  }

  return {
    success: true,
    message: `এডমিন অ্যাকাউন্ট সফলভাবে ডিফল্ট সেটিংসে রিসেট করা হয়েছে (ইউজারনেম: "${DEFAULT_ADMIN_USERNAME}", পাসওয়ার্ড: "${DEFAULT_ADMIN_PASSWORD}")।`,
  };
}

// ---------------------------------------------------------------------------
// OTP & Account Verification System (Phone, Email & Password Recovery)
// ---------------------------------------------------------------------------
const OTP_STORAGE_KEY = 'cp_active_otp_sessions_v1';

interface ActiveOtpRecord {
  type: 'phone_verify' | 'email_verify' | 'password_recovery';
  target: string;
  code: string;
  expiresAt: number;
  attempts: number;
  resetToken?: string;
  role?: 'admin' | 'student';
  studentInternalId?: string;
}

function loadOtpRecords(): ActiveOtpRecord[] {
  try {
    const raw = sessionStorage.getItem(OTP_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // filter out expired
        const now = Date.now();
        return parsed.filter((r: ActiveOtpRecord) => r.expiresAt > now);
      }
    }
  } catch {
    // ignore
  }
  return [];
}

function saveOtpRecords(records: ActiveOtpRecord[]): void {
  try {
    const now = Date.now();
    const valid = records.filter((r) => r.expiresAt > now);
    sessionStorage.setItem(OTP_STORAGE_KEY, JSON.stringify(valid));
  } catch {
    // ignore
  }
}

export function maskPhoneNumber(phone: string): string {
  const clean = normalizeBangladeshiPhone(phone);
  if (clean.length < 8) return clean;
  return clean.slice(0, 3) + '*****' + clean.slice(-3);
}

export function maskEmailAddress(email: string): string {
  const parts = email.split('@');
  if (parts.length !== 2) return email;
  const name = parts[0];
  const domain = parts[1];
  const maskedName = name.length <= 2 ? name[0] + '*' : name[0] + '***' + name.slice(-1);
  return `${maskedName}@${domain}`;
}

// Admin: Send Mobile OTP (Section 3 & 4)
export async function sendAdminPhoneVerificationOtp(phoneInput?: string): Promise<{
  success: boolean;
  message: string;
  maskedPhone?: string;
  simulationCode?: string;
  waitSeconds?: number;
}> {
  const config = await getAdminConfig();
  const phoneToUse = phoneInput && phoneInput.trim() ? phoneInput.trim() : config.phone;

  if (!phoneToUse || !phoneToUse.trim()) {
    return { success: false, message: 'প্রথমে একটি বৈধ মোবাইল নম্বর যুক্ত করুন।' };
  }

  const phoneCheck = validateBangladeshiPhone(phoneToUse);
  if (!phoneCheck.isValid) {
    return { success: false, message: phoneCheck.error || 'ভুল মোবাইল নম্বর।' };
  }

  const normPhone = phoneCheck.normalized;

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{
    success: boolean;
    message: string;
    expiresAt?: number;
    isSimulated?: boolean;
    simulationCode?: string;
    waitSeconds?: number;
  }>('/send-otp', {
    method: 'POST',
    body: JSON.stringify({
      type: 'mobile',
      target: normPhone,
      purpose: 'admin_verify',
    }),
  });

  if (apiRes) {
    if (!apiRes.success) {
      return {
        success: false,
        message: apiRes.message,
        waitSeconds: apiRes.waitSeconds,
      };
    }

    return {
      success: true,
      message: apiRes.message || `ভেরিফিকেশন কোড পাঠানো হয়েছে (${maskPhoneNumber(normPhone)}) নম্বরে। কোডের মেয়াদ ৫ মিনিট।`,
      maskedPhone: maskPhoneNumber(normPhone),
      simulationCode: apiRes.simulationCode,
    };
  }

  // Fallback to local OTP generator
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const records = loadOtpRecords().filter((r) => r.type !== 'phone_verify');
  records.push({
    type: 'phone_verify',
    target: normPhone,
    code,
    expiresAt: Date.now() + 5 * 60 * 1000,
    attempts: 0,
    role: 'admin',
  });
  saveOtpRecords(records);

  return {
    success: true,
    message: `ভেরিফিকেশন কোড পাঠানো হয়েছে (${maskPhoneNumber(normPhone)}) নম্বরে। কোডের মেয়াদ ৫ মিনিট।`,
    maskedPhone: maskPhoneNumber(normPhone),
    simulationCode: code,
  };
}

// Admin: Verify Mobile OTP (Section 3)
export async function verifyAdminPhoneOtp(
  code: string,
  phoneInput?: string
): Promise<{ success: boolean; message: string }> {
  const cleanCode = (code || '').trim();
  if (!cleanCode || cleanCode.length < 4) {
    return { success: false, message: 'অনুগ্রহ করে সঠিক ভেরিফিকেশন কোড দিন।' };
  }

  const config = await getAdminConfig();
  const targetPhone = phoneInput ? normalizeBangladeshiPhone(phoneInput) : config.phone;

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{ success: boolean; message: string }>('/verify-otp', {
    method: 'POST',
    body: JSON.stringify({
      type: 'mobile',
      target: targetPhone,
      code: cleanCode,
      purpose: 'admin_verify',
    }),
  });

  if (apiRes) {
    if (apiRes.success) {
      config.isPhoneVerified = true;
      config.phoneVerifiedAt = Date.now();
      config.updatedAt = Date.now();
      localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));
    }
    return apiRes;
  }

  // Local fallback
  const records = loadOtpRecords();
  const index = records.findIndex((r) => r.type === 'phone_verify');
  if (index === -1) {
    return { success: false, message: 'কোনো সক্রিয় ভেরিফিকেশন কোড পাওয়া যায়নি বা মেয়াদ উত্তীর্ণ হয়েছে। পুনরায় কোড পাঠান।' };
  }

  const record = records[index];
  if (record.attempts >= 5) {
    records.splice(index, 1);
    saveOtpRecords(records);
    return { success: false, message: 'অতিরিক্ত ভুল চেষ্টার কারণে কোডটি বাতিল হয়েছে। নতুন কোডের অনুরোধ করুন।' };
  }

  if (record.code !== cleanCode) {
    record.attempts += 1;
    saveOtpRecords(records);
    return { success: false, message: `ভুল কোড! আপনার আর ${5 - record.attempts} বার চেষ্টা বাকি রয়েছে।` };
  }

  records.splice(index, 1);
  saveOtpRecords(records);

  config.isPhoneVerified = true;
  config.phoneVerifiedAt = Date.now();
  config.updatedAt = Date.now();
  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

  return { success: true, message: '✓ মোবাইল নম্বর সফলভাবে ভেরিফাই ও ডেটাবেজে সংরক্ষিত হয়েছে।' };
}

// Admin: Send Email OTP (Section 2 & 5)
export async function sendAdminEmailVerificationOtp(emailInput?: string): Promise<{
  success: boolean;
  message: string;
  maskedEmail?: string;
  simulationCode?: string;
  waitSeconds?: number;
}> {
  const config = await getAdminConfig();
  const emailToUse = emailInput && emailInput.trim() ? emailInput.trim() : config.email;

  if (!emailToUse || !emailToUse.trim()) {
    return { success: false, message: 'প্রথমে একটি বৈধ ইমেইল ঠিকানা যুক্ত করুন।' };
  }

  const emailCheck = validateEmailAddress(emailToUse);
  if (!emailCheck.isValid) {
    return { success: false, message: emailCheck.error || 'ভুল ইমেইল ঠিকানা।' };
  }

  const normEmail = emailCheck.normalized;

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{
    success: boolean;
    message: string;
    expiresAt?: number;
    isSimulated?: boolean;
    simulationCode?: string;
    waitSeconds?: number;
  }>('/send-otp', {
    method: 'POST',
    body: JSON.stringify({
      type: 'email',
      target: normEmail,
      purpose: 'admin_verify',
    }),
  });

  if (apiRes) {
    if (!apiRes.success) {
      return {
        success: false,
        message: apiRes.message,
        waitSeconds: apiRes.waitSeconds,
      };
    }

    return {
      success: true,
      message: apiRes.message || `ভেরিফিকেশন কোড পাঠানো হয়েছে (${maskEmailAddress(normEmail)}) ইমেইলে।`,
      maskedEmail: maskEmailAddress(normEmail),
      simulationCode: apiRes.simulationCode,
    };
  }

  // Local fallback
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const records = loadOtpRecords().filter((r) => r.type !== 'email_verify');
  records.push({
    type: 'email_verify',
    target: normEmail,
    code,
    expiresAt: Date.now() + 5 * 60 * 1000,
    attempts: 0,
    role: 'admin',
  });
  saveOtpRecords(records);

  return {
    success: true,
    message: `ভেরিফিকেশন কোড পাঠানো হয়েছে (${maskEmailAddress(normEmail)}) ইমেইলে।`,
    maskedEmail: maskEmailAddress(normEmail),
    simulationCode: code,
  };
}

// Admin: Verify Email OTP (Section 2)
export async function verifyAdminEmailOtp(
  code: string,
  emailInput?: string
): Promise<{ success: boolean; message: string }> {
  const cleanCode = (code || '').trim();
  if (!cleanCode || cleanCode.length < 4) {
    return { success: false, message: 'অনুগ্রহ করে সঠিক ভেরিফিকেশন কোড দিন।' };
  }

  const config = await getAdminConfig();
  const targetEmail = emailInput ? emailInput.trim().toLowerCase() : config.email;

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{ success: boolean; message: string }>('/verify-otp', {
    method: 'POST',
    body: JSON.stringify({
      type: 'email',
      target: targetEmail,
      code: cleanCode,
      purpose: 'admin_verify',
    }),
  });

  if (apiRes) {
    if (apiRes.success) {
      config.isEmailVerified = true;
      config.emailVerifiedAt = Date.now();
      config.updatedAt = Date.now();
      localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));
    }
    return apiRes;
  }

  // Local fallback
  const records = loadOtpRecords();
  const index = records.findIndex((r) => r.type === 'email_verify');
  if (index === -1) {
    return { success: false, message: 'কোনো সক্রিয় ইমেইল ভেরিফিকেশন কোড পাওয়া যায়নি বা মেয়াদ উত্তীর্ণ হয়েছে।' };
  }

  const record = records[index];
  if (record.attempts >= 5) {
    records.splice(index, 1);
    saveOtpRecords(records);
    return { success: false, message: 'অতিরিক্ত ভুল চেষ্টার কারণে কোডটি বাতিল হয়েছে।' };
  }

  if (record.code !== cleanCode) {
    record.attempts += 1;
    saveOtpRecords(records);
    return { success: false, message: `ভুল কোড! আর ${5 - record.attempts} বার চেষ্টা বাকি রয়েছে।` };
  }

  records.splice(index, 1);
  saveOtpRecords(records);

  config.isEmailVerified = true;
  config.emailVerifiedAt = Date.now();
  config.updatedAt = Date.now();
  localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

  return { success: true, message: '✓ ইমেইল ঠিকানা সফলভাবে ভেরিফাই ও নিশ্চিত করা হয়েছে।' };
}

// Revoke other active sessions
export async function revokeOtherSessions(): Promise<{ success: boolean; message: string }> {
  const sess = getCurrentSession();
  if (!sess) return { success: false, message: 'সক্রিয় সেশন পাওয়া যায়নি।' };

  sess.token = `${sess.user.role}_sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  saveSession(sess, sess.rememberMe);

  return {
    success: true,
    message: '✓ অন্যান্য সকল ডিভাইসের সেশন বাতিল করা হয়েছে। বর্তমান ডিভাইসটি সক্রিয় রয়েছে।',
  };
}

// ---------------------------------------------------------------------------
// Forgot Password / Password Recovery Flow (Section 9, 10, 11, 12)
// ---------------------------------------------------------------------------
export async function requestPasswordRecovery(
  rawIdentifier: string,
  preferredRole?: 'admin' | 'student'
): Promise<{
  success: boolean;
  message: string;
  targetRole?: 'admin' | 'student';
  targetType?: 'email' | 'mobile';
  maskedTarget?: string;
  simulationCode?: string;
  identifier?: string;
  targetContact?: string;
  waitSeconds?: number;
}> {
  const input = (rawIdentifier || '').trim();
  if (!input) {
    return { success: false, message: 'অনুগ্রহ করে ইউজারনেম, স্টুডেন্ট আইডি, ইমেইল বা মোবাইল নম্বর দিন।' };
  }

  const cleanPhone = normalizeBangladeshiPhone(input);
  const cleanEmail = input.toLowerCase();
  const normalizedId = normalizeStudentId(input);

  // 1. Check if matches Admin
  const adminConfig = await getAdminConfig();
  const isInputEmail = cleanEmail.includes('@');
  const isInputPhone = !!cleanPhone && cleanPhone.startsWith('01');

  const adminMatches =
    input.toLowerCase() === (adminConfig.username || DEFAULT_ADMIN_USERNAME).toLowerCase() ||
    (cleanEmail && adminConfig.email && cleanEmail === adminConfig.email.toLowerCase()) ||
    (cleanPhone && adminConfig.phone && cleanPhone === adminConfig.phone) ||
    (cleanPhone && adminConfig.recoveryPhone && cleanPhone === adminConfig.recoveryPhone) ||
    (cleanEmail && adminConfig.recoveryEmail && cleanEmail === adminConfig.recoveryEmail.toLowerCase());

  if (preferredRole === 'admin' || (adminMatches && preferredRole !== 'student')) {
    // Choose recovery contact: prioritize the one typed or verified
    let targetType: 'email' | 'mobile' = 'mobile';
    let contactTarget = adminConfig.phone;

    if (isInputEmail && adminConfig.email) {
      targetType = 'email';
      contactTarget = adminConfig.email;
    } else if (isInputPhone && adminConfig.phone) {
      targetType = 'mobile';
      contactTarget = adminConfig.phone;
    } else if (adminConfig.isEmailVerified && adminConfig.email) {
      targetType = 'email';
      contactTarget = adminConfig.email;
    } else if (adminConfig.isPhoneVerified && adminConfig.phone) {
      targetType = 'mobile';
      contactTarget = adminConfig.phone;
    } else if (adminConfig.phone) {
      targetType = 'mobile';
      contactTarget = adminConfig.phone;
    } else if (adminConfig.email) {
      targetType = 'email';
      contactTarget = adminConfig.email;
    }

    const maskedContact = targetType === 'email'
      ? (contactTarget ? maskEmailAddress(contactTarget) : 'ইমেইল ঠিকানা')
      : (contactTarget ? maskPhoneNumber(contactTarget) : 'মোবাইল নম্বর');

    // Call server API
    if (contactTarget) {
      const apiRes = await callAuthApi<{
        success: boolean;
        message: string;
        simulationCode?: string;
        waitSeconds?: number;
      }>('/send-otp', {
        method: 'POST',
        body: JSON.stringify({
          type: targetType,
          target: contactTarget,
          purpose: 'recovery',
        }),
      });

      if (apiRes) {
        if (!apiRes.success && apiRes.waitSeconds) {
          return {
            success: false,
            message: apiRes.message,
            waitSeconds: apiRes.waitSeconds,
          };
        }

        // Section 10: Generic message to prevent account enumeration
        return {
          success: true,
          message: 'যদি এই তথ্যের সাথে কোনো account যুক্ত থাকে, তাহলে verification code পাঠানো হয়েছে।',
          targetRole: 'admin',
          targetType,
          maskedTarget: maskedContact,
          targetContact: contactTarget,
          simulationCode: apiRes.simulationCode,
          identifier: adminConfig.username,
        };
      }
    }

    // Local fallback
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const records = loadOtpRecords().filter((r) => r.type !== 'password_recovery' || r.role !== 'admin');
    records.push({
      type: 'password_recovery',
      target: contactTarget || input,
      code,
      expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
      attempts: 0,
      role: 'admin',
    });
    saveOtpRecords(records);

    return {
      success: true,
      message: 'যদি এই তথ্যের সাথে কোনো account যুক্ত থাকে, তাহলে verification code পাঠানো হয়েছে।',
      targetRole: 'admin',
      targetType,
      maskedTarget: maskedContact,
      targetContact: contactTarget,
      simulationCode: code,
      identifier: adminConfig.username,
    };
  }

  // 2. Check if matches Student
  await syncAndInitializeAccounts();
  const accounts = loadStudentAccounts();
  const students = loadStudents();

  const matchingAccount = accounts.find((a) => {
    if (normalizeStudentId(a.customStudentId) === normalizedId) return true;
    if (normalizeStudentId(a.username) === normalizedId) return true;
    const st = students.find((s) => s.id === a.studentId);
    if (st) {
      if (normalizeStudentId(st.studentIdCode) === normalizedId) return true;
      if (cleanPhone && st.mobile && normalizeBangladeshiPhone(st.mobile) === cleanPhone) return true;
      if (cleanEmail && st.email && st.email.toLowerCase() === cleanEmail) return true;
      const asNum = parseInt(normalizedId, 10);
      if (!isNaN(asNum) && st.roll === asNum) return true;
    }
    return false;
  });

  if (!matchingAccount) {
    // Section 10: Generic response even on mismatch
    return {
      success: false,
      message: 'যদি এই তথ্যের সাথে কোনো account যুক্ত থাকে, তাহলে verification code পাঠানো হয়েছে।',
    };
  }

  const student = students.find((s) => s.id === matchingAccount.studentId);
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const records = loadOtpRecords().filter((r) => r.type !== 'password_recovery' || r.role !== 'student');

  const contactInfo = student?.mobile
    ? maskPhoneNumber(student.mobile)
    : student?.email
    ? maskEmailAddress(student.email)
    : `শিক্ষার্থী (${student?.name || matchingAccount.customStudentId})`;

  records.push({
    type: 'password_recovery',
    target: matchingAccount.customStudentId,
    code,
    expiresAt: Date.now() + 5 * 60 * 1000,
    attempts: 0,
    role: 'student',
    studentInternalId: matchingAccount.studentId,
  });
  saveOtpRecords(records);

  return {
    success: true,
    message: `শিক্ষার্থী ${student?.name || ''}-এর জন্য রিকভারি কোড তৈরি হয়েছে (${contactInfo})।`,
    targetRole: 'student',
    maskedTarget: contactInfo,
    simulationCode: code,
    identifier: matchingAccount.customStudentId,
  };
}

// Verify Recovery Code (Section 9 & 12)
export async function verifyPasswordRecoveryCode(
  identifier: string,
  code: string,
  targetContact?: string,
  targetType?: 'email' | 'mobile'
): Promise<{ success: boolean; message: string; resetToken?: string; role?: 'admin' | 'student' }> {
  const cleanCode = (code || '').trim();
  if (!cleanCode || cleanCode.length < 4) {
    return { success: false, message: 'অনুগ্রহ করে সঠিক রিকভারি কোড দিন।' };
  }

  const contactToUse = targetContact || identifier;
  const typeToUse = targetType || (contactToUse.includes('@') ? 'email' : 'mobile');

  // 1. Check Server API
  const apiRes = await callAuthApi<{
    success: boolean;
    message: string;
    resetToken?: string;
  }>('/verify-otp', {
    method: 'POST',
    body: JSON.stringify({
      type: typeToUse,
      target: contactToUse,
      code: cleanCode,
      purpose: 'recovery',
    }),
  });

  if (apiRes) {
    if (apiRes.success && apiRes.resetToken) {
      return {
        success: true,
        message: apiRes.message || '✓ রিকভারি কোড সফলভাবে যাচাই হয়েছে। এবার নতুন পাসওয়ার্ড নির্ধারণ করুন।',
        resetToken: apiRes.resetToken,
        role: 'admin',
      };
    }
    return {
      success: false,
      message: apiRes.message || 'ভুল রিকভারি কোড।',
    };
  }

  // Local fallback
  const records = loadOtpRecords();
  const index = records.findIndex((r) => r.type === 'password_recovery');
  if (index === -1) {
    return {
      success: false,
      message: 'কোনো রিকভারি রিকোয়েস্ট পাওয়া যায়নি বা ৫ মিনিটের মেয়াদ শেষ হয়েছে। পুনরায় চেষ্টা করুন।',
    };
  }

  const record = records[index];
  if (record.attempts >= 5) {
    records.splice(index, 1);
    saveOtpRecords(records);
    return { success: false, message: 'অতিরিক্ত ভুল কোড প্রবেশের কারণে রিকোয়েস্ট বাতিল করা হয়েছে।' };
  }

  if (record.code !== cleanCode) {
    record.attempts += 1;
    saveOtpRecords(records);
    return { success: false, message: `ভুল রিকভারি কোড! অবশিষ্ট চেষ্টা: ${5 - record.attempts} বার।` };
  }

  // Generate secure single-use resetToken
  const resetToken = `rst_${generateSalt()}_${Date.now()}`;
  record.resetToken = resetToken;
  record.expiresAt = Date.now() + 15 * 60 * 1000;
  saveOtpRecords(records);

  return {
    success: true,
    message: '✓ রিকভারি কোড সফলভাবে যাচাই হয়েছে। এবার নতুন পাসওয়ার্ড নির্ধারণ করুন।',
    resetToken,
    role: record.role,
  };
}

// Complete Password Reset with Verified Token (Section 9, 11 & 12)
export async function resetPasswordWithToken(
  resetToken: string,
  newPassword: string
): Promise<{ success: boolean; message: string }> {
  // Validate Password Complexity (Section 11)
  const strength = evaluatePasswordStrength(newPassword);
  if (!strength.isValid) {
    return {
      success: false,
      message: `পাসওয়ার্ড শর্তাবলী পূরণ করেনি: ${strength.errors.join(', ')}`,
    };
  }

  // 1. Call Backend Server API
  const apiRes = await callAuthApi<{ success: boolean; message: string }>('/reset-password', {
    method: 'POST',
    body: JSON.stringify({ resetToken, newPassword }),
  });

  if (apiRes) {
    if (apiRes.success) {
      // Also update local cache
      const config = await getAdminConfig();
      const newSalt = generateSalt();
      config.salt = newSalt;
      config.passwordHash = await hashPassword(newPassword, newSalt);
      config.passwordChangedAt = Date.now();
      config.updatedAt = Date.now();
      localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));
    }
    return apiRes;
  }

  // Local fallback
  const records = loadOtpRecords();
  const index = records.findIndex((r) => r.type === 'password_recovery' && r.resetToken === resetToken);
  if (index === -1) {
    return { success: false, message: 'পাসওয়ার্ড রিসেট টোকেনটি অবৈধ বা মেয়াদোত্তীর্ণ। অনুগ্রহ করে আবার শুরু করুন।' };
  }

  const record = records[index];
  if (record.role === 'admin') {
    const config = await getAdminConfig();
    const newSalt = generateSalt();
    const newHash = await hashPassword(newPassword, newSalt);

    config.passwordHash = newHash;
    config.salt = newSalt;
    config.passwordChangedAt = Date.now();
    config.updatedAt = Date.now();
    localStorage.setItem(ADMIN_ACCOUNT_KEY, JSON.stringify(config));

    // Clear record
    records.splice(index, 1);
    saveOtpRecords(records);

    return {
      success: true,
      message: '✓ শিক্ষক / এডমিন পাসওয়ার্ড সফলভাবে রিসেট হয়েছে! নতুন পাসওয়ার্ড দিয়ে লগইন করুন।',
    };
  } else {
    // Student reset
    const accounts = loadStudentAccounts();
    const account = accounts.find((a) => a.studentId === record.studentInternalId || a.customStudentId === record.target);
    if (!account) {
      return { success: false, message: 'স্টুডেন্ট অ্যাকাউন্ট পাওয়া যায়নি।' };
    }

    const newSalt = generateSalt();
    const newHash = await hashPassword(newPassword, newSalt);

    account.passwordHash = newHash;
    account.salt = newSalt;
    account.updatedAt = Date.now();
    saveStudentAccounts(accounts);

    records.splice(index, 1);
    saveOtpRecords(records);

    return {
      success: true,
      message: '✓ আপনার শিক্ষার্থী পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে! নতুন পাসওয়ার্ড দিয়ে লগইন করুন।',
    };
  }
}


// Student Login Verification
export interface LoginResult {
  success: boolean;
  message?: string;
  session?: AuthSession;
}

export async function loginStudent(
  idOrUsername: string,
  plainPassword: string,
  rememberMe: boolean = true
): Promise<LoginResult> {
  const cleanedInput = normalizeStudentId(idOrUsername);
  if (!cleanedInput || !plainPassword.trim()) {
    return { success: false, message: 'Student ID অথবা Password সঠিক নয়।' };
  }

  await syncAndInitializeAccounts();
  const accounts = loadStudentAccounts();
  const students = loadStudents();

  // Match by customStudentId, username, or student's studentIdCode (case-insensitive & trimmed)
  const account = accounts.find((a) => {
    if (normalizeStudentId(a.customStudentId) === cleanedInput) return true;
    if (normalizeStudentId(a.username) === cleanedInput) return true;
    const matchingStudent = students.find((s) => s.id === a.studentId);
    if (matchingStudent && normalizeStudentId(matchingStudent.studentIdCode) === cleanedInput) return true;
    // Also match numeric roll if typed e.g. 1
    const asNum = parseInt(cleanedInput, 10);
    if (!isNaN(asNum) && matchingStudent && matchingStudent.roll === asNum) return true;
    return false;
  });

  if (!account) {
    return { success: false, message: 'Student ID অথবা Password সঠিক নয়।' };
  }

  if (account.status !== 'active') {
    return {
      success: false,
      message: 'আপনার অ্যাকাউন্টটি নিষ্ক্রিয় করা হয়েছে। অনুগ্রহ করে শিক্ষকের সাথে যোগাযোগ করুন।',
    };
  }

  const computedHash = await hashPassword(plainPassword, account.salt);
  if (computedHash !== account.passwordHash) {
    return { success: false, message: 'Student ID অথবা Password সঠিক নয়।' };
  }

  const student = students.find((s) => s.id === account.studentId);
  if (!student) {
    return { success: false, message: 'তথ্য লোড করা সম্ভব হয়নি। অনুগ্রহ করে আবার চেষ্টা করুন।' };
  }

  const user: AuthUser = {
    id: student.id,
    name: student.name,
    role: 'student',
    customStudentId: account.customStudentId,
    batchId: student.batchId || (student.academicClass === 'XII' ? (student.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a'),
    student,
  };

  const session: AuthSession = {
    user,
    token: `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    rememberMe,
    loggedInAt: Date.now(),
  };

  saveSession(session, rememberMe);
  return { success: true, session };
}

// Admin / Teacher Login Verification
export async function loginAdmin(
  usernameInput: string,
  plainPassword: string,
  rememberMe: boolean = true
): Promise<LoginResult> {
  const cleaned = usernameInput.trim();
  if (!cleaned || !plainPassword.trim()) {
    return { success: false, message: 'Username অথবা Password সঠিক নয়।' };
  }

  const adminConfig = await getAdminConfig();
  if (cleaned.toLowerCase() !== adminConfig.username.toLowerCase()) {
    return { success: false, message: 'Username অথবা Password সঠিক নয়।' };
  }

  const computedHash = await hashPassword(plainPassword, adminConfig.salt);
  if (computedHash !== adminConfig.passwordHash) {
    return { success: false, message: 'Username অথবা Password সঠিক নয়।' };
  }

  const user: AuthUser = {
    id: 'admin_user',
    name: adminConfig.name || 'আইসিটি শিক্ষক / Admin',
    role: 'admin',
  };

  const session: AuthSession = {
    user,
    token: `adm_sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    rememberMe,
    loggedInAt: Date.now(),
  };

  saveSession(session, rememberMe);
  return { success: true, session };
}

// Session persistence - Deprecated.
// Supabase Auth exclusively manages authentication session and persistence.
export function saveSession(_session: AuthSession, _rememberMe: boolean): void {
  try {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    localStorage.removeItem('isAuthenticated');
    sessionStorage.removeItem('isAuthenticated');
    localStorage.removeItem('currentUser');
    sessionStorage.removeItem('currentUser');
  } catch {
    // ignore
  }
}

export function getCurrentSession(): AuthSession | null {
  // Legacy function deprecated: Supabase Auth exclusively determines authentication state.
  return null;
}

export function logout(): void {
  try {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    localStorage.removeItem('isAuthenticated');
    sessionStorage.removeItem('isAuthenticated');
    localStorage.removeItem('currentUser');
    sessionStorage.removeItem('currentUser');
  } catch {
    // ignore
  }
}

// Student self password change
export async function changeStudentPassword(
  studentId: string,
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; message: string }> {
  if (!newPassword || newPassword.length < 4) {
    return { success: false, message: 'নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' };
  }

  const accounts = loadStudentAccounts();
  const account = accounts.find((a) => a.studentId === studentId);
  if (!account) {
    return { success: false, message: 'অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।' };
  }

  const currentComputed = await hashPassword(currentPassword, account.salt);
  if (currentComputed !== account.passwordHash) {
    return { success: false, message: 'বর্তমান পাসওয়ার্ড সঠিক নয়।' };
  }

  const newSalt = generateSalt();
  const newHash = await hashPassword(newPassword, newSalt);

  account.passwordHash = newHash;
  account.salt = newSalt;
  account.updatedAt = Date.now();

  saveStudentAccounts(accounts);
  return { success: true, message: 'Password successfully updated.' };
}

// Admin reset student password
export async function adminResetStudentPassword(
  studentId: string,
  newPassword: string = DEFAULT_STUDENT_PASSWORD
): Promise<{ success: boolean; message: string }> {
  const accounts = loadStudentAccounts();
  const account = accounts.find((a) => a.studentId === studentId);
  if (!account) {
    return { success: false, message: 'অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।' };
  }

  const newSalt = generateSalt();
  const newHash = await hashPassword(newPassword, newSalt);

  account.passwordHash = newHash;
  account.salt = newSalt;
  account.updatedAt = Date.now();

  saveStudentAccounts(accounts);
  return {
    success: true,
    message: `পাসওয়ার্ড সফলভাবে রিসেট করা হয়েছে (নতুন পাসওয়ার্ড: "${newPassword}")।`,
  };
}

// Admin toggle active / inactive
export function adminToggleStudentStatus(
  studentId: string,
  status: 'active' | 'inactive'
): { success: boolean; message: string } {
  const accounts = loadStudentAccounts();
  const account = accounts.find((a) => a.studentId === studentId);
  if (!account) {
    return { success: false, message: 'অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।' };
  }

  account.status = status;
  account.updatedAt = Date.now();
  saveStudentAccounts(accounts);

  return {
    success: true,
    message: `অ্যাকাউন্ট স্ট্যাটাস সফলভাবে ${status === 'active' ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Inactive)'} করা হয়েছে।`,
  };
}

// Link newly added student
export async function createStudentAccount(student: Student, initialPassword?: string): Promise<StudentAccount> {
  const accounts = loadStudentAccounts();
  const codeToUse = (student.studentIdCode || '').trim() || formatStudentIdCode(student.roll, student.academicClass, student.group);
  const salt = generateSalt();
  const passToUse = initialPassword && initialPassword.trim() ? initialPassword.trim() : DEFAULT_STUDENT_PASSWORD;
  const passwordHash = await hashPassword(passToUse, salt);

  const newAcc: StudentAccount = {
    studentId: student.id,
    customStudentId: codeToUse,
    username: codeToUse,
    passwordHash,
    salt,
    status: 'active',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  // Prevent duplicate account for same internal student ID
  const filtered = accounts.filter((a) => a.studentId !== student.id);
  filtered.push(newAcc);
  saveStudentAccounts(filtered);
  return newAcc;
}
