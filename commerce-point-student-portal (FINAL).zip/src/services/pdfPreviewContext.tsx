import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

export interface PdfPreviewData {
  blob: Blob;
  objectUrl: string;
  fileName: string;
  title: string;
  totalPages: number;
  orientation: 'portrait' | 'landscape';
  pageImages?: string[]; // High-DPI base64 image data URLs of each page
  pageHtmls?: string[]; // 100% Vector HTML of each page for razor-sharp, selectable preview and vector printing
  onPrint?: () => void; // Trigger browser vector print engine
}

export interface PdfPreviewContextValue {
  isOpen: boolean;
  previewData: PdfPreviewData | null;
  openPdfPreview: (data: PdfPreviewData) => void;
  closePdfPreview: () => void;
}

const PdfPreviewContext = createContext<PdfPreviewContextValue | undefined>(undefined);

let globalOpenPdfPreviewHandler: ((data: PdfPreviewData) => void) | null = null;

/**
 * Global bridge allowing non-React services (like pdfExport.ts) to trigger the PDF Preview Modal
 */
export function showPdfPreview(data: PdfPreviewData): void {
  if (globalOpenPdfPreviewHandler) {
    globalOpenPdfPreviewHandler(data);
  } else {
    console.warn('PdfPreviewProvider is not mounted yet. Falling back to direct download.');
    const a = document.createElement('a');
    a.href = data.objectUrl || URL.createObjectURL(data.blob);
    a.download = data.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

export const PdfPreviewProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [previewData, setPreviewData] = useState<PdfPreviewData | null>(null);

  const openPdfPreview = useCallback((data: PdfPreviewData) => {
    // Revoke previous object URL if different
    if (previewData && previewData.objectUrl !== data.objectUrl) {
      try {
        URL.revokeObjectURL(previewData.objectUrl);
      } catch {
        // Ignore
      }
    }
    setPreviewData(data);
    setIsOpen(true);
  }, [previewData]);

  const closePdfPreview = useCallback(() => {
    setIsOpen(false);
    // Keep previewData briefly for smooth exit animation, then clean up
    setTimeout(() => {
      setPreviewData((prev) => {
        if (prev?.objectUrl) {
          try {
            URL.revokeObjectURL(prev.objectUrl);
          } catch {
            // Ignore
          }
        }
        return null;
      });
    }, 300);
  }, []);

  useEffect(() => {
    globalOpenPdfPreviewHandler = openPdfPreview;
    return () => {
      globalOpenPdfPreviewHandler = null;
    };
  }, [openPdfPreview]);

  return (
    <PdfPreviewContext.Provider
      value={{
        isOpen,
        previewData,
        openPdfPreview,
        closePdfPreview,
      }}
    >
      {children}
    </PdfPreviewContext.Provider>
  );
};

export function usePdfPreview(): PdfPreviewContextValue {
  const context = useContext(PdfPreviewContext);
  if (!context) {
    throw new Error('usePdfPreview must be used within a PdfPreviewProvider');
  }
  return context;
}
