import { supabase } from '../supabase';
import { Student, Exam, StudentMarkEntry } from '../types';
import { calculateGrade, ALL_DEFAULT_SUBJECT_IDS } from '../data/initialData';
import { loadStudents, saveStudents, loadExams, saveExams } from './storage';

/**
 * Fetches the logged-in student's record strictly from Supabase 'students' table
 * using: supabase.from('students').select('*').single()
 * under active Row Level Security (RLS) policies.
 */
export async function fetchLoggedInStudentRecord(): Promise<{
  data: any | null;
  error: any | null;
}> {
  try {
    const response = await supabase
      .from('students')
      .select('*')
      .single();

    return {
      data: response.data,
      error: response.error,
    };
  } catch (err: any) {
    console.warn('fetchLoggedInStudentRecord error:', err);
    return { data: null, error: err };
  }
}

/**
 * Fetches the logged-in student's exam results strictly from Supabase 'exam_results' table
 * under active Row Level Security (RLS) policies.
 */
export async function fetchLoggedInStudentExamResults(): Promise<{
  data: any[] | null;
  error: any | null;
}> {
  try {
    const response = await supabase
      .from('exam_results')
      .select('*')
      .order('exam_date', { ascending: true });

    return {
      data: response.data,
      error: response.error,
    };
  } catch (err: any) {
    console.warn('fetchLoggedInStudentExamResults error:', err);
    return { data: null, error: err };
  }
}

/**
 * Fetches all student records for Admin/Staff under active RLS policies
 */
export async function fetchAdminStudentsList(): Promise<{
  data: any[] | null;
  error: any | null;
}> {
  try {
    const response = await supabase
      .from('students')
      .select('*');

    return {
      data: response.data,
      error: response.error,
    };
  } catch (err: any) {
    console.warn('fetchAdminStudentsList error:', err);
    return { data: null, error: err };
  }
}

/**
 * Fetches all exam results for Admin/Staff under active RLS policies
 */
export async function fetchAdminExamResults(): Promise<{
  data: any[] | null;
  error: any | null;
}> {
  try {
    const response = await supabase
      .from('exam_results')
      .select('*');

    return {
      data: response.data,
      error: response.error,
    };
  } catch (err: any) {
    console.warn('fetchAdminExamResults error:', err);
    return { data: null, error: err };
  }
}

/**
 * Maps a database row from Supabase 'students' table to the frontend Student interface.
 */
export function mapDatabaseRowToStudent(row: any, fallback?: Student): Student {
  if (!row) {
    return (
      fallback || {
        id: 'student_1',
        roll: 1,
        name: 'শিক্ষার্থী',
        studentIdCode: 'CP/C-11/B-A 001',
        batchId: 'class-11-a',
        academicClass: 'XI',
        group: 'B-A',
        subject: 'ICT',
        session: '2026',
        assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS,
      }
    );
  }

  const rawId = row.student_id || row.studentIdCode || fallback?.studentIdCode || '';
  const rollFromId = parseInt(rawId.replace(/\D/g, '').slice(-3) || '1', 10);
  const roll = row.roll || rollFromId || fallback?.roll || 1;

  const rawClass = (row.class || fallback?.academicClass || 'XI').toUpperCase();
  const academicClass = rawClass.includes('12') || rawClass.includes('XII') ? 'XII' : 'XI';

  let batchId = row.batch_id || fallback?.batchId;
  if (!batchId) {
    const rawBatch = (row.batch || '').toLowerCase();
    if (academicClass === 'XII') {
      batchId = rawBatch.includes('b') ? 'class-12-b' : 'class-12-a';
    } else {
      batchId = 'class-11-a';
    }
  }

  const group = row.group || (batchId === 'class-12-b' ? 'B-B' : 'B-A');

  return {
    id: row.id ? String(row.id) : fallback?.id || 'student_1',
    roll,
    name: row.name || fallback?.name || 'শিক্ষার্থী',
    studentIdCode:
      row.student_id ||
      row.studentIdCode ||
      fallback?.studentIdCode ||
      `CP/C-11/B-A ${String(roll).padStart(3, '0')}`,
    batchId,
    academicClass,
    group,
    subject: row.subject || fallback?.subject || 'ICT',
    assignedSubjectIds:
      row.assigned_subject_ids || fallback?.assignedSubjectIds || ALL_DEFAULT_SUBJECT_IDS,
    session: row.session || fallback?.session || '2026',
    email: row.email || fallback?.email,
    mobile: row.mobile || fallback?.mobile,
  };
}

/**
 * 1. REAL-TIME STUDENTS DIRECT SUPABASE SYNC:
 * Fetches real-time data directly from `supabase.from('students').select('*')`.
 * Retains localStorage solely as an offline fallback.
 */
export async function fetchRealtimeStudents(): Promise<Student[]> {
  try {
    const { data: dbStudents, error } = await supabase.from('students').select('*');

    if (!error && Array.isArray(dbStudents) && dbStudents.length > 0) {
      const fallbackList = loadStudents();
      const mappedStudents: Student[] = dbStudents.map((row) => {
        const matched = fallbackList.find(
          (s) =>
            (row.student_id && s.studentIdCode === row.student_id) ||
            (row.id && String(row.id) === s.id) ||
            (row.roll && s.roll === row.roll && s.batchId === (row.batch_id || 'class-11-a'))
        );
        return mapDatabaseRowToStudent(row, matched);
      });

      // Save to localStorage solely as an offline fallback
      try {
        saveStudents(mappedStudents);
      } catch {
        // ignore
      }
      return mappedStudents;
    }
  } catch (err) {
    console.warn('Error fetching students from Supabase (offline fallback active):', err);
  }

  // Offline fallback
  return loadStudents();
}

/**
 * 2. REAL-TIME EXAM RESULTS DIRECT SUPABASE SYNC:
 * Fetches real-time data directly from `supabase.from('exam_results').select('*')`.
 * Reconstructs Exam objects and retains localStorage solely as an offline fallback.
 */
export async function fetchRealtimeExamResults(allStudents: Student[]): Promise<Exam[]> {
  try {
    const { data: dbRows, error } = await supabase.from('exam_results').select('*');

    if (!error && Array.isArray(dbRows) && dbRows.length > 0) {
      const baseExams = loadExams();

      // Group dbRows by exam identifier: exam_title + exam_date + subject
      const groupedMap = new Map<string, any[]>();
      dbRows.forEach((row) => {
        const key = `${(row.exam_title || '').trim().toLowerCase()}_${row.exam_date}_${(row.subject || 'ict').trim().toLowerCase()}`;
        const existing = groupedMap.get(key) || [];
        existing.push(row);
        groupedMap.set(key, existing);
      });

      const reconstructedExams: Exam[] = [];

      groupedMap.forEach((rows, key) => {
        const firstRow = rows[0];
        const examTitle = firstRow.exam_title || 'পরীক্ষা';
        const examDate = firstRow.exam_date || new Date().toISOString().split('T')[0];
        const rawSubject = (firstRow.subject || 'ict').toLowerCase();

        let subjectId = 'ict';
        if (rawSubject.includes('bangla') || rawSubject.includes('বাংলা')) subjectId = 'bangla';
        else if (rawSubject.includes('eng')) subjectId = 'english';
        else if (rawSubject.includes('acc') || rawSubject.includes('হিসাব')) subjectId = 'accounting';
        else if (rawSubject.includes('mkt') || rawSubject.includes('মার্কেটিং')) subjectId = 'marketing';
        else if (rawSubject.includes('mgt') || rawSubject.includes('ব্যবস্থাপনা')) subjectId = 'management';
        else if (rawSubject.includes('eco') || rawSubject.includes('অর্থনীতি')) subjectId = 'economics';
        else subjectId = rawSubject;

        // Try to match with an existing baseExam for exact full marks & batch
        const matchedBase = baseExams.find(
          (b) =>
            b.name.trim().toLowerCase() === examTitle.trim().toLowerCase() &&
            b.date === examDate &&
            (b.subjectId || 'ict') === subjectId
        );

        const totalFullMarks =
          matchedBase?.totalFullMarks || (firstRow.highest_marks && firstRow.highest_marks > 50 ? 100 : 50);
        const cqFullMarks = matchedBase?.cqFullMarks || (totalFullMarks === 100 ? 70 : 35);
        const mcqFullMarks = matchedBase?.mcqFullMarks || (totalFullMarks === 100 ? 30 : 15);

        const marksDict: Record<string, StudentMarkEntry> = {};
        let totalScoreSum = 0;
        let attendedCount = 0;

        rows.forEach((r) => {
          // Match student by r.student_id (can be internal ID or studentIdCode)
          const matchedStudent = allStudents.find(
            (s) =>
              s.id === r.student_id ||
              s.studentIdCode === r.student_id ||
              (r.student_id && s.studentIdCode.replace(/\s+/g, '') === String(r.student_id).replace(/\s+/g, ''))
          );

          const studentIdKey = matchedStudent ? matchedStudent.id : r.student_id;
          const studentName = matchedStudent ? matchedStudent.name : 'শিক্ষার্থী';

          const cq =
            r.cq_marks !== null && r.cq_marks !== undefined && r.cq_marks !== ''
              ? Number(r.cq_marks)
              : '';
          const mcq =
            r.mcq_marks !== null && r.mcq_marks !== undefined && r.mcq_marks !== ''
              ? Number(r.mcq_marks)
              : '';
          const total =
            r.total_marks !== null && r.total_marks !== undefined
              ? Number(r.total_marks)
              : Number(cq || 0) + Number(mcq || 0);

          const percentage =
            totalFullMarks > 0 ? Number(((total / totalFullMarks) * 100).toFixed(1)) : 0;
          const grade = calculateGrade(percentage);

          if (cq !== '' || mcq !== '' || total > 0) {
            attendedCount++;
            totalScoreSum += total;
          }

          marksDict[studentIdKey] = {
            studentId: studentIdKey,
            studentName,
            cq,
            mcq,
            total,
            percentage,
            grade,
          };
        });

        // Determine batchId from participating students or matched base
        let examBatchId = matchedBase?.batchId;
        if (!examBatchId) {
          const firstMatchedStudent = allStudents.find((s) => marksDict[s.id]);
          examBatchId = firstMatchedStudent?.batchId || 'class-11-a';
        }

        const average = attendedCount > 0 ? Number((totalScoreSum / attendedCount).toFixed(1)) : 0;
        const averagePercentage =
          totalFullMarks > 0 ? Math.round((average / totalFullMarks) * 100) : 0;

        reconstructedExams.push({
          id: matchedBase?.id || `exam_db_${firstRow.id || key}`,
          batchId: examBatchId,
          subjectId,
          date: examDate,
          name: examTitle,
          cqFullMarks,
          mcqFullMarks,
          totalFullMarks,
          marks: marksDict,
          average,
          averagePercentage,
          createdAt: firstRow.created_at ? new Date(firstRow.created_at).getTime() : Date.now(),
        });
      });

      // Merge any local offline exams that haven't synced yet
      baseExams.forEach((be) => {
        const exists = reconstructedExams.some(
          (re) =>
            re.name.trim().toLowerCase() === be.name.trim().toLowerCase() &&
            re.date === be.date &&
            re.subjectId === be.subjectId
        );
        if (!exists) {
          reconstructedExams.push(be);
        }
      });

      // Save to localStorage solely as an offline fallback
      try {
        saveExams(reconstructedExams);
      } catch {
        // ignore
      }

      return reconstructedExams;
    }
  } catch (err) {
    console.warn('Error fetching exam_results from Supabase (offline fallback active):', err);
  }

  // Offline fallback
  return loadExams();
}

/**
 * 3. REAL-TIME WRITE TO SUPABASE 'exam_results' TABLE:
 * Writes a single student's mark directly to Supabase.
 */
export async function writeMarkToSupabase(
  studentId: string,
  subject: string,
  examTitle: string,
  examDate: string,
  cq: number | '',
  mcq: number | '',
  total: number,
  highestMarks: number
): Promise<{ success: boolean; error?: any }> {
  try {
    const payload = {
      student_id: studentId,
      subject: subject || 'ICT',
      exam_title: examTitle,
      exam_date: examDate,
      cq_marks: cq === '' ? null : Number(cq),
      mcq_marks: mcq === '' ? null : Number(mcq),
      total_marks: Number(total),
      highest_marks: Number(highestMarks),
    };

    // Attempt upsert with primary key or unique conflict
    const { error } = await supabase
      .from('exam_results')
      .upsert(payload, { onConflict: 'student_id,exam_title,exam_date' });

    if (error) {
      // Fallback direct insert if conflict constraint is different
      const { error: insErr } = await supabase.from('exam_results').insert(payload);
      if (insErr) {
        console.warn('Supabase exam_results write error:', insErr);
        return { success: false, error: insErr };
      }
    }

    return { success: true };
  } catch (err: any) {
    console.warn('writeMarkToSupabase exception:', err);
    return { success: false, error: err };
  }
}

/**
 * 4. REAL-TIME WRITE TO SUPABASE 'exam_results' TABLE:
 * Writes an entire Exam and all of its student marks directly to Supabase.
 */
export async function writeWholeExamToSupabase(
  exam: Exam,
  students: Student[]
): Promise<{ success: boolean; error?: any }> {
  try {
    const marksEntries = Object.entries(exam.marks || {});
    if (marksEntries.length === 0) return { success: true };

    const records = marksEntries.map(([studentId, entry]) => {
      const student = students.find((s) => s.id === studentId);
      const studentIdentifier = student ? student.id : studentId;

      return {
        student_id: studentIdentifier,
        subject: exam.subjectId || 'ICT',
        exam_title: exam.name,
        exam_date: exam.date,
        cq_marks: entry.cq === '' ? null : Number(entry.cq),
        mcq_marks: entry.mcq === '' ? null : Number(entry.mcq),
        total_marks: Number(entry.total),
        highest_marks: Number(exam.totalFullMarks),
      };
    });

    const { error } = await supabase
      .from('exam_results')
      .upsert(records, { onConflict: 'student_id,exam_title,exam_date' });

    if (error) {
      // Try individual writes if bulk upsert encountered constraint mismatch
      for (const rec of records) {
        try {
          await supabase.from('exam_results').insert(rec);
        } catch {
          // ignore
        }
      }
    }

    return { success: true };
  } catch (err: any) {
    console.warn('writeWholeExamToSupabase exception:', err);
    return { success: false, error: err };
  }
}

/**
 * 5. REAL-TIME POSTGRES CHANGES SUBSCRIPTION:
 * Listens for live updates on 'students' and 'exam_results' tables.
 */
export function subscribeToSupabaseRealtime(
  onUpdate: () => void
): () => void {
  try {
    const channel = supabase
      .channel('commerce-point-realtime-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'exam_results' },
        () => {
          onUpdate();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'students' },
        () => {
          onUpdate();
        }
      )
      .subscribe();

    return () => {
      try {
        supabase.removeChannel(channel);
      } catch {
        // ignore
      }
    };
  } catch (err) {
    console.warn('Realtime subscription initialization error:', err);
    return () => {};
  }
}

/**
 * Builds or isolates exams strictly for the logged-in student based on
 * Supabase 'exam_results' rows and existing exams.
 * Guarantees that NO peer student's marks exist in the returned exams.
 */
export function isolateStudentExams(
  dbResults: any[] | null,
  student: Student,
  baseExams: Exam[]
): Exam[] {
  // If exam_results are returned from Supabase for this student:
  if (dbResults && dbResults.length > 0) {
    const mappedDbExams: Exam[] = dbResults.map((r, idx) => {
      const cq =
        r.cq_marks !== null && r.cq_marks !== undefined && r.cq_marks !== ''
          ? Number(r.cq_marks)
          : '';
      const mcq =
        r.mcq_marks !== null && r.mcq_marks !== undefined && r.mcq_marks !== ''
          ? Number(r.mcq_marks)
          : '';
      const total =
        r.total_marks !== null && r.total_marks !== undefined
          ? Number(r.total_marks)
          : Number(cq || 0) + Number(mcq || 0);

      const matched = baseExams.find(
        (b) =>
          b.name.trim().toLowerCase() === (r.exam_title || '').trim().toLowerCase() ||
          b.id === r.exam_id
      );

      const totalFullMarks =
        matched?.totalFullMarks || (r.highest_marks && r.highest_marks > 50 ? 100 : 50);
      const cqFullMarks = matched?.cqFullMarks || (totalFullMarks === 100 ? 70 : 35);
      const mcqFullMarks = matched?.mcqFullMarks || (totalFullMarks === 100 ? 30 : 15);
      const percentage =
        totalFullMarks > 0 ? Number(((total / totalFullMarks) * 100).toFixed(1)) : 0;
      const grade = calculateGrade(percentage);

      const rawSub = (r.subject || matched?.subjectId || 'ict').toLowerCase();
      let subjectId = 'ict';
      if (rawSub.includes('bangla') || rawSub.includes('বাংলা')) subjectId = 'bangla';
      else if (rawSub.includes('eng')) subjectId = 'english';
      else if (rawSub.includes('acc') || rawSub.includes('হিসাব')) subjectId = 'accounting';
      else if (rawSub.includes('mkt') || rawSub.includes('মার্কেটিং')) subjectId = 'marketing';
      else if (rawSub.includes('mgt') || rawSub.includes('ব্যবস্থাপনা')) subjectId = 'management';
      else if (rawSub.includes('eco') || rawSub.includes('অর্থনীতি')) subjectId = 'economics';
      else if (rawSub.includes('ict') || rawSub.includes('আইসিটি')) subjectId = 'ict';
      else subjectId = rawSub;

      const studentEntry: StudentMarkEntry = {
        studentId: student.id,
        studentName: student.name,
        cq,
        mcq,
        total,
        percentage,
        grade,
      };

      return {
        id: r.id ? String(r.id) : matched?.id || `db_exam_${idx}_${r.exam_date}`,
        batchId: student.batchId || 'class-11-a',
        subjectId: matched?.subjectId || subjectId,
        date: r.exam_date || matched?.date || new Date().toISOString().split('T')[0],
        name: r.exam_title || matched?.name || `পরীক্ষা ${idx + 1}`,
        cqFullMarks,
        mcqFullMarks,
        totalFullMarks,
        // STRICT ISOLATION: marks dictionary contains ONLY the logged-in student's marks
        marks: {
          [student.id]: studentEntry,
        },
        average: total,
        averagePercentage: percentage,
        createdAt: r.created_at ? new Date(r.created_at).getTime() : Date.now(),
      };
    });

    // Also include any baseExams that have marks for this student but weren't in dbResults
    const existingTitles = new Set(
      mappedDbExams.map((e) => e.name.trim().toLowerCase())
    );

    baseExams.forEach((be) => {
      if (!existingTitles.has(be.name.trim().toLowerCase())) {
        const studentEntry = be.marks ? be.marks[student.id] : undefined;
        if (studentEntry) {
          mappedDbExams.push({
            ...be,
            // STRICT ISOLATION: Remove all peer students' marks
            marks: {
              [student.id]: studentEntry,
            },
          });
        }
      }
    });

    return mappedDbExams;
  }

  // If no rows in Supabase exam_results yet, strictly filter baseExams:
  // Strip out ALL peer students' marks so that marks dictionary ONLY contains [student.id]
  return baseExams.map((exam) => {
    const studentEntry = exam.marks ? exam.marks[student.id] : undefined;
    return {
      ...exam,
      marks: studentEntry ? { [student.id]: studentEntry } : {},
    };
  });
}
