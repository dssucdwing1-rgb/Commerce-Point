import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';
import { Exam, Student, Subject } from '../types';
import { calculateGrade, toBengaliNum } from '../data/initialData';
import { formatDisplayDate } from './excelExport';
import { calculateStudentMonthlySummary } from '../components/monthly/monthUtils';
import {
  rankStudentsForExam,
  rankStudentsForMonthlyMaster,
  getStudentExamPosition,
  getStudentMonthlyPosition,
} from '../utils/ranking';
import { showPdfPreview, PdfPreviewData } from './pdfPreviewContext';
import pdfStyles from '../styles/pdfPrint.module.css';
import {
  PDF_COLORS,
  COMMERCE_POINT_LOGO_BASE64,
  getCommercePointLogoHtml,
} from '../styles/pdfPrintStyles';

/**
 * Ensures all Bengali font faces (Nikosh, Kalpurush, Noto Sans Bengali) are loaded before capturing.
 * This prevents font-swapping or missing Bengali glyphs during rendering.
 */
export async function ensureFontsReady(): Promise<void> {
  if (typeof document !== 'undefined') {
    if (document.fonts && document.fonts.ready) {
      await document.fonts.ready;
    }
    if (document.fonts && document.fonts.load) {
      try {
        await Promise.all([
          document.fonts.load('400 14px "Nikosh"'),
          document.fonts.load('600 14px "Nikosh"'),
          document.fonts.load('700 14px "Nikosh"'),
          document.fonts.load('400 14px "Kalpurush"'),
          document.fonts.load('600 14px "Kalpurush"'),
          document.fonts.load('700 14px "Kalpurush"'),
          document.fonts.load('400 14px "Noto Sans Bengali"'),
          document.fonts.load('600 14px "Noto Sans Bengali"'),
          document.fonts.load('700 14px "Noto Sans Bengali"'),
        ]);
      } catch {
        // Continue even if browser has font cached
      }
    }
    // Brief RAF pause to ensure layout and SVG stabilization
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 80)));
  }
}

/**
 * Returns the official high-DPI transparent PNG base64 data URL for Commerce Point emblem.
 */
export async function getCommercePointLogoBase64(): Promise<string> {
  return COMMERCE_POINT_LOGO_BASE64;
}

/**
 * Ensures any img elements inside the container are fully decoded before capturing.
 */
async function waitForImagesToLoad(container: HTMLElement): Promise<void> {
  const images = Array.from(container.querySelectorAll('img'));
  if (images.length === 0) return;
  await Promise.all(
    images.map((img) => {
      if (img.complete) return Promise.resolve();
      return new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve();
      });
    })
  );
}

/**
 * Formats safe, clean filenames preserving readable Bengali text.
 */
function sanitizeFileName(str: string): string {
  return str.replace(/[\s/\\?%*:|"<>]/g, '_');
}

/**
 * Configures the dedicated DOM print container so that window.print() outputs
 * 100% Vector PDF with native text, Nikosh fonts, SVG logos, and zero rasterization.
 */
function preparePrintContainer(pageHtmls: string[], orientation: 'portrait' | 'landscape'): () => void {
  if (typeof document === 'undefined') return () => {};

  let printContainer = document.getElementById('commerce-point-print-container');
  if (!printContainer) {
    printContainer = document.createElement('div');
    printContainer.id = 'commerce-point-print-container';
    document.body.appendChild(printContainer);
  }

  const styleElId = 'commerce-point-print-style';
  let styleEl = document.getElementById(styleElId);
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = styleElId;
    document.head.appendChild(styleEl);
  }
  styleEl.innerHTML = `
    @media print {
      @page {
        size: A4 ${orientation};
        margin: 0 !important;
      }
      body > *:not(#commerce-point-print-container) {
        display: none !important;
      }
      #commerce-point-print-container {
        display: block !important;
        position: static !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
      }
      .pdfPagePortrait, .pdfPageLandscape {
        page-break-after: always !important;
        break-after: page !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
    }
    @media screen {
      #commerce-point-print-container {
        display: none !important;
      }
    }
  `;

  printContainer.innerHTML = pageHtmls.join('');

  return () => {
    window.print();
  };
}

export interface GeneratePdfOptions {
  pageHtmls: string[];
  orientation: 'portrait' | 'landscape';
  fileName: string;
  title: string;
}

/**
 * Centralized, High-Quality PDF Engine:
 * 1. Takes 100% Vector HTML strings for each page.
 * 2. Mounts them for instant vector printing (Save as PDF).
 * 3. Captures high-DPI 300+ DPI equivalent pages with lossless PNG.
 * 4. Produces ONE single final PDF Blob used for both Preview and Download.
 */
export async function generateHighQualityPdf(options: GeneratePdfOptions): Promise<PdfPreviewData> {
  const { pageHtmls, orientation, fileName, title } = options;
  await ensureFontsReady();

  const isLandscape = orientation === 'landscape';
  const pdfWidth = isLandscape ? 297 : 210;
  const pdfHeight = isLandscape ? 210 : 297;
  const widthPt = isLandscape ? 841.89 : 595.28;

  // Mount print container
  const triggerPrint = preparePrintContainer(pageHtmls, orientation);

  const container = document.createElement('div');
  container.className = 'pdf-isolated-root';
  container.style.position = 'fixed';
  container.style.left = '-99999px';
  container.style.top = '0';
  container.style.width = `${widthPt}pt`;
  container.style.backgroundColor = '#ffffff';
  container.style.fontFamily = "'Nikosh', 'Kalpurush', 'Noto Sans Bengali', sans-serif";
  container.style.color = '#0f172a';
  container.style.boxSizing = 'border-box';
  document.body.appendChild(container);

  const pageImages: string[] = [];

  try {
    const pdf = new jsPDF({
      orientation,
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    for (let i = 0; i < pageHtmls.length; i++) {
      const pageWrapper = document.createElement('div');
      pageWrapper.innerHTML = pageHtmls[i];
      const targetEl = (pageWrapper.firstElementChild as HTMLElement) || pageWrapper;

      container.innerHTML = '';
      container.appendChild(targetEl);

      await waitForImagesToLoad(targetEl);

      // Dynamic Scaling in html2canvas / jsPDF: windowWidth 1150, scale 2, proportional single page fit
      const canvas = await html2canvas(targetEl, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        windowWidth: 1150,
      });

      const imgData = canvas.toDataURL('image/png');
      pageImages.push(imgData);

      if (i > 0) {
        pdf.addPage([pdfWidth, pdfHeight], orientation);
      }

      const imgHeight = (canvas.height * pdfWidth) / canvas.width;

      // Force single page fit if the calculated height exceeds A4 height by less than 18%:
      if (imgHeight > pdfHeight && imgHeight <= pdfHeight * 1.18) {
        // Scale proportionally to fit within 1 single page without multi-page split
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      } else {
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
      }
    }

    const blob = pdf.output('blob');
    const objectUrl = URL.createObjectURL(blob);

    const result: PdfPreviewData = {
      blob,
      objectUrl,
      fileName,
      title,
      totalPages: pageHtmls.length,
      orientation,
      pageImages,
      pageHtmls,
      onPrint: triggerPrint,
    };

    showPdfPreview(result);
    return result;
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

// =========================================================================
// 1. MONTHLY MASTER RESULT SHEET PDF (TEACHER LOGIN & ADMIN)
// Complete Dataset, A4 Landscape, Multi-page with repeated headers & signatures
// =========================================================================
export async function exportMonthlyMasterPdf(
  examsInMonth: Exam[],
  students: Student[],
  monthLabel: string,
  subjects: Subject[]
): Promise<PdfPreviewData> {
  const sortedExams = [...examsInMonth].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  // Rank students strictly by Total Obtained Marks descending across all exams in month
  const rankedStudents = rankStudentsForMonthlyMaster(sortedExams, students);

  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  // Determine pagination: Auto-fit up to 25-30 students on a single page
  const studentCount = rankedStudents.length;
  const STUDENTS_PER_PAGE = studentCount <= 30 ? Math.max(studentCount, 1) : 25;
  const totalPages = Math.max(1, Math.ceil(rankedStudents.length / STUDENTS_PER_PAGE));

  const pageHtmls: string[] = [];

  // Dynamic Compact Row Padding for Print/PDF:
  const isCompact = studentCount > 15;
  const isSuperCompact = studentCount > 22;
  const cellPy = isSuperCompact ? '1.2pt' : isCompact ? '1.8pt' : '3pt';
  const cellFontSize = isSuperCompact ? '7pt' : isCompact ? '7.5pt' : '8pt';
  const nameFontSize = isSuperCompact ? '7.5pt' : isCompact ? '8pt' : '8.5pt';
  const logoSize = isCompact ? 42 : 54;
  const headerPy = isCompact ? '2.5pt' : '3.5pt';
  const pagePadding = isCompact ? '12pt 16pt' : '18pt 22pt';

  for (let pageIdx = 0; pageIdx < totalPages; pageIdx++) {
    const pageStudents = rankedStudents.slice(
      pageIdx * STUDENTS_PER_PAGE,
      (pageIdx + 1) * STUDENTS_PER_PAGE
    );

    // Page Header with official large logo in pt
    const headerHtml = `
      <div style="border-bottom: 2pt solid #1e3a8a; padding-bottom: ${isCompact ? '5pt' : '8pt'}; margin-bottom: ${isCompact ? '5pt' : '8pt'};">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div style="display: flex; align-items: center; gap: 10pt;">
            ${getCommercePointLogoHtml(logoSize, logoSize)}
            <div>
              <div style="font-size: ${isCompact ? '17pt' : '19.5pt'}; font-weight: 900; color: #1e3a8a; letter-spacing: -0.25pt; line-height: ${isCompact ? '19pt' : '22pt'};">
                COMMERCE POINT
              </div>
              <div style="font-size: ${isCompact ? '9pt' : '10pt'}; font-weight: 700; color: #334155; margin-top: 1pt; line-height: 12pt;">
                একাডেমিক মূল্যায়ন ও শিক্ষার্থী অগ্রগতি ব্যবস্থাপনা
              </div>
              <div style="font-size: 8pt; font-weight: 600; color: #64748b; margin-top: 0.5pt; line-height: 10pt;">
                HSC Business Studies & Academic Care
              </div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="display: inline-block; background-color: #1e3a8a; color: #fde047; font-size: ${isCompact ? '8pt' : '9pt'}; font-weight: 800; padding: ${isCompact ? '2.5pt 8pt' : '3.5pt 10pt'}; border-radius: 4pt; border: 0.75pt solid #1e40af;">
              মাসিক মাস্টার রেজাল্ট শিট (Master Result Sheet)
            </div>
            <div style="font-size: 8.5pt; font-weight: 700; color: #0f172a; margin-top: 2.5pt; line-height: 11pt;">
              মাস: <span style="color: #1e3a8a; font-weight: 900;">${monthLabel}</span> · শিক্ষাবর্ষ: ২০২৬
            </div>
          </div>
        </div>
        <div style="display: flex; justify-content: space-between; margin-top: 4pt; font-size: 7.5pt; color: #64748b; font-weight: 600; line-height: 10pt;">
          <div>মোট শিক্ষার্থী: <strong style="color: #0f172a;">${toBengaliNum(rankedStudents.length)} জন</strong> | মোট পরীক্ষা: <strong style="color: #0f172a;">${toBengaliNum(sortedExams.length)}টি</strong></div>
          <div>প্রিন্ট তারিখ: ${new Date().toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' })} | পৃষ্ঠা ${toBengaliNum(pageIdx + 1)} / ${toBengaliNum(totalPages)}</div>
        </div>
      </div>
    `;

      // Table Header Rows
      let examGroupHeaders = '';
      let examSubHeaders = '';

      sortedExams.forEach((exam) => {
        const sub = subjectMap.get(exam.subjectId || 'ict');
        const subName = sub ? sub.name : (exam.subjectId || 'ICT').toUpperCase();
        examGroupHeaders += `
          <th colspan="3" style="border: 0.75pt solid #334155; padding: ${headerPy} 2pt; text-align: center; background-color: #1e293b; color: #ffffff;">
            <div style="font-size: 8pt; font-weight: 900; color: #fde047; line-height: 9.5pt;">${subName}</div>
            <div style="font-size: 6.5pt; color: #cbd5e1; font-weight: 600; line-height: 8.5pt;">${formatDisplayDate(exam.date)} · ${exam.name}</div>
          </th>
        `;
        examSubHeaders += `
          <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 700; background-color: #f1f5f9; color: #334155; width: 28pt;">CQ (${toBengaliNum(exam.cqFullMarks)})</th>
          <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 700; background-color: #f1f5f9; color: #334155; width: 28pt;">MCQ (${toBengaliNum(exam.mcqFullMarks)})</th>
          <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 800; background-color: #e2e8f0; color: #0f172a; width: 32pt;">Total (${toBengaliNum(exam.totalFullMarks)})</th>
        `;
      });

      // Table Body Rows
      let bodyRows = '';
      pageStudents.forEach((ranked, idx) => {
        const st = ranked.student;
        const studentIdCode = st.studentIdCode || `CP-${String(st.roll).padStart(3, '0')}`;
        let attended = 0;
        let totalObtained = 0;
        let totalFull = 0;

        let examCells = '';
        sortedExams.forEach((exam) => {
          const mark = exam.marks ? exam.marks[st.id] : undefined;
          const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

          if (!isAbsent && mark) {
            attended++;
            totalObtained += mark.total;
            totalFull += exam.totalFullMarks;
          }

          examCells += `
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; text-align: center; font-size: ${cellFontSize}; line-height: 1.15; color: #334155;">
              ${!isAbsent && mark && mark.cq !== '' ? toBengaliNum(mark.cq) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; text-align: center; font-size: ${cellFontSize}; line-height: 1.15; color: #334155;">
              ${!isAbsent && mark && mark.mcq !== '' ? toBengaliNum(mark.mcq) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; text-align: center; font-size: ${cellFontSize}; line-height: 1.15; font-weight: 800; background-color: ${isAbsent ? '#fee2e2' : '#f8fafc'}; color: ${isAbsent ? '#dc2626' : '#0f172a'};">
              ${isAbsent ? 'অনুপস্থিত' : toBengaliNum(mark.total)}
            </td>
          `;
        });

        const avgScore = attended > 0 ? Number((totalObtained / attended).toFixed(1)) : 0;
        const avgPct = totalFull > 0 ? Math.round((totalObtained / totalFull) * 100) : 0;
        const grade = attended > 0 ? calculateGrade(avgPct) : '-';
        const isPass = attended > 0 && grade !== 'F' && grade !== '-';

        bodyRows += `
          <tr style="background-color: ${idx % 2 === 1 ? '#f8fafc' : '#ffffff'}; line-height: 1.15;" class="leading-tight">
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; font-weight: 900; text-align: center; color: #1e3a8a; background-color: ${!ranked.isAbsent && ranked.position && ranked.position <= 3 ? '#fefce8' : '#f1f5f9'};">
              ${ranked.isAbsent ? '—' : `${ranked.position === 1 ? '🥇 ' : ranked.position === 2 ? '🥈 ' : ranked.position === 3 ? '🥉 ' : ''}${ranked.positionBengali}`}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; text-align: center; color: #0f172a; font-weight: 700;">
              ${toBengaliNum(st.roll)}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3.5pt; font-size: ${nameFontSize}; line-height: 1.15; font-weight: 700; color: #0f172a; white-space: nowrap;">
              ${st.name}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2.5pt; font-size: ${isCompact ? '6.5pt' : '7.5pt'}; line-height: 1.15; font-family: monospace; font-weight: 600; color: #475569; white-space: nowrap;">
              ${studentIdCode}
            </td>
            ${examCells}
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; text-align: center; color: #334155;">
              ${attended > 0 ? toBengaliNum(ranked.cqTotal) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; text-align: center; color: #334155;">
              ${attended > 0 ? toBengaliNum(ranked.mcqTotal) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; font-weight: 900; text-align: center; color: #0f172a; background-color: #f1f5f9;">
              ${attended > 0 ? toBengaliNum(totalObtained) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; font-weight: 700; text-align: center; color: #1e3a8a;">
              ${attended > 0 ? `${toBengaliNum(avgPct)}%` : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; line-height: 1.15; font-weight: 900; text-align: center; color: ${grade === 'A+' ? '#059669' : grade === 'F' ? '#dc2626' : '#1e3a8a'};">
              ${grade}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: 7pt; line-height: 1.15; font-weight: 800; text-align: center;">
              ${ranked.isAbsent ? '<span style="color: #64748b;">অনুপস্থিত</span>' : !isPass ? '<span style="color: #dc2626; background-color: #fee2e2; padding: 1pt 2.5pt; border-radius: 2pt;">Fail</span>' : '<span style="color: #059669; background-color: #d1fae5; padding: 1pt 2.5pt; border-radius: 2pt;">Pass</span>'}
            </td>
          </tr>
        `;
      });

      const tableHtml = `
        <table style="width: 100%; border-collapse: collapse; margin-top: 2pt; line-height: 1.15;" class="leading-tight">
          <thead>
            <tr>
              <th rowspan="2" style="border: 0.75pt solid #334155; padding: ${headerPy} 2pt; font-size: 7.5pt; line-height: 9pt; font-weight: 800; background-color: #0f172a; color: #fde047; text-align: center; width: 44pt;">
                মেধাক্রম / Position
              </th>
              <th rowspan="2" style="border: 0.75pt solid #334155; padding: ${headerPy} 2pt; font-size: 7.5pt; line-height: 9pt; font-weight: 800; background-color: #0f172a; color: #ffffff; text-align: center; width: 26pt;">
                রোল
              </th>
              <th rowspan="2" style="border: 0.75pt solid #334155; padding: ${headerPy} 3.5pt; font-size: 8pt; line-height: 9.5pt; font-weight: 800; background-color: #0f172a; color: #ffffff; text-align: left; width: 90pt;">
                শিক্ষার্থীর নাম
              </th>
              <th rowspan="2" style="border: 0.75pt solid #334155; padding: ${headerPy} 2.5pt; font-size: 7.5pt; line-height: 9pt; font-weight: 800; background-color: #0f172a; color: #ffffff; text-align: left; width: 70pt;">
                Student ID
              </th>
              ${examGroupHeaders}
              <th colspan="6" style="border: 0.75pt solid #334155; padding: ${headerPy} 2pt; font-size: 7.5pt; line-height: 9pt; font-weight: 900; background-color: #1e293b; color: #fde047; text-align: center;">
                মাসিক সামগ্রিক ফলাফল ও মূল্যায়ন
              </th>
            </tr>
            <tr>
              ${examSubHeaders}
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 700; background-color: #f1f5f9; color: #334155; width: 24pt;">মোট CQ</th>
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 700; background-color: #f1f5f9; color: #334155; width: 24pt;">মোট MCQ</th>
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 800; background-color: #e2e8f0; color: #0f172a; width: 30pt;">মোট নম্বর</th>
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 700; background-color: #f1f5f9; color: #334155; width: 28pt;">গড় %</th>
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 800; background-color: #f1f5f9; color: #1e3a8a; width: 26pt;">গ্রেড</th>
              <th style="border: 0.75pt solid #cbd5e1; padding: ${isCompact ? '1.5pt 1.5pt' : '2.5pt 2pt'}; text-align: center; font-size: 7pt; line-height: 9pt; font-weight: 800; background-color: #d1fae5; color: #065f46; width: 32pt;">স্ট্যাটাস</th>
            </tr>
          </thead>
          <tbody>
            ${bodyRows}
          </tbody>
        </table>
      `;

      // Page Footer with Teacher and Principal/Director Signatures (margin-top: 8px)
      const footerHtml = `
        <div style="margin-top: 8px; padding-top: 6px; page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid; display: flex; justify-content: space-between; align-items: flex-end; font-size: 8pt; line-height: 10pt; width: 100%;">
          <div style="text-align: center; width: 130pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">শ্রেণি শিক্ষকের স্বাক্ষর</div>
          </div>
          <div style="text-align: center; font-size: 7.5pt; color: #64748b;">
            পৃষ্ঠা ${toBengaliNum(pageIdx + 1)} / ${toBengaliNum(totalPages)}
          </div>
          <div style="text-align: center; width: 150pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</div>
          </div>
        </div>
      `;

      const pageHtml = `
        <div class="${pdfStyles.pdfPageLandscape} pdf-isolated-root" style="width: 841.89pt; min-height: 595.28pt; height: 595.28pt; padding: ${pagePadding}; box-sizing: border-box; background-color: #ffffff; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; page-break-inside: avoid; break-inside: avoid;">
          <div>
            ${headerHtml}
            ${tableHtml}
          </div>
          ${footerHtml}
        </div>
      `;
      pageHtmls.push(pageHtml);
    }

    const safeMonth = sanitizeFileName(monthLabel);
    const fileName = `CP_Monthly_Master_Result_${safeMonth}_2026.pdf`;
    const title = `মাসিক মাস্টার রেজাল্ট শিট (${monthLabel})`;

    return await generateHighQualityPdf({
      pageHtmls,
      orientation: 'landscape',
      fileName,
      title,
    });
}

// =========================================================================
// 2. STUDENT MONTHLY RESULT CARD PDF (STUDENT LOGIN & TEACHER LOGIN)
// Authorized Single Student, All Subjects Examined in Selected Month, A4 Portrait
// =========================================================================
export async function exportStudentMonthlyPdf(
  student: Student,
  examsInMonth: Exam[],
  monthLabel: string,
  subjects: Subject[],
  allStudents?: Student[]
): Promise<PdfPreviewData> {
  await ensureFontsReady();
  const logoDataUrl = await getCommercePointLogoBase64();

  const summary = calculateStudentMonthlySummary(student, examsInMonth, subjects);
  const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;

  // Monthly position lookup if allStudents provided
  let monthlyPosStr = '—';
  if (allStudents && allStudents.length > 0) {
    const pos = getStudentMonthlyPosition(student.id, examsInMonth, allStudents);
    monthlyPosStr = pos.positionBengali !== '—'
      ? `${pos.positionBengali} / ${toBengaliNum(allStudents.length)}`
      : '—';
  }

  // Top Header Banner with large official logo in pt
  const headerHtml = `
    <div style="border-bottom: 2.25pt double #1e3a8a; padding-bottom: 9pt; margin-bottom: 10pt;">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 12pt;">
          ${getCommercePointLogoHtml(54, 54)}
          <div>
            <div style="font-size: 20pt; font-weight: 900; color: #1e3a8a; letter-spacing: -0.25pt; line-height: 23pt;">
              COMMERCE POINT
            </div>
            <div style="font-size: 10pt; font-weight: 700; color: #334155; margin-top: 2pt; line-height: 13pt;">
              একাডেমিক মূল্যায়ন ও শিক্ষার্থী অগ্রগতি পর্যবেক্ষণ কেন্দ্র
            </div>
            <div style="font-size: 8.5pt; font-weight: 600; color: #64748b; margin-top: 1pt; line-height: 11pt;">
              উচ্চ মাধ্যমিক বাণিজ্য বিভাগ শিক্ষা সহায়তা ও মূল্যায়ন কার্যক্রম
            </div>
          </div>
        </div>
        <div style="text-align: right;">
          <div style="background-color: #1e3a8a; color: #fde047; font-size: 9pt; font-weight: 800; padding: 3.5pt 10pt; border-radius: 4pt; border: 0.75pt solid #1e40af;">
            মাসিক একাডেমিক ফলাফল পত্র
          </div>
          <div style="font-size: 9pt; font-weight: 700; color: #0f172a; margin-top: 3.5pt; line-height: 12pt;">
            মাস: <strong style="color: #1e3a8a;">${monthLabel}</strong> · শিক্ষাবর্ষ: ২০২৬
          </div>
        </div>
      </div>
    </div>
  `;

    // Student Info Card
    const infoHtml = `
      <div style="background-color: #f8fafc; border: 0.75pt solid #cbd5e1; border-radius: 4pt; padding: 6pt 10pt; margin-bottom: 10pt;">
        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6pt; font-size: 7.5pt; line-height: 10pt;">
          <div>
            <span style="color: #64748b; font-weight: 600; display: block; font-size: 7pt; text-transform: uppercase;">শিক্ষার্থীর নাম</span>
            <div style="font-size: 9.5pt; font-weight: 800; color: #0f172a; margin-top: 1.5pt;">${student.name}</div>
          </div>
          <div>
            <span style="color: #64748b; font-weight: 600; display: block; font-size: 7pt; text-transform: uppercase;">Student ID</span>
            <div style="font-size: 8.5pt; font-family: monospace; font-weight: 700; color: #1e3a8a; margin-top: 1.5pt;">${studentIdCode}</div>
          </div>
          <div>
            <span style="color: #64748b; font-weight: 600; display: block; font-size: 7pt; text-transform: uppercase;">ক্লাস রোল নং</span>
            <div style="font-size: 9.5pt; font-weight: 800; color: #0f172a; margin-top: 1.5pt;">${toBengaliNum(student.roll)}</div>
          </div>
          <div>
            <span style="color: #64748b; font-weight: 600; display: block; font-size: 7pt; text-transform: uppercase;">শ্রেণি ও বিভাগ</span>
            <div style="font-size: 8.5pt; font-weight: 700; color: #0f172a; margin-top: 1.5pt;">${student.academicClass || 'একাদশ'} (${student.group || 'B-A'})</div>
          </div>
          <div>
            <span style="color: #64748b; font-weight: 600; display: block; font-size: 7pt; text-transform: uppercase;">মাসিক মেধা অবস্থান</span>
            <div style="font-size: 9.5pt; font-weight: 900; color: #1e3a8a; margin-top: 1.5pt;">${monthlyPosStr}</div>
          </div>
        </div>
      </div>
    `;

    // Exam Results Table Rows
    let tableRows = '';
    summary.examEntries.forEach((entry, idx) => {
      const isAbsent = entry.isAbsent;
      const targetExam = examsInMonth.find((e) => e.id === entry.examId);
      let examPosStr = '—';
      if (allStudents && targetExam) {
        const p = getStudentExamPosition(student.id, targetExam, allStudents);
        examPosStr = p.positionBengali;
      }

      tableRows += `
        <tr style="background-color: ${idx % 2 === 1 ? '#f8fafc' : '#ffffff'};">
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 7.5pt; font-weight: 600; color: #64748b;">
            ${toBengaliNum(idx + 1)}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 5pt; font-size: 8pt; font-weight: 800; color: #1e3a8a;">
            <span style="background-color: #dbeafe; color: #1e40af; padding: 1.5pt 4pt; border-radius: 2pt; font-size: 7.5pt;">${entry.subjectBengaliName || entry.subjectName}</span>
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 3.5pt; font-size: 7.5pt; color: #475569; text-align: center;">
            ${formatDisplayDate(entry.date)}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 4.5pt; font-size: 8pt; font-weight: 700; color: #0f172a;">
            ${entry.examName}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; font-weight: 800; color: #1e3a8a; background-color: #f1f5f9;">
            ${examPosStr}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; font-weight: 600; color: #334155;">
            ${toBengaliNum(entry.fullMarks)}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; color: #334155;">
            ${!isAbsent && entry.cq !== '' ? toBengaliNum(entry.cq) : '-'}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; color: #334155;">
            ${!isAbsent && entry.mcq !== '' ? toBengaliNum(entry.mcq) : '-'}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8.5pt; font-weight: 900; background-color: ${isAbsent ? '#fee2e2' : '#f8fafc'}; color: ${isAbsent ? '#dc2626' : '#0f172a'};">
            ${isAbsent ? 'অনুপস্থিত' : toBengaliNum(entry.total)}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; font-weight: 800; color: #059669; background-color: #ecfdf5;">
            ${isAbsent ? '-' : `${toBengaliNum(entry.percentage)}%`}
          </td>
          <td style="border: 0.75pt solid #cbd5e1; padding: 3pt 2.5pt; text-align: center; font-size: 8pt; font-weight: 900; color: ${entry.grade === 'A+' ? '#059669' : '#1e3a8a'};">
            ${isAbsent ? 'Absent' : entry.grade}
          </td>
        </tr>
      `;
    });

    const examsTableHtml = `
      <div style="margin-bottom: 10pt;">
        <div style="font-size: 8.5pt; font-weight: 800; color: #1e3a8a; margin-bottom: 4pt; border-bottom: 0.75pt solid #cbd5e1; padding-bottom: 2pt;">
          ১. পরীক্ষাভিত্তিক ফলাফল বিবরণী (Exam-by-Exam Results)
        </div>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #0f172a; color: #ffffff;">
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 2.5pt; font-size: 7.5pt; font-weight: 800; color: #fde047; text-align: center; width: 22pt;">ক্রম</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 4.5pt; font-size: 8pt; font-weight: 800; text-align: left; width: 68pt;">বিষয়</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 50pt;">তারিখ</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 4.5pt; font-size: 8pt; font-weight: 800; text-align: left;">পরীক্ষার নাম</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 38pt; color: #fde047;">অবস্থান</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 36pt;">পূর্ণমান</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 32pt;">CQ</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 32pt;">MCQ</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 42pt; background-color: #1e293b; color: #fde047;">মোট প্রাপ্ত</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 36pt;">শতকরা</th>
              <th style="border: 0.75pt solid #334155; padding: 3.5pt 3.5pt; font-size: 7.5pt; font-weight: 800; text-align: center; width: 30pt;">গ্রেড</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>
      </div>
    `;

    // Monthly Summary KPIs
    const kpiHtml = `
      <div style="background-color: #f1f5f9; border: 0.75pt solid #cbd5e1; border-radius: 4pt; padding: 6pt 10pt; margin-bottom: 10pt;">
        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 5pt; text-align: center;">
          <div style="background-color: #ffffff; border: 0.75pt solid #e2e8f0; border-radius: 3.5pt; padding: 4.5pt 6pt;">
            <div style="font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase;">মোট পরীক্ষা / উপস্থিতি</div>
            <div style="font-size: 13.5pt; font-weight: 900; color: #1e3a8a; margin-top: 1.5pt;">
              ${toBengaliNum(summary.overall.attendedExams)} / ${toBengaliNum(summary.overall.totalExamsInMonth)}
            </div>
            <div style="font-size: 7pt; color: #059669; font-weight: 700;">(${toBengaliNum(summary.overall.participationRate)}%)</div>
          </div>
          <div style="background-color: #ffffff; border: 0.75pt solid #e2e8f0; border-radius: 3.5pt; padding: 4.5pt 6pt;">
            <div style="font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase;">মোট প্রাপ্ত নম্বর</div>
            <div style="font-size: 13.5pt; font-weight: 900; color: #0f172a; margin-top: 1.5pt;">
              ${toBengaliNum(summary.overall.totalObtainedMarks)} / ${toBengaliNum(summary.overall.totalFullMarks)}
            </div>
            <div style="font-size: 7pt; color: #64748b;">পূর্ণমান</div>
          </div>
          <div style="background-color: #ffffff; border: 0.75pt solid #e2e8f0; border-radius: 3.5pt; padding: 4.5pt 6pt;">
            <div style="font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase;">গড় নম্বর</div>
            <div style="font-size: 13.5pt; font-weight: 900; color: #1e3a8a; margin-top: 1.5pt;">
              ${toBengaliNum(summary.overall.averageMarks)}
            </div>
            <div style="font-size: 7pt; color: #64748b;">প্রতি পরীক্ষায়</div>
          </div>
          <div style="background-color: #ffffff; border: 0.75pt solid #e2e8f0; border-radius: 3.5pt; padding: 4.5pt 6pt;">
            <div style="font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase;">গড় শতকরা হার</div>
            <div style="font-size: 13.5pt; font-weight: 900; color: #059669; margin-top: 1.5pt;">
              ${toBengaliNum(summary.overall.averagePercentage)}%
            </div>
            <div style="font-size: 7pt; color: #059669; font-weight: 700;">অর্জন হার</div>
          </div>
          <div style="background-color: #ffffff; border: 0.75pt solid #e2e8f0; border-radius: 3.5pt; padding: 4.5pt 6pt;">
            <div style="font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase;">চূড়ান্ত গ্রেড</div>
            <div style="font-size: 14pt; font-weight: 900; color: #1e3a8a; margin-top: 1.5pt;">
              ${summary.overall.overallGrade}
            </div>
            <div style="font-size: 7pt; color: #1e3a8a; font-weight: 700;">মানদণ্ড</div>
          </div>
        </div>
      </div>
    `;

    // Signatures Footer (margin-top: 8px for tight attachment on single page)
    const footerHtml = `
      <div style="margin-top: 8px; padding-top: 6px; page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid; width: 100%;">
        <div style="display: flex; justify-content: space-between; align-items: flex-end; font-size: 8pt; width: 100%;">
          <div style="text-align: center; width: 130pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2.5pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">শ্রেণি শিক্ষকের স্বাক্ষর</div>
          </div>
          <div style="text-align: center; font-size: 7.5pt; color: #94a3b8;">
            * অফিশিয়াল মাসিক ফলাফল বিবরণী
          </div>
          <div style="text-align: center; width: 150pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2.5pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</div>
          </div>
        </div>
        <div style="text-align: center; font-size: 6.5pt; color: #94a3b8; margin-top: 3pt;">
          * এটি COMMERCE POINT Academic Care কর্তৃক কম্পিউটার জেনারেটেড অফিশিয়াল মাসিক ফলাফল কার্ড।
        </div>
      </div>
    `;

    const cardHtml = `
      <div class="${pdfStyles.pdfPagePortrait} pdf-isolated-root" style="width: 595.28pt; min-height: 841.89pt; height: 841.89pt; padding: 18pt 22pt; box-sizing: border-box; background-color: #ffffff; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; page-break-inside: avoid; break-inside: avoid;">
        <div>
          ${headerHtml}
          ${infoHtml}
          ${kpiHtml}
          ${examsTableHtml}
        </div>
        ${footerHtml}
      </div>
    `;

    const safeName = sanitizeFileName(student.name);
    const safeMonth = sanitizeFileName(monthLabel);
    const fileName = `CP_Monthly_Result_${safeName}_${safeMonth}_2026.pdf`;
    const title = `${student.name} — মাসিক ফলাফল পত্র (${monthLabel})`;

    return await generateHighQualityPdf({
      pageHtmls: [cardHtml],
      orientation: 'portrait',
      fileName,
      title,
    });
}

// =========================================================================
// 3. INDIVIDUAL EXAM MARKSHEET PDF (Single Exam with Automatic Ranking)
// Clean Multi-Page Pagination: 16 students per page, no split rows
// =========================================================================
export async function exportSingleExamPdf(
  exam: Exam,
  students: Student[],
  subjectName?: string
): Promise<PdfPreviewData> {
  // Centralized Automatic Ranking: highest total marks first
  const rankedStudents = rankStudentsForExam(exam, students);

  // Strict Single-Page Auto-fit for up to 25-30 students
  const studentCount = rankedStudents.length;
  const STUDENTS_PER_PAGE = studentCount <= 30 ? Math.max(studentCount, 1) : 26;
  const totalPages = Math.max(1, Math.ceil(rankedStudents.length / STUDENTS_PER_PAGE));

  const pageHtmls: string[] = [];

  let attendedCount = 0;
  let absentCount = 0;
  rankedStudents.forEach((r) => {
    if (r.isAbsent) absentCount++;
    else attendedCount++;
  });

  // Dynamic Compact Spacing based on student count
  const isCompact = studentCount > 15;
  const isSuperCompact = studentCount > 22;
  const cellPy = isSuperCompact ? '1.5pt' : isCompact ? '2pt' : '3pt';
  const thPy = isCompact ? '2.5pt' : '3.5pt';
  const cellFontSize = isSuperCompact ? '7.5pt' : isCompact ? '8pt' : '8.5pt';
  const nameFontSize = isSuperCompact ? '8pt' : isCompact ? '8.5pt' : '9pt';
  const logoSize = isCompact ? 44 : 54;
  const pagePadding = isCompact ? '12pt 18pt' : '18pt 22pt';

  for (let pageIdx = 0; pageIdx < totalPages; pageIdx++) {
    const pageStudents = rankedStudents.slice(
      pageIdx * STUDENTS_PER_PAGE,
      (pageIdx + 1) * STUDENTS_PER_PAGE
    );

    const headerHtml = `
        <div style="border-bottom: 2.25pt double #1e3a8a; padding-bottom: ${isCompact ? '6pt' : '9pt'}; margin-bottom: ${isCompact ? '6pt' : '10pt'};">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 10pt;">
              ${getCommercePointLogoHtml(logoSize, logoSize)}
              <div>
                <div style="font-size: ${isCompact ? '18pt' : '20pt'}; font-weight: 900; color: #1e3a8a; letter-spacing: -0.25pt; line-height: ${isCompact ? '20pt' : '23pt'};">
                  COMMERCE POINT
                </div>
                <div style="font-size: ${isCompact ? '9pt' : '10pt'}; font-weight: 700; color: #334155; margin-top: 1pt; line-height: 12pt;">
                  একাডেমিক মূল্যায়ন ও মেধা তালিকা (Merit List)
                </div>
                <div style="font-size: 8pt; font-weight: 600; color: #64748b; margin-top: 0.5pt; line-height: 10pt;">
                  HSC Business Studies & Academic Care
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <div style="background-color: #1e3a8a; color: #fde047; font-size: ${isCompact ? '8pt' : '9pt'}; font-weight: 800; padding: ${isCompact ? '2.5pt 8pt' : '3.5pt 10pt'}; border-radius: 4pt; border: 0.75pt solid #1e40af;">
                অফিশিয়াল পরীক্ষার মার্কশিট
              </div>
              <div style="font-size: 8.5pt; font-weight: 700; color: #0f172a; margin-top: 2.5pt; line-height: 11pt;">
                ${subjectName ? `<span style="color: #1e3a8a; font-weight: 800;">${subjectName}</span> · ` : ''}তারিখ: ${formatDisplayDate(exam.date)}
              </div>
            </div>
          </div>
        </div>
      `;

      const examInfoHtml = `
        <div style="background-color: #f8fafc; border: 0.75pt solid #cbd5e1; border-radius: 4pt; padding: ${isCompact ? '4pt 8pt' : '6pt 10pt'}; margin-bottom: ${isCompact ? '6pt' : '10pt'};">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-size: ${isCompact ? '10pt' : '11pt'}; font-weight: 900; color: #0f172a;">${exam.name}</div>
              <div style="font-size: 7.5pt; color: #64748b; margin-top: 1pt;">
                পূর্ণমান: CQ ${toBengaliNum(exam.cqFullMarks)} + MCQ ${toBengaliNum(exam.mcqFullMarks)} = ${toBengaliNum(exam.totalFullMarks)} | মোট শিক্ষার্থী: ${toBengaliNum(students.length)} জন (উপস্থিত ${toBengaliNum(attendedCount)}, অনুপস্থিত ${toBengaliNum(absentCount)})
              </div>
            </div>
            <div style="text-align: right; background-color: #ffffff; padding: ${isCompact ? '2.5pt 6pt' : '3.5pt 8pt'}; border-radius: 3pt; border: 0.75pt solid #cbd5e1;">
              <span style="font-size: 7.5pt; color: #64748b; font-weight: 600;">গড় ফলাফল: </span>
              <span style="font-size: 9pt; font-weight: 900; color: #1e3a8a;">${toBengaliNum(exam.average)} / ${toBengaliNum(exam.totalFullMarks)}</span>
              <span style="font-size: 7.5pt; font-weight: 700; color: #059669; margin-left: 3pt;">(${toBengaliNum(exam.averagePercentage)}%)</span>
            </div>
          </div>
        </div>
      `;

      let rowsHtml = '';
      pageStudents.forEach((r, idx) => {
        const st = r.student;
        const studentIdCode = st.studentIdCode || `CP-${String(st.roll).padStart(3, '0')}`;
        const isAbsent = r.isAbsent;
        const medal = r.position === 1 ? '🥇 ' : r.position === 2 ? '🥈 ' : r.position === 3 ? '🥉 ' : '';

        rowsHtml += `
          <tr style="background-color: ${idx % 2 === 1 ? '#f8fafc' : '#ffffff'}; line-height: 1.15;" class="leading-tight">
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2.5pt; text-align: center; font-size: ${cellFontSize}; font-weight: 900; color: #1e3a8a; background-color: #f1f5f9;">
              ${isAbsent ? '—' : `${medal}${r.positionBengali}`}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 4.5pt; font-size: ${nameFontSize}; font-weight: 700; color: #0f172a; white-space: nowrap;">
              ${st.name}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; font-size: ${isCompact ? '7pt' : '7.5pt'}; font-family: monospace; font-weight: 600; color: #475569; text-align: center;">
              ${studentIdCode}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 2pt; font-size: ${cellFontSize}; text-align: center; color: #475569;">
              ${toBengaliNum(st.roll)}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; text-align: center; font-size: ${cellFontSize}; color: #334155;">
              ${!isAbsent && r.cq !== '' ? toBengaliNum(r.cq) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; text-align: center; font-size: ${cellFontSize}; color: #334155;">
              ${!isAbsent && r.mcq !== '' ? toBengaliNum(r.mcq) : '-'}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; text-align: center; font-size: ${nameFontSize}; font-weight: 900; color: #0f172a; background-color: #f1f5f9;">
              ${isAbsent ? '<span style="color: #dc2626;">অনুপস্থিত</span>' : toBengaliNum(r.total)}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; text-align: center; font-size: ${cellFontSize}; font-weight: 800; color: #059669; background-color: #ecfdf5;">
              ${isAbsent ? '-' : `${toBengaliNum(r.percentage)}%`}
            </td>
            <td style="border: 0.75pt solid #cbd5e1; padding: ${cellPy} 3pt; text-align: center; font-size: ${cellFontSize}; font-weight: 900; color: ${r.grade === 'A+' ? '#059669' : '#1e3a8a'};">
              ${isAbsent ? 'Absent' : r.grade}
            </td>
          </tr>
        `;
      });

      const tableHtml = `
        <div style="margin-bottom: ${isCompact ? '4pt' : '8pt'};">
          <table style="width: 100%; border-collapse: collapse; font-size: 8pt; line-height: 1.15;" class="leading-tight">
            <thead>
              <tr style="background-color: #0f172a; color: #ffffff;">
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 2.5pt; width: 44pt; text-align: center; font-weight: 900; color: #fde047;">মেধাক্রম / Position</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 4.5pt; text-align: left;">শিক্ষার্থীর নাম</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3.5pt; text-align: center; width: 72pt;">Student ID</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 2.5pt; text-align: center; width: 28pt;">রোল</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3pt; text-align: center; width: 34pt;">CQ (${toBengaliNum(exam.cqFullMarks)})</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3pt; text-align: center; width: 34pt;">MCQ (${toBengaliNum(exam.mcqFullMarks)})</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3pt; text-align: center; width: 42pt; background-color: #1e293b; color: #fde047;">মোট (${toBengaliNum(exam.totalFullMarks)})</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3pt; text-align: center; width: 34pt;">শতকরা</th>
                <th style="border: 0.75pt solid #334155; padding: ${thPy} 3pt; text-align: center; width: 30pt;">গ্রেড</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>
      `;

      // Page Footer with Teacher and Principal/Director Signatures (margin-top: 8px)
      const footerHtml = `
        <div style="margin-top: 8px; padding-top: 6px; page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid; width: 100%;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end; font-size: 8pt; width: 100%;">
            <div style="text-align: center; width: 130pt;">
              <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2pt;"></div>
              <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">শ্রেণি শিক্ষকের স্বাক্ষর</div>
            </div>
            <div style="text-align: center; font-size: 7.5pt; color: #64748b;">
              পৃষ্ঠা ${toBengaliNum(pageIdx + 1)} / ${toBengaliNum(totalPages)}
            </div>
            <div style="text-align: center; width: 150pt;">
              <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 2pt;"></div>
              <div style="font-weight: 700; color: #0f172a; font-size: 8pt;">পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</div>
            </div>
          </div>
          <div style="text-align: center; font-size: 6.5pt; color: #94a3b8; margin-top: 3pt;">
            * এটি একটি স্বয়ংক্রিয় মেধা ক্রমতালিকা অনুযায়ী প্রস্তুতকৃত রেজাল্ট শিট।
          </div>
        </div>
      `;

      const pageHtml = `
        <div class="${pdfStyles.pdfPagePortrait} pdf-isolated-root" style="width: 595.28pt; min-height: 841.89pt; height: 841.89pt; padding: ${pagePadding}; box-sizing: border-box; background-color: #ffffff; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; page-break-inside: avoid; break-inside: avoid;">
          <div>
            ${headerHtml}
            ${examInfoHtml}
            ${tableHtml}
          </div>
          ${footerHtml}
        </div>
      `;
      pageHtmls.push(pageHtml);
    }

    const safeName = sanitizeFileName(exam.name);
    const fileName = `CP_Marksheet_${safeName}_${exam.date}.pdf`;
    const title = `${exam.name} — অফিশিয়াল মার্কশিট`;

    return await generateHighQualityPdf({
      pageHtmls,
      orientation: 'portrait',
      fileName,
      title,
    });
}

// =========================================================================
// 4. STUDENT MONTHLY / COMPLETE PROGRESS ANALYSIS PDF
// Supports single selected month or complete all-months academic progress report.
// Clean pagination: Page 1 (Summary + Subjects), Page 2 (Detailed Exams) if long.
// =========================================================================
export async function exportStudentMonthlyProgressReportPdf(
  student: Student,
  exams: Exam[],
  monthLabel: string,
  subjects: Subject[],
  allStudents?: Student[],
  isCompleteReport: boolean = false
): Promise<PdfPreviewData> {
  await ensureFontsReady();
  const logoDataUrl = await getCommercePointLogoBase64();

  const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  const sortedExams = [...exams].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  let attendedCount = 0;
  let absentCount = 0;
  let totalObtained = 0;
  let totalFull = 0;
  const distinctSubjects = new Set<string>();

  const subMap = new Map<string, {
    subjectName: string;
    examsCount: number;
    attendedCount: number;
    cqTotal: number;
    mcqTotal: number;
    obtainedTotal: number;
    fullTotal: number;
  }>();

  const examRows: {
    subjectName: string;
    date: string;
    examName: string;
    cq: number | string;
    mcq: number | string;
    total: number | string;
    fullMarks: number;
    percentage: number | string;
    grade: string;
    positionBengali: string;
    isAbsent: boolean;
  }[] = [];

  sortedExams.forEach((exam) => {
    const subId = exam.subjectId || 'ict';
    const subObj = subjectMap.get(subId);
    const subName = subObj ? subObj.name : subId.toUpperCase();
    distinctSubjects.add(subId);

    if (!subMap.has(subId)) {
      subMap.set(subId, {
        subjectName: subName,
        examsCount: 0,
        attendedCount: 0,
        cqTotal: 0,
        mcqTotal: 0,
        obtainedTotal: 0,
        fullTotal: 0,
      });
    }
    const subStat = subMap.get(subId)!;
    subStat.examsCount++;

    const mark = exam.marks ? exam.marks[student.id] : undefined;
    const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

    let examPos = '—';
    if (allStudents && allStudents.length > 0) {
      const p = getStudentExamPosition(student.id, exam, allStudents);
      examPos = p.positionBengali;
    }

    if (!isAbsent && mark) {
      attendedCount++;
      const tot = Number(mark.total) || 0;
      totalObtained += tot;
      totalFull += exam.totalFullMarks;

      const cqVal = mark.cq !== '' ? Number(mark.cq) : 0;
      const mcqVal = mark.mcq !== '' ? Number(mark.mcq) : 0;

      subStat.attendedCount++;
      subStat.cqTotal += cqVal;
      subStat.mcqTotal += mcqVal;
      subStat.obtainedTotal += tot;
      subStat.fullTotal += exam.totalFullMarks;

      examRows.push({
        subjectName: subName,
        date: exam.date,
        examName: exam.name,
        cq: mark.cq !== '' ? mark.cq : 0,
        mcq: mark.mcq !== '' ? mark.mcq : 0,
        total: tot,
        fullMarks: exam.totalFullMarks,
        percentage: Number(mark.percentage) || 0,
        grade: mark.grade || 'F',
        positionBengali: examPos,
        isAbsent: false,
      });
    } else {
      absentCount++;
      examRows.push({
        subjectName: subName,
        date: exam.date,
        examName: exam.name,
        cq: '—',
        mcq: '—',
        total: 'অনুপস্থিত',
        fullMarks: exam.totalFullMarks,
        percentage: '—',
        grade: 'Absent',
        positionBengali: '—',
        isAbsent: true,
      });
    }
  });

  const avgMarks = attendedCount > 0 ? Number((totalObtained / attendedCount).toFixed(1)) : 0;
  const avgPct = totalFull > 0 ? Math.round((totalObtained / totalFull) * 100) : 0;
  const participationRate = sortedExams.length > 0 ? Math.round((attendedCount / sortedExams.length) * 100) : 0;

  let overallGrade = 'F';
  if (avgPct >= 80) overallGrade = 'A+';
  else if (avgPct >= 70) overallGrade = 'A';
  else if (avgPct >= 60) overallGrade = 'A-';
  else if (avgPct >= 50) overallGrade = 'B';
  else if (avgPct >= 40) overallGrade = 'C';
  else if (avgPct >= 33) overallGrade = 'D';
  if (attendedCount === 0) overallGrade = 'Absent';

  let monthlyPosStr = '—';
  if (allStudents && allStudents.length > 0 && exams.length > 0) {
    const pos = getStudentMonthlyPosition(student.id, exams, allStudents);
    monthlyPosStr = pos.positionBengali !== '—'
      ? `${pos.positionBengali} / ${toBengaliNum(allStudents.length)}`
      : '—';
  }

  // Paging logic: if complete report or examRows > 8, split into 2 pages so everything is legible
  const isMultiPage = examRows.length > 8;
  const totalPages = isMultiPage ? 2 : 1;

  const pageHtmls: string[] = [];

  const renderHeader = () => `
      <div style="border-bottom: 2.25pt double #1e3a8a; padding-bottom: 9pt; margin-bottom: 10pt;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div style="display: flex; align-items: center; gap: 12pt;">
            ${getCommercePointLogoHtml(54, 54)}
            <div>
              <h1 style="font-size: 20pt; font-weight: 900; color: #1e3a8a; margin: 0; letter-spacing: -0.25pt; line-height: 23pt;">COMMERCE POINT</h1>
              <p style="font-size: 9.5pt; font-weight: 700; color: #b45309; margin: 2pt 0 0 0; line-height: 12pt;">HSC Business Studies & Academic Care</p>
              <p style="font-size: 8pt; color: #64748b; margin: 1pt 0 0 0; line-height: 10.5pt;">উচ্চ মাধ্যমিক বাণিজ্য বিভাগ শিক্ষা সহায়তা ও মূল্যায়ন কার্যক্রম</p>
            </div>
          </div>
          <div style="text-align: right; background: #f8fafc; border: 0.75pt solid #cbd5e1; padding: 4pt 10pt; border-radius: 4pt;">
            <div style="font-size: 9pt; font-weight: 800; color: #1e3a8a;">
              ${isCompleteReport ? 'সার্বিক একাডেমিক অগ্রগতি বিবরণী' : 'মাসিক অগ্রগতি বিশ্লেষণ ও রেজাল্ট শিট'}
            </div>
            <div style="font-size: 8pt; font-weight: 700; color: #047857; margin-top: 1.5pt;">
              সময়কাল: ${monthLabel}
            </div>
          </div>
        </div>
      </div>
    `;

    const renderStudentInfo = () => `
      <div style="background-color: #f8fafc; border: 0.75pt solid #cbd5e1; border-radius: 4pt; padding: 6pt 10pt; margin-bottom: 8pt; display: grid; grid-template-columns: repeat(4, 1fr); gap: 6pt; font-size: 7.5pt; line-height: 10pt;">
        <div>
          <span style="color: #64748b; display: block; font-size: 7pt; text-transform: uppercase;">শিক্ষার্থীর নাম</span>
          <span style="font-weight: 800; color: #0f172a; font-size: 9.5pt;">${student.name}</span>
        </div>
        <div>
          <span style="color: #64748b; display: block; font-size: 7pt; text-transform: uppercase;">স্টুডেন্ট আইডি / রোল</span>
          <span style="font-weight: 800; color: #1e3a8a; font-size: 8.5pt; font-family: monospace;">${studentIdCode} (রোল: ${toBengaliNum(student.roll)})</span>
        </div>
        <div>
          <span style="color: #64748b; display: block; font-size: 7pt; text-transform: uppercase;">শ্রেণি · গ্রুপ · সেশন</span>
          <span style="font-weight: 700; color: #334155; font-size: 8.5pt;">${student.academicClass || 'XI'} · ${student.group || 'B-A'} (${student.session || '2026'})</span>
        </div>
        <div style="text-align: right;">
          <span style="color: #64748b; display: block; font-size: 7pt; text-transform: uppercase;">সার্বিক মেধা অবস্থান</span>
          <span style="font-weight: 900; color: #b45309; font-size: 9.5pt;">${monthlyPosStr}</span>
        </div>
      </div>
    `;

    const renderKpis = () => `
      <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 5pt; margin-bottom: 10pt;">
        <div style="background: #eff6ff; border: 0.75pt solid #bfdbfe; border-radius: 3.5pt; padding: 4.5pt 6pt; text-align: center;">
          <span style="font-size: 7pt; color: #1e40af; display: block; text-transform: uppercase;">মোট বিষয় / পরীক্ষা</span>
          <span style="font-size: 13.5pt; font-weight: 800; color: #1e3a8a; line-height: 16pt;">${toBengaliNum(distinctSubjects.size)} / ${toBengaliNum(sortedExams.length)}</span>
        </div>
        <div style="background: #f0fdf4; border: 0.75pt solid #bbf7d0; border-radius: 3.5pt; padding: 4.5pt 6pt; text-align: center;">
          <span style="font-size: 7pt; color: #166534; display: block; text-transform: uppercase;">উপস্থিতি হার</span>
          <span style="font-size: 13.5pt; font-weight: 800; color: #15803d; line-height: 16pt;">${toBengaliNum(attendedCount)} (${toBengaliNum(participationRate)}%)</span>
        </div>
        <div style="background: #fefce8; border: 0.75pt solid #fef08a; border-radius: 3.5pt; padding: 4.5pt 6pt; text-align: center;">
          <span style="font-size: 7pt; color: #854d0e; display: block; text-transform: uppercase;">মোট প্রাপ্ত নম্বর</span>
          <span style="font-size: 13.5pt; font-weight: 800; color: #a16207; line-height: 16pt;">${toBengaliNum(totalObtained)} / ${toBengaliNum(totalFull)}</span>
        </div>
        <div style="background: #faf5ff; border: 0.75pt solid #e9d5ff; border-radius: 3.5pt; padding: 4.5pt 6pt; text-align: center;">
          <span style="font-size: 7pt; color: #6b21a8; display: block; text-transform: uppercase;">গড় ও শতকরা</span>
          <span style="font-size: 13.5pt; font-weight: 800; color: #7e22ce; line-height: 16pt;">${toBengaliNum(avgMarks)} (${toBengaliNum(avgPct)}%)</span>
        </div>
        <div style="background: #fff1f2; border: 0.75pt solid #fecdd3; border-radius: 3.5pt; padding: 4.5pt 6pt; text-align: center;">
          <span style="font-size: 7pt; color: #9f1239; display: block; text-transform: uppercase;">চূড়ান্ত গ্রেড</span>
          <span style="font-size: 14pt; font-weight: 900; color: #be123c; line-height: 16pt;">${overallGrade}</span>
        </div>
      </div>
    `;

    let subRowsHtml = '';
    Array.from(subMap.entries()).forEach(([_, stat], idx) => {
      const pct = stat.fullTotal > 0 ? Math.round((stat.obtainedTotal / stat.fullTotal) * 100) : 0;
      const grade = calculateGrade(pct);
      const bg = idx % 2 === 1 ? '#f8fafc' : '#ffffff';
      subRowsHtml += `
        <tr style="background-color: ${bg}; border-bottom: 0.75pt solid #e2e8f0; font-size: 8pt;">
          <td style="padding: 3pt 4.5pt; font-weight: 700; color: #1e3a8a;">${stat.subjectName}</td>
          <td style="padding: 3pt 3.5pt; text-align: center;">${toBengaliNum(stat.attendedCount)} / ${toBengaliNum(stat.examsCount)}</td>
          <td style="padding: 3pt 3.5pt; text-align: center;">${stat.attendedCount > 0 ? toBengaliNum(stat.cqTotal) : '—'}</td>
          <td style="padding: 3pt 3.5pt; text-align: center;">${stat.attendedCount > 0 ? toBengaliNum(stat.mcqTotal) : '—'}</td>
          <td style="padding: 3pt 3.5pt; text-align: center; font-weight: 800; color: #0f172a;">${stat.attendedCount > 0 ? toBengaliNum(stat.obtainedTotal) : '—'}</td>
          <td style="padding: 3pt 3.5pt; text-align: center; color: #64748b;">${toBengaliNum(stat.fullTotal)}</td>
          <td style="padding: 3pt 3.5pt; text-align: center; font-weight: 700; color: #047857;">${stat.attendedCount > 0 ? `${toBengaliNum(pct)}%` : '—'}</td>
          <td style="padding: 3pt 3.5pt; text-align: center; font-weight: 800;">${grade}</td>
        </tr>
      `;
    });

    const subTableHtml = `
      <div style="margin-bottom: 10pt;">
        <div style="font-size: 8.5pt; font-weight: 800; color: #1e3a8a; margin-bottom: 3pt; border-bottom: 0.75pt solid #cbd5e1; padding-bottom: 2pt;">
          ১. বিষয়ভিত্তিক ফলাফল সারসংক্ষেপ (Subject Performance Summary)
        </div>
        <table style="width: 100%; border-collapse: collapse; border: 0.75pt solid #cbd5e1;">
          <thead>
            <tr style="background-color: #1e3a8a; color: #ffffff; font-size: 7.5pt; font-weight: 700;">
              <th style="padding: 3.5pt 4.5pt; text-align: left;">বিষয় (Subject)</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">পরীক্ষা সংখ্যা</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">মোট CQ</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">মোট MCQ</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">প্রাপ্ত মোট</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">পূর্ণমান</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">শতকরা (%)</th>
              <th style="padding: 3.5pt 3.5pt; text-align: center;">গ্রেড</th>
            </tr>
          </thead>
          <tbody>
            ${subRowsHtml}
          </tbody>
        </table>
      </div>
    `;

    const renderExamTable = (rows: typeof examRows, titleStr: string) => {
      let examDetailRowsHtml = '';
      rows.forEach((r, idx) => {
        const bg = idx % 2 === 1 ? '#f8fafc' : '#ffffff';
        examDetailRowsHtml += `
          <tr style="background-color: ${bg}; border-bottom: 0.75pt solid #e2e8f0; font-size: 7.5pt;">
            <td style="padding: 2.5pt 4.5pt; color: #475569; white-space: nowrap;">${formatDisplayDate(r.date)}</td>
            <td style="padding: 2.5pt 4.5pt; font-weight: 700; color: #1e3a8a;">${r.subjectName}</td>
            <td style="padding: 2.5pt 4.5pt; color: #1e293b;">${r.examName}</td>
            <td style="padding: 2.5pt 3.5pt; text-align: center; font-weight: 800; color: #b45309; background-color: #fefce8;">${r.positionBengali}</td>
            <td style="padding: 2.5pt 3.5pt; text-align: center;">${r.isAbsent ? '—' : toBengaliNum(r.cq)}</td>
            <td style="padding: 2.5pt 3.5pt; text-align: center;">${r.isAbsent ? '—' : toBengaliNum(r.mcq)}</td>
            <td style="padding: 2.5pt 3.5pt; text-align: center; font-weight: 800; color: ${r.isAbsent ? '#e11d48' : '#0f172a'};">
              ${r.isAbsent ? 'অনুপস্থিত' : toBengaliNum(r.total)}
            </td>
            <td style="padding: 2.5pt 3.5pt; text-align: center; color: #64748b;">${toBengaliNum(r.fullMarks)}</td>
            <td style="padding: 2.5pt 3.5pt; text-align: center; font-weight: 700; color: #047857;">
              ${r.isAbsent ? '—' : `${toBengaliNum(r.percentage)}%`}
            </td>
            <td style="padding: 2.5pt 3.5pt; text-align: center; font-weight: 800;">${r.grade}</td>
          </tr>
        `;
      });

      return `
        <div style="margin-bottom: 10pt;">
          <div style="font-size: 8.5pt; font-weight: 800; color: #1e3a8a; margin-bottom: 3pt; border-bottom: 0.75pt solid #cbd5e1; padding-bottom: 2pt;">
            ${titleStr}
          </div>
          <table style="width: 100%; border-collapse: collapse; border: 0.75pt solid #cbd5e1;">
            <thead>
              <tr style="background-color: #0f172a; color: #ffffff; font-size: 7.5pt; font-weight: 700;">
                <th style="padding: 3.5pt 4.5pt; text-align: left;">তারিখ</th>
                <th style="padding: 3.5pt 4.5pt; text-align: left;">বিষয়</th>
                <th style="padding: 3.5pt 4.5pt; text-align: left;">পরীক্ষার নাম</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center; background-color: #b45309; color: #ffffff;">অবস্থান</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">CQ</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">MCQ</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">মোট নম্বর</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">পূর্ণমান</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">শতকরা</th>
                <th style="padding: 3.5pt 3.5pt; text-align: center;">গ্রেড</th>
              </tr>
            </thead>
            <tbody>
              ${examDetailRowsHtml}
            </tbody>
          </table>
        </div>
      `;
    };

    const renderFooter = (pageNumber: number) => `
      <div style="margin-top: auto; padding-top: 8pt; page-break-before: avoid; break-before: avoid; width: 100%;">
        <div style="display: flex; justify-content: space-between; align-items: flex-end; font-size: 8pt; width: 100%;">
          <div style="text-align: center; width: 140pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 3.5pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8.5pt;">শ্রেণি শিক্ষকের স্বাক্ষর</div>
          </div>
          <div style="text-align: center; font-size: 7.5pt; color: #64748b;">
            পৃষ্ঠা ${toBengaliNum(pageNumber)} / ${toBengaliNum(totalPages)}
          </div>
          <div style="text-align: center; width: 160pt;">
            <div style="border-top: 1pt dotted #475569; width: 100%; margin-bottom: 3.5pt;"></div>
            <div style="font-weight: 700; color: #0f172a; font-size: 8.5pt;">পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</div>
          </div>
        </div>
        <div style="text-align: center; font-size: 7pt; color: #94a3b8; margin-top: 5pt;">
          * এটি COMMERCE POINT Academic Care কর্তৃক কম্পিউটার জেনারেটেড অফিশিয়াল প্রগ্রেস কার্ড।
        </div>
      </div>
    `;

    for (let page = 1; page <= totalPages; page++) {
      let pageContent = '';
      if (page === 1) {
        const rowsForPage1 = isMultiPage ? examRows.slice(0, 6) : examRows;
        pageContent = `
          <div>
            ${renderHeader()}
            ${renderStudentInfo()}
            ${renderKpis()}
            ${subTableHtml}
            ${renderExamTable(rowsForPage1, '২. পরীক্ষা ভিত্তিক বিস্তারিত মূল্যায়ন (Exam Breakdown)')}
          </div>
          ${renderFooter(1)}
        `;
      } else {
        const rowsForPage2 = examRows.slice(6);
        pageContent = `
          <div>
            ${renderHeader()}
            ${renderStudentInfo()}
            ${renderExamTable(rowsForPage2, '২. পরীক্ষা ভিত্তিক বিস্তারিত মূল্যায়ন (চলমান / Continued)')}
          </div>
          ${renderFooter(2)}
        `;
      }

      const pageHtml = `
        <div class="${pdfStyles.pdfPagePortrait} pdf-isolated-root" style="width: 595.28pt; min-height: 841.89pt; height: 841.89pt; padding: 20pt 24pt; box-sizing: border-box; background-color: #ffffff; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden;">
          ${pageContent}
        </div>
      `;
      pageHtmls.push(pageHtml);
    }

    const safeName = sanitizeFileName(student.name);
    const safePeriod = sanitizeFileName(monthLabel);
    const fileName = isCompleteReport
      ? `CP_Complete_Progress_${safeName}_2026.pdf`
      : `CP_Student_Progress_${safeName}_${safePeriod}_2026.pdf`;
    const title = `${student.name} — ${isCompleteReport ? 'সার্বিক একাডেমিক অগ্রগতি' : 'মাসিক অগ্রগতি'}`;

    return await generateHighQualityPdf({
      pageHtmls,
      orientation: 'portrait',
      fileName,
      title,
    });
}

// =========================================================================
// 5. STUDENT PROGRESS REPORT CARD PDF (ACADEMIC PROGRESS CARD MODAL)
// Captures single-page report card with high-DPI scaling and opens PDF preview
// =========================================================================
export async function exportStudentProgressCardPdfFromElement(
  element: HTMLElement,
  fileName: string,
  title: string,
  isLandscape: boolean = false
): Promise<PdfPreviewData> {
  await ensureFontsReady();

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    windowWidth: 1150,
  });

  const imgData = canvas.toDataURL('image/png');
  const pdf = new jsPDF({
    orientation: isLandscape ? 'landscape' : 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();
  const imgHeight = (canvas.height * pdfWidth) / canvas.width;

  // Force single page fit if the calculated height exceeds A4 height by less than 18%:
  if (imgHeight > pdfHeight && imgHeight <= pdfHeight * 1.18) {
    // Scale proportionally to fit within 1 single page without multi-page split
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
  } else {
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
  }

  const blob = pdf.output('blob');
  const objectUrl = URL.createObjectURL(blob);

  const result: PdfPreviewData = {
    blob,
    objectUrl,
    fileName,
    title,
    totalPages: 1,
    orientation: isLandscape ? 'landscape' : 'portrait',
    pageImages: [imgData],
    pageHtmls: [element.outerHTML],
    onPrint: () => window.print(),
  };

  showPdfPreview(result);
  return result;
}
