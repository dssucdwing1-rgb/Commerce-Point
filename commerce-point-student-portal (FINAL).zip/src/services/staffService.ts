import { supabase } from '../supabase';
import { StaffMember } from '../types';

const STAFF_STORAGE_KEY = 'cp_staff_members_v1';

// Default initial staff member seed for offline fallback & demo
const DEFAULT_STAFF_MEMBERS: StaffMember[] = [
  {
    id: 'd9b8a7c6-1e2f-4a5b-8c9d-0e1f2a3b4c5d',
    name: 'অপারেটর ১ (Staff 1)',
    email: 'staff1@student.commercepoint.app',
    phone: '01700000001',
    is_active: true,
    created_at: new Date('2026-01-01').toISOString(),
  },
];

/**
 * Loads staff members from localStorage cache
 */
export function loadStaffFromStorage(): StaffMember[] {
  try {
    const raw = localStorage.getItem(STAFF_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load staff members from storage:', err);
  }
  return DEFAULT_STAFF_MEMBERS;
}

/**
 * Saves staff members to localStorage cache
 */
export function saveStaffToStorage(staffList: StaffMember[]): void {
  try {
    localStorage.setItem(STAFF_STORAGE_KEY, JSON.stringify(staffList));
  } catch (err) {
    console.warn('Failed to save staff members to storage:', err);
  }
}

/**
 * Fetches staff members from Supabase `staff_members` table
 * and synchronizes with the local cache.
 */
export async function fetchStaffMembers(): Promise<StaffMember[]> {
  const localList = loadStaffFromStorage();

  try {
    const { data: dbStaff, error } = await supabase
      .from('staff_members')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && Array.isArray(dbStaff) && dbStaff.length > 0) {
      const mappedDbStaff: StaffMember[] = dbStaff.map((row) => ({
        id: String(row.id),
        name: row.name || 'স্টাফ অপারেটর',
        email: (row.email || '').toLowerCase(),
        phone: row.phone || '',
        is_active: row.is_active !== false,
        created_at: row.created_at || new Date().toISOString(),
        updated_at: row.updated_at,
      }));

      // Merge with any local offline additions that might not yet be in DB
      const mergedMap = new Map<string, StaffMember>();
      localList.forEach((s) => mergedMap.set(s.email.toLowerCase(), s));
      mappedDbStaff.forEach((s) => mergedMap.set(s.email.toLowerCase(), s));

      const mergedList = Array.from(mergedMap.values());
      saveStaffToStorage(mergedList);
      return mergedList;
    }
  } catch (err) {
    console.warn('Error fetching staff_members from Supabase:', err);
  }

  return localList;
}

/**
 * Formats or normalizes staff email
 * E.g., "staff2" -> "staff2@student.commercepoint.app"
 */
export function normalizeStaffEmail(input: string): string {
  const clean = input.trim().toLowerCase();
  if (!clean.includes('@')) {
    return `${clean}@student.commercepoint.app`;
  }
  return clean;
}

/**
 * Validates staff email format:
 * Must start with "staff" and have a valid email format.
 */
export function validateStaffEmail(email: string): { isValid: boolean; error?: string } {
  const clean = email.trim().toLowerCase();
  if (!clean) {
    return { isValid: false, error: 'স্টাফ ইমেইল লিখুন।' };
  }
  if (!clean.startsWith('staff')) {
    return {
      isValid: false,
      error: 'স্টাফ ইমেইল অবশ্যই "staff" দিয়ে শুরু হতে হবে (যেমন: staff1@student.commercepoint.app)।',
    };
  }
  if (!clean.includes('@') || !clean.includes('.')) {
    return {
      isValid: false,
      error: 'সঠিক ইমেইল ফরম্যাট প্রদান করুন (যেমন: staff2@student.commercepoint.app)।',
    };
  }
  return { isValid: true };
}

/**
 * Admin creates a new staff member:
 * 1. Validates inputs
 * 2. Triggers supabase.rpc('admin_create_staff', { ... })
 * 3. Registers / auto-provisions user via supabase.auth.signUp if necessary
 * 4. Upserts to Supabase `staff_members` table
 * 5. Updates local storage cache
 */
export async function createStaffMember(params: {
  name: string;
  email: string;
  password: string;
  phone?: string;
}): Promise<{ success: boolean; staff?: StaffMember; message: string }> {
  const cleanName = params.name.trim();
  const cleanEmail = normalizeStaffEmail(params.email);
  const cleanPassword = params.password.trim();
  const cleanPhone = (params.phone || '').trim();

  if (!cleanName) {
    return { success: false, message: 'স্টাফের নাম প্রদান করুন।' };
  }

  const emailVal = validateStaffEmail(cleanEmail);
  if (!emailVal.isValid) {
    return { success: false, message: emailVal.error || 'সঠিক স্টাফ ইমেইল প্রদান করুন।' };
  }

  if (!cleanPassword || cleanPassword.length < 6) {
    return { success: false, message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' };
  }

  // Check for duplicate email in local cache
  const localList = loadStaffFromStorage();
  const exists = localList.some((s) => s.email.toLowerCase() === cleanEmail.toLowerCase());
  if (exists) {
    return { success: false, message: 'এই ইমেইল দিয়ে ইতোমধ্যে একজন স্টাফ যুক্ত রয়েছেন।' };
  }

  let createdId = crypto.randomUUID ? crypto.randomUUID() : `staff_${Date.now()}`;
  let rpcSuccess = false;
  let rpcMessage = '';

  // 1. Trigger supabase.rpc('admin_create_staff')
  try {
    const { data: rpcData, error: rpcError } = await supabase.rpc('admin_create_staff', {
      staff_name: cleanName,
      staff_email: cleanEmail,
      staff_password: cleanPassword,
      staff_phone: cleanPhone,
    });

    if (rpcError) {
      console.warn('admin_create_staff RPC error:', rpcError);
      rpcMessage = rpcError.message;
    } else if (rpcData) {
      rpcSuccess = rpcData.success !== false;
      rpcMessage = rpcData.message || '';
      if (rpcData.staff_id || rpcData.id) {
        createdId = rpcData.staff_id || rpcData.id;
      }
    }
  } catch (err: any) {
    console.warn('admin_create_staff RPC exception:', err);
    rpcMessage = err?.message || '';
  }

  // 2. Also register in Supabase Auth GoTrue so staff can securely sign in with password
  try {
    await supabase.auth.signUp({
      email: cleanEmail,
      password: cleanPassword,
      options: {
        data: {
          role: 'staff',
          name: cleanName,
          phone: cleanPhone,
          username: cleanEmail.split('@')[0],
        },
      },
    });
  } catch (authErr) {
    console.warn('GoTrue signUp for staff note:', authErr);
  }

  // 3. Upsert into Supabase `staff_members` table
  try {
    await supabase.from('staff_members').upsert(
      {
        id: createdId,
        name: cleanName,
        email: cleanEmail,
        phone: cleanPhone,
        is_active: true,
        created_at: new Date().toISOString(),
      },
      { onConflict: 'email' }
    );
  } catch (dbErr) {
    console.warn('staff_members direct upsert note:', dbErr);
  }

  // 4. Update local cache
  const newStaff: StaffMember = {
    id: createdId,
    name: cleanName,
    email: cleanEmail,
    phone: cleanPhone,
    is_active: true,
    created_at: new Date().toISOString(),
  };

  const updatedList = [newStaff, ...localList.filter((s) => s.email.toLowerCase() !== cleanEmail.toLowerCase())];
  saveStaffToStorage(updatedList);

  return {
    success: true,
    staff: newStaff,
    message: rpcMessage || 'নতুন স্টাফ সফলভাবে তৈরি হয়েছে!',
  };
}

/**
 * Toggles a staff member's active/inactive status:
 * If deactivated, staff is blocked from logging in or entering marks.
 */
export async function toggleStaffStatus(
  staffId: string,
  staffEmail: string,
  currentStatus: boolean
): Promise<{ success: boolean; newStatus: boolean; message: string }> {
  const newStatus = !currentStatus;

  // 1. Update in Supabase `staff_members` table
  try {
    const { error } = await supabase
      .from('staff_members')
      .update({ is_active: newStatus, updated_at: new Date().toISOString() })
      .or(`id.eq.${staffId},email.eq.${staffEmail}`);

    if (error) {
      console.warn('Supabase toggle staff error:', error);
    }
  } catch (err) {
    console.warn('Supabase toggle staff exception:', err);
  }

  // 2. Update local storage cache
  const localList = loadStaffFromStorage();
  const updatedList = localList.map((s) => {
    if (s.id === staffId || s.email.toLowerCase() === staffEmail.toLowerCase()) {
      return { ...s, is_active: newStatus };
    }
    return s;
  });
  saveStaffToStorage(updatedList);

  return {
    success: true,
    newStatus,
    message: newStatus ? 'স্টাফ অ্যাকাউন্ট সক্রিয় করা হয়েছে।' : 'স্টাফ অ্যাকাউন্ট নিষ্ক্রিয় করা হয়েছে।',
  };
}

/**
 * Admin permanently deletes a staff member:
 * Calls `supabase.rpc('admin_delete_staff', { target_staff_id })`
 * Also deletes from Supabase `staff_members` and local storage cache.
 */
export async function deleteStaffMember(
  staffId: string,
  staffEmail?: string
): Promise<{ success: boolean; message: string }> {
  let rpcMessage = '';

  // 1. Trigger supabase.rpc('admin_delete_staff', { target_staff_id: staffId })
  try {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(staffId);
    if (isUuid) {
      const { data, error } = await supabase.rpc('admin_delete_staff', {
        target_staff_id: staffId,
      });
      if (error) {
        console.warn('admin_delete_staff RPC error:', error);
      } else if (data) {
        rpcMessage = data.message || '';
      }
    }
  } catch (err) {
    console.warn('admin_delete_staff RPC exception:', err);
  }

  // 2. Delete from Supabase `staff_members` table
  try {
    if (staffEmail) {
      await supabase.from('staff_members').delete().or(`id.eq.${staffId},email.eq.${staffEmail}`);
    } else {
      await supabase.from('staff_members').delete().eq('id', staffId);
    }
  } catch (dbErr) {
    console.warn('staff_members delete error:', dbErr);
  }

  // 3. Update local storage cache
  const localList = loadStaffFromStorage();
  const updatedList = localList.filter((s) => {
    if (s.id === staffId) return false;
    if (staffEmail && s.email.toLowerCase() === staffEmail.toLowerCase()) return false;
    return true;
  });
  saveStaffToStorage(updatedList);

  return {
    success: true,
    message: rpcMessage || 'স্টাফ অ্যাকাউন্ট সফলভাবে মুছে ফেলা হয়েছে!',
  };
}

/**
 * Checks if a staff member is active:
 * When a user logs in, if their email starts with "staff",
 * check `public.staff_members` to ensure `is_active !== false`.
 */
export async function checkStaffIsActive(
  emailOrUsername: string
): Promise<{ isActive: boolean; reason?: string }> {
  const cleanEmail = normalizeStaffEmail(emailOrUsername);

  // 1. Check Supabase `staff_members` table directly
  try {
    const { data: dbRow, error } = await supabase
      .from('staff_members')
      .select('is_active')
      .or(`email.eq.${cleanEmail},email.ilike.${cleanEmail}`)
      .maybeSingle();

    if (!error && dbRow) {
      if (dbRow.is_active === false) {
        return {
          isActive: false,
          reason: 'আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।',
        };
      }
      return { isActive: true };
    }
  } catch (err) {
    console.warn('checkStaffIsActive Supabase error:', err);
  }

  // 2. Check local storage cache
  const localList = loadStaffFromStorage();
  const found = localList.find((s) => s.email.toLowerCase() === cleanEmail.toLowerCase());
  if (found && found.is_active === false) {
    return {
      isActive: false,
      reason: 'আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।',
    };
  }

  return { isActive: true };
}

/**
 * Staff self password change:
 * In the Staff Dashboard / Header, allow the logged-in staff member to securely update their own password
 * using `supabase.auth.updateUser({ password: newPassword })`.
 * Validates that the new password is at least 6 characters long.
 */
export async function updateStaffSelfPassword(
  newPassword: string
): Promise<{ success: boolean; message: string }> {
  const clean = (newPassword || '').trim();
  if (!clean || clean.length < 6) {
    return {
      success: false,
      message: 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।',
    };
  }

  try {
    const { error } = await supabase.auth.updateUser({
      password: clean,
    });

    if (error) {
      const errMsg = (error.message || '').toLowerCase();
      if (errMsg.includes('network') || errMsg.includes('fetch')) {
        return {
          success: false,
          message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।',
        };
      }
      return {
        success: false,
        message: error.message || 'পাসওয়ার্ড পরিবর্তন করা সম্ভব হয়নি।',
      };
    }

    return {
      success: true,
      message: 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'পাসওয়ার্ড পরিবর্তন করতে সমস্যা হয়েছে।',
    };
  }
}
