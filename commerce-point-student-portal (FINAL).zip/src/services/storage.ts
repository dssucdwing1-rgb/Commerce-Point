import { Batch, BATCHES, DEFAULT_BATCH_ID, getBatchById, Exam, Student, StudentIdChangeRecord, Subject } from '../types';
import {
  INITIAL_EXAMS,
  STUDENTS_LIST,
  DEFAULT_SUBJECTS,
  ALL_DEFAULT_SUBJECT_IDS,
  STUDENTS_CLASS_12_A,
  STUDENTS_CLASS_12_B,
  ALL_INITIAL_STUDENTS,
  INITIAL_EXAMS_CLASS_12_A,
  INITIAL_EXAMS_CLASS_12_B,
  ALL_INITIAL_EXAMS,
} from '../data/initialData';

const EXAMS_KEY = 'ict_student_progress_exams_v1';
const STUDENTS_KEY = 'ict_student_progress_students_v1';
const SUBJECTS_KEY = 'ict_student_progress_subjects_v1';
const ACTIVE_SUBJECT_KEY = 'commerce_point_active_subject_id_v1';
const ACTIVE_BATCH_KEY = 'commerce_point_active_batch_id_v1';
const DEFAULT_BATCH_KEY = 'commerce_point_default_batch_id_v1';
const EXAMS_SEED_VERSION_KEY = 'commerce_point_exams_seed_v7_multibatch';
const EXAMS_PURGE_DUMMY_VERSION_KEY = 'commerce_point_exams_purge_all_dummy_v1';
export const STUDENTS_CORRECTION_VERSION_KEY = 'commerce_point_students_v8_authoritative';
export const EXAMS_CORRECTION_VERSION_KEY = 'commerce_point_exams_v8_authoritative';

// ==========================================================
// Batch Management APIs
// ==========================================================

export function getActiveBatchId(): string {
  try {
    const saved = localStorage.getItem(ACTIVE_BATCH_KEY);
    if (saved && BATCHES.some((b) => b.id === saved)) {
      return saved;
    }
    return getDefaultBatchId();
  } catch {
    return DEFAULT_BATCH_ID;
  }
}

export function setActiveBatchId(batchId: string): void {
  try {
    localStorage.setItem(ACTIVE_BATCH_KEY, batchId);
  } catch (err) {
    console.error('Failed to set active batch id', err);
  }
}

export function getDefaultBatchId(): string {
  try {
    const saved = localStorage.getItem(DEFAULT_BATCH_KEY);
    if (saved && BATCHES.some((b) => b.id === saved)) {
      return saved;
    }
  } catch {
    // fallback
  }
  return DEFAULT_BATCH_ID;
}

export function setDefaultBatchId(batchId: string): void {
  try {
    localStorage.setItem(DEFAULT_BATCH_KEY, batchId);
  } catch (err) {
    console.error('Failed to set default batch id', err);
  }
}

// Format suggested Student ID based on roll, class, and group
export function generateSuggestedStudentId(
  roll: number,
  academicClass: string = 'XI',
  group: string = 'B-A'
): string {
  const normClass = (academicClass || '').toUpperCase();
  const classNum = normClass.includes('12') || normClass.includes('XII') || normClass.includes('দ্বাদশ') ? '12' : '11';
  let cleanGroup = (group || '').trim().toUpperCase();
  if (!cleanGroup || cleanGroup.includes('এ') || cleanGroup === 'A' || cleanGroup === 'B-A') {
    cleanGroup = 'B-A';
  } else if (cleanGroup.includes('বি') || cleanGroup === 'B' || cleanGroup === 'B-B') {
    cleanGroup = 'B-B';
  }
  return `CP/C-${classNum}/${cleanGroup} ${String(roll).padStart(3, '0')}`;
}

export function generateSuggestedStudentIdForBatch(roll: number, batchId: string = 'class-11-a'): string {
  const batch = getBatchById(batchId);
  return generateSuggestedStudentId(roll, batch.academicClass, batch.group);
}

// Normalize student ID for duplicate checking (trimmed, uppercase, collapses multiple spaces)
export function normalizeStudentId(id: string): string {
  return (id || '').trim().replace(/\s+/g, ' ').toUpperCase();
}

// Check if a Student ID string is valid according to requirements
export function validateStudentId(id: string): { valid: boolean; error?: string } {
  const trimmed = (id || '').trim();
  if (!trimmed) {
    return { valid: false, error: 'Student ID is required.' };
  }

  // Allowed characters: English letters, numbers, '/', '-', and spaces
  const allowedPattern = /^[A-Za-z0-9/\-\s]+$/;
  if (!allowedPattern.test(trimmed)) {
    return {
      valid: false,
      error: 'Student ID-তে শুধুমাত্র ইংরেজি অক্ষর, সংখ্যা, /, - এবং স্পেস ব্যবহার করা যাবে।',
    };
  }

  if (trimmed.length < 3) {
    return { valid: false, error: 'Student ID অত্যন্ত ছোট। কমপক্ষে ৩টি অক্ষর দিন।' };
  }

  return { valid: true };
}

// Check whether candidate Student ID is unique across all students (case-insensitive & trimmed)
export function isStudentIdUnique(
  candidateId: string,
  excludeInternalStudentId?: string,
  studentsList?: Student[]
): boolean {
  const norm = normalizeStudentId(candidateId);
  if (!norm) return false;

  const current = studentsList || loadStudents();
  return !current.some((s) => {
    if (excludeInternalStudentId && s.id === excludeInternalStudentId) {
      return false; // Skip the student currently being edited
    }
    return normalizeStudentId(s.studentIdCode) === norm;
  });
}

// ==========================================================
// Subject Management APIs
// ==========================================================

export const BENGALI_SUBJECT_TRANSLATIONS: Record<string, string> = {
  'বাংলা': 'Bangla',
  'ইংরেজি': 'English',
  'হিসাব বিজ্ঞান': 'Accounting',
  'হিসাববিজ্ঞান': 'Accounting',
  'অর্থনীতি': 'Economics',
  'আইসিটি': 'ICT',
  'মার্কেটিং': 'Marketing',
  'ব্যবস্থাপনা': 'Management',
  'ব্যবসায় সংগঠন ও ব্যবস্থাপনা': 'Business Organization & Management',
  'ফিন্যান্স': 'Finance',
  'ফিন্যান্স ও ব্যাংকিং': 'Finance & Banking',
  'পরিসংখ্যান': 'Statistics',
};

const DEFAULT_SUBJECT_EN_NAMES: Record<string, string> = {
  bangla: 'Bangla',
  accounting: 'Accounting',
  economics: 'Economics',
  ict: 'ICT',
  english: 'English',
  marketing: 'Marketing',
  management: 'Management',
};

export function loadSubjects(): Subject[] {
  try {
    const raw = localStorage.getItem(SUBJECTS_KEY);
    if (!raw) {
      saveSubjects(DEFAULT_SUBJECTS);
      return DEFAULT_SUBJECTS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      let changed = false;
      let updated = parsed.map((s: Subject) => {
        let newName = s.name;
        if (BENGALI_SUBJECT_TRANSLATIONS[s.name]) {
          newName = BENGALI_SUBJECT_TRANSLATIONS[s.name];
        } else if (DEFAULT_SUBJECT_EN_NAMES[s.id] && (s.name === 'বাংলা' || s.name === 'হিসাব বিজ্ঞান' || s.name === 'অর্থনীতি')) {
          newName = DEFAULT_SUBJECT_EN_NAMES[s.id];
        }
        if (newName !== s.name) {
          changed = true;
          return {
            ...s,
            name: newName,
            bengaliName: s.bengaliName || s.name,
          };
        }
        return s;
      });

      // Ensure all default subjects exist
      const existingIds = new Set(updated.map((s: Subject) => s.id));
      DEFAULT_SUBJECTS.forEach((ds) => {
        if (!existingIds.has(ds.id)) {
          updated.push(ds);
          changed = true;
        }
      });
      if (changed) {
        saveSubjects(updated);
      }
      return updated;
    }
    saveSubjects(DEFAULT_SUBJECTS);
    return DEFAULT_SUBJECTS;
  } catch (err) {
    console.error('Failed to load subjects', err);
    return DEFAULT_SUBJECTS;
  }
}

export function saveSubjects(subjects: Subject[]): void {
  try {
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
  } catch (err) {
    console.error('Failed to save subjects', err);
  }
}

export function addSubject(
  subjectDataOrName: { name: string; code?: string; bengaliName?: string } | string,
  optionalCode?: string
): { success: boolean; subject?: Subject; error?: string; subjects: Subject[] } {
  const current = loadSubjects();
  let name = '';
  let code = '';
  let bengaliName = '';

  if (typeof subjectDataOrName === 'string') {
    name = subjectDataOrName.trim();
    code = (optionalCode || name.substring(0, 4)).trim().toUpperCase();
    bengaliName = name;
  } else {
    name = subjectDataOrName.name.trim();
    code = (subjectDataOrName.code || name.substring(0, 4)).trim().toUpperCase();
    bengaliName = subjectDataOrName.bengaliName?.trim() || name;
  }

  if (!name) {
    return { success: false, error: 'বিষয়ের নাম আবশ্যক।', subjects: current };
  }

  // Duplicate name check
  if (current.some((s) => s.name.toLowerCase() === name.toLowerCase())) {
    return { success: false, error: 'এই বিষয়ের নাম ইতোমধ্যে অন্তর্ভুক্ত রয়েছে।', subjects: current };
  }

  const generatedId = `sub-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  const newSubject: Subject = {
    id: generatedId,
    name,
    code,
    bengaliName,
    isActive: true,
    isDefault: false,
    order: current.length + 1,
  };

  const updated = [...current, newSubject];
  saveSubjects(updated);
  return { success: true, subject: newSubject, subjects: updated };
}

export function updateSubject(
  subjectId: string,
  data: { name: string; code?: string; bengaliName?: string; isActive?: boolean }
): { success: boolean; subjects: Subject[]; error?: string } {
  const current = loadSubjects();
  const index = current.findIndex((s) => s.id === subjectId);
  if (index === -1) {
    return { success: false, error: 'বিষয়টি পাওয়া যায়নি।', subjects: current };
  }

  const updated = [...current];
  updated[index] = {
    ...updated[index],
    name: data.name.trim() || updated[index].name,
    code: (data.code || updated[index].code).trim().toUpperCase(),
    bengaliName: data.bengaliName?.trim() || updated[index].bengaliName,
    isActive: data.isActive !== undefined ? data.isActive : updated[index].isActive,
  };

  saveSubjects(updated);
  return { success: true, subjects: updated };
}

export function deleteSubject(subjectId: string): Subject[] {
  const current = loadSubjects();
  // Don't delete ICT if it's the core default
  if (subjectId === 'ict') {
    return current;
  }
  const updated = current.filter((s) => s.id !== subjectId);
  saveSubjects(updated);
  return updated;
}

export function toggleSubjectStatus(subjectId: string): Subject[] {
  const current = loadSubjects();
  const updated = current.map((s) => {
    if (s.id === subjectId) {
      return { ...s, isActive: !s.isActive };
    }
    return s;
  });
  saveSubjects(updated);
  return updated;
}

export function getActiveSubjectId(): string {
  try {
    const saved = localStorage.getItem(ACTIVE_SUBJECT_KEY);
    if (saved) return saved;
  } catch {
    // ignore
  }
  return 'ict';
}

export function setActiveSubjectId(subjectId: string): void {
  try {
    localStorage.setItem(ACTIVE_SUBJECT_KEY, subjectId);
  } catch (err) {
    console.error('Failed to set active subject id', err);
  }
}

// ==========================================================
// Student Management APIs
// ==========================================================

export function synchronizeAuthoritativeStudents(students: Student[]): { students: Student[]; updated: boolean } {
  // 1. Class 11 students: STRICTLY UNTOUCHED
  const class11Students = students.filter((s) => {
    const bId = s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
    return bId === 'class-11-a';
  });
  const finalClass11 = class11Students.length > 0 ? class11Students : STUDENTS_LIST;

  // 2. Class 12 Batch A: Exactly 31 students (Roll 1..31)
  const existing12A = students.filter((s) => {
    const bId = s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
    return bId === 'class-12-a';
  });

  const final12A: Student[] = STUDENTS_CLASS_12_A.map((authSpec) => {
    // Find existing by roll or by internal immutable ID 'c12a-' + roll
    const existing = existing12A.find((s) => s.roll === authSpec.roll || s.id === authSpec.id);
    if (existing) {
      return {
        ...existing,
        id: authSpec.id,
        roll: authSpec.roll,
        name: authSpec.name,
        studentIdCode: authSpec.studentIdCode,
        batchId: 'class-12-a',
        academicClass: 'XII',
        group: 'B-A',
        subject: 'ICT',
        session: '2026',
        assignedSubjectIds:
          Array.isArray(existing.assignedSubjectIds) && existing.assignedSubjectIds.length > 0
            ? existing.assignedSubjectIds
            : ALL_DEFAULT_SUBJECT_IDS,
      };
    }
    return { ...authSpec };
  });

  // 3. Class 12 Batch B: Exactly 13 students (Roll 1..13)
  const existing12B = students.filter((s) => {
    const bId = s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
    return bId === 'class-12-b';
  });

  const final12B: Student[] = STUDENTS_CLASS_12_B.map((authSpec) => {
    const existing = existing12B.find((s) => s.roll === authSpec.roll || s.id === authSpec.id);
    if (existing) {
      return {
        ...existing,
        id: authSpec.id,
        roll: authSpec.roll,
        name: authSpec.name,
        studentIdCode: authSpec.studentIdCode,
        batchId: 'class-12-b',
        academicClass: 'XII',
        group: 'B-B',
        subject: 'ICT',
        session: '2026',
        assignedSubjectIds:
          Array.isArray(existing.assignedSubjectIds) && existing.assignedSubjectIds.length > 0
            ? existing.assignedSubjectIds
            : ALL_DEFAULT_SUBJECT_IDS,
      };
    }
    return { ...authSpec };
  });

  const finalStudents = [...finalClass11, ...final12A, ...final12B];
  return { students: finalStudents, updated: true };
}

export function loadStudents(): Student[] {
  try {
    const raw = localStorage.getItem(STUDENTS_KEY);
    const correctionVersion = localStorage.getItem(STUDENTS_CORRECTION_VERSION_KEY);
    let students: Student[] = [];

    if (!raw) {
      students = ALL_INITIAL_STUDENTS;
      saveStudents(students);
      localStorage.setItem(STUDENTS_CORRECTION_VERSION_KEY, 'v8_authoritative_class12');
      return students;
    }

    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      students = parsed;
    } else {
      students = ALL_INITIAL_STUDENTS;
    }

    // Check if Class 12 Batch A (31) and Batch B (13) authoritative correction is applied
    const countA = students.filter((s) => (s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')) === 'class-12-a').length;
    const countB = students.filter((s) => (s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')) === 'class-12-b').length;

    // Check first student names of batch A and B to verify authoritative list
    const firstA = students.find((s) => s.id === 'c12a-1' || (s.roll === 1 && s.batchId === 'class-12-a'));
    const isFirstACorrect = firstA?.name === 'প্রান্তিকা' && firstA?.studentIdCode === 'CP/C-12/B-A 001';

    const firstB = students.find((s) => s.id === 'c12b-1' || (s.roll === 1 && s.batchId === 'class-12-b'));
    const isFirstBCorrect = firstB?.name === 'সুবর্ণা' && firstB?.studentIdCode === 'CP/C-12/B-B 001';

    const needsCorrection =
      correctionVersion !== 'v8_authoritative_class12' ||
      countA !== 31 ||
      countB !== 13 ||
      !isFirstACorrect ||
      !isFirstBCorrect;

    if (needsCorrection) {
      const synced = synchronizeAuthoritativeStudents(students);
      saveStudents(synced.students);
      localStorage.setItem(STUDENTS_CORRECTION_VERSION_KEY, 'v8_authoritative_class12');
      return synced.students;
    }

    return students;
  } catch (err) {
    console.error('Failed to read students from localStorage', err);
    return ALL_INITIAL_STUDENTS;
  }
}

export function saveStudents(students: Student[]): void {
  try {
    localStorage.setItem(STUDENTS_KEY, JSON.stringify(students));
  } catch (err) {
    console.error('Failed to save students to localStorage', err);
  }
}

export interface AddStudentParams {
  name: string;
  roll?: number;
  studentIdCode: string;
  batchId?: string;
  academicClass?: string;
  group?: string;
  subject?: string;
  assignedSubjectIds?: string[];
  session?: string;
  mobile?: string;
  email?: string;
}

export function addStudent(
  inputOrName: string | AddStudentParams,
  optionalRoll?: number,
  optionalStudentIdCode?: string,
  optionalBatchId?: string
): { success: boolean; student?: Student; error?: string; students: Student[] } {
  const current = loadStudents();

  let params: AddStudentParams;
  if (typeof inputOrName === 'string') {
    const targetBatchId = optionalBatchId || getActiveBatchId();
    const batchInfo = getBatchById(targetBatchId);
    const batchStudents = current.filter((s) => (s.batchId || 'class-11-a') === targetBatchId);
    const nextRoll = optionalRoll !== undefined && optionalRoll > 0
      ? optionalRoll
      : (batchStudents.length > 0 ? Math.max(...batchStudents.map((s) => s.roll)) + 1 : 1);

    params = {
      name: inputOrName.trim(),
      roll: nextRoll,
      studentIdCode: optionalStudentIdCode?.trim() || generateSuggestedStudentId(nextRoll, batchInfo.academicClass, batchInfo.group),
      batchId: targetBatchId,
      academicClass: batchInfo.academicClass,
      group: batchInfo.group,
      subject: 'ICT',
      assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS,
      session: '2026',
    };
  } else {
    params = inputOrName;
  }

  // 1. Validate name
  if (!params.name || !params.name.trim()) {
    return { success: false, error: 'শিক্ষার্থীর নাম আবশ্যক।', students: current };
  }

  // 2. Validate Student ID format
  const valResult = validateStudentId(params.studentIdCode);
  if (!valResult.valid) {
    return { success: false, error: valResult.error, students: current };
  }

  // 3. Validate Student ID uniqueness (case-insensitive & whitespace normalized)
  if (!isStudentIdUnique(params.studentIdCode, undefined, current)) {
    return {
      success: false,
      error: 'এই Student ID ইতোমধ্যে অন্য একজন শিক্ষার্থীর জন্য ব্যবহৃত হয়েছে। অনুগ্রহ করে একটি ভিন্ন ID দিন।',
      students: current,
    };
  }

  const effectiveBatchId = params.batchId || (params.academicClass === 'XII' ? (params.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
  const batchInfo = getBatchById(effectiveBatchId);
  const batchStudents = current.filter((s) => (s.batchId || 'class-11-a') === effectiveBatchId);
  const nextRoll = params.roll !== undefined && params.roll > 0
    ? params.roll
    : (batchStudents.length > 0 ? Math.max(...batchStudents.map((s) => s.roll)) + 1 : 1);

  // Internal immutable unique database record ID
  const internalId = `student-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

  const newStudent: Student = {
    id: internalId,
    roll: nextRoll,
    name: params.name.trim(),
    studentIdCode: params.studentIdCode.trim(),
    batchId: effectiveBatchId,
    academicClass: params.academicClass?.trim() || batchInfo.academicClass,
    group: params.group?.trim() || batchInfo.group,
    subject: params.subject?.trim() || 'ICT',
    assignedSubjectIds:
      params.assignedSubjectIds && params.assignedSubjectIds.length > 0
        ? params.assignedSubjectIds
        : ALL_DEFAULT_SUBJECT_IDS,
    session: params.session?.trim() || '2026',
    mobile: params.mobile?.trim() || '',
    email: params.email?.trim() || '',
    idHistory: [],
  };

  const updated = [...current, newStudent];
  saveStudents(updated);
  return { success: true, student: newStudent, students: updated };
}

export function removeStudent(studentId: string): Student[] {
  const current = loadStudents();
  const updated = current.filter((s) => s.id !== studentId);
  saveStudents(updated);
  return updated;
}

export interface UpdateStudentParams {
  name: string;
  roll: number;
  studentIdCode: string;
  batchId?: string;
  academicClass?: string;
  group?: string;
  subject?: string;
  assignedSubjectIds?: string[];
  session?: string;
  mobile?: string;
  email?: string;
  changeReason?: string;
}

export function updateStudent(
  studentId: string,
  paramsOrName: string | UpdateStudentParams,
  optionalRoll?: number,
  optionalStudentIdCode?: string,
  changedBy: string = 'Admin'
): {
  success: boolean;
  student?: Student;
  error?: string;
  students: Student[];
  idChanged: boolean;
  previousId?: string;
  newId?: string;
} {
  const current = loadStudents();
  const targetIndex = current.findIndex((s) => s.id === studentId);

  if (targetIndex === -1) {
    return { success: false, error: 'শিক্ষার্থী পাওয়া যায়নি।', students: current, idChanged: false };
  }

  const targetStudent = current[targetIndex];

  let params: UpdateStudentParams;
  if (typeof paramsOrName === 'string') {
    params = {
      name: paramsOrName.trim(),
      roll: optionalRoll !== undefined ? optionalRoll : targetStudent.roll,
      studentIdCode: optionalStudentIdCode?.trim() || targetStudent.studentIdCode,
      batchId: targetStudent.batchId || 'class-11-a',
      academicClass: targetStudent.academicClass || 'XI',
      group: targetStudent.group || 'B-A',
      subject: targetStudent.subject || 'ICT',
      assignedSubjectIds: targetStudent.assignedSubjectIds || ALL_DEFAULT_SUBJECT_IDS,
      session: targetStudent.session || '2026',
      mobile: targetStudent.mobile || '',
      email: targetStudent.email || '',
    };
  } else {
    params = paramsOrName;
  }

  // 1. Validate Name
  if (!params.name || !params.name.trim()) {
    return { success: false, error: 'শিক্ষার্থীর নাম আবশ্যক।', students: current, idChanged: false };
  }

  // 2. Validate Student ID format
  const valResult = validateStudentId(params.studentIdCode);
  if (!valResult.valid) {
    return { success: false, error: valResult.error, students: current, idChanged: false };
  }

  // 3. Validate Student ID uniqueness (excluding this student's immutable internal ID)
  if (!isStudentIdUnique(params.studentIdCode, studentId, current)) {
    return {
      success: false,
      error: 'এই Student ID ইতোমধ্যে অন্য একজন শিক্ষার্থীর জন্য ব্যবহৃত হয়েছে। অনুগ্রহ করে একটি ভিন্ন ID দিন।',
      students: current,
      idChanged: false,
    };
  }

  const trimmedNewId = params.studentIdCode.trim();
  const idChanged = normalizeStudentId(targetStudent.studentIdCode) !== normalizeStudentId(trimmedNewId);

  // Maintain Audit History if ID changed
  let updatedHistory = targetStudent.idHistory ? [...targetStudent.idHistory] : [];
  if (idChanged) {
    const historyEntry: StudentIdChangeRecord = {
      previousId: targetStudent.studentIdCode,
      newId: trimmedNewId,
      changedAt: Date.now(),
      changedBy,
      reason: params.changeReason,
    };
    updatedHistory.push(historyEntry);
  }

  const effectiveBatchId = params.batchId || targetStudent.batchId || 'class-11-a';
  const batchInfo = getBatchById(effectiveBatchId);

  // Update student: Internal immutable ID is preserved without any change!
  const updatedStudent: Student = {
    ...targetStudent,
    name: params.name.trim(),
    roll: params.roll,
    studentIdCode: trimmedNewId,
    batchId: effectiveBatchId,
    academicClass: params.academicClass?.trim() || batchInfo.academicClass,
    group: params.group?.trim() || batchInfo.group,
    subject: params.subject?.trim() || 'ICT',
    assignedSubjectIds:
      params.assignedSubjectIds !== undefined
        ? params.assignedSubjectIds
        : targetStudent.assignedSubjectIds || ALL_DEFAULT_SUBJECT_IDS,
    session: params.session?.trim() || '2026',
    mobile: params.mobile?.trim() || '',
    email: params.email?.trim() || '',
    idHistory: updatedHistory,
  };

  const updatedStudents = [...current];
  updatedStudents[targetIndex] = updatedStudent;
  saveStudents(updatedStudents);

  return {
    success: true,
    student: updatedStudent,
    students: updatedStudents,
    idChanged,
    previousId: targetStudent.studentIdCode,
    newId: trimmedNewId,
  };
}

// ==========================================================
// Exam Management APIs
// ==========================================================

export function loadExams(): Exam[] {
  try {
    // One-time purge of all legacy dummy exams across all batches & subjects for fresh start
    const purgeFlag = localStorage.getItem(EXAMS_PURGE_DUMMY_VERSION_KEY);
    if (purgeFlag !== 'v1_cleared_all_dummy_exams') {
      saveExams([]);
      localStorage.setItem(EXAMS_PURGE_DUMMY_VERSION_KEY, 'v1_cleared_all_dummy_exams');
      return [];
    }

    const raw = localStorage.getItem(EXAMS_KEY);
    if (!raw) {
      saveExams([]);
      return [];
    }

    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (err) {
    console.error('Failed to read exams from localStorage', err);
    return [];
  }
}

export function syncAllDummyExams(): Exam[] {
  return loadExams();
}

export function saveExams(exams: Exam[]): void {
  try {
    localStorage.setItem(EXAMS_KEY, JSON.stringify(exams));
  } catch (err) {
    console.error('Failed to save exams to localStorage', err);
  }
}

export function addExam(exam: Exam, activeBatchId?: string): Exam[] {
  const current = loadExams();
  // Ensure subjectId and batchId are set
  const examToSave: Exam = {
    ...exam,
    batchId: exam.batchId || activeBatchId || getActiveBatchId(),
    subjectId: exam.subjectId || 'ict',
  };
  const updated = [examToSave, ...current];
  saveExams(updated);
  return updated;
}

export function updateExam(updatedExam: Exam): Exam[] {
  const current = loadExams();
  const examToSave: Exam = {
    ...updatedExam,
    batchId: updatedExam.batchId || 'class-11-a',
    subjectId: updatedExam.subjectId || 'ict',
  };
  const updated = current.map((e) => (e.id === examToSave.id ? examToSave : e));
  saveExams(updated);
  return updated;
}

export function deleteExam(examId: string): Exam[] {
  const current = loadExams();
  const updated = current.filter((e) => e.id !== examId);
  saveExams(updated);
  return updated;
}

export function resetExams(): Exam[] {
  saveExams([]);
  return [];
}

