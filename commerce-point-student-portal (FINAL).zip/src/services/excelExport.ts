import * as XLSX from 'xlsx';
import { Exam, Student, Subject } from '../types';
import {
  rankStudentsForExam,
  rankStudentsForMonthlyMaster,
  rankStudentsForSubjectMonth,
  getStudentExamPosition,
  getStudentMonthlyPosition,
} from '../utils/ranking';

/**
 * Sanitizes a string for use in safe filenames by removing invalid characters
 * Invalid filename characters: / \ : * ? " < > |
 */
export function sanitizeFileName(name: string): string {
  return name.replace(/[/\\?%*:|"<>]/g, '_').replace(/\s+/g, '_').trim();
}

/**
 * Format date nicely for display, e.g. "2026-09-10" -> "10 Sep 2026"
 */
export function formatDisplayDate(dateStr: string): string {
  if (!dateStr) return '';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parts[0];
      const monthIdx = parseInt(parts[1], 10) - 1;
      const day = parts[2];
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      if (monthIdx >= 0 && monthIdx < 12) {
        return `${day} ${months[monthIdx]} ${year}`;
      }
    }
    return dateStr;
  } catch {
    return dateStr;
  }
}

/**
 * Helper to download XLSX workbook as a browser file download using Blob
 */
function downloadWorkbook(workbook: XLSX.WorkBook, fileName: string): void {
  const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([wbout], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Triggers browser download of a CSV file with UTF-8 BOM
 * UTF-8 BOM (\uFEFF) ensures Excel renders Bengali text cleanly
 */
function downloadCsv(csvContent: string, fileName: string): void {
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeCsvCell(value: string | number | undefined | null): string {
  if (value === undefined || value === null) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

// =========================================================================
// 1. ALL EXAMS EXCEL DOWNLOAD (Consolidated Row-per-Result)
// =========================================================================
/**
 * Export all students' exam results across all exams into a clean Excel (.xlsx) file.
 * Each row corresponds to one student's result for one exam.
 */
export async function exportAllExamsToExcel(
  exams: Exam[],
  students: Student[]
): Promise<boolean> {
  if (!exams || exams.length === 0) {
    throw new Error('Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
  }

  // Sort exams chronologically (oldest to newest)
  const sortedExams = [...exams].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  // Sort students by roll
  const sortedStudents = [...students].sort((a, b) => a.roll - b.roll);

  const headers = [
    'Position / Rank (মেধাক্রম)',
    'রোল (Roll)',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'পরীক্ষার নাম (Exam Name)',
    'পরীক্ষার তারিখ (Date)',
    'CQ নম্বর',
    'CQ পূর্ণমান',
    'MCQ নম্বর',
    'MCQ পূর্ণমান',
    'মোট প্রাপ্ত নম্বর (Total)',
    'মোট পূর্ণমান (Full Marks)',
    'শতকরা (Percentage %)',
    'গ্রেড (Grade)',
    'স্ট্যাটাস (Status)',
  ];

  const dataRows: (string | number)[][] = [headers];

  sortedExams.forEach((exam) => {
    const rankedStudents = rankStudentsForExam(exam, students);
    rankedStudents.forEach((ranked) => {
      const student = ranked.student;
      const isAbsent = ranked.isAbsent;
      const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
      const positionStr = isAbsent ? '—' : ranked.positionDisplay;
      const cqVal = !isAbsent && ranked.cq !== '' ? ranked.cq : (isAbsent ? '' : 0);
      const mcqVal = !isAbsent && ranked.mcq !== '' ? ranked.mcq : (isAbsent ? '' : 0);
      const totalVal = !isAbsent ? ranked.total : (isAbsent ? '' : 0);
      const percentageStr = !isAbsent ? `${ranked.percentage}%` : '';
      const gradeStr = !isAbsent ? ranked.grade : 'Absent';
      const statusStr = isAbsent ? 'অনুপস্থিত (Absent)' : ranked.status === 'Pass' ? 'কৃতকার্য (Pass)' : 'অকৃতকার্য (Fail)';

      dataRows.push([
        positionStr,
        student.roll,
        student.name,
        studentIdCode,
        exam.name,
        exam.date,
        cqVal,
        exam.cqFullMarks,
        mcqVal,
        exam.mcqFullMarks,
        totalVal,
        exam.totalFullMarks,
        percentageStr,
        gradeStr,
        statusStr,
      ]);
    });
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(dataRows);

  // Column widths
  ws['!cols'] = [
    { wch: 14 }, // Position
    { wch: 22 }, // Name
    { wch: 20 }, // Student ID
    { wch: 10 }, // Roll
    { wch: 28 }, // Exam Name
    { wch: 14 }, // Date
    { wch: 12 }, // CQ
    { wch: 12 }, // CQ Full
    { wch: 12 }, // MCQ
    { wch: 12 }, // MCQ Full
    { wch: 14 }, // Total
    { wch: 14 }, // Total Full
    { wch: 14 }, // Percentage
    { wch: 12 }, // Grade
    { wch: 18 }, // Status
  ];

  // Freeze top row
  ws['!views'] = [{ state: 'frozen', xSplit: 0, ySplit: 1 }];

  XLSX.utils.book_append_sheet(wb, ws, 'সকল পরীক্ষার ফলাফল');

  const today = new Date().toISOString().split('T')[0];
  const fileName = `COMMERCE_POINT_All_Results_List_${today}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

/**
 * Export all exams into CSV with UTF-8 BOM
 */
export function exportAllExamsToCsv(exams: Exam[], students: Student[]): void {
  if (!exams || exams.length === 0) {
    throw new Error('Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
  }

  const sortedExams = [...exams].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const headers = [
    'Position (ক্রম)',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'রোল (Roll)',
    'পরীক্ষার নাম (Exam Name)',
    'পরীক্ষার তারিখ (Date)',
    'CQ নম্বর',
    'CQ পূর্ণমান',
    'MCQ নম্বর',
    'MCQ পূর্ণমান',
    'মোট প্রাপ্ত নম্বর (Total)',
    'সর্বমোট পূর্ণমান (Full Marks)',
    'শতকরা (Percentage %)',
    'গ্রেড (Grade)',
    'স্ট্যাটাস (Status)',
  ];

  const rows: string[] = [headers.map(escapeCsvCell).join(',')];

  sortedExams.forEach((exam) => {
    const rankedStudents = rankStudentsForExam(exam, students);
    rankedStudents.forEach((ranked) => {
      const student = ranked.student;
      const isAbsent = ranked.isAbsent;
      const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
      const positionStr = isAbsent ? '—' : String(ranked.position);
      const cqVal = !isAbsent && ranked.cq !== '' ? ranked.cq : (isAbsent ? '' : 0);
      const mcqVal = !isAbsent && ranked.mcq !== '' ? ranked.mcq : (isAbsent ? '' : 0);
      const totalVal = !isAbsent ? ranked.total : (isAbsent ? '' : 0);
      const percentageStr = !isAbsent ? `${ranked.percentage}%` : '';
      const gradeStr = !isAbsent ? ranked.grade : 'Absent';
      const statusStr = isAbsent ? 'অনুপস্থিত' : 'উপস্থিত';

      rows.push(
        [
          positionStr,
          student.name,
          studentIdCode,
          student.roll,
          exam.name,
          exam.date,
          cqVal,
          exam.cqFullMarks,
          mcqVal,
          exam.mcqFullMarks,
          totalVal,
          exam.totalFullMarks,
          percentageStr,
          gradeStr,
          statusStr,
        ]
          .map(escapeCsvCell)
          .join(',')
      );
    });
  });

  const today = new Date().toISOString().split('T')[0];
  const fileName = `COMMERCE_POINT_All_Results_List_${today}.csv`;
  downloadCsv(rows.join('\r\n'), fileName);
}

// =========================================================================
// 2. INDIVIDUAL EXAM EXCEL DOWNLOAD
// =========================================================================
/**
 * Export a single exam results sheet into a clean, formatted Excel (.xlsx) file.
 */
export async function exportSingleExamToExcel(
  exam: Exam,
  students: Student[]
): Promise<boolean> {
  if (!exam) {
    throw new Error('এই পরীক্ষার জন্য কোনো ফলাফল পাওয়া যায়নি।');
  }

  // Rank students strictly by Total Marks descending
  const rankedStudents = rankStudentsForExam(exam, students);

  // Compute stats
  let attendedCount = 0;
  let absentCount = 0;
  rankedStudents.forEach((st) => {
    if (!st.isAbsent) {
      attendedCount++;
    } else {
      absentCount++;
    }
  });

  const dataRows: (string | number)[][] = [
    ['পরীক্ষার নাম:', exam.name],
    ['পরীক্ষার তারিখ:', exam.date],
    ['পূর্ণমান:', `CQ: ${exam.cqFullMarks} + MCQ: ${exam.mcqFullMarks} = Total ${exam.totalFullMarks}`],
    ['অংশগ্রহণকারী:', `${attendedCount} জন উপস্থিত, ${absentCount} জন অনুপস্থিত (মোট ${students.length} জন)`],
    ['গড় নম্বর:', `${exam.average} (শতকরা ${exam.averagePercentage}%)`],
    [], // Blank separator row
    [
      'মেধাক্রম / Position',
      'রোল (Roll)',
      'শিক্ষার্থীর নাম (Student Name)',
      'Student ID',
      'CQ প্রাপ্ত নম্বর',
      `CQ পূর্ণমান (${exam.cqFullMarks})`,
      'MCQ প্রাপ্ত নম্বর',
      `MCQ পূর্ণমান (${exam.mcqFullMarks})`,
      'মোট নম্বর (Total Marks)',
      `মোট পূর্ণমান (${exam.totalFullMarks})`,
      'শতকরা (%)',
      'গ্রেড (Grade)',
      'স্ট্যাটাস (Status)',
    ],
  ];

  rankedStudents.forEach((ranked) => {
    const student = ranked.student;
    const isAbsent = ranked.isAbsent;
    const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
    const positionStr = isAbsent ? '—' : ranked.positionDisplay;
    const cqVal = !isAbsent && ranked.cq !== '' ? ranked.cq : (isAbsent ? '' : 0);
    const mcqVal = !isAbsent && ranked.mcq !== '' ? ranked.mcq : (isAbsent ? '' : 0);
    const totalVal = !isAbsent ? ranked.total : (isAbsent ? '' : 0);
    const percentageStr = !isAbsent ? `${ranked.percentage}%` : '';
    const gradeStr = !isAbsent ? ranked.grade : 'Absent';
    const statusStr = isAbsent ? 'অনুপস্থিত (Absent)' : ranked.status === 'Pass' ? 'কৃতকার্য (Pass)' : 'অকৃতকার্য (Fail)';

    dataRows.push([
      positionStr,
      student.roll,
      student.name,
      studentIdCode,
      cqVal,
      exam.cqFullMarks,
      mcqVal,
      exam.mcqFullMarks,
      totalVal,
      exam.totalFullMarks,
      percentageStr,
      gradeStr,
      statusStr,
    ]);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(dataRows);

  ws['!cols'] = [
    { wch: 14 }, // Position / Rank
    { wch: 10 }, // Roll
    { wch: 22 }, // Name
    { wch: 20 }, // Student ID
    { wch: 14 }, // CQ
    { wch: 14 }, // CQ Full
    { wch: 14 }, // MCQ
    { wch: 14 }, // MCQ Full
    { wch: 16 }, // Total
    { wch: 16 }, // Total Full
    { wch: 14 }, // Percentage
    { wch: 12 }, // Grade
    { wch: 18 }, // Status
  ];

  // Freeze panes after row 7 (header row)
  ws['!views'] = [{ state: 'frozen', xSplit: 0, ySplit: 7 }];

  const safeExamName = sanitizeFileName(exam.name);
  const sheetName = (exam.name.length > 25 ? exam.name.substring(0, 25) : exam.name).replace(/[/\\?*:[\]]/g, '');
  XLSX.utils.book_append_sheet(wb, ws, sheetName || 'Exam Result');

  const fileName = `${safeExamName}_${exam.date}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

/**
 * Export a single exam results sheet into CSV with UTF-8 BOM
 */
export function exportSingleExamToCsv(exam: Exam, students: Student[]): void {
  if (!exam) {
    throw new Error('এই পরীক্ষার জন্য কোনো ফলাফল পাওয়া যায়নি।');
  }

  const rankedStudents = rankStudentsForExam(exam, students);
  const headers = [
    'Position (ক্রম)',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'রোল (Roll)',
    'CQ প্রাপ্ত নম্বর',
    `CQ পূর্ণমান (${exam.cqFullMarks})`,
    'MCQ প্রাপ্ত নম্বর',
    `MCQ পূর্ণমান (${exam.mcqFullMarks})`,
    'মোট নম্বর (Total)',
    `মোট পূর্ণমান (${exam.totalFullMarks})`,
    'শতকরা (%)',
    'গ্রেড (Grade)',
    'স্ট্যাটাস (Status)',
  ];

  const rows: string[] = [];
  rows.push(['পরীক্ষার নাম:', exam.name].map(escapeCsvCell).join(','));
  rows.push(['তারিখ:', exam.date].map(escapeCsvCell).join(','));
  rows.push(['গড় নম্বর:', `${exam.average} / ${exam.totalFullMarks}`].map(escapeCsvCell).join(','));
  rows.push(['গড় শতকরা:', `${exam.averagePercentage}%`].map(escapeCsvCell).join(','));
  rows.push('');
  rows.push(headers.map(escapeCsvCell).join(','));

  rankedStudents.forEach((ranked) => {
    const student = ranked.student;
    const isAbsent = ranked.isAbsent;
    const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
    const positionStr = isAbsent ? '—' : String(ranked.position);
    const cqVal = !isAbsent && ranked.cq !== '' ? ranked.cq : (isAbsent ? '' : 0);
    const mcqVal = !isAbsent && ranked.mcq !== '' ? ranked.mcq : (isAbsent ? '' : 0);
    const totalVal = !isAbsent ? ranked.total : (isAbsent ? '' : 0);
    const percentageStr = !isAbsent ? `${ranked.percentage}%` : '';
    const gradeStr = !isAbsent ? ranked.grade : 'Absent';
    const statusStr = isAbsent ? 'অনুপস্থিত' : 'উপস্থিত';

    rows.push(
      [
        positionStr,
        student.name,
        studentIdCode,
        student.roll,
        cqVal,
        exam.cqFullMarks,
        mcqVal,
        exam.mcqFullMarks,
        totalVal,
        exam.totalFullMarks,
        percentageStr,
        gradeStr,
        statusStr,
      ]
        .map(escapeCsvCell)
        .join(',')
    );
  });

  const safeExamName = sanitizeFileName(exam.name);
  const fileName = `${safeExamName}_${exam.date}.csv`;
  downloadCsv(rows.join('\r\n'), fileName);
}

// =========================================================================
// 3. MASTER RESULT EXCEL (Teacher-Only, 1 Row = 1 Student, Two-tier Header)
// =========================================================================
/**
 * Generates the Teacher Master Result Sheet:
 * - Exclusively available to authenticated Teacher role (userRole === 'admin')
 * - 1 Row = 1 Student (sorted by Student roll / order)
 * - Chronologically date-sorted exam columns (oldest to newest)
 * - Dual-level headers:
 *     Level 1 (Row 0): Student info | Date & Exam Name Group Header (spans CQ, MCQ, Total) | Overall Summary
 *     Level 2 (Row 1): Blank for student info | CQ (marks) | MCQ (marks) | Total (marks) | Stats columns
 * - Blank cells for absent/unattended exams (no artificial 0)
 * - Professionally formatted for printing:
 *     * Landscape orientation (A4 paper size)
 *     * Fit to page width
 *     * Narrow margins for maximum printable data
 *     * Frozen header rows (top 2) and student identifier columns (left 3)
 *     * Grid lines enabled for clean tabular printouts
 */
export async function exportMasterResultExcel(
  exams: Exam[],
  students: Student[],
  userRole?: string
): Promise<boolean> {
  // 1. Strict security check: Only authenticated Teachers/Admins can generate this master export
  if (userRole !== 'admin') {
    throw new Error('শুধুমাত্র শিক্ষকগণ (Teacher Login) মাস্টার এক্সেল ডাউনলোড করতে পারবেন।');
  }

  if (!exams || exams.length === 0) {
    throw new Error('Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
  }

  if (!students || students.length === 0) {
    throw new Error('কোনো শিক্ষার্থীর তথ্য পাওয়া যায়নি।');
  }

  // 2. Sort exams strictly chronologically by Date (oldest to newest)
  const sortedExams = [...exams].sort((a, b) => {
    const diff = new Date(a.date).getTime() - new Date(b.date).getTime();
    if (diff !== 0) return diff;
    return (a.createdAt || 0) - (b.createdAt || 0);
  });

  // 3. Rank students strictly by Total Marks descending across all exams
  const rankedStudents = rankStudentsForMonthlyMaster(sortedExams, students);

  // ==========================================
  // DUAL-LEVEL HEADER CONSTRUCTION
  // ==========================================
  // Level 1: Group Header Row (Row 0)
  const headerRow0: (string | number)[] = [
    'মেধাক্রম / Position',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'রোল (Roll)',
  ];

  // Level 2: Sub-Header Row (Row 1)
  const headerRow1: (string | number)[] = [
    '',
    '',
    '',
    '',
  ];

  // Cell merges: Rows 0 and 1 for the 4 student identification columns
  const merges: XLSX.Range[] = [
    { s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, // Position spans 2 rows
    { s: { r: 0, c: 1 }, e: { r: 1, c: 1 } }, // Student Name spans 2 rows
    { s: { r: 0, c: 2 }, e: { r: 1, c: 2 } }, // Student ID spans 2 rows
    { s: { r: 0, c: 3 }, e: { r: 1, c: 3 } }, // Roll spans 2 rows
  ];

  const colWidths: { wch: number }[] = [
    { wch: 14 }, // Position
    { wch: 24 }, // Student Name
    { wch: 20 }, // Student ID
    { wch: 10 }, // Roll
  ];

  // Populate Exam columns in both header rows (Level 1: Exam Date & Name, Level 2: CQ, MCQ, Total)
  let colIndex = 4;
  sortedExams.forEach((exam) => {
    const formattedDate = formatDisplayDate(exam.date);
    // Level 1 Header: Date – Exam Name (Total Marks)
    const examHeaderTitle = `${formattedDate} – ${exam.name} (পূর্ণমান: ${exam.totalFullMarks})`;

    headerRow0.push(examHeaderTitle, '', '');
    // Merge across the 3 sub-columns (CQ, MCQ, Total)
    merges.push({
      s: { r: 0, c: colIndex },
      e: { r: 0, c: colIndex + 2 },
    });

    // Level 2 Sub-Headers
    headerRow1.push(
      `CQ (${exam.cqFullMarks})`,
      `MCQ (${exam.mcqFullMarks})`,
      `Total (${exam.totalFullMarks})`
    );

    // Optimized column widths for print and view
    colWidths.push({ wch: 12 }, { wch: 12 }, { wch: 13 });
    colIndex += 3;
  });

  // Overall Statistics Group at the end
  headerRow0.push('সর্বমোট পরিসংখ্যান (Overall Summary)', '', '', '');
  merges.push({
    s: { r: 0, c: colIndex },
    e: { r: 0, c: colIndex + 3 },
  });
  headerRow1.push('মোট অংশগ্রহণ', 'মোট প্রাপ্ত নম্বর', 'গড় নম্বর', 'গড় শতকরা');
  colWidths.push({ wch: 14 }, { wch: 16 }, { wch: 14 }, { wch: 14 });

  const sheetData: (string | number)[][] = [headerRow0, headerRow1];

  // ==========================================
  // STUDENT DATA ROWS (1 Row per Student)
  // ==========================================
  rankedStudents.forEach((ranked) => {
    const student = ranked.student;
    const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
    const row: (string | number)[] = [
      ranked.positionDisplay,
      student.name,
      studentIdCode,
      student.roll,
    ];

    let attendedCount = 0;
    let totalObtainedMarks = 0;
    let totalFullMarksAttended = 0;

    sortedExams.forEach((exam) => {
      const mark = exam.marks[student.id];
      const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

      if (!isAbsent && mark) {
        attendedCount++;
        const cqNum = typeof mark.cq === 'number' ? mark.cq : 0;
        const mcqNum = typeof mark.mcq === 'number' ? mark.mcq : 0;
        const totalNum = mark.total;

        totalObtainedMarks += totalNum;
        totalFullMarksAttended += exam.totalFullMarks;

        row.push(cqNum, mcqNum, totalNum);
      } else {
        // Missing or Absent: MUST REMAIN BLANK (no artificial 0!)
        row.push('', '', '');
      }
    });

    // Summary calculations
    const attendedStr = `${attendedCount} / ${sortedExams.length}`;
    const overallAvg =
      attendedCount > 0 ? Number((totalObtainedMarks / attendedCount).toFixed(1)) : '';
    const overallPercentage =
      totalFullMarksAttended > 0
        ? `${((totalObtainedMarks / totalFullMarksAttended) * 100).toFixed(1)}%`
        : '';

    row.push(
      attendedStr,
      attendedCount > 0 ? totalObtainedMarks : '',
      overallAvg !== '' ? overallAvg : '',
      overallPercentage
    );

    sheetData.push(row);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(sheetData);

  ws['!merges'] = merges;
  ws['!cols'] = colWidths;

  // ==========================================
  // PROFESSIONAL PRINT & VIEW CONFIGURATION
  // ==========================================
  // 1. Freeze top 2 header rows and left 3 columns (Name, ID, Roll)
  ws['!views'] = [
    {
      state: 'frozen',
      xSplit: 3,
      ySplit: 2,
      showGridLines: true,
    },
  ];

  // 2. Page Setup: Landscape orientation on A4, fit to 1 page wide
  ws['!pageSetup'] = {
    orientation: 'landscape',
    paperSize: 9, // A4
    fitToWidth: 1,
    fitToHeight: 0,
    scale: 100,
  };

  // 3. Narrow margins to maximize printable result columns
  ws['!margins'] = {
    left: 0.35,
    right: 0.35,
    top: 0.5,
    bottom: 0.5,
    header: 0.3,
    footer: 0.3,
  };

  XLSX.utils.book_append_sheet(wb, ws, 'Master Result Sheet');

  const today = new Date().toISOString().split('T')[0];
  const fileName = `COMMERCE_POINT_Master_Result_Sheet_${today}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

// =========================================================================
// 4. MONTHLY MASTER RESULT EXCEL (All Subjects, All Exams in Selected Month)
// =========================================================================
/**
 * Export full monthly master result sheet with multi-level headers:
 * Row 0: COMMERCE POINT
 * Row 1: Monthly Examination Result – [Month Year]
 * Row 2: Blank
 * Row 3: Level 1 Header (Student Name, ID, Roll | Subject – Date – Exam Name | Monthly Summary)
 * Row 4: Level 2 Sub-Header (CQ, MCQ, Total per exam | Attended, Obtained, Avg, %)
 */
export async function exportMonthlyMasterExcel(
  examsInMonth: Exam[],
  students: Student[],
  monthLabel: string,
  subjects: Subject[]
): Promise<boolean> {
  if (!examsInMonth || examsInMonth.length === 0) {
    throw new Error('এই মাসে Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
  }

  if (!students || students.length === 0) {
    throw new Error('কোনো শিক্ষার্থীর তথ্য পাওয়া যায়নি।');
  }

  // Create subject map for lookup
  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  // Sort exams chronologically (oldest to newest)
  const sortedExams = [...examsInMonth].sort((a, b) => {
    const diff = new Date(a.date).getTime() - new Date(b.date).getTime();
    if (diff !== 0) return diff;
    return (a.createdAt || 0) - (b.createdAt || 0);
  });

  // Rank students strictly by Total Obtained Marks descending across all exams in month
  const rankedStudents = rankStudentsForMonthlyMaster(examsInMonth, students);

  // Headers
  const row0 = ['COMMERCE POINT'];
  const row1 = [`Monthly Examination Result – ${monthLabel}`];
  const row2: string[] = [];

  const row3: (string | number)[] = [
    'মেধাক্রম / Position',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'রোল (Roll)',
  ];

  const row4: (string | number)[] = [
    '',
    '',
    '',
    '',
  ];

  // Merges configuration
  const merges: XLSX.Range[] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }, // Title row
    { s: { r: 1, c: 0 }, e: { r: 1, c: 6 } }, // Subtitle row
    { s: { r: 3, c: 0 }, e: { r: 4, c: 0 } }, // Position spans 2 rows
    { s: { r: 3, c: 1 }, e: { r: 4, c: 1 } }, // Student Name spans 2 rows
    { s: { r: 3, c: 2 }, e: { r: 4, c: 2 } }, // Student ID spans 2 rows
    { s: { r: 3, c: 3 }, e: { r: 4, c: 3 } }, // Roll spans 2 rows
  ];

  const colWidths: { wch: number }[] = [
    { wch: 14 }, // Position
    { wch: 24 }, // Student Name
    { wch: 20 }, // Student ID
    { wch: 10 }, // Roll
  ];

  let colIndex = 4;
  sortedExams.forEach((exam) => {
    const subObj = subjectMap.get(exam.subjectId || 'ict');
    const subName = subObj ? subObj.name : (exam.subjectId || 'ICT').toUpperCase();
    const formattedDate = formatDisplayDate(exam.date);
    const examHeaderTitle = `${subName} – ${formattedDate} – ${exam.name} (${exam.totalFullMarks})`;

    row3.push(examHeaderTitle, '', '');
    merges.push({
      s: { r: 3, c: colIndex },
      e: { r: 3, c: colIndex + 2 },
    });

    row4.push(
      `CQ (${exam.cqFullMarks})`,
      `MCQ (${exam.mcqFullMarks})`,
      `Total (${exam.totalFullMarks})`
    );

    colWidths.push({ wch: 12 }, { wch: 12 }, { wch: 13 });
    colIndex += 3;
  });

  // Overall Monthly Stats Header
  row3.push('মাসিক মূল্যায়ন ও পরিসংখ্যান (Monthly Summary)', '', '', '');
  merges.push({
    s: { r: 3, c: colIndex },
    e: { r: 3, c: colIndex + 3 },
  });
  row4.push('অংশগ্রহণ', 'মোট প্রাপ্ত নম্বর', 'গড় নম্বর', 'গড় শতকরা');
  colWidths.push({ wch: 14 }, { wch: 16 }, { wch: 14 }, { wch: 14 });

  const sheetData: (string | number)[][] = [row0, row1, row2, row3, row4];

  // Student Rows sorted strictly by ranking
  rankedStudents.forEach((ranked) => {
    const student = ranked.student;
    const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
    const row: (string | number)[] = [
      ranked.positionDisplay,
      student.name,
      studentIdCode,
      student.roll,
    ];

    let attendedCount = 0;
    let totalObtainedMarks = 0;
    let totalFullMarksAttended = 0;

    sortedExams.forEach((exam) => {
      const mark = exam.marks ? exam.marks[student.id] : undefined;
      const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

      if (!isAbsent && mark) {
        attendedCount++;
        const cqNum = typeof mark.cq === 'number' ? mark.cq : 0;
        const mcqNum = typeof mark.mcq === 'number' ? mark.mcq : 0;
        const totalNum = mark.total;

        totalObtainedMarks += totalNum;
        totalFullMarksAttended += exam.totalFullMarks;

        row.push(cqNum, mcqNum, totalNum);
      } else {
        // Absent / Unattended: Keep blank (no fake 0)
        row.push('', '', '');
      }
    });

    const attendedStr = `${attendedCount} / ${sortedExams.length}`;
    const overallAvg =
      attendedCount > 0 ? Number((totalObtainedMarks / attendedCount).toFixed(1)) : '';
    const overallPercentage =
      totalFullMarksAttended > 0
        ? `${((totalObtainedMarks / totalFullMarksAttended) * 100).toFixed(1)}%`
        : '';

    row.push(
      attendedStr,
      attendedCount > 0 ? totalObtainedMarks : '',
      overallAvg !== '' ? overallAvg : '',
      overallPercentage
    );

    sheetData.push(row);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(sheetData);

  ws['!merges'] = merges;
  ws['!cols'] = colWidths;

  // Freeze top 5 rows and 4 left columns
  ws['!views'] = [
    {
      state: 'frozen',
      xSplit: 4,
      ySplit: 5,
      showGridLines: true,
    },
  ];

  // Print setup: Landscape A4
  ws['!pageSetup'] = {
    orientation: 'landscape',
    paperSize: 9, // A4
    fitToWidth: 1,
    fitToHeight: 0,
    scale: 100,
  };

  const safeMonth = sanitizeFileName(monthLabel);
  XLSX.utils.book_append_sheet(wb, ws, 'Monthly Result');

  const fileName = `COMMERCE_POINT_Monthly_Result_${safeMonth}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

// =========================================================================
// 5. STUDENT MONTHLY RESULT EXCEL (Single Student Across All Subjects in Month)
// =========================================================================
export async function exportStudentMonthlyExcel(
  student: Student,
  examsInMonth: Exam[],
  monthLabel: string,
  subjects: Subject[],
  allStudents?: Student[]
): Promise<boolean> {
  if (!student) {
    throw new Error('শিক্ষার্থীর তথ্য পাওয়া যায়নি।');
  }

  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  const sortedExams = [...examsInMonth].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;

  // Calculate monthly rank if allStudents is provided
  let monthlyRankDisplay = '—';
  if (allStudents && allStudents.length > 0) {
    const monthlyPos = getStudentMonthlyPosition(student.id, sortedExams, allStudents);
    monthlyRankDisplay = monthlyPos.positionDisplay !== '—'
      ? `${monthlyPos.positionDisplay} / ${allStudents.length}`
      : '—';
  }

  const sheetData: (string | number)[][] = [
    ['COMMERCE POINT'],
    [`Student Monthly Academic Result – ${monthLabel}`],
    [],
    ['শিক্ষার্থীর নাম:', student.name, '', 'Student ID:', studentIdCode],
    ['শ্রেণি:', student.academicClass || 'XI', '', 'রোল:', student.roll],
    ['গ্রুপ:', student.group || 'B-A', '', 'সেশন:', student.session || '2026'],
    ['মাসিক অবস্থান (Monthly Rank):', monthlyRankDisplay, '', 'মোট শিক্ষার্থী:', allStudents ? allStudents.length : ''],
    [],
    [
      'তারিখ (Date)',
      'বিষয় (Subject)',
      'পরীক্ষার নাম (Exam Name)',
      'পরীক্ষায় অবস্থান (Position)',
      'CQ প্রাপ্ত নম্বর',
      'CQ পূর্ণমান',
      'MCQ প্রাপ্ত নম্বর',
      'MCQ পূর্ণমান',
      'মোট প্রাপ্ত নম্বর',
      'মোট পূর্ণমান',
      'শতকরা (%)',
      'গ্রেড (Grade)',
      'স্ট্যাটাস (Status)',
    ],
  ];

  let attendedCount = 0;
  let totalObtained = 0;
  let totalFull = 0;

  sortedExams.forEach((exam) => {
    const subObj = subjectMap.get(exam.subjectId || 'ict');
    const subName = subObj ? subObj.name : (exam.subjectId || 'ICT').toUpperCase();
    const mark = exam.marks ? exam.marks[student.id] : undefined;
    const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

    let examPosStr = '—';
    if (allStudents && allStudents.length > 0) {
      const pos = getStudentExamPosition(student.id, exam, allStudents);
      examPosStr = pos.positionDisplay;
    }

    const cqVal = mark && mark.cq !== '' ? mark.cq : (isAbsent ? '' : 0);
    const mcqVal = mark && mark.mcq !== '' ? mark.mcq : (isAbsent ? '' : 0);
    const totalVal = mark && !isAbsent ? mark.total : (isAbsent ? '' : 0);
    const pctVal = mark && !isAbsent ? `${mark.percentage}%` : '';
    const gradeVal = mark && !isAbsent ? mark.grade : (isAbsent ? 'Absent' : 'F');
    const statusVal = isAbsent ? 'অনুপস্থিত' : 'উপস্থিত';

    if (!isAbsent && mark) {
      attendedCount++;
      totalObtained += mark.total;
      totalFull += exam.totalFullMarks;
    }

    sheetData.push([
      exam.date,
      subName,
      exam.name,
      examPosStr,
      cqVal,
      exam.cqFullMarks,
      mcqVal,
      exam.mcqFullMarks,
      totalVal,
      exam.totalFullMarks,
      pctVal,
      gradeVal,
      statusVal,
    ]);
  });

  sheetData.push([]);
  sheetData.push(['মাসিক সামগ্রিক ফলাফল (Monthly Overall Summary)']);
  sheetData.push(['মাসিক অবস্থান (Monthly Rank):', monthlyRankDisplay]);
  sheetData.push(['মোট পরীক্ষা:', sortedExams.length, 'উপস্থিত পরীক্ষা:', attendedCount]);
  sheetData.push([
    'মোট প্রাপ্ত নম্বর:',
    totalObtained,
    'গড় নম্বর:',
    attendedCount > 0 ? Number((totalObtained / attendedCount).toFixed(1)) : 0,
  ]);
  sheetData.push([
    'গড় শতকরা:',
    totalFull > 0 ? `${((totalObtained / totalFull) * 100).toFixed(1)}%` : '0%',
    'অংশগ্রহণের হার:',
    sortedExams.length > 0 ? `${Math.round((attendedCount / sortedExams.length) * 100)}%` : '0%',
  ]);

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(sheetData);

  ws['!cols'] = [
    { wch: 14 }, // Date
    { wch: 18 }, // Subject
    { wch: 28 }, // Exam Name
    { wch: 16 }, // Position
    { wch: 14 }, // CQ
    { wch: 14 }, // CQ Full
    { wch: 14 }, // MCQ
    { wch: 14 }, // MCQ Full
    { wch: 16 }, // Total
    { wch: 14 }, // Total Full
    { wch: 14 }, // %
    { wch: 12 }, // Grade
    { wch: 16 }, // Status
  ];

  ws['!views'] = [{ state: 'frozen', xSplit: 0, ySplit: 8 }];

  const safeStudentName = sanitizeFileName(student.name);
  const safeMonth = sanitizeFileName(monthLabel);
  XLSX.utils.book_append_sheet(wb, ws, 'Student Monthly Result');

  const fileName = `COMMERCE_POINT_${safeStudentName}_Monthly_Result_${safeMonth}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

// =========================================================================
// 6. SUBJECT MONTHLY RESULT EXCEL (Single Subject in Selected Month)
// =========================================================================
export async function exportSubjectMonthlyExcel(
  subject: Subject,
  examsInMonth: Exam[],
  students: Student[],
  monthLabel: string
): Promise<boolean> {
  const subjectExams = examsInMonth.filter((e) => (e.subjectId || 'ict') === subject.id);
  if (subjectExams.length === 0) {
    throw new Error(`${subject.name} বিষয়ের জন্য এই মাসে কোনো পরীক্ষা পাওয়া যায়নি।`);
  }

  const sortedExams = [...subjectExams].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  // Rank students strictly by Total Marks / Performance in this subject
  const rankedStudents = rankStudentsForSubjectMonth(sortedExams, students);

  const row0 = ['COMMERCE POINT'];
  const row1 = [`${subject.name} – Monthly Examination Result – ${monthLabel}`];
  const row2: string[] = [];

  const row3: (string | number)[] = [
    'মেধাক্রম / Position',
    'শিক্ষার্থীর নাম (Student Name)',
    'Student ID',
    'রোল (Roll)',
  ];

  sortedExams.forEach((exam) => {
    row3.push(`${formatDisplayDate(exam.date)} (${exam.totalFullMarks})`);
  });
  row3.push('অংশগ্রহণ', 'মোট নম্বর', 'মাসিক গড় (Monthly Avg)', 'শতকরা (%)');

  const sheetData: (string | number)[][] = [row0, row1, row2, row3];

  rankedStudents.forEach((ranked) => {
    const student = ranked.student;
    const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
    const row: (string | number)[] = [
      ranked.positionDisplay,
      student.name,
      studentIdCode,
      student.roll,
    ];

    let attended = 0;
    let sumMarks = 0;
    let sumFull = 0;

    sortedExams.forEach((exam) => {
      const mark = exam.marks ? exam.marks[student.id] : undefined;
      const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');
      if (!isAbsent && mark) {
        attended++;
        sumMarks += mark.total;
        sumFull += exam.totalFullMarks;
        row.push(mark.total);
      } else {
        row.push('');
      }
    });

    const avg = attended > 0 ? Number((sumMarks / attended).toFixed(1)) : '';
    const pct = sumFull > 0 ? `${((sumMarks / sumFull) * 100).toFixed(1)}%` : '';

    row.push(
      `${attended} / ${sortedExams.length}`,
      attended > 0 ? sumMarks : '',
      avg,
      pct
    );

    sheetData.push(row);
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(sheetData);

  ws['!cols'] = [
    { wch: 14 }, // Position
    { wch: 22 }, // Name
    { wch: 20 }, // Student ID
    { wch: 10 }, // Roll
    ...sortedExams.map(() => ({ wch: 16 })),
    { wch: 14 },
    { wch: 14 },
    { wch: 18 },
    { wch: 14 },
  ];

  ws['!views'] = [{ state: 'frozen', xSplit: 3, ySplit: 4 }];

  const safeSubject = sanitizeFileName(subject.name);
  const safeMonth = sanitizeFileName(monthLabel);
  XLSX.utils.book_append_sheet(wb, ws, `${safeSubject} Result`);

  const fileName = `COMMERCE_POINT_${safeSubject}_${safeMonth}.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

/**
 * 7. STUDENT MONTHLY PROGRESS ANALYSIS WORKBOOK (3 Sheets)
 * Sheet 1: Monthly Summary
 * Sheet 2: Subject-wise Result
 * Sheet 3: Monthly Trend
 */
export async function exportStudentMonthlyProgressExcel(
  student: Student,
  exams: Exam[],
  monthLabel: string,
  subjects: Subject[],
  allStudents?: Student[]
): Promise<boolean> {
  const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;
  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  // Sort exams by date ascending
  const sortedExams = [...exams].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Aggregate stats
  const totalExamsCount = sortedExams.length;
  let attendedCount = 0;
  let absentCount = 0;
  let totalObtained = 0;
  let totalFull = 0;
  let highestMark = 0;
  let lowestMark = 999999;
  const distinctSubjects = new Set<string>();

  const examRows: {
    subjectName: string;
    date: string;
    examName: string;
    cq: number | string;
    mcq: number | string;
    total: number | string;
    fullMarks: number;
    percentage: number | string;
    grade: string;
    position: string;
    monthKey: string;
  }[] = [];

  sortedExams.forEach((exam) => {
    const subId = exam.subjectId || 'ict';
    const subObj = subjectMap.get(subId);
    const subName = subObj ? subObj.name : subId.toUpperCase();
    distinctSubjects.add(subId);

    const mark = exam.marks ? exam.marks[student.id] : undefined;
    const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

    let examPos = '—';
    if (allStudents && allStudents.length > 0) {
      const p = getStudentExamPosition(student.id, exam, allStudents);
      examPos = p.positionDisplay;
    }

    const monthKey = exam.date.substring(0, 7);

    if (!isAbsent && mark) {
      attendedCount++;
      const tot = Number(mark.total) || 0;
      totalObtained += tot;
      totalFull += exam.totalFullMarks;
      if (tot > highestMark) highestMark = tot;
      if (tot < lowestMark) lowestMark = tot;

      examRows.push({
        subjectName: subName,
        date: exam.date,
        examName: exam.name,
        cq: mark.cq !== '' ? mark.cq : 0,
        mcq: mark.mcq !== '' ? mark.mcq : 0,
        total: tot,
        fullMarks: exam.totalFullMarks,
        percentage: Number(mark.percentage) || 0,
        grade: mark.grade || 'F',
        position: examPos,
        monthKey,
      });
    } else {
      absentCount++;
      examRows.push({
        subjectName: subName,
        date: exam.date,
        examName: exam.name,
        cq: '—',
        mcq: '—',
        total: 'Absent',
        fullMarks: exam.totalFullMarks,
        percentage: '—',
        grade: 'Absent',
        position: '—',
        monthKey,
      });
    }
  });

  if (lowestMark === 999999) lowestMark = 0;
  const avgMarks = attendedCount > 0 ? Number((totalObtained / attendedCount).toFixed(1)) : 0;
  const avgPct = totalFull > 0 ? Number(((totalObtained / totalFull) * 100).toFixed(1)) : 0;

  // Monthly position lookup
  let monthlyPosStr = '—';
  if (allStudents && allStudents.length > 0 && exams.length > 0) {
    const pos = getStudentMonthlyPosition(student.id, exams, allStudents);
    monthlyPosStr = pos.positionDisplay;
  }

  // SHEET 1: Monthly Summary
  const s1Data: (string | number)[][] = [
    ['COMMERCE POINT - Academic Student Progress Summary'],
    [`Student Name: ${student.name}`, `Student ID: ${studentIdCode}`, `Roll: ${student.roll}`, `Period: ${monthLabel}`],
    [],
    [
      'Student Name',
      'Student ID',
      'Roll',
      'Period / Month',
      'Total Subjects',
      'Total Exams',
      'Attended Exams',
      'Absent Exams',
      'Total Obtained Marks',
      'Total Full Marks',
      'Average Marks',
      'Average Percentage',
      'Highest Marks',
      'Lowest Marks',
      'Overall Position',
    ],
    [
      student.name,
      studentIdCode,
      student.roll,
      monthLabel,
      distinctSubjects.size,
      totalExamsCount,
      attendedCount,
      absentCount,
      totalObtained,
      totalFull,
      avgMarks,
      `${avgPct}%`,
      highestMark,
      lowestMark,
      monthlyPosStr,
    ],
  ];

  // SHEET 2: Subject-wise Result
  const s2Data: (string | number)[][] = [
    ['COMMERCE POINT - Subject-wise Exam Results'],
    [`Student: ${student.name} (${studentIdCode})`, `Period: ${monthLabel}`],
    [],
    [
      'Subject',
      'Exam Date',
      'Exam Name',
      'CQ Marks',
      'MCQ Marks',
      'Total Marks',
      'Full Marks',
      'Percentage',
      'Grade',
      'Position',
    ],
  ];

  examRows.forEach((r) => {
    s2Data.push([
      r.subjectName,
      formatDisplayDate(r.date),
      r.examName,
      r.cq,
      r.mcq,
      r.total,
      r.fullMarks,
      typeof r.percentage === 'number' ? `${r.percentage}%` : r.percentage,
      r.grade,
      r.position,
    ]);
  });

  // SHEET 3: Monthly Trend
  const monthSubjectMap = new Map<string, {
    monthKey: string;
    subjectName: string;
    examsCount: number;
    attendedCount: number;
    totalMarks: number;
    totalFull: number;
    positions: number[];
  }>();

  examRows.forEach((r) => {
    const key = `${r.monthKey}_${r.subjectName}`;
    if (!monthSubjectMap.has(key)) {
      monthSubjectMap.set(key, {
        monthKey: r.monthKey,
        subjectName: r.subjectName,
        examsCount: 0,
        attendedCount: 0,
        totalMarks: 0,
        totalFull: 0,
        positions: [],
      });
    }
    const item = monthSubjectMap.get(key)!;
    item.examsCount++;
    if (typeof r.total === 'number') {
      item.attendedCount++;
      item.totalMarks += r.total;
      item.totalFull += r.fullMarks;
      const numPos = parseInt(r.position, 10);
      if (!isNaN(numPos)) item.positions.push(numPos);
    }
  });

  const s3Data: (string | number)[][] = [
    ['COMMERCE POINT - Student Monthly Progress Trend'],
    [`Student: ${student.name} (${studentIdCode})`, `Period: ${monthLabel}`],
    [],
    [
      'Month',
      'Subject',
      'Exams Count',
      'Attended',
      'Total Marks',
      'Full Marks',
      'Average %',
      'Best Position',
    ],
  ];

  Array.from(monthSubjectMap.values()).forEach((item) => {
    const avgP = item.totalFull > 0 ? `${((item.totalMarks / item.totalFull) * 100).toFixed(1)}%` : '—';
    const bestPos = item.positions.length > 0 ? Math.min(...item.positions) : '—';
    s3Data.push([
      item.monthKey,
      item.subjectName,
      item.examsCount,
      item.attendedCount,
      item.attendedCount > 0 ? item.totalMarks : 0,
      item.totalFull,
      avgP,
      bestPos,
    ]);
  });

  const wb = XLSX.utils.book_new();

  const ws1 = XLSX.utils.aoa_to_sheet(s1Data);
  ws1['!cols'] = [
    { wch: 22 }, { wch: 18 }, { wch: 8 }, { wch: 18 }, { wch: 14 },
    { wch: 12 }, { wch: 14 }, { wch: 14 }, { wch: 20 }, { wch: 16 },
    { wch: 14 }, { wch: 18 }, { wch: 14 }, { wch: 14 }, { wch: 16 },
  ];
  XLSX.utils.book_append_sheet(wb, ws1, 'Monthly Summary');

  const ws2 = XLSX.utils.aoa_to_sheet(s2Data);
  ws2['!cols'] = [
    { wch: 20 }, { wch: 14 }, { wch: 26 }, { wch: 12 }, { wch: 12 },
    { wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 10 }, { wch: 12 },
  ];
  XLSX.utils.book_append_sheet(wb, ws2, 'Subject-wise Result');

  const ws3 = XLSX.utils.aoa_to_sheet(s3Data);
  ws3['!cols'] = [
    { wch: 16 }, { wch: 20 }, { wch: 14 }, { wch: 12 }, { wch: 14 },
    { wch: 12 }, { wch: 14 }, { wch: 14 },
  ];
  XLSX.utils.book_append_sheet(wb, ws3, 'Monthly Trend');

  const safeName = sanitizeFileName(student.name);
  const safePeriod = sanitizeFileName(monthLabel);
  const fileName = `COMMERCE_POINT_${safeName}_${safePeriod}_Monthly_Progress.xlsx`;
  downloadWorkbook(wb, fileName);
  return true;
}

