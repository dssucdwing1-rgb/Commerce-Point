/**
 * COMMERCE POINT — Dedicated Print & PDF Styling Constants
 * 
 * Strict 'pt' units for typography and spacing.
 * Fully resolved opaque color definitions.
 */

import pdfStyles from './pdfPrint.module.css';
import { COMMERCE_POINT_LOGO_BASE64 } from './commercePointLogoBase64';

export const COMMERCE_POINT_LOGO_SVG_PATH = '/commerce-point-logo.svg';

/**
 * Returns clean, crisp, scalable Logo HTML prioritizing pure vector SVG with base64 PNG fallback.
 * Guarantees zero blur, zero pixelation, proper aspect ratio, and explicit pt sizing.
 */
export function getCommercePointLogoHtml(widthPt: number = 58, heightPt: number = 58): string {
  return `<img src="/commerce-point-logo.svg" onerror="this.onerror=null;this.src='${COMMERCE_POINT_LOGO_BASE64}';" alt="COMMERCE POINT" style="width: ${widthPt}pt; height: ${heightPt}pt; object-fit: contain; flex-shrink: 0;" />`;
}

export { pdfStyles, COMMERCE_POINT_LOGO_BASE64 };

/**
 * Resolved, print-safe, opaque Hex Color Palette
 * Eliminates all CSS opacity, CSS variable, and color profile discrepancies.
 */
export const PDF_COLORS = {
  // Brand Primary & Navy
  brandNavy: '#1e3a8a',
  brandNavyDark: '#1e40af',
  slateDark: '#0f172a',
  slateHeaderBg: '#1e293b',
  
  // Body Typography
  textPrimary: '#0f172a',
  textSecondary: '#334155',
  textMuted: '#475569',
  textLight: '#64748b',
  textWhite: '#ffffff',
  
  // Accents & Badges
  accentGold: '#fde047',
  accentGoldBg: '#fef3c7',
  accentGoldBorder: '#d97706',
  
  // Status Colors
  successGreen: '#059669',
  successGreenDark: '#065f46',
  successGreenBg: '#ecfdf5',
  successGreenBorder: '#6ee7b7',
  
  dangerRed: '#dc2626',
  dangerRedDark: '#b91c1c',
  dangerRedBg: '#fee2e2',
  dangerRedBorder: '#fca5a5',
  
  // Borders & Surfaces
  borderLight: '#cbd5e1',
  borderDark: '#334155',
  borderMuted: '#94a3b8',
  bgCard: '#f8fafc',
  bgHeaderSub: '#f1f5f9',
  bgWhite: '#ffffff',
} as const;

/**
 * Typography sizes strictly in 'pt'
 * 72pt = 1 inch = 96 CSS pixels (1pt = 1.333 CSS px)
 */
export const PDF_TYPOGRAPHY = {
  institutionTitle: '19.5pt',
  institutionTitleLineHeight: '22pt',
  
  institutionSubtitle: '10pt',
  institutionSubtitleLineHeight: '13pt',
  
  tagline: '8.5pt',
  taglineLineHeight: '11pt',
  
  sectionTitle: '12pt',
  sectionTitleLineHeight: '15pt',
  
  badge: '9pt',
  badgeLineHeight: '11pt',
  
  tableHeader: '8pt',
  tableHeaderGroup: '8.5pt',
  tableHeaderSub: '7.5pt',
  
  tableCell: '8pt',
  tableCellLineHeight: '10.5pt',
  tableCellName: '8.5pt',
  tableCellId: '7.5pt',
  
  statValue: '13.5pt',
  statValueLineHeight: '16pt',
  statLabel: '7.5pt',
  statSub: '7pt',
  
  metaText: '8pt',
  signatureName: '8.5pt',
  signatureRole: '7.5pt',
  footerNote: '7pt',
} as const;

/**
 * Physical A4 Dimensions in 'pt'
 * Portrait:  210mm x 297mm = 595.28pt x 841.89pt
 * Landscape: 297mm x 210mm = 841.89pt x 595.28pt
 */
export const PDF_PAGE_METRICS = {
  portrait: {
    widthPt: 595.28,
    heightPt: 841.89,
    widthMm: 210,
    heightMm: 297,
    padding: '20pt 24pt',
  },
  landscape: {
    widthPt: 841.89,
    heightPt: 595.28,
    widthMm: 297,
    heightMm: 210,
    padding: '18pt 22pt',
  },
} as const;

/**
 * Injects dedicated print-focused CSS rules into any off-screen container
 * to ensure that html2canvas captures 100% identical typography and spacing.
 */
export function getPdfPrintStylesSheet(): string {
  return `
    .pdf-isolated-root * {
      box-sizing: border-box !important;
      -webkit-font-smoothing: antialiased !important;
      -moz-osx-font-smoothing: grayscale !important;
      text-rendering: geometricPrecision !important;
    }
    .pdf-isolated-root {
      font-family: 'Nikosh', 'Kalpurush', 'Noto Sans Bengali', sans-serif !important;
      background-color: #ffffff !important;
      color: #0f172a !important;
    }
  `;
}
