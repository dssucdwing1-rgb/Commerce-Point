import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { PdfPreviewProvider } from './services/pdfPreviewContext.tsx';
import { PdfPreviewModal } from './components/pdf/PdfPreviewModal.tsx';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <PdfPreviewProvider>
      <App />
      <PdfPreviewModal />
    </PdfPreviewProvider>
  </StrictMode>,
);

