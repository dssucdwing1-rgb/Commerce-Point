import { Student, Exam, StudentMarkEntry, Subject } from '../types';

export const DEFAULT_SUBJECTS: Subject[] = [
  { id: 'ict', name: 'ICT', code: 'ICT', bengaliName: 'আইসিটি', isActive: true, isDefault: true, order: 1 },
  { id: 'bangla', name: 'Bangla', code: 'BANGLA', bengaliName: 'বাংলা', isActive: true, isDefault: true, order: 2 },
  { id: 'english', name: 'English', code: 'ENGLISH', bengaliName: 'English', isActive: true, isDefault: true, order: 3 },
  { id: 'accounting', name: 'Accounting', code: 'ACC', bengaliName: 'হিসাব বিজ্ঞান', isActive: true, isDefault: true, order: 4 },
  { id: 'marketing', name: 'Marketing', code: 'MKT', bengaliName: 'Marketing', isActive: true, isDefault: true, order: 5 },
  { id: 'management', name: 'Management', code: 'MGT', bengaliName: 'Management', isActive: true, isDefault: true, order: 6 },
  { id: 'economics', name: 'Economics', code: 'ECO', bengaliName: 'অর্থনীতি', isActive: true, isDefault: true, order: 7 },
];

export const ALL_DEFAULT_SUBJECT_IDS = DEFAULT_SUBJECTS.map((s) => s.id);

export const STUDENTS_LIST: Student[] = [
  { id: '1', roll: 1, name: 'মুসকান', studentIdCode: 'CP/C-11/B-A 001', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '2', roll: 2, name: 'রিমি', studentIdCode: 'CP/C-11/B-A 002', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '3', roll: 3, name: 'ইয়াসিন', studentIdCode: 'CP/C-11/B-A 003', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '4', roll: 4, name: 'ইমু', studentIdCode: 'CP/C-11/B-A 004', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '5', roll: 5, name: 'মাহিয়া (নিউ)', studentIdCode: 'CP/C-11/B-A 005', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '6', roll: 6, name: 'লোকমান (নিউ)', studentIdCode: 'CP/C-11/B-A 006', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '7', roll: 7, name: 'আরমান', studentIdCode: 'CP/C-11/B-A 007', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '8', roll: 8, name: 'রনি', studentIdCode: 'CP/C-11/B-A 008', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '9', roll: 9, name: 'তসলিমা', studentIdCode: 'CP/C-11/B-A 009', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '10', roll: 10, name: 'হাবিবা', studentIdCode: 'CP/C-11/B-A 010', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '11', roll: 11, name: 'অনন্ত (নিউ)', studentIdCode: 'CP/C-11/B-A 011', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '12', roll: 12, name: 'আবিদ (নিউ)', studentIdCode: 'CP/C-11/B-A 012', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '13', roll: 13, name: 'নাবিল (নিউ)', studentIdCode: 'CP/C-11/B-A 013', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '14', roll: 14, name: 'বুশরা', studentIdCode: 'CP/C-11/B-A 014', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '15', roll: 15, name: 'রাহেব', studentIdCode: 'CP/C-11/B-A 015', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '16', roll: 16, name: 'সুরাইয়া (নিউ)', studentIdCode: 'CP/C-11/B-A 016', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: '17', roll: 17, name: 'জারিন', studentIdCode: 'CP/C-11/B-A 017', batchId: 'class-11-a', academicClass: 'XI', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
];

// Class 12 - Batch A (দ্বাদশ শ্রেণি — ব্যাচ এ: ৩১ জন শিক্ষার্থী)
export const STUDENTS_CLASS_12_A: Student[] = [
  { id: 'c12a-1', roll: 1, name: 'প্রান্তিকা', studentIdCode: 'CP/C-12/B-A 001', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-2', roll: 2, name: 'সাদিয়া', studentIdCode: 'CP/C-12/B-A 002', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-3', roll: 3, name: 'সানজানা', studentIdCode: 'CP/C-12/B-A 003', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-4', roll: 4, name: 'সুবহা', studentIdCode: 'CP/C-12/B-A 004', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-5', roll: 5, name: 'মিম–১', studentIdCode: 'CP/C-12/B-A 005', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-6', roll: 6, name: 'জিনালী', studentIdCode: 'CP/C-12/B-A 006', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-7', roll: 7, name: 'রোজা', studentIdCode: 'CP/C-12/B-A 007', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-8', roll: 8, name: 'জান্নাত', studentIdCode: 'CP/C-12/B-A 008', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-9', roll: 9, name: 'নাবিলা', studentIdCode: 'CP/C-12/B-A 009', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-10', roll: 10, name: 'সুইটি', studentIdCode: 'CP/C-12/B-A 010', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-11', roll: 11, name: 'মৌমিতা', studentIdCode: 'CP/C-12/B-A 011', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-12', roll: 12, name: 'রিতু', studentIdCode: 'CP/C-12/B-A 012', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-13', roll: 13, name: 'ইয়াসমিন', studentIdCode: 'CP/C-12/B-A 013', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-14', roll: 14, name: 'মিষ্টি', studentIdCode: 'CP/C-12/B-A 014', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-15', roll: 15, name: 'পরমা', studentIdCode: 'CP/C-12/B-A 015', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-16', roll: 16, name: 'হ্যাপি', studentIdCode: 'CP/C-12/B-A 016', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-17', roll: 17, name: 'ফারদিনা', studentIdCode: 'CP/C-12/B-A 017', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-18', roll: 18, name: 'নেহা', studentIdCode: 'CP/C-12/B-A 018', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-19', roll: 19, name: 'স্বর্ণা', studentIdCode: 'CP/C-12/B-A 019', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-20', roll: 20, name: 'রাফিদ', studentIdCode: 'CP/C-12/B-A 020', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-21', roll: 21, name: 'সাকিব', studentIdCode: 'CP/C-12/B-A 021', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-22', roll: 22, name: 'রিমু', studentIdCode: 'CP/C-12/B-A 022', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-23', roll: 23, name: 'মিম–২', studentIdCode: 'CP/C-12/B-A 023', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-24', roll: 24, name: 'নাদিয়া', studentIdCode: 'CP/C-12/B-A 024', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-25', roll: 25, name: 'আরাফাত', studentIdCode: 'CP/C-12/B-A 025', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-26', roll: 26, name: 'ইয়াসিন', studentIdCode: 'CP/C-12/B-A 026', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-27', roll: 27, name: 'চাঁদ', studentIdCode: 'CP/C-12/B-A 027', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-28', roll: 28, name: 'আলিফ', studentIdCode: 'CP/C-12/B-A 028', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-29', roll: 29, name: 'হালিম', studentIdCode: 'CP/C-12/B-A 029', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-30', roll: 30, name: 'আদিল', studentIdCode: 'CP/C-12/B-A 030', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12a-31', roll: 31, name: 'মাহের', studentIdCode: 'CP/C-12/B-A 031', batchId: 'class-12-a', academicClass: 'XII', group: 'B-A', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
];

// Class 12 - Batch B (দ্বাদশ শ্রেণি — ব্যাচ বি: ১৩ জন শিক্ষার্থী)
export const STUDENTS_CLASS_12_B: Student[] = [
  { id: 'c12b-1', roll: 1, name: 'সুবর্ণা', studentIdCode: 'CP/C-12/B-B 001', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-2', roll: 2, name: 'অধরা', studentIdCode: 'CP/C-12/B-B 002', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-3', roll: 3, name: 'শাকিলা', studentIdCode: 'CP/C-12/B-B 003', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-4', roll: 4, name: 'সানজিদা', studentIdCode: 'CP/C-12/B-B 004', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-5', roll: 5, name: 'জেমি', studentIdCode: 'CP/C-12/B-B 005', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-6', roll: 6, name: 'মাহি', studentIdCode: 'CP/C-12/B-B 006', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-7', roll: 7, name: 'মিমি', studentIdCode: 'CP/C-12/B-B 007', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-8', roll: 8, name: 'সুমাইয়া', studentIdCode: 'CP/C-12/B-B 008', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-9', roll: 9, name: 'ইকরা', studentIdCode: 'CP/C-12/B-B 009', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-10', roll: 10, name: 'আলিফ', studentIdCode: 'CP/C-12/B-B 010', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-11', roll: 11, name: 'দ্বীন ইসলাম', studentIdCode: 'CP/C-12/B-B 011', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-12', roll: 12, name: 'নাফিজ', studentIdCode: 'CP/C-12/B-B 012', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
  { id: 'c12b-13', roll: 13, name: 'সিয়াম', studentIdCode: 'CP/C-12/B-B 013', batchId: 'class-12-b', academicClass: 'XII', group: 'B-B', subject: 'ICT', session: '2026', assignedSubjectIds: ALL_DEFAULT_SUBJECT_IDS },
];

export const ALL_INITIAL_STUDENTS: Student[] = [
  ...STUDENTS_LIST,
  ...STUDENTS_CLASS_12_A,
  ...STUDENTS_CLASS_12_B,
];

export function calculateGrade(percentage: number): string {
  if (percentage >= 80) return 'A+';
  if (percentage >= 70) return 'A';
  if (percentage >= 60) return 'A-';
  if (percentage >= 50) return 'B';
  if (percentage >= 40) return 'C';
  if (percentage >= 33) return 'D';
  return 'F';
}

export function getGradeBadgeColor(grade: string): { bg: string; text: string; border: string } {
  switch (grade) {
    case 'A+':
      return { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' };
    case 'A':
      return { bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-200' };
    case 'A-':
      return { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' };
    case 'B':
      return { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' };
    case 'C':
      return { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' };
    case 'D':
      return { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200' };
    default:
      return { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' };
  }
}

// Convert western numbers to Bengali numbers for pleasant UI display
export function toBengaliNum(num: number | string): string {
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (w) => bengaliDigits[+w]);
}

// Fixed Marks Pair: [CQ (out of 30), MCQ (out of 20)] -> Total (out of 50)
type StudentMarkMap = Record<string, [number, number]>;

function buildExam(
  id: string,
  date: string,
  name: string,
  subjectId: string,
  marksMap: StudentMarkMap,
  cqFull: number = 30,
  mcqFull: number = 20,
  batchId: string = 'class-11-a',
  targetStudents: Student[] = STUDENTS_LIST
): Exam {
  const totalFullMarks = cqFull + mcqFull;
  const marks: Record<string, StudentMarkEntry> = {};
  let totalScoreSum = 0;
  let attendedCount = 0;

  targetStudents.forEach((s) => {
    const pair = marksMap[s.id];
    if (!pair) {
      // Absent
      marks[s.id] = {
        studentId: s.id,
        studentName: s.name,
        cq: '',
        mcq: '',
        total: 0,
        percentage: 0,
        grade: 'Absent',
      };
      return;
    }

    const [cq, mcq] = pair;
    const total = cq + mcq;
    const percentage = Math.round((total / totalFullMarks) * 100);
    const grade = calculateGrade(percentage);

    marks[s.id] = {
      studentId: s.id,
      studentName: s.name,
      cq,
      mcq,
      total,
      percentage,
      grade,
    };

    totalScoreSum += total;
    attendedCount++;
  });

  const average = attendedCount > 0 ? Number((totalScoreSum / attendedCount).toFixed(1)) : 0;
  const averagePercentage = totalFullMarks > 0 ? Math.round((average / totalFullMarks) * 100) : 0;

  return {
    id,
    batchId,
    subjectId,
    date,
    name,
    cqFullMarks: cqFull,
    mcqFullMarks: mcqFull,
    totalFullMarks,
    marks,
    average,
    averagePercentage,
    createdAt: new Date(date).getTime(),
  };
}

// ========================================================
// 12 REALISTIC DEMO EXAMS (4 per Month x 3 Months)
// September 2026, October 2026, November 2026
// Exactly 1 Exam per Subject per Month
// ========================================================

// --------------------------------------------------------
// MONTH 1: SEPTEMBER 2026
// Subjects: 1. ICT, 2. বাংলা, 3. English, 4. হিসাব বিজ্ঞান
// --------------------------------------------------------

// 1. ICT Monthly Test – September (05 Sep 2026)
// মুসকান: CQ 22, MCQ 15, Total 37
// রিমি: CQ 24, MCQ 16, Total 40
// ইয়াসিন: CQ 19, MCQ 13, Total 32
const marks_sep_ict: StudentMarkMap = {
  '1': [22, 15],  // মুসকান -> 37 (74% - A)
  '2': [24, 16],  // রিমি -> 40 (80% - A+)
  '3': [19, 13],  // ইয়াসিন -> 32 (64% - A-)
  '4': [25, 17],  // ইমু -> 42 (84% - A+)
  '5': [18, 11],  // মাহিয়া -> 29 (58% - B)
  '6': [21, 14],  // লোকমান -> 35 (70% - A)
  '7': [27, 18],  // আরমান -> 45 (90% - A+)
  '8': [17, 12],  // রনি -> 29 (58% - B)
  '9': [23, 15],  // তসলিমা -> 38 (76% - A)
  '10': [26, 17], // হাবিবা -> 43 (86% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [21, 14], // আবিদ -> 35 (70% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [22, 15], // রাহেব -> 37 (74% - A)
  '16': [16, 11], // সুরাইয়া -> 27 (54% - B)
  '17': [24, 16], // জারিন -> 40 (80% - A+)
};

// 2. বাংলা Monthly Test – September (10 Sep 2026)
// মুসকান: 10 Sep — CQ 24 — MCQ 16 — Total 40
const marks_sep_bn: StudentMarkMap = {
  '1': [24, 16],  // মুসকান -> 40 (80% - A+)
  '2': [23, 15],  // রিমি -> 38 (76% - A)
  '3': [18, 12],  // ইয়াসিন -> 30 (60% - A-)
  '4': [26, 17],  // ইমু -> 43 (86% - A+)
  '5': [17, 12],  // মাহিয়া -> 29 (58% - B)
  '6': [20, 14],  // লোকমান -> 34 (68% - A-)
  '7': [26, 18],  // আরমান -> 44 (88% - A+)
  '8': [18, 11],  // রনি -> 29 (58% - B)
  '9': [24, 15],  // তসলিমা -> 39 (78% - A)
  '10': [25, 17], // হাবিবা -> 42 (84% - A+)
  '11': [19, 13], // অনন্ত -> 32 (64% - A-)
  '12': [22, 14], // আবিদ -> 36 (72% - A)
  '13': [18, 12], // নাবিল -> 30 (60% - A-)
  '14': [27, 18], // বুশরা -> 45 (90% - A+)
  '15': [23, 14], // রাহেব -> 37 (74% - A)
  '16': [17, 10], // সুরাইয়া -> 27 (54% - B)
  '17': [25, 16], // জারিন -> 41 (82% - A+)
};

// 3. English Monthly Test – September (17 Sep 2026)
// মুসকান: 17 Sep — CQ 20 — MCQ 14 — Total 34
const marks_sep_eng: StudentMarkMap = {
  '1': [20, 14],  // মুসকান -> 34 (68% - A-)
  '2': [22, 15],  // রিমি -> 37 (74% - A)
  '3': [17, 11],  // ইয়াসিন -> 28 (56% - B)
  '4': [24, 16],  // ইমু -> 40 (80% - A+)
  '5': [16, 10],  // মাহিয়া -> 26 (52% - B)
  '6': [21, 13],  // লোকমান -> 34 (68% - A-)
  '7': [28, 18],  // আরমান -> 46 (92% - A+)
  '8': [17, 11],  // রনি -> 28 (56% - B)
  '9': [23, 14],  // তসলিমা -> 37 (74% - A)
  '10': [25, 16], // হাবিবা -> 41 (82% - A+)
  '11': [19, 12], // অনন্ত -> 31 (62% - A-)
  '12': [20, 13], // আবিদ -> 33 (66% - A-)
  '13': [18, 11], // নাবিল -> 29 (58% - B)
  '14': [27, 19], // বুশরা -> 46 (92% - A+)
  '15': [21, 14], // রাহেব -> 35 (70% - A)
  '16': [15, 10], // সুরাইয়া -> 25 (50% - B)
  '17': [24, 15], // জারিন -> 39 (78% - A)
};

// 4. হিসাব বিজ্ঞান Monthly Test – September (24 Sep 2026)
// মুসকান: 24 Sep — CQ 25 — MCQ 18 — Total 43
const marks_sep_acc: StudentMarkMap = {
  '1': [25, 18],  // মুসকান -> 43 (86% - A+)
  '2': [24, 17],  // রিমি -> 41 (82% - A+)
  '3': [19, 13],  // ইয়াসিন -> 32 (64% - A-)
  '4': [26, 18],  // ইমু -> 44 (88% - A+)
  '5': [18, 11],  // মাহিয়া -> 29 (58% - B)
  '6': [22, 14],  // লোকমান -> 36 (72% - A)
  '7': [28, 19],  // আরমান -> 47 (94% - A+)
  '8': [19, 12],  // রনি -> 31 (62% - A-)
  '9': [24, 16],  // তসলিমা -> 40 (80% - A+)
  '10': [26, 18], // হাবিবা -> 44 (88% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [21, 14], // আবিদ -> 35 (70% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [23, 15], // রাহেব -> 38 (76% - A)
  '16': [17, 11], // সুরাইয়া -> 28 (56% - B)
  '17': [25, 17], // জারিন -> 42 (84% - A+)
};

// --------------------------------------------------------
// MONTH 2: OCTOBER 2026
// Subjects: 1. Marketing, 2. Management, 3. অর্থনীতি, 4. ICT
// --------------------------------------------------------

// 5. Marketing Monthly Test – October (05 Oct 2026)
const marks_oct_mkt: StudentMarkMap = {
  '1': [23, 16],  // মুসকান -> 39 (78% - A)
  '2': [24, 16],  // রিমি -> 40 (80% - A+)
  '3': [18, 12],  // ইয়াসিন -> 30 (60% - A-)
  '4': [25, 17],  // ইমু -> 42 (84% - A+)
  '5': [17, 11],  // মাহিয়া -> 28 (56% - B)
  '6': [21, 14],  // লোকমান -> 35 (70% - A)
  '7': [27, 18],  // আরমান -> 45 (90% - A+)
  '8': [18, 12],  // রনি -> 30 (60% - A-)
  '9': [23, 15],  // তসলিমা -> 38 (76% - A)
  '10': [26, 17], // হাবিবা -> 43 (86% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [22, 14], // আবিদ -> 36 (72% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [27, 19], // বুশরা -> 46 (92% - A+)
  '15': [23, 15], // রাহেব -> 38 (76% - A)
  '16': [16, 10], // সুরাইয়া -> 26 (52% - B)
  '17': [24, 16], // জারিন -> 40 (80% - A+)
};

// 6. Management Monthly Test – October (12 Oct 2026)
const marks_oct_mgt: StudentMarkMap = {
  '1': [24, 16],  // মুসকান -> 40 (80% - A+)
  '2': [23, 15],  // রিমি -> 38 (76% - A)
  '3': [19, 13],  // ইয়াসিন -> 32 (64% - A-)
  '4': [26, 17],  // ইমু -> 43 (86% - A+)
  '5': [18, 11],  // মাহিয়া -> 29 (58% - B)
  '6': [22, 14],  // লোকমান -> 36 (72% - A)
  '7': [28, 19],  // আরমান -> 47 (94% - A+)
  '8': [17, 11],  // রনি -> 28 (56% - B)
  '9': [24, 16],  // তসলিমা -> 40 (80% - A+)
  '10': [26, 18], // হাবিবা -> 44 (88% - A+)
  '11': [19, 13], // অনন্ত -> 32 (64% - A-)
  '12': [21, 14], // আবিদ -> 35 (70% - A)
  '13': [18, 12], // নাবিল -> 30 (60% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [22, 14], // রাহেব -> 36 (72% - A)
  '16': [17, 11], // সুরাইয়া -> 28 (56% - B)
  '17': [25, 17], // জারিন -> 42 (84% - A+)
};

// 7. অর্থনীতি Monthly Test – October (19 Oct 2026)
const marks_oct_eco: StudentMarkMap = {
  '1': [22, 15],  // মুসকান -> 37 (74% - A)
  '2': [24, 16],  // রিমি -> 40 (80% - A+)
  '3': [18, 11],  // ইয়াসিন -> 29 (58% - B)
  '4': [25, 17],  // ইমু -> 42 (84% - A+)
  '5': [17, 11],  // মাহিয়া -> 28 (56% - B)
  '6': [20, 13],  // লোকমান -> 33 (66% - A-)
  '7': [27, 18],  // আরমান -> 45 (90% - A+)
  '8': [18, 12],  // রনি -> 30 (60% - A-)
  '9': [23, 15],  // তসলিমা -> 38 (76% - A)
  '10': [26, 17], // হাবিবা -> 43 (86% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [21, 14], // আবিদ -> 35 (70% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [22, 14], // রাহেব -> 36 (72% - A)
  '16': [16, 10], // সুরাইয়া -> 26 (52% - B)
  '17': [24, 16], // জারিন -> 40 (80% - A+)
};

// 8. ICT Monthly Test – October (26 Oct 2026)
const marks_oct_ict: StudentMarkMap = {
  '1': [24, 16],  // মুসকান -> 40 (80% - A+)
  '2': [25, 17],  // রিমি -> 42 (84% - A+)
  '3': [20, 13],  // ইয়াসিন -> 33 (66% - A-)
  '4': [26, 18],  // ইমু -> 44 (88% - A+)
  '5': [18, 12],  // মাহিয়া -> 30 (60% - A-)
  '6': [22, 15],  // লোকমান -> 37 (74% - A)
  '7': [28, 19],  // আরমান -> 47 (94% - A+)
  '8': [19, 12],  // রনি -> 31 (62% - A-)
  '9': [24, 16],  // তসলিমা -> 40 (80% - A+)
  '10': [27, 18], // হাবিবা -> 45 (90% - A+)
  '11': [21, 14], // অনন্ত -> 35 (70% - A)
  '12': [22, 15], // আবিদ -> 37 (74% - A)
  '13': [20, 13], // নাবিল -> 33 (66% - A-)
  '14': [29, 19], // বুশরা -> 48 (96% - A+)
  '15': [23, 15], // রাহেব -> 38 (76% - A)
  '16': [17, 11], // সুরাইয়া -> 28 (56% - B)
  '17': [25, 17], // জারিন -> 42 (84% - A+)
};

// --------------------------------------------------------
// MONTH 3: NOVEMBER 2026
// Subjects: 1. বাংলা, 2. English, 3. Marketing, 4. অর্থনীতি
// --------------------------------------------------------

// 9. বাংলা Monthly Test – November (05 Nov 2026)
const marks_nov_bn: StudentMarkMap = {
  '1': [25, 17],  // মুসকান -> 42 (84% - A+)
  '2': [24, 16],  // রিমি -> 40 (80% - A+)
  '3': [19, 13],  // ইয়াসিন -> 32 (64% - A-)
  '4': [27, 18],  // ইমু -> 45 (90% - A+)
  '5': [18, 12],  // মাহিয়া -> 30 (60% - A-)
  '6': [22, 14],  // লোকমান -> 36 (72% - A)
  '7': [27, 18],  // আরমান -> 45 (90% - A+)
  '8': [19, 12],  // রনি -> 31 (62% - A-)
  '9': [25, 16],  // তসলিমা -> 41 (82% - A+)
  '10': [26, 18], // হাবিবা -> 44 (88% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [22, 14], // আবিদ -> 36 (72% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [24, 15], // রাহেব -> 39 (78% - A)
  '16': [17, 11], // সুরাইয়া -> 28 (56% - B)
  '17': [26, 17], // জারিন -> 43 (86% - A+)
};

// 10. English Monthly Test – November (12 Nov 2026)
const marks_nov_eng: StudentMarkMap = {
  '1': [22, 15],  // মুসকান -> 37 (74% - A)
  '2': [23, 16],  // রিমি -> 39 (78% - A)
  '3': [18, 12],  // ইয়াসিন -> 30 (60% - A-)
  '4': [25, 17],  // ইমু -> 42 (84% - A+)
  '5': [17, 11],  // মাহিয়া -> 28 (56% - B)
  '6': [21, 14],  // লোকমান -> 35 (70% - A)
  '7': [28, 19],  // আরমান -> 47 (94% - A+)
  '8': [18, 11],  // রনি -> 29 (58% - B)
  '9': [23, 15],  // তসলিমা -> 38 (76% - A)
  '10': [26, 17], // হাবিবা -> 43 (86% - A+)
  '11': [19, 13], // অনন্ত -> 32 (64% - A-)
  '12': [21, 14], // আবিদ -> 35 (70% - A)
  '13': [18, 12], // নাবিল -> 30 (60% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [22, 14], // রাহেব -> 36 (72% - A)
  '16': [16, 10], // সুরাইয়া -> 26 (52% - B)
  '17': [24, 16], // জারিন -> 40 (80% - A+)
};

// 11. Marketing Monthly Test – November (19 Nov 2026)
const marks_nov_mkt: StudentMarkMap = {
  '1': [24, 16],  // মুসকান -> 40 (80% - A+)
  '2': [25, 17],  // রিমি -> 42 (84% - A+)
  '3': [19, 13],  // ইয়াসিন -> 32 (64% - A-)
  '4': [26, 18],  // ইমু -> 44 (88% - A+)
  '5': [18, 12],  // মাহিয়া -> 30 (60% - A-)
  '6': [22, 14],  // লোকমান -> 36 (72% - A)
  '7': [27, 18],  // আরমান -> 45 (90% - A+)
  '8': [19, 12],  // রনি -> 31 (62% - A-)
  '9': [24, 16],  // তসলিমা -> 40 (80% - A+)
  '10': [27, 18], // হাবিবা -> 45 (90% - A+)
  '11': [21, 14], // অনন্ত -> 35 (70% - A)
  '12': [22, 15], // আবিদ -> 37 (74% - A)
  '13': [19, 13], // নাবিল -> 32 (64% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [23, 15], // রাহেব -> 38 (76% - A)
  '16': [17, 11], // সুরাইয়া -> 28 (56% - B)
  '17': [25, 17], // জারিন -> 42 (84% - A+)
};

// 12. অর্থনীতি Monthly Test – November (26 Nov 2026)
const marks_nov_eco: StudentMarkMap = {
  '1': [23, 16],  // মুসকান -> 39 (78% - A)
  '2': [24, 16],  // রিমি -> 40 (80% - A+)
  '3': [19, 12],  // ইয়াসিন -> 31 (62% - A-)
  '4': [26, 17],  // ইমু -> 43 (86% - A+)
  '5': [17, 11],  // মাহিয়া -> 28 (56% - B)
  '6': [21, 14],  // লোকমান -> 35 (70% - A)
  '7': [28, 19],  // আরমান -> 47 (94% - A+)
  '8': [18, 12],  // রনি -> 30 (60% - A-)
  '9': [24, 15],  // তসলিমা -> 39 (78% - A)
  '10': [26, 17], // হাবিবা -> 43 (86% - A+)
  '11': [20, 13], // অনন্ত -> 33 (66% - A-)
  '12': [22, 14], // আবিদ -> 36 (72% - A)
  '13': [19, 12], // নাবিল -> 31 (62% - A-)
  '14': [28, 19], // বুশরা -> 47 (94% - A+)
  '15': [23, 15], // রাহেব -> 38 (76% - A)
  '16': [16, 10], // সুরাইয়া -> 26 (52% - B)
  '17': [25, 16], // জারিন -> 41 (82% - A+)
};

// Empty demo exams - Fresh start with zero exams across all subjects and batches
export const INITIAL_EXAMS: Exam[] = [];
export const INITIAL_EXAMS_CLASS_12_A: Exam[] = [];
export const INITIAL_EXAMS_CLASS_12_B: Exam[] = [];
export const ALL_INITIAL_EXAMS: Exam[] = [];
