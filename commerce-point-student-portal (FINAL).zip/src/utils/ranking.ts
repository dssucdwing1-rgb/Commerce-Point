import { Exam, Student, StudentMarkEntry } from '../types';
import { toBengaliNum } from '../data/initialData';

/**
 * Formats a numeric rank into standard Bengali ordinal string.
 * Examples: 1 -> ১ম, 2 -> ২য়, 3 -> ৩য়, 4 -> ৪র্থ, 5 -> ৫ম, 6 -> ৬ষ্ঠ, 7 -> ৭ম, 8 -> ৮ম, 9 -> ৯ম, 10 -> ১০ম, 11 -> ১১তম...
 */
export function formatBengaliOrdinal(rank: number | null | undefined): string {
  if (rank === null || rank === undefined) return '—';
  const num = Number(rank);
  if (isNaN(num) || num <= 0) return '—';
  if (num === 1) return '১ম';
  if (num === 2) return '২য়';
  if (num === 3) return '৩য়';
  if (num === 4) return '৪র্থ';
  if (num === 5) return '৫ম';
  if (num === 6) return '৬ষ্ঠ';
  if (num === 7) return '৭ম';
  if (num === 8) return '৮ম';
  if (num === 9) return '৯ম';
  if (num === 10) return '১০ম';
  return `${toBengaliNum(num)}তম`;
}

/**
 * Formats a numeric rank into standard English ordinal string.
 * Examples: 1 -> 1st, 2 -> 2nd, 3 -> 3rd, 4 -> 4th...
 */
export function formatEnglishOrdinal(rank: number | null | undefined): string {
  if (rank === null || rank === undefined) return '—';
  const num = Number(rank);
  if (isNaN(num) || num <= 0) return '—';
  const j = num % 10;
  const k = num % 100;
  if (j === 1 && k !== 11) return `${num}st`;
  if (j === 2 && k !== 12) return `${num}nd`;
  if (j === 3 && k !== 13) return `${num}rd`;
  return `${num}th`;
}

/**
 * Standard interface for a ranked student entry in an exam or combined result.
 */
export interface RankedExamStudent {
  student: Student;
  position: number | null; // null if absent
  positionDisplay: string; // "১ম", "২য়", "—"
  positionBengali: string; // "১ম", "২য়", "—"
  rankFormatted: string; // "১ম", "২য়", "—"
  isAbsent: boolean;
  cq: number | '';
  mcq: number | '';
  total: number;
  percentage: number;
  grade: string;
  status: string; // "Pass", "Fail", "Absent"
  statusBengali: string; // "কৃতকার্য", "অকৃতকার্য", "অনুপস্থিত"
  roll: number;
}

/**
 * Interface for student ranked in a monthly master sheet (across multiple exams).
 */
export interface RankedMonthlyMasterStudent {
  student: Student;
  position: number | null; // null if completely absent
  positionDisplay: string; // "১ম", "২য়", "—"
  positionBengali: string; // "১ম", "২য়", "—"
  rankFormatted: string; // "১ম", "২য়", "—"
  attendedCount: number;
  totalObtainedMarks: number;
  totalFullMarks: number;
  averageMarks: number;
  averagePercentage: number;
  overallGrade: string;
  status: string; // "Pass", "Fail", "Absent"
  statusBengali: string; // "কৃতকার্য", "অকৃতকার্য", "অনুপস্থিত"
  isAbsent: boolean; // attendedCount === 0
  cqTotal: number;
  mcqTotal: number;
  examMarksMap: Record<
    string,
    {
      cq: number | '';
      mcq: number | '';
      total: number;
      isAbsent: boolean;
    }
  >;
}

/**
 * Helper to check if a student mark entry represents an absence or no result.
 */
export function isStudentAbsent(mark?: StudentMarkEntry): boolean {
  if (!mark) return true;
  return mark.cq === '' && mark.mcq === '';
}

/**
 * 1. INDIVIDUAL EXAM RANKING
 *
 * Sorts students by:
 * 1. Attended before Absent
 * 2. Total Marks (descending)
 * 3. CQ Marks (descending)
 * 4. MCQ Marks (descending)
 * 5. Roll (ascending)
 *
 * Assigns Standard Competition Ranking (1, 2, 2, 4) for ties in Total Marks.
 * Absent students receive position: null and display: "—".
 */
export function rankStudentsForExam(exam: Exam, students: Student[]): RankedExamStudent[] {
  if (!exam || !students || students.length === 0) return [];

  // Map students into initial items
  const items: RankedExamStudent[] = students.map((student) => {
    const mark = exam.marks ? exam.marks[student.id] : undefined;
    const absent = isStudentAbsent(mark);

    const cq = mark && mark.cq !== '' ? Number(mark.cq) : (absent ? '' : 0);
    const mcq = mark && mark.mcq !== '' ? Number(mark.mcq) : (absent ? '' : 0);
    const total = mark && !absent ? Number(mark.total) || 0 : (absent ? 0 : 0);
    const percentage = mark && !absent ? Number(mark.percentage) || 0 : 0;
    const grade = mark && !absent ? mark.grade : (absent ? 'Absent' : 'F');

    const isPass = !absent && grade !== 'F' && grade !== 'Absent';
    const status = absent ? 'Absent' : (isPass ? 'Pass' : 'Fail');
    const statusBengali = absent ? 'অনুপস্থিত' : (isPass ? 'কৃতকার্য' : 'অকৃতকার্য');

    return {
      student,
      position: null,
      positionDisplay: '—',
      positionBengali: '—',
      rankFormatted: '—',
      isAbsent: absent,
      cq,
      mcq,
      total,
      percentage,
      grade,
      status,
      statusBengali,
      roll: student.roll || 0,
    };
  });

  // Sort: Attended first, then Total desc, CQ desc, MCQ desc, Roll asc. Absent at bottom by Roll asc.
  items.sort((a, b) => {
    if (a.isAbsent && !b.isAbsent) return 1;
    if (!a.isAbsent && b.isAbsent) return -1;
    if (a.isAbsent && b.isAbsent) return a.roll - b.roll;

    // Both attended: compare Total (descending)
    if (b.total !== a.total) {
      return b.total - a.total;
    }

    // Tie-breaker 1: CQ Marks (descending)
    const aCq = typeof a.cq === 'number' ? a.cq : 0;
    const bCq = typeof b.cq === 'number' ? b.cq : 0;
    if (bCq !== aCq) {
      return bCq - aCq;
    }

    // Tie-breaker 2: MCQ Marks (descending)
    const aMcq = typeof a.mcq === 'number' ? a.mcq : 0;
    const bMcq = typeof b.mcq === 'number' ? b.mcq : 0;
    if (bMcq !== aMcq) {
      return bMcq - aMcq;
    }

    // Tie-breaker 3: Roll number (ascending)
    return a.roll - b.roll;
  });

  // Assign Standard Competition Ranking (1, 2, 2, 4...) based on Total Marks
  let currentRank = 1;
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (item.isAbsent) {
      item.position = null;
      item.positionDisplay = '—';
      item.positionBengali = '—';
      item.rankFormatted = '—';
      continue;
    }

    if (i > 0 && !items[i - 1].isAbsent && item.total === items[i - 1].total) {
      // Tie: share same position as previous student
      item.position = items[i - 1].position;
    } else {
      item.position = currentRank;
    }
    const ordinalBn = formatBengaliOrdinal(item.position);
    item.positionDisplay = ordinalBn;
    item.positionBengali = ordinalBn;
    item.rankFormatted = ordinalBn;

    currentRank = i + 2; // Next student if not tied gets (i + 1) + 1 = i + 2
  }

  return items;
}

/**
 * 2. MONTHLY MASTER RESULT SHEET RANKING
 *
 * Sorts students across all exams in a given month:
 * 1. Attended count > 0 before 0
 * 2. Total Obtained Marks (descending)
 * 3. Average Percentage (descending)
 * 4. CQ Total (descending)
 * 5. MCQ Total (descending)
 * 6. Roll (ascending)
 *
 * Assigns Standard Competition Ranking (1, 2, 2, 4) for ties in Total Obtained Marks.
 */
export function rankStudentsForMonthlyMaster(
  examsInMonth: Exam[],
  students: Student[]
): RankedMonthlyMasterStudent[] {
  if (!students || students.length === 0) return [];

  const items: RankedMonthlyMasterStudent[] = students.map((student) => {
    let attendedCount = 0;
    let totalObtainedMarks = 0;
    let totalFullMarks = 0;
    let cqTotal = 0;
    let mcqTotal = 0;

    const examMarksMap: Record<
      string,
      {
        cq: number | '';
        mcq: number | '';
        total: number;
        isAbsent: boolean;
      }
    > = {};

    examsInMonth.forEach((exam) => {
      const mark = exam.marks ? exam.marks[student.id] : undefined;
      const absent = isStudentAbsent(mark);

      if (!absent && mark) {
        attendedCount++;
        totalObtainedMarks += Number(mark.total) || 0;
        totalFullMarks += Number(exam.totalFullMarks) || 0;
        if (typeof mark.cq === 'number') cqTotal += mark.cq;
        if (typeof mark.mcq === 'number') mcqTotal += mark.mcq;

        examMarksMap[exam.id] = {
          cq: mark.cq,
          mcq: mark.mcq,
          total: mark.total,
          isAbsent: false,
        };
      } else {
        examMarksMap[exam.id] = {
          cq: '',
          mcq: '',
          total: 0,
          isAbsent: true,
        };
      }
    });

    const isAbsent = attendedCount === 0;
    const averageMarks = attendedCount > 0 ? Number((totalObtainedMarks / attendedCount).toFixed(1)) : 0;
    const averagePercentage = totalFullMarks > 0 ? Math.round((totalObtainedMarks / totalFullMarks) * 100) : 0;

    let overallGrade = 'F';
    if (averagePercentage >= 80) overallGrade = 'A+';
    else if (averagePercentage >= 70) overallGrade = 'A';
    else if (averagePercentage >= 60) overallGrade = 'A-';
    else if (averagePercentage >= 50) overallGrade = 'B';
    else if (averagePercentage >= 40) overallGrade = 'C';
    else if (averagePercentage >= 33) overallGrade = 'D';

    if (isAbsent) overallGrade = 'Absent';

    const isPass = !isAbsent && overallGrade !== 'F' && overallGrade !== 'Absent';
    const status = isAbsent ? 'Absent' : (isPass ? 'Pass' : 'Fail');
    const statusBengali = isAbsent ? 'অনুপস্থিত' : (isPass ? 'কৃতকার্য' : 'অকৃতকার্য');

    return {
      student,
      position: null,
      positionDisplay: '—',
      positionBengali: '—',
      rankFormatted: '—',
      attendedCount,
      totalObtainedMarks,
      totalFullMarks,
      averageMarks,
      averagePercentage,
      overallGrade,
      status,
      statusBengali,
      isAbsent,
      cqTotal,
      mcqTotal,
      examMarksMap,
    };
  });

  // Sort: Attended first, then Total desc, CQ desc, MCQ desc, Roll asc. Absent at bottom by Roll asc.
  items.sort((a, b) => {
    if (a.isAbsent && !b.isAbsent) return 1;
    if (!a.isAbsent && b.isAbsent) return -1;
    if (a.isAbsent && b.isAbsent) return (a.student.roll || 0) - (b.student.roll || 0);

    // Primary: Total Obtained Marks descending (highest scorer listed first)
    if (b.totalObtainedMarks !== a.totalObtainedMarks) {
      return b.totalObtainedMarks - a.totalObtainedMarks;
    }

    // Secondary: CQ Total descending
    if (b.cqTotal !== a.cqTotal) {
      return b.cqTotal - a.cqTotal;
    }

    // Tertiary: MCQ Total descending
    if (b.mcqTotal !== a.mcqTotal) {
      return b.mcqTotal - a.mcqTotal;
    }

    // Quaternary: Average Percentage descending
    if (b.averagePercentage !== a.averagePercentage) {
      return b.averagePercentage - a.averagePercentage;
    }

    // Roll number ascending
    return (a.student.roll || 0) - (b.student.roll || 0);
  });

  // Assign Standard Competition Ranking
  let currentRank = 1;
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (item.isAbsent) {
      item.position = null;
      item.positionDisplay = '—';
      item.positionBengali = '—';
      item.rankFormatted = '—';
      continue;
    }

    if (i > 0 && !items[i - 1].isAbsent && item.totalObtainedMarks === items[i - 1].totalObtainedMarks) {
      // Tie in Total Obtained Marks: Same rank assigned
      item.position = items[i - 1].position;
    } else {
      item.position = currentRank;
    }
    const ordinalBn = formatBengaliOrdinal(item.position);
    item.positionDisplay = ordinalBn;
    item.positionBengali = ordinalBn;
    item.rankFormatted = ordinalBn;

    currentRank = i + 2;
  }

  return items;
}

/**
 * 3. SUBJECT-WISE MONTHLY RANKING
 *
 * Ranks students within a single subject's exams for a month.
 */
export function rankStudentsForSubjectMonth(
  subjectExams: Exam[],
  students: Student[]
): RankedMonthlyMasterStudent[] {
  return rankStudentsForMonthlyMaster(subjectExams, students);
}

/**
 * 4. GET A SPECIFIC STUDENT'S EXAM POSITION
 */
export function getStudentExamPosition(
  studentId: string,
  exam: Exam,
  allStudents: Student[]
): {
  position: number | null;
  positionDisplay: string;
  positionBengali: string;
  totalStudents: number;
} {
  const ranked = rankStudentsForExam(exam, allStudents);
  const found = ranked.find((r) => r.student.id === studentId);
  return {
    position: found?.position ?? null,
    positionDisplay: found?.positionDisplay ?? '—',
    positionBengali: found?.positionBengali ?? '—',
    totalStudents: allStudents.length,
  };
}

/**
 * 5. GET A SPECIFIC STUDENT'S MONTHLY OVERALL POSITION
 */
export function getStudentMonthlyPosition(
  studentId: string,
  examsInMonth: Exam[],
  allStudents: Student[]
): {
  position: number | null;
  positionDisplay: string;
  positionBengali: string;
  totalStudents: number;
} {
  const ranked = rankStudentsForMonthlyMaster(examsInMonth, allStudents);
  const found = ranked.find((r) => r.student.id === studentId);
  return {
    position: found?.position ?? null,
    positionDisplay: found?.positionDisplay ?? '—',
    positionBengali: found?.positionBengali ?? '—',
    totalStudents: allStudents.length,
  };
}
