import { Student, Exam } from '../types';

export interface AuthoritativeStudentSpec {
  roll: number;
  name: string;
  studentIdCode: string;
  batchId: 'class-12-a' | 'class-12-b';
}

export const AUTHORITATIVE_CLASS_12_A: AuthoritativeStudentSpec[] = [
  { roll: 1, name: 'প্রান্তিকা', studentIdCode: 'CP/C-12/B-A 001', batchId: 'class-12-a' },
  { roll: 2, name: 'সাদিয়া', studentIdCode: 'CP/C-12/B-A 002', batchId: 'class-12-a' },
  { roll: 3, name: 'সানজানা', studentIdCode: 'CP/C-12/B-A 003', batchId: 'class-12-a' },
  { roll: 4, name: 'সুবহা', studentIdCode: 'CP/C-12/B-A 004', batchId: 'class-12-a' },
  { roll: 5, name: 'মিম–১', studentIdCode: 'CP/C-12/B-A 005', batchId: 'class-12-a' },
  { roll: 6, name: 'জিনালী', studentIdCode: 'CP/C-12/B-A 006', batchId: 'class-12-a' },
  { roll: 7, name: 'রোজা', studentIdCode: 'CP/C-12/B-A 007', batchId: 'class-12-a' },
  { roll: 8, name: 'জান্নাত', studentIdCode: 'CP/C-12/B-A 008', batchId: 'class-12-a' },
  { roll: 9, name: 'নাবিলা', studentIdCode: 'CP/C-12/B-A 009', batchId: 'class-12-a' },
  { roll: 10, name: 'সুইটি', studentIdCode: 'CP/C-12/B-A 010', batchId: 'class-12-a' },
  { roll: 11, name: 'মৌমিতা', studentIdCode: 'CP/C-12/B-A 011', batchId: 'class-12-a' },
  { roll: 12, name: 'রিতু', studentIdCode: 'CP/C-12/B-A 012', batchId: 'class-12-a' },
  { roll: 13, name: 'ইয়াসমিন', studentIdCode: 'CP/C-12/B-A 013', batchId: 'class-12-a' },
  { roll: 14, name: 'মিষ্টি', studentIdCode: 'CP/C-12/B-A 014', batchId: 'class-12-a' },
  { roll: 15, name: 'পরমা', studentIdCode: 'CP/C-12/B-A 015', batchId: 'class-12-a' },
  { roll: 16, name: 'হ্যাপি', studentIdCode: 'CP/C-12/B-A 016', batchId: 'class-12-a' },
  { roll: 17, name: 'ফারদিনা', studentIdCode: 'CP/C-12/B-A 017', batchId: 'class-12-a' },
  { roll: 18, name: 'নেহা', studentIdCode: 'CP/C-12/B-A 018', batchId: 'class-12-a' },
  { roll: 19, name: 'স্বর্ণা', studentIdCode: 'CP/C-12/B-A 019', batchId: 'class-12-a' },
  { roll: 20, name: 'রাফিদ', studentIdCode: 'CP/C-12/B-A 020', batchId: 'class-12-a' },
  { roll: 21, name: 'সাকিব', studentIdCode: 'CP/C-12/B-A 021', batchId: 'class-12-a' },
  { roll: 22, name: 'রিমু', studentIdCode: 'CP/C-12/B-A 022', batchId: 'class-12-a' },
  { roll: 23, name: 'মিম–২', studentIdCode: 'CP/C-12/B-A 023', batchId: 'class-12-a' },
  { roll: 24, name: 'নাদিয়া', studentIdCode: 'CP/C-12/B-A 024', batchId: 'class-12-a' },
  { roll: 25, name: 'আরাফাত', studentIdCode: 'CP/C-12/B-A 025', batchId: 'class-12-a' },
  { roll: 26, name: 'ইয়াসিন', studentIdCode: 'CP/C-12/B-A 026', batchId: 'class-12-a' },
  { roll: 27, name: 'চাঁদ', studentIdCode: 'CP/C-12/B-A 027', batchId: 'class-12-a' },
  { roll: 28, name: 'আলিফ', studentIdCode: 'CP/C-12/B-A 028', batchId: 'class-12-a' },
  { roll: 29, name: 'হালিম', studentIdCode: 'CP/C-12/B-A 029', batchId: 'class-12-a' },
  { roll: 30, name: 'আদিল', studentIdCode: 'CP/C-12/B-A 030', batchId: 'class-12-a' },
  { roll: 31, name: 'মাহের', studentIdCode: 'CP/C-12/B-A 031', batchId: 'class-12-a' },
];

export const AUTHORITATIVE_CLASS_12_B: AuthoritativeStudentSpec[] = [
  { roll: 1, name: 'সুবর্ণা', studentIdCode: 'CP/C-12/B-B 001', batchId: 'class-12-b' },
  { roll: 2, name: 'অধরা', studentIdCode: 'CP/C-12/B-B 002', batchId: 'class-12-b' },
  { roll: 3, name: 'শাকিলা', studentIdCode: 'CP/C-12/B-B 003', batchId: 'class-12-b' },
  { roll: 4, name: 'সানজিদা', studentIdCode: 'CP/C-12/B-B 004', batchId: 'class-12-b' },
  { roll: 5, name: 'জেমি', studentIdCode: 'CP/C-12/B-B 005', batchId: 'class-12-b' },
  { roll: 6, name: 'মাহি', studentIdCode: 'CP/C-12/B-B 006', batchId: 'class-12-b' },
  { roll: 7, name: 'মিমি', studentIdCode: 'CP/C-12/B-B 007', batchId: 'class-12-b' },
  { roll: 8, name: 'সুমাইয়া', studentIdCode: 'CP/C-12/B-B 008', batchId: 'class-12-b' },
  { roll: 9, name: 'ইকরা', studentIdCode: 'CP/C-12/B-B 009', batchId: 'class-12-b' },
  { roll: 10, name: 'আলিফ', studentIdCode: 'CP/C-12/B-B 010', batchId: 'class-12-b' },
  { roll: 11, name: 'দ্বীন ইসলাম', studentIdCode: 'CP/C-12/B-B 011', batchId: 'class-12-b' },
  { roll: 12, name: 'নাফিজ', studentIdCode: 'CP/C-12/B-B 012', batchId: 'class-12-b' },
  { roll: 13, name: 'সিয়াম', studentIdCode: 'CP/C-12/B-B 013', batchId: 'class-12-b' },
];

export interface BatchAuditResult {
  batchName: string;
  batchKey: string;
  expectedStudents: number;
  actualCount: number;
  correctStudents: number;
  missingStudents: number;
  duplicateUserIds: number;
  incorrectBatchMapping: number;
  mismatches: {
    roll: number;
    expectedName: string;
    actualName?: string;
    expectedUserId: string;
    actualUserId?: string;
    issue: string;
  }[];
}

export interface FullAuditReport {
  timestamp: number;
  overallValid: boolean;
  class12A: BatchAuditResult;
  class12B: BatchAuditResult;
  class11Count: number;
  class11Unchanged: boolean;
  totalStudents: number;
  summaryText: string;
}

export function auditAndValidateDatabase(students: Student[], _exams: Exam[] = []): FullAuditReport {
  // 1. Audit Class 12 Batch A
  const batchAStudents = students.filter(
    (s) => (s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')) === 'class-12-a'
  );

  const seenAIds = new Set<string>();
  let duplicateAIds = 0;
  batchAStudents.forEach((s) => {
    const code = (s.studentIdCode || '').trim().toUpperCase();
    if (seenAIds.has(code)) {
      duplicateAIds++;
    } else {
      seenAIds.add(code);
    }
  });

  const mismatchesA: BatchAuditResult['mismatches'] = [];
  let correctCountA = 0;

  AUTHORITATIVE_CLASS_12_A.forEach((expected) => {
    // Match by roll first or studentIdCode
    const found = batchAStudents.find(
      (s) => s.roll === expected.roll || s.studentIdCode?.trim().toUpperCase() === expected.studentIdCode.toUpperCase()
    );

    if (!found) {
      mismatchesA.push({
        roll: expected.roll,
        expectedName: expected.name,
        expectedUserId: expected.studentIdCode,
        issue: 'শিক্ষার্থী অনুপস্থিত (Missing Student)',
      });
      return;
    }

    const nameMatches = found.name.trim() === expected.name.trim();
    const idMatches = found.studentIdCode.trim().toUpperCase() === expected.studentIdCode.toUpperCase();
    const batchMatches = (found.batchId || 'class-12-a') === 'class-12-a';

    if (nameMatches && idMatches && batchMatches) {
      correctCountA++;
    } else {
      const issues: string[] = [];
      if (!nameMatches) issues.push(`নাম অমিল (বর্তমান: ${found.name}, প্রত্যাশিত: ${expected.name})`);
      if (!idMatches) issues.push(`ID অমিল (বর্তমান: ${found.studentIdCode}, প্রত্যাশিত: ${expected.studentIdCode})`);
      if (!batchMatches) issues.push(`ভুল ব্যাচ (${found.batchId})`);

      mismatchesA.push({
        roll: expected.roll,
        expectedName: expected.name,
        actualName: found.name,
        expectedUserId: expected.studentIdCode,
        actualUserId: found.studentIdCode,
        issue: issues.join('; '),
      });
    }
  });

  const auditA: BatchAuditResult = {
    batchName: 'দ্বাদশ শ্রেণি — ব্যাচ এ',
    batchKey: 'class12_batch_a',
    expectedStudents: 31,
    actualCount: batchAStudents.length,
    correctStudents: correctCountA,
    missingStudents: Math.max(0, 31 - batchAStudents.length),
    duplicateUserIds: duplicateAIds,
    incorrectBatchMapping: batchAStudents.filter((s) => s.academicClass !== 'XII' || s.group !== 'B-A').length,
    mismatches: mismatchesA,
  };

  // 2. Audit Class 12 Batch B
  const batchBStudents = students.filter(
    (s) => (s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')) === 'class-12-b'
  );

  const seenBIds = new Set<string>();
  let duplicateBIds = 0;
  batchBStudents.forEach((s) => {
    const code = (s.studentIdCode || '').trim().toUpperCase();
    if (seenBIds.has(code)) {
      duplicateBIds++;
    } else {
      seenBIds.add(code);
    }
  });

  const mismatchesB: BatchAuditResult['mismatches'] = [];
  let correctCountB = 0;

  AUTHORITATIVE_CLASS_12_B.forEach((expected) => {
    const found = batchBStudents.find(
      (s) => s.roll === expected.roll || s.studentIdCode?.trim().toUpperCase() === expected.studentIdCode.toUpperCase()
    );

    if (!found) {
      mismatchesB.push({
        roll: expected.roll,
        expectedName: expected.name,
        expectedUserId: expected.studentIdCode,
        issue: 'শিক্ষার্থী অনুপস্থিত (Missing Student)',
      });
      return;
    }

    const nameMatches = found.name.trim() === expected.name.trim();
    const idMatches = found.studentIdCode.trim().toUpperCase() === expected.studentIdCode.toUpperCase();
    const batchMatches = (found.batchId || 'class-12-b') === 'class-12-b';

    if (nameMatches && idMatches && batchMatches) {
      correctCountB++;
    } else {
      const issues: string[] = [];
      if (!nameMatches) issues.push(`নাম অমিল (বর্তমান: ${found.name}, প্রত্যাশিত: ${expected.name})`);
      if (!idMatches) issues.push(`ID অমিল (বর্তমান: ${found.studentIdCode}, প্রত্যাশিত: ${expected.studentIdCode})`);
      if (!batchMatches) issues.push(`ভুল ব্যাচ (${found.batchId})`);

      mismatchesB.push({
        roll: expected.roll,
        expectedName: expected.name,
        actualName: found.name,
        expectedUserId: expected.studentIdCode,
        actualUserId: found.studentIdCode,
        issue: issues.join('; '),
      });
    }
  });

  const auditB: BatchAuditResult = {
    batchName: 'দ্বাদশ শ্রেণি — ব্যাচ বি',
    batchKey: 'class12_batch_b',
    expectedStudents: 13,
    actualCount: batchBStudents.length,
    correctStudents: correctCountB,
    missingStudents: Math.max(0, 13 - batchBStudents.length),
    duplicateUserIds: duplicateBIds,
    incorrectBatchMapping: batchBStudents.filter((s) => s.academicClass !== 'XII' || s.group !== 'B-B').length,
    mismatches: mismatchesB,
  };

  // 3. Audit Class 11
  const batch11Students = students.filter(
    (s) => (s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')) === 'class-11-a'
  );

  const isClass11Unchanged = batch11Students.length >= 16;
  const overallValid =
    auditA.correctStudents === 31 &&
    auditA.missingStudents === 0 &&
    auditA.duplicateUserIds === 0 &&
    auditB.correctStudents === 13 &&
    auditB.missingStudents === 0 &&
    auditB.duplicateUserIds === 0 &&
    isClass11Unchanged;

  const summaryLines = [
    'Class 12 — Batch A',
    `Expected Students: ${auditA.expectedStudents}`,
    `Correct Students: ${auditA.correctStudents}`,
    `Missing Students: ${auditA.missingStudents}`,
    `Duplicate User IDs: ${auditA.duplicateUserIds}`,
    `Incorrect Batch Mapping: ${auditA.incorrectBatchMapping}`,
    '',
    'Class 12 — Batch B',
    `Expected Students: ${auditB.expectedStudents}`,
    `Correct Students: ${auditB.correctStudents}`,
    `Missing Students: ${auditB.missingStudents}`,
    `Duplicate User IDs: ${auditB.duplicateUserIds}`,
    `Incorrect Batch Mapping: ${auditB.incorrectBatchMapping}`,
  ];

  return {
    timestamp: Date.now(),
    overallValid,
    class12A: auditA,
    class12B: auditB,
    class11Count: batch11Students.length,
    class11Unchanged: isClass11Unchanged,
    totalStudents: students.length,
    summaryText: summaryLines.join('\n'),
  };
}
