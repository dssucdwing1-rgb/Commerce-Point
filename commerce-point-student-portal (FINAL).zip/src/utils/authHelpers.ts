/**
 * Authentication Helpers for Supabase Auth Integration
 * Commerce Point Academic Portal
 */

/**
 * Converts any Student ID or username to the dummy email format required by Supabase Auth.
 * Example: "CP/C-12/B-A 001" -> "cpc12ba001@student.commercepoint.app"
 * Example: "admin" -> "admin@student.commercepoint.app"
 * If already an email (e.g. contains '@'), returns the lowercased email.
 */
export function studentIdToDummyEmail(studentIdOrInput: string): string {
  const trimmed = (studentIdOrInput || '').trim();
  if (!trimmed) return '';

  // If already a valid email address format, return as lowercased email
  if (trimmed.includes('@')) {
    return trimmed.toLowerCase();
  }

  // Strip all spaces, slashes, hyphens, and non-alphanumeric characters, then lowercase
  const cleanId = trimmed.toLowerCase().replace(/[^a-z0-9]/g, '');
  return `${cleanId}@student.commercepoint.app`;
}

/**
 * Extracts the base alphanumeric identifier from a dummy email.
 * Example: "cpc12ba001@student.commercepoint.app" -> "cpc12ba001"
 */
export function extractIdFromDummyEmail(email: string): string {
  if (!email) return '';
  const atIndex = email.indexOf('@');
  if (atIndex === -1) return email;
  return email.slice(0, atIndex).toLowerCase();
}
