import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  KeyRound,
  User,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Loader2,
  Save,
  RotateCcw,
  Sparkles,
  Smartphone,
  Mail,
  ShieldAlert,
  Clock,
  Shield,
  Laptop,
  Check,
  Send,
  LogOut,
  RefreshCw,
  HelpCircle,
  Server,
  Settings,
  ArrowRight,
} from 'lucide-react';
import {
  getAdminProfile,
  changeAdminPassword,
  updateAdminProfile,
  resetAdminAccountToDefault,
  validateBangladeshiPhone,
  validateEmailAddress,
  sendAdminPhoneVerificationOtp,
  verifyAdminPhoneOtp,
  sendAdminEmailVerificationOtp,
  verifyAdminEmailOtp,
  revokeOtherSessions,
  maskPhoneNumber,
  maskEmailAddress,
  DEFAULT_ADMIN_USERNAME,
  DEFAULT_ADMIN_PASSWORD,
  AdminProfileData,
  evaluatePasswordStrength,
  getServerProviderStatus,
  updateServerProviderConfig,
  testServerProvider,
  PasswordStrengthReport,
} from '../services/authService';
import { AuthUser } from '../types';
import { toBengaliNum } from '../data/initialData';
import { updateCurrentUserPassword } from '../services/supabaseAuth';

interface AdminAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthUser;
  onProfileUpdated?: (updatedUser: AuthUser) => void;
  initialTab?: 'personal' | 'security' | 'providers' | 'actions';
}

export function AdminAccountModal({
  isOpen,
  onClose,
  currentUser,
  onProfileUpdated,
  initialTab = 'personal',
}: AdminAccountModalProps) {
  // Navigation tabs:
  // 1. Personal & Contact (ব্যক্তিগত ও যোগাযোগ তথ্য)
  // 2. Security & Password (পাসওয়ার্ড ও নিরাপত্তা)
  // 3. SMS & Email Gateways (প্রোভাইডার কনফিগারেশন)
  // 4. Status & Actions (স্ট্যাটাস ও অ্যাকশন)
  const [activeTab, setActiveTab] = useState<'personal' | 'security' | 'providers' | 'actions'>(initialTab);

  // Profile Form State
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryPhone, setRecoveryPhone] = useState('');
  const [avatarColor, setAvatarColor] = useState('indigo');
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  // Snapshot of verified phone & email from DB (Section 13: Detect changes)
  const [initialSavedPhone, setInitialSavedPhone] = useState('');
  const [initialSavedEmail, setInitialSavedEmail] = useState('');

  // Status indicators from DB
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [phoneVerifiedAt, setPhoneVerifiedAt] = useState<number | undefined>();
  const [emailVerifiedAt, setEmailVerifiedAt] = useState<number | undefined>();
  const [updatedAt, setUpdatedAt] = useState<number | undefined>();
  const [passwordChangedAt, setPasswordChangedAt] = useState<number | undefined>();

  // Password Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Live password strength report (Section 11)
  const passwordStrength: PasswordStrengthReport = evaluatePasswordStrength(newPassword);

  // Verification OTP Modal States
  const [activeOtpDialog, setActiveOtpDialog] = useState<'none' | 'phone' | 'email'>('none');
  const [otpCodeInput, setOtpCodeInput] = useState('');
  const [otpSimulationHint, setOtpSimulationHint] = useState<string | null>(null);
  const [otpTargetMasked, setOtpTargetMasked] = useState<string>('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Provider Settings State (Section 4 & 5)
  const [smsProvider, setSmsProvider] = useState<'simulation' | 'greenweb' | 'bulksmsbd' | 'alphanet' | 'mim_sms' | 'generic_http'>('simulation');
  const [smsApiKey, setSmsApiKey] = useState('');
  const [smsSenderId, setSmsSenderId] = useState('COMMERCE PT');
  const [smsApiUrl, setSmsApiUrl] = useState('');
  const [emailHost, setEmailHost] = useState('smtp.gmail.com');
  const [emailPort, setEmailPort] = useState(587);
  const [emailSecure, setEmailSecure] = useState(false);
  const [emailUser, setEmailUser] = useState('');
  const [emailPassword, setEmailPassword] = useState('');
  const [emailFrom, setEmailFrom] = useState('');
  const [testTargetPhone, setTestTargetPhone] = useState('');
  const [testTargetEmail, setTestTargetEmail] = useState('');
  const [testResult, setTestResult] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isTestingProvider, setIsTestingProvider] = useState(false);

  // Status & Notification
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Confirmation for Factory Reset
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Countdown timer for OTP Resend (Section 8: 60s rate limit)
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const interval = setInterval(() => {
      setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [resendCooldown]);

  // Section 13: Detect if currently typed phone or email is different from verified snapshot
  const isCurrentPhoneVerified =
    isPhoneVerified &&
    phone.trim() !== '' &&
    initialSavedPhone !== '' &&
    phone.trim() === initialSavedPhone;

  const isCurrentEmailVerified =
    isEmailVerified &&
    email.trim() !== '' &&
    initialSavedEmail !== '' &&
    email.trim().toLowerCase() === initialSavedEmail.toLowerCase();

  // Load admin details & provider status
  const refreshProfileData = async () => {
    try {
      const prof: AdminProfileData = await getAdminProfile();
      setUsername(prof.username);
      setName(prof.name);
      setPhone(prof.phone);
      setEmail(prof.email);
      setInitialSavedPhone(prof.phone || '');
      setInitialSavedEmail(prof.email || '');
      setRecoveryEmail(prof.recoveryEmail);
      setRecoveryPhone(prof.recoveryPhone);
      setAvatarColor(prof.avatarColor || 'indigo');
      setTwoFactorEnabled(prof.twoFactorEnabled);
      setIsPhoneVerified(prof.isPhoneVerified);
      setIsEmailVerified(prof.isEmailVerified);
      setPhoneVerifiedAt(prof.phoneVerifiedAt);
      setEmailVerifiedAt(prof.emailVerifiedAt);
      setUpdatedAt(prof.updatedAt);
      setPasswordChangedAt(prof.passwordChangedAt);

      if (prof.phone) setTestTargetPhone(prof.phone);
      if (prof.email) setTestTargetEmail(prof.email);

      // Load server provider configuration
      const providerData = await getServerProviderStatus();
      if (providerData?.providers) {
        if (providerData.providers.sms) {
          setSmsProvider(providerData.providers.sms.provider || 'simulation');
          setSmsSenderId(providerData.providers.sms.senderId || 'COMMERCE PT');
        }
        if (providerData.providers.email) {
          setEmailHost(providerData.providers.email.host || 'smtp.gmail.com');
          setEmailPort(providerData.providers.email.port || 587);
          setEmailSecure(!!providerData.providers.email.secure);
          setEmailUser(providerData.providers.email.user || '');
          setEmailFrom(providerData.providers.email.from || '');
        }
      }
    } catch (err) {
      console.error('Failed to load admin profile', err);
    }
  };

  useEffect(() => {
    if (!isOpen) {
      setStatusMessage(null);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setShowResetConfirm(false);
      setActiveOtpDialog('none');
      setOtpCodeInput('');
      setOtpSimulationHint(null);
      setTestResult(null);
      return;
    }

    refreshProfileData();
  }, [isOpen]);

  if (!isOpen) return null;

  // Format timestamp helper
  const formatTimestamp = (ts?: number) => {
    if (!ts) return 'ডিফল্ট সিস্টেম ইনিশিয়াল';
    try {
      const date = new Date(ts);
      const day = toBengaliNum(date.getDate());
      const monthNames = [
        'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
        'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
      ];
      const month = monthNames[date.getMonth()];
      const year = toBengaliNum(date.getFullYear());
      const timeStr = date.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
      return `${day} ${month} ${year}, ${timeStr}`;
    } catch {
      return new Date(ts).toLocaleString();
    }
  };

  // -------------------------------------------------------------------------
  // Handle Personal Information Save (Section 1 & 13)
  // -------------------------------------------------------------------------
  const handleSavePersonalInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!name.trim()) {
      setStatusMessage({ type: 'error', text: 'শিক্ষক / অ্যাডমিনের নাম খালি রাখা যাবে না।' });
      return;
    }

    if (!username.trim() || username.trim().length < 3) {
      setStatusMessage({ type: 'error', text: 'ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে।' });
      return;
    }

    // Validate phone if provided
    let cleanPhone = phone.trim();
    if (cleanPhone) {
      const phoneCheck = validateBangladeshiPhone(cleanPhone);
      if (!phoneCheck.isValid) {
        setStatusMessage({
          type: 'error',
          text: phoneCheck.error || 'সঠিক বাংলাদেশি মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX, মোট ১১ ডিজিট)।',
        });
        return;
      }
      cleanPhone = phoneCheck.normalized;
    }

    // Validate email if provided
    let cleanEmail = email.trim();
    if (cleanEmail) {
      const emailCheck = validateEmailAddress(cleanEmail);
      if (!emailCheck.isValid) {
        setStatusMessage({
          type: 'error',
          text: emailCheck.error || 'সঠিক ইমেইল ঠিকানা দিন (যেমন: teacher@example.com)।',
        });
        return;
      }
      cleanEmail = emailCheck.normalized;
    }

    try {
      setIsLoading(true);
      const res = await updateAdminProfile({
        name: name.trim(),
        username: username.trim(),
        phone: cleanPhone,
        email: cleanEmail,
        recoveryEmail: recoveryEmail.trim(),
        recoveryPhone: recoveryPhone.trim(),
        avatarColor,
        twoFactorEnabled,
      });

      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: '✓ ব্যক্তিগত তথ্য সফলভাবে সংরক্ষিত হয়েছে! মোবাইল/ইমেইল পরিবর্তন করা হলে পুনরায় ভেরিফাই করুন।',
        });
        if (res.updatedUser && onProfileUpdated) {
          onProfileUpdated(res.updatedUser);
        }
        await refreshProfileData();
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'সংরক্ষণে ত্রুটি হয়েছে।';
      setStatusMessage({ type: 'error', text: msg });
    } finally {
      setIsLoading(false);
    }
  };

  // -------------------------------------------------------------------------
  // Handle Password Change (Section 11)
  // -------------------------------------------------------------------------
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!currentPassword) {
      setStatusMessage({
        type: 'error',
        text: 'অনুগ্রহ করে বর্তমান পাসওয়ার্ডটি প্রদান করুন।',
      });
      return;
    }

    // Validate password complexity
    if (!passwordStrength.isValid) {
      setStatusMessage({
        type: 'error',
        text: `নতুন পাসওয়ার্ড শর্তাবলী পূরণ করেনি: ${passwordStrength.errors.join(', ')}`,
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      setStatusMessage({
        type: 'error',
        text: 'নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না। পুনরায় চেক করুন।',
      });
      return;
    }

    if (newPassword === currentPassword) {
      setStatusMessage({
        type: 'error',
        text: 'নতুন পাসওয়ার্ড বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।',
      });
      return;
    }

    try {
      setIsLoading(true);
      const res = await updateCurrentUserPassword(currentPassword, newPassword, confirmPassword);
      if (res.success) {
        setStatusMessage({
          type: 'success',
          text: '✓ এডমিন পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে! পরবর্তী লগইনের সময় নতুন পাসওয়ার্ড ব্যবহার করুন।',
        });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        await refreshProfileData();
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'পাসওয়ার্ড পরিবর্তনে ত্রুটি হয়েছে।';
      setStatusMessage({ type: 'error', text: msg });
    } finally {
      setIsLoading(false);
    }
  };

  // -------------------------------------------------------------------------
  // Handle Mobile OTP Verification (Section 3 & 8)
  // -------------------------------------------------------------------------
  const handleInitiatePhoneVerification = async () => {
    setStatusMessage(null);
    const target = phone.trim();
    if (!target) {
      setStatusMessage({ type: 'error', text: 'প্রথমে একটি মোবাইল নম্বর প্রদান করুন।' });
      return;
    }

    setIsLoading(true);
    try {
      const res = await sendAdminPhoneVerificationOtp(target);
      if (res.success) {
        setActiveOtpDialog('phone');
        setOtpTargetMasked(res.maskedPhone || maskPhoneNumber(target));
        setOtpSimulationHint(res.simulationCode || null);
        setOtpCodeInput('');
        setResendCooldown(60); // 60s cooldown
      } else {
        setStatusMessage({ type: 'error', text: res.message });
        if (res.waitSeconds) setResendCooldown(res.waitSeconds);
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'মোবাইল ওটিপি পাঠাতে ব্যর্থ হয়েছে।' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyPhoneOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCodeInput.trim()) return;

    setIsLoading(true);
    try {
      const res = await verifyAdminPhoneOtp(otpCodeInput.trim(), phone.trim());
      if (res.success) {
        setActiveOtpDialog('none');
        setStatusMessage({ type: 'success', text: res.message });
        await refreshProfileData();
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'কোড যাচাইয়ে ত্রুটি হয়েছে।' });
    } finally {
      setIsLoading(false);
    }
  };

  // -------------------------------------------------------------------------
  // Handle Email OTP Verification (Section 2 & 8)
  // -------------------------------------------------------------------------
  const handleInitiateEmailVerification = async () => {
    setStatusMessage(null);
    const target = email.trim();
    if (!target) {
      setStatusMessage({ type: 'error', text: 'প্রথমে একটি ইমেইল ঠিকানা প্রদান করুন।' });
      return;
    }

    setIsLoading(true);
    try {
      const res = await sendAdminEmailVerificationOtp(target);
      if (res.success) {
        setActiveOtpDialog('email');
        setOtpTargetMasked(res.maskedEmail || maskEmailAddress(target));
        setOtpSimulationHint(res.simulationCode || null);
        setOtpCodeInput('');
        setResendCooldown(60); // 60s cooldown
      } else {
        setStatusMessage({ type: 'error', text: res.message });
        if (res.waitSeconds) setResendCooldown(res.waitSeconds);
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'ইমেইল ভেরিফিকেশন কোড পাঠাতে ব্যর্থ হয়েছে।' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyEmailOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCodeInput.trim()) return;

    setIsLoading(true);
    try {
      const res = await verifyAdminEmailOtp(otpCodeInput.trim(), email.trim());
      if (res.success) {
        setActiveOtpDialog('none');
        setStatusMessage({ type: 'success', text: res.message });
        await refreshProfileData();
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'ইমেইল কোড যাচাইয়ে ত্রুটি হয়েছে।' });
    } finally {
      setIsLoading(false);
    }
  };

  // -------------------------------------------------------------------------
  // Handle Provider Settings Save & Test (Section 4 & 5)
  // -------------------------------------------------------------------------
  const handleSaveProviderConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setTestResult(null);
    setIsLoading(true);

    try {
      const res = await updateServerProviderConfig({
        sms: {
          provider: smsProvider,
          apiKey: smsApiKey.trim(),
          senderId: smsSenderId.trim(),
          apiUrl: smsApiUrl.trim(),
        },
        email: {
          host: emailHost.trim(),
          port: emailPort,
          secure: emailSecure,
          user: emailUser.trim(),
          password: emailPassword,
          from: emailFrom.trim(),
        },
      });

      if (res?.success) {
        setStatusMessage({
          type: 'success',
          text: '✓ এসএমএস ও ইমেইল প্রোভাইডার সেটিংস সফলভাবে সার্ভারে সংরক্ষিত হয়েছে!',
        });
      } else {
        setStatusMessage({ type: 'error', text: res?.message || 'সংরক্ষণে ব্যর্থ হয়েছে।' });
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'প্রোভাইডার কনফিগারেশন সংরক্ষণ করা সম্ভব হয়নি।' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestSms = async () => {
    const target = (testTargetPhone || phone).trim();
    if (!target) {
      setTestResult({ type: 'error', message: 'অনুগ্রহ করে টেস্ট মোবাইল নম্বর প্রদান করুন।' });
      return;
    }

    setIsTestingProvider(true);
    setTestResult(null);
    try {
      const res = await testServerProvider('mobile', target);
      if (res?.success) {
        setTestResult({
          type: 'success',
          message: res.isSimulated
            ? `✓ টেস্ট সফল (সিমুলেশন মোড): ${target} নম্বরে এসএমএস কনসোলে ডিসপ্যাচ হয়েছে।`
            : `✓ টেস্ট সফল: ${target} নম্বরে এসএমএস সফলভাবে ডেলিভারি হয়েছে!`,
        });
      } else {
        setTestResult({
          type: 'error',
          message: res?.error || 'টেস্ট এসএমএস পাঠাতে ব্যর্থ হয়েছে। এপিআই কী ও ব্যালেন্স চেক করুন।',
        });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'টেস্ট কল ব্যর্থ।';
      setTestResult({ type: 'error', message: msg });
    } finally {
      setIsTestingProvider(false);
    }
  };

  const handleTestEmail = async () => {
    const target = (testTargetEmail || email).trim();
    if (!target) {
      setTestResult({ type: 'error', message: 'অনুগ্রহ করে টেস্ট ইমেইল ঠিকানা প্রদান করুন।' });
      return;
    }

    setIsTestingProvider(true);
    setTestResult(null);
    try {
      const res = await testServerProvider('email', target);
      if (res?.success) {
        setTestResult({
          type: 'success',
          message: res.isSimulated
            ? `✓ টেস্ট সফল (সিমুলেশন মোড): ${target} ঠিকানায় ইমেইল কনসোলে ডিসপ্যাচ হয়েছে।`
            : `✓ টেস্ট সফল: ${target} ঠিকানায় সফলভাবে ইমেইল পৌঁছেছে! ইনবক্স চেক করুন।`,
        });
      } else {
        setTestResult({
          type: 'error',
          message: res?.error || 'টেস্ট ইমেইল পাঠাতে ব্যর্থ। হোস্ট ও পাসওয়ার্ড যাচাই করুন।',
        });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'টেস্ট কল ব্যর্থ।';
      setTestResult({ type: 'error', message: msg });
    } finally {
      setIsTestingProvider(false);
    }
  };

  // Revoke other devices
  const handleRevokeOtherSessions = async () => {
    try {
      setIsLoading(true);
      const res = await revokeOtherSessions();
      setStatusMessage({ type: 'success', text: res.message });
    } catch {
      setStatusMessage({ type: 'error', text: 'সেশন রিমোট লগআউটে সমস্যা হয়েছে।' });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Factory Reset
  const handleResetToDefault = async () => {
    try {
      setIsLoading(true);
      const res = await resetAdminAccountToDefault();
      if (res.success) {
        await refreshProfileData();
        setShowResetConfirm(false);
        setStatusMessage({
          type: 'success',
          text: res.message,
        });
        if (currentUser && onProfileUpdated) {
          onProfileUpdated({
            ...currentUser,
            name: 'আইসিটি শিক্ষক / Admin',
            username: DEFAULT_ADMIN_USERNAME,
          });
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'রিসেট করতে ব্যর্থ হয়েছে।';
      setStatusMessage({ type: 'error', text: msg });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      id="admin-account-modal-backdrop"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150 relative"
        onClick={(e) => e.stopPropagation()}
        id="admin-account-modal-content"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white p-4 sm:p-5 relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-md shrink-0">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                  Admin Account Management
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  Admin
                </span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">
                সিকিউর অথেনটিকেশন, মোবাইল ওটিপি, ইমেইল ভেরিফিকেশন ও পাসওয়ার্ড রিকভারি
              </p>
            </div>
          </div>

          {/* Navigation Tabs - 4 Sections */}
          <div className="grid grid-cols-4 gap-1.5 mt-4 pt-3 border-t border-white/10">
            <button
              type="button"
              id="tab-admin-personal"
              onClick={() => {
                setActiveTab('personal');
                setStatusMessage(null);
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer truncate ${
                activeTab === 'personal'
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <User className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">ব্যক্তিগত ও যোগাযোগ</span>
            </button>

            <button
              type="button"
              id="tab-admin-security"
              onClick={() => {
                setActiveTab('security');
                setStatusMessage(null);
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer truncate ${
                activeTab === 'security'
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Lock className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">পাসওয়ার্ড পরিবর্তন</span>
            </button>

            <button
              type="button"
              id="tab-admin-providers"
              onClick={() => {
                setActiveTab('providers');
                setStatusMessage(null);
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer truncate ${
                activeTab === 'providers'
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Server className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">এসএমএস ও ইমেইল</span>
            </button>

            <button
              type="button"
              id="tab-admin-actions"
              onClick={() => {
                setActiveTab('actions');
                setStatusMessage(null);
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer truncate ${
                activeTab === 'actions'
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">স্ট্যাটাস ও অ্যাকশন</span>
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {statusMessage && (
          <div
            className={`p-3 text-xs font-semibold flex items-center justify-between gap-2 border-b ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span className="leading-snug">{statusMessage.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusMessage(null)}
              className="text-xs uppercase font-bold opacity-60 hover:opacity-100 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-4 sm:p-6 max-h-[72vh] overflow-y-auto space-y-4">
          {/* ===============================================================
              SECTION 1: PERSONAL & CONTACT INFORMATION (ব্যক্তিগত ও যোগাযোগ তথ্য)
              =============================================================== */}
          {activeTab === 'personal' && (
            <form onSubmit={handleSavePersonalInfo} className="space-y-4">
              {/* Profile Avatar / Photo Header */}
              <div className="flex items-center gap-4 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-amber-300 flex items-center justify-center font-black text-xl shadow-xs border-2 border-indigo-200 shrink-0">
                  {name ? name.slice(0, 1) : 'A'}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-extrabold text-slate-900 truncate">
                      {name || 'আইসিটি শিক্ষক'}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200 shrink-0">
                      সক্রিয় (Active)
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium truncate mt-0.5">
                    রোল: শিক্ষক ও সিস্টেম অ্যাডমিন • ইউজারনেম: <span className="font-mono font-bold text-slate-700">{username}</span>
                  </p>
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  শিক্ষক / অ্যাডমিনের পুরো নাম (Admin Name) *
                </label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="যেমন: আইসিটি শিক্ষক / Admin"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              {/* Login Username */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  লগইন ইউজারনেম (Login Username) *
                </label>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="যেমন: admin"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              {/* Mobile Number Section (Section 3 & 14) */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-blue-700" />
                    <label className="text-xs font-bold text-slate-800">
                      মোবাইল নম্বর (Mobile Number)
                    </label>
                  </div>

                  {/* Status Badge (Section 1 & 13) */}
                  <div>
                    {!phone.trim() ? (
                      <span className="text-[11px] text-slate-400 font-medium">যুক্ত করা হয়নি</span>
                    ) : isCurrentPhoneVerified ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300">
                        <Check className="w-3 h-3 text-emerald-600" />
                        Verified ✓
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md border border-amber-300">
                        <Clock className="w-3 h-3 text-amber-600" />
                        Pending Verification
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="০১XXXXXXXXX বা 01XXXXXXXXX"
                      className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden font-mono"
                    />
                  </div>

                  {/* Send OTP button */}
                  <button
                    type="button"
                    onClick={handleInitiatePhoneVerification}
                    disabled={isLoading || !phone.trim() || isCurrentPhoneVerified}
                    className="py-2.5 px-3 bg-amber-500 hover:bg-amber-600 active:scale-98 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                    title={isCurrentPhoneVerified ? 'ইতোমধ্যে যাচাইকৃত' : 'এসএমএস ওটিপি পাঠান'}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isCurrentPhoneVerified ? 'ভেরিফাইড' : 'Send OTP'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-500">
                  ১১ ডিজিটের বাংলাদেশি মোবাইল নম্বর (যেমন: <code className="bg-slate-200/70 px-1 rounded font-mono">01712345678</code>)। মোবাইল পরিবর্তনের পর পুনরায় ওটিপি ভেরিফিকেশন আবশ্যক।
                </p>
              </div>

              {/* Email Address Section (Section 2 & 14) */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-indigo-700" />
                    <label className="text-xs font-bold text-slate-800">
                      ইমেইল ঠিকানা (Email Address)
                    </label>
                  </div>

                  {/* Status Badge (Section 1 & 13) */}
                  <div>
                    {!email.trim() ? (
                      <span className="text-[11px] text-slate-400 font-medium">যুক্ত করা হয়নি</span>
                    ) : isCurrentEmailVerified ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300">
                        <Check className="w-3 h-3 text-emerald-600" />
                        Verified ✓
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md border border-amber-300">
                        <Clock className="w-3 h-3 text-amber-600" />
                        Pending Verification
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="teacher@commercepoint.edu.bd"
                      className="w-full px-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Send Verification Code button */}
                  <button
                    type="button"
                    onClick={handleInitiateEmailVerification}
                    disabled={isLoading || !email.trim() || isCurrentEmailVerified}
                    className="py-2.5 px-3 bg-indigo-700 hover:bg-indigo-800 active:scale-98 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                    title={isCurrentEmailVerified ? 'ইতোমধ্যে যাচাইকৃত' : 'ভেরিফিকেশন কোড পাঠান'}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isCurrentEmailVerified ? 'ভেরিফাইড' : 'Send Verification Code'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-500">
                  ভেরিফাইড ইমেইলে সিস্টেম নোটিফিকেশন ও পাসওয়ার্ড রিকভারি ওটিপি প্রেরণ করা হবে।
                </p>
              </div>

              {/* Save Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading || !name.trim() || !username.trim()}
                  className="w-full py-2.5 px-4 bg-indigo-700 hover:bg-indigo-800 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>সংরক্ষণ হচ্ছে...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>ব্যক্তিগত তথ্য ও পরিবর্তন সংরক্ষণ করুন</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* ===============================================================
              SECTION 2: SECURITY & PASSWORD (পাসওয়ার্ড পরিবর্তন ও নিরাপত্তা)
              =============================================================== */}
          {activeTab === 'security' && (
            <div className="space-y-5">
              {/* Change Password Sub-form (Section 11) */}
              <form onSubmit={handleChangePasswordSubmit} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3.5">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200 text-slate-900">
                  <Lock className="w-4 h-4 text-indigo-700" />
                  <span className="font-extrabold text-xs sm:text-sm">পাসওয়ার্ড পরিবর্তন (Change Password)</span>
                </div>

                {/* Current Password */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    বর্তমান পাসওয়ার্ড *
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPassword ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="বর্তমান পাসওয়ার্ড লিখুন"
                      className="w-full pl-3 pr-10 py-2 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:border-indigo-600 focus:outline-hidden"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* New Password with live complexity checklist */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      নতুন পাসওয়ার্ড *
                    </label>
                    <span className="text-[10px] text-slate-500 font-semibold">কমপক্ষে ৮ অক্ষর</span>
                  </div>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="নতুন পাসওয়ার্ড লিখুন"
                      className="w-full pl-3 pr-10 py-2 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm font-medium focus:border-indigo-600 focus:outline-hidden"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Section 11: Real-time Password Security Requirements checklist */}
                  {newPassword && (
                    <div className="mt-2.5 p-3 bg-white border border-slate-200 rounded-xl text-[11px] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-700">নিরাপত্তা শর্তাবলী:</span>
                        <span className={`font-bold ${passwordStrength.score >= 80 ? 'text-emerald-600' : passwordStrength.score >= 40 ? 'text-amber-600' : 'text-rose-600'}`}>
                          {passwordStrength.score >= 100 ? 'শক্তিশালী (Strong)' : passwordStrength.score >= 60 ? 'মাঝারি (Medium)' : 'দুর্বল (Weak)'}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-slate-600">
                        <div className={`flex items-center gap-1.5 ${passwordStrength.rules.minLength ? 'text-emerald-700 font-bold' : ''}`}>
                          <span>{passwordStrength.rules.minLength ? '✓' : '•'}</span>
                          <span>কমপক্ষে ৮ অক্ষরের হতে হবে</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${passwordStrength.rules.hasUpper ? 'text-emerald-700 font-bold' : ''}`}>
                          <span>{passwordStrength.rules.hasUpper ? '✓' : '•'}</span>
                          <span>১টি বড় হাতের অক্ষর (A-Z)</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${passwordStrength.rules.hasLower ? 'text-emerald-700 font-bold' : ''}`}>
                          <span>{passwordStrength.rules.hasLower ? '✓' : '•'}</span>
                          <span>১টি ছোট হাতের অক্ষর (a-z)</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${passwordStrength.rules.hasNumber ? 'text-emerald-700 font-bold' : ''}`}>
                          <span>{passwordStrength.rules.hasNumber ? '✓' : '•'}</span>
                          <span>১টি সংখ্যা (0-9)</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${passwordStrength.rules.hasSpecial ? 'text-emerald-700 font-bold' : ''}`}>
                          <span>{passwordStrength.rules.hasSpecial ? '✓' : '•'}</span>
                          <span>১টি বিশেষ চিহ্ন (!@#$%^&*)</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    নতুন পাসওয়ার্ড নিশ্চিত করুন *
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="নতুন পাসওয়ার্ড পুনরায় লিখুন"
                      className={`w-full pl-3 pr-10 py-2 bg-white border rounded-xl text-xs sm:text-sm font-medium focus:outline-hidden ${
                        confirmPassword && confirmPassword !== newPassword
                          ? 'border-rose-300 focus:border-rose-600'
                          : 'border-slate-300 focus:border-indigo-600'
                      }`}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {confirmPassword && confirmPassword !== newPassword && (
                    <p className="text-[11px] text-rose-600 font-semibold mt-1">
                      পাসওয়ার্ড দুটি মিলছে না!
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !currentPassword || !newPassword || newPassword !== confirmPassword || !passwordStrength.isValid}
                  className="w-full py-2.5 px-4 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>পাসওয়ার্ড পরিবর্তন করুন</span>
                </button>
              </form>

              {/* Password Recovery Info & Flow (Section 9) */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200 text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span className="font-extrabold text-xs sm:text-sm">পাসওয়ার্ড রিকভারি মেথড (Password Recovery)</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  পাসওয়ার্ড ভুলে গেলে আপনার ভেরিফাইড মোবাইল নম্বর (<span className="font-bold text-slate-800">{phone ? maskPhoneNumber(phone) : 'যুক্ত নেই'}</span>) অথবা ভেরিফাইড ইমেইল (<span className="font-bold text-slate-800">{email ? maskEmailAddress(email) : 'যুক্ত নেই'}</span>)-এ ৫-মিনিট মেয়াদি ওটিপি পাঠিয়ে লগইন পেজ থেকে তাৎক্ষণিক অ্যাকাউন্ট রিকভারি করা যাবে।
                </p>

                <div className="flex items-center justify-between pt-1 text-xs">
                  <span className="font-semibold text-slate-700">টু-ফ্যাক্টর নিরাপত্তা সতর্কতা (2FA Alert)</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={twoFactorEnabled}
                      onChange={(e) => {
                        setTwoFactorEnabled(e.target.checked);
                        updateAdminProfile({
                          username,
                          name,
                          phone,
                          email,
                          twoFactorEnabled: e.target.checked,
                        });
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>
              </div>

              {/* Active Sessions */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs sm:text-sm">
                    <Laptop className="w-4 h-4 text-blue-600" />
                    <span>সক্রিয় সেশন (Active Sessions)</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    বর্তমান ডিভাইস সক্রিয়
                  </span>
                </div>
                <div className="text-xs text-slate-600 flex items-center justify-between">
                  <span>ব্রাউজার সেশন স্ট্যাটাস:</span>
                  <span className="font-semibold text-slate-800">Secure Web Token</span>
                </div>
                <button
                  type="button"
                  onClick={handleRevokeOtherSessions}
                  disabled={isLoading}
                  className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5 text-slate-500" />
                  <span>অন্যান্য ডিভাইস থেকে লগআউট করুন (Revoke Others)</span>
                </button>
              </div>
            </div>
          )}

          {/* ===============================================================
              SECTION 3: SMS & EMAIL GATEWAY PROVIDERS (Section 4 & 5)
              =============================================================== */}
          {activeTab === 'providers' && (
            <div className="space-y-5">
              {/* Test Result Feedback */}
              {testResult && (
                <div
                  className={`p-3 text-xs font-semibold rounded-xl border flex items-center gap-2 ${
                    testResult.type === 'success'
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}
                >
                  {testResult.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}

              {/* Bangladeshi SMS Gateway Section */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs sm:text-sm">
                    <Smartphone className="w-4 h-4 text-amber-600" />
                    <span>বাংলাদেশি মোবাইল SMS Gateway কনফিগারেশন</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                    {smsProvider.toUpperCase()}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      এসএমএস প্রোভাইডার নির্বাচন করুন
                    </label>
                    <select
                      value={smsProvider}
                      onChange={(e) => setSmsProvider(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:border-indigo-600 focus:outline-hidden cursor-pointer"
                    >
                      <option value="simulation">সিমুলেশন / কনসোল মোড (Simulation / Test)</option>
                      <option value="greenweb">Greenweb Bangladesh (api.greenweb.com.bd)</option>
                      <option value="bulksmsbd">BulkSMS BD (bulksmsbd.net)</option>
                      <option value="alphanet">Alpha Net / SMSNet24 (smsnet24.com)</option>
                      <option value="mim_sms">MimSMS (mimsms.com)</option>
                      <option value="generic_http">Generic HTTP REST Gateway</option>
                    </select>
                  </div>

                  {smsProvider !== 'simulation' && (
                    <>
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          এসএমএস এপিআই কী / টোকেন (API Key / Token)
                        </label>
                        <input
                          type="password"
                          value={smsApiKey}
                          onChange={(e) => setSmsApiKey(e.target.value)}
                          placeholder="আপনার SMS Provider API Key"
                          className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono focus:border-indigo-600 focus:outline-hidden"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            সেন্ডার আইডি (Sender ID)
                          </label>
                          <input
                            type="text"
                            value={smsSenderId}
                            onChange={(e) => setSmsSenderId(e.target.value)}
                            placeholder="COMMERCE PT"
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-700 mb-1">
                            কাস্টম এপিআই ইউআরএল (ঐচ্ছিক)
                          </label>
                          <input
                            type="text"
                            value={smsApiUrl}
                            onChange={(e) => setSmsApiUrl(e.target.value)}
                            placeholder="https://..."
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {/* Test SMS Button */}
                  <div className="pt-2 flex items-center gap-2">
                    <input
                      type="tel"
                      value={testTargetPhone}
                      onChange={(e) => setTestTargetPhone(e.target.value)}
                      placeholder="টেস্ট নম্বর (যেমন: 017XXXXXXXX)"
                      className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-mono focus:border-indigo-600 focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={handleTestSms}
                      disabled={isTestingProvider || !testTargetPhone.trim()}
                      className="py-1.5 px-3 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      {isTestingProvider ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      <span>টেস্ট এসএমএস পাঠান</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Email SMTP Section */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs sm:text-sm">
                    <Mail className="w-4 h-4 text-blue-700" />
                    <span>ইমেইল এসএমটিপি (SMTP Email Gateway) কনফিগারেশন</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-200">
                    SMTP
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-slate-700 mb-1">
                        এসএমটিপি হোস্ট (EMAIL_HOST)
                      </label>
                      <input
                        type="text"
                        value={emailHost}
                        onChange={(e) => setEmailHost(e.target.value)}
                        placeholder="smtp.gmail.com"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        পোর্ট (EMAIL_PORT)
                      </label>
                      <input
                        type="number"
                        value={emailPort}
                        onChange={(e) => setEmailPort(Number(e.target.value))}
                        placeholder="587"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        ইউজারনেম / ইমেইল (EMAIL_USER)
                      </label>
                      <input
                        type="email"
                        value={emailUser}
                        onChange={(e) => setEmailUser(e.target.value)}
                        placeholder="admin@commercepoint.edu.bd"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        অ্যাপ পাসওয়ার্ড (EMAIL_PASSWORD)
                      </label>
                      <input
                        type="password"
                        value={emailPassword}
                        onChange={(e) => setEmailPassword(e.target.value)}
                        placeholder="Google App Password (16-digit)"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      সেন্ডার অ্যাড্রেস (EMAIL_FROM)
                    </label>
                    <input
                      type="text"
                      value={emailFrom}
                      onChange={(e) => setEmailFrom(e.target.value)}
                      placeholder="COMMERCE POINT <noreply@commercepoint.edu.bd>"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Test Email Button */}
                  <div className="pt-2 flex items-center gap-2">
                    <input
                      type="email"
                      value={testTargetEmail}
                      onChange={(e) => setTestTargetEmail(e.target.value)}
                      placeholder="টেস্ট ইমেইল ঠিকানা"
                      className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs focus:border-indigo-600 focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={handleTestEmail}
                      disabled={isTestingProvider || !testTargetEmail.trim()}
                      className="py-1.5 px-3 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      {isTestingProvider ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      <span>টেস্ট ইমেইল পাঠান</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Save All Provider Settings */}
              <button
                type="button"
                onClick={handleSaveProviderConfig}
                disabled={isLoading}
                className="w-full py-2.5 px-4 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                <span>গেটওয়ে ও প্রোভাইডার সেটিংস সার্ভারে সংরক্ষণ করুন</span>
              </button>
            </div>
          )}

          {/* ===============================================================
              SECTION 4: ACTIONS & VERIFICATION STATUS TABLE (Section 1 & 14)
              =============================================================== */}
          {activeTab === 'actions' && (
            <div className="space-y-4">
              {/* Account Recovery & Security Status Table */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-2 font-black text-xs sm:text-sm text-slate-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>সিকিউরিটি ও ভেরিফিকেশন স্ট্যাটাস টেবিল</span>
                  </div>
                  <button
                    type="button"
                    onClick={refreshProfileData}
                    className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                    title="রিফ্রেশ"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="divide-y divide-slate-200 text-xs">
                  {/* Row 1: Admin Name */}
                  <div className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-800 block">এডমিনের নাম (Admin Name)</span>
                      <span className="text-[11px] text-slate-500">{name || 'অপ্রধান'}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded-md bg-slate-200 text-slate-800 font-bold text-[10px]">
                      Username: {username}
                    </span>
                  </div>

                  {/* Row 2: Mobile Number */}
                  <div className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-800 block">মোবাইল নম্বর (Mobile Number)</span>
                      <span className="text-[11px] text-slate-500">
                        {phone ? maskPhoneNumber(phone) : 'যুক্ত করা হয়নি'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {phone ? (
                        isCurrentPhoneVerified ? (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-black text-[10px] border border-emerald-300">
                            ✓ Verified
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={handleInitiatePhoneVerification}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] cursor-pointer shadow-2xs"
                          >
                            Verify Now
                          </button>
                        )
                      ) : (
                        <button
                          type="button"
                          onClick={() => setActiveTab('personal')}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] border border-indigo-200 cursor-pointer"
                        >
                          + যোগ করুন
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Row 3: Email Address */}
                  <div className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-800 block">ইমেইল ঠিকানা (Email Address)</span>
                      <span className="text-[11px] text-slate-500">
                        {email ? maskEmailAddress(email) : 'যুক্ত করা হয়নি'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {email ? (
                        isCurrentEmailVerified ? (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-black text-[10px] border border-emerald-300">
                            ✓ Verified
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={handleInitiateEmailVerification}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] cursor-pointer shadow-2xs"
                          >
                            Verify Now
                          </button>
                        )
                      ) : (
                        <button
                          type="button"
                          onClick={() => setActiveTab('personal')}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] border border-indigo-200 cursor-pointer"
                        >
                          + যোগ করুন
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Row 4: Password */}
                  <div className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-800 block">পাসওয়ার্ড (Password)</span>
                      <span className="text-[11px] text-slate-500">
                        সর্বশেষ পরিবর্তন: {formatTimestamp(passwordChangedAt)}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('security')}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] border border-slate-300 cursor-pointer"
                    >
                      Change
                    </button>
                  </div>

                  {/* Row 5: Recovery Method */}
                  <div className="py-2.5 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-800 block">পাসওয়ার্ড রিকভারি মেথড</span>
                      <span className="text-[11px] text-slate-500">
                        {isCurrentPhoneVerified || isCurrentEmailVerified
                          ? 'ভেরিফাইড মোবাইল ও ইমেইল ওটিপি সক্রিয়'
                          : 'ভেরিফিকেশন সম্পন্ন হয়নি'}
                      </span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                        isCurrentPhoneVerified || isCurrentEmailVerified
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isCurrentPhoneVerified || isCurrentEmailVerified ? 'Active' : 'Pending'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Danger Zone: Factory Reset */}
              <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-2xl">
                <div className="flex items-start gap-2.5">
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="text-xs sm:text-sm font-bold text-rose-950">
                      ডিফল্ট ক্রেডেনশিয়ালসে রিকভারি (Factory Reset)
                    </h4>
                    <p className="text-xs text-rose-800 mt-1 leading-relaxed">
                      কখনও পাসওয়ার্ড সংক্রান্ত সমস্যার সম্মুখীন হলে, আপনি এডমিন অ্যাকাউন্টকে প্রাথমিক ডিফল্ট ক্রেডেনশিয়ালসে ফিরিয়ে নিতে পারেন।
                    </p>
                    <p className="text-[11px] text-rose-900 font-semibold mt-1">
                      ডিফল্ট ইউজারনেম: <code className="bg-white px-1.5 py-0.5 rounded border border-rose-200">{DEFAULT_ADMIN_USERNAME}</code> • 
                      ডিফল্ট পাসওয়ার্ড: <code className="bg-white px-1.5 py-0.5 rounded border border-rose-200">{DEFAULT_ADMIN_PASSWORD}</code>
                    </p>

                    {!showResetConfirm ? (
                      <button
                        type="button"
                        onClick={() => setShowResetConfirm(true)}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>ডিফল্ট সেটিংসে ফিরিয়ে নিন</span>
                      </button>
                    ) : (
                      <div className="mt-3 p-3 bg-white rounded-xl border border-rose-300 space-y-2">
                        <p className="text-xs font-bold text-rose-900">
                          আপনি কি নিশ্চিত যে ইউজারনেম ও পাসওয়ার্ড ডিফল্ট ({DEFAULT_ADMIN_USERNAME} / {DEFAULT_ADMIN_PASSWORD}) এ রিসেট করতে চান?
                        </p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleResetToDefault}
                            disabled={isLoading}
                            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                          >
                            {isLoading ? 'রিসেট হচ্ছে...' : 'হ্যাঁ, রিসেট করুন'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowResetConfirm(false)}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                          >
                            বাতিল
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>COMMERCE POINT • Secure Authentication & Verification</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>

        {/* -------------------------------------------------------------
            MODAL OVERLAY: OTP Verification Prompt (Mobile or Email)
            ------------------------------------------------------------- */}
        {activeOtpDialog !== 'none' && (
          <div className="absolute inset-0 z-20 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl p-5 shadow-2xl border border-slate-200 w-full max-w-sm space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                  <ShieldCheck className="w-5 h-5 text-indigo-600" />
                  <span>
                    {activeOtpDialog === 'phone' ? 'মোবাইল ওটিপি ভেরিফিকেশন' : 'ইমেইল ভেরিফিকেশন কোড'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveOtpDialog('none')}
                  className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="text-xs text-slate-600 space-y-2">
                <p>
                  <strong className="text-slate-900">{otpTargetMasked}</strong> ঠিকানায় পাঠানো ৬-ডিজিটের ভেরিফিকেশন কোডটি লিখুন:
                </p>

                <div className="flex items-center justify-between text-[11px] text-amber-800 bg-amber-50 px-2.5 py-1.5 rounded-lg border border-amber-200">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>মেয়াদ: ৫ মিনিট</span>
                  </span>
                  <span className="font-semibold text-slate-500">
                    ওয়ান-টাইম ওটিপি
                  </span>
                </div>

                {otpSimulationHint && (
                  <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] space-y-0.5">
                    <p className="font-bold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                      <span>সিমুলেটেড সিকিউরিটি কোড:</span>
                    </p>
                    <p>
                      ভেরিফিকেশন ওটিপি: <code className="font-mono font-bold text-sm bg-white px-2 py-0.5 rounded border border-blue-300 text-indigo-700">{otpSimulationHint}</code>
                    </p>
                    <p className="text-[10px] text-blue-700 italic mt-0.5">
                      (বাস্তব এসএমএস/ইমেইল গেটওয়ে কনফিগার না থাকলে এই কোড দিয়ে তাৎক্ষণিক ভেরিফাই সম্পন্ন করা যাবে)
                    </p>
                  </div>
                )}
              </div>

              <form
                onSubmit={
                  activeOtpDialog === 'phone'
                    ? handleVerifyPhoneOtpSubmit
                    : handleVerifyEmailOtpSubmit
                }
                className="space-y-3"
              >
                <div>
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCodeInput}
                    onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="৬ ডিজিটের কোড"
                    className="w-full text-center tracking-widest text-lg font-mono font-bold py-2 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                    autoFocus
                    required
                  />
                </div>

                {/* Section 8: Resend Button with 60s cooldown */}
                <div className="flex items-center justify-between text-xs px-1">
                  <span className="text-slate-500">কোড পাননি?</span>
                  <button
                    type="button"
                    disabled={isLoading || resendCooldown > 0}
                    onClick={
                      activeOtpDialog === 'phone'
                        ? handleInitiatePhoneVerification
                        : handleInitiateEmailVerification
                    }
                    className="font-bold text-indigo-700 hover:text-indigo-900 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer transition-colors"
                  >
                    {resendCooldown > 0 ? `পুনরায় পাঠান (${resendCooldown}s)` : 'Resend Code'}
                  </button>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={isLoading || otpCodeInput.length < 4}
                    className="flex-1 py-2 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>যাচাই ও নিশ্চিত করুন</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveOtpDialog('none')}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    বাতিল
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
