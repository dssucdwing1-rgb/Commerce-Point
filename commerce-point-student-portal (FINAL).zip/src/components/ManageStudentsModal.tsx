import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  UserPlus,
  Trash2,
  Users,
  AlertCircle,
  CheckCircle2,
  Pencil,
  Check,
  Shield,
  KeyRound,
  Lock,
  Unlock,
  Eye,
  ShieldCheck,
  Copy,
  Search,
  History,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  GraduationCap,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Filter,
  RotateCcw,
} from 'lucide-react';
import { Student, StudentAccount, StudentIdChangeRecord, Subject, Batch, BATCHES, getBatchById, Exam } from '../types';
import { toBengaliNum, DEFAULT_SUBJECTS } from '../data/initialData';
import {
  loadStudentAccounts,
  adminToggleStudentStatus,
  createStudentAccount,
  syncStudentIdAccount,
} from '../services/authService';
import { studentIdToDummyEmail } from '../utils/authHelpers';
import { supabase } from '../supabase';
import {
  validateStudentId,
  isStudentIdUnique,
  generateSuggestedStudentId,
  normalizeStudentId,
} from '../services/storage';
import { AuditReportModal } from './AuditReportModal';

/**
 * Resolves a student's batch ID ('class-11-a' | 'class-12-a' | 'class-12-b')
 */
export const getStudentBatchId = (student: Student): string => {
  if (student.batchId) {
    if (student.batchId === 'class11_batch_a') return 'class-11-a';
    if (student.batchId === 'class12_batch_a') return 'class-12-a';
    if (student.batchId === 'class12_batch_b') return 'class-12-b';
    return student.batchId;
  }
  if (student.studentIdCode) {
    const code = student.studentIdCode.toUpperCase();
    if (code.includes('C-11') || code.includes('CLASS-11') || code.includes('11/B-A')) return 'class-11-a';
    if (code.includes('C-12/B-B') || code.includes('12/B-B') || code.includes('BATCH-B')) return 'class-12-b';
    if (code.includes('C-12/B-A') || code.includes('12/B-A') || code.includes('BATCH-A')) return 'class-12-a';
  }
  if (student.academicClass === 'XII') {
    return student.group === 'B-B' ? 'class-12-b' : 'class-12-a';
  }
  return 'class-11-a';
};

interface ManageStudentsModalProps {
  isOpen: boolean;
  students: Student[];
  subjects?: Subject[];
  exams?: Exam[];
  activeBatchId?: string;
  initialTab?: 'students' | 'add' | 'accounts';
  onClose: () => void;
  onRefreshDatabase?: () => void;
  onAddStudent: (
    name: string,
    roll?: number,
    studentIdCode?: string,
    academicClass?: string,
    group?: string,
    subject?: string,
    session?: string,
    assignedSubjectIds?: string[],
    batchId?: string
  ) => void;
  onUpdateStudent: (
    studentId: string,
    name: string,
    roll: number,
    studentIdCode?: string,
    academicClass?: string,
    group?: string,
    subject?: string,
    session?: string,
    changedBy?: string,
    changeReason?: string,
    assignedSubjectIds?: string[],
    batchId?: string
  ) => void;
  onRemoveStudent: (studentId: string) => void;
  onOpenAdminAccount?: () => void;
}

export function ManageStudentsModal({
  isOpen,
  students,
  subjects,
  exams = [],
  activeBatchId = 'class-11-a',
  initialTab = 'students',
  onClose,
  onRefreshDatabase,
  onAddStudent,
  onUpdateStudent,
  onRemoveStudent,
  onOpenAdminAccount,
}: ManageStudentsModalProps) {
  // Tabs: 'students' (List) | 'add' (Add New Student) | 'accounts' (Login Accounts)
  const [activeTab, setActiveTab] = useState<'students' | 'add' | 'accounts'>(initialTab || 'students');

  // Filters for Student List
  const [selectedBatchFilter, setSelectedBatchFilter] = useState<string>(activeBatchId || 'all');
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Pagination State (Default to 0 / All so all students in any batch are immediately visible and scrollable)
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [rowsPerPage, setRowsPerPage] = useState<number>(0);

  // Track modal open transition so we only initialize state upon opening,
  // preventing user's manual batch filter selections from being overwritten while open
  const wasOpenRef = useRef(false);
  useEffect(() => {
    if (isOpen && !wasOpenRef.current) {
      if (initialTab) setActiveTab(initialTab);
      setSelectedBatchFilter(activeBatchId || 'all');
      setNewBatchId(activeBatchId || 'class-11-a');
      const b = getBatchById(activeBatchId || 'class-11-a');
      setNewClass(b.academicClass);
      setNewGroup(b.group);
      setAccounts(loadStudentAccounts());
      setCurrentPage(1);
    }
    wasOpenRef.current = isOpen;
  }, [isOpen, initialTab, activeBatchId]);

  // Reference for scrolling student list table back to top
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Dedicated batch filter change handler (resets view & updates counts)
  const handleBatchFilterChange = (batchId: string) => {
    setSelectedBatchFilter(batchId);
    setCurrentPage(1);
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Reset view to all batches and clear search / status filters
  const handleResetView = () => {
    setSelectedBatchFilter('all');
    setSelectedClassFilter('all');
    setSelectedStatusFilter('all');
    setSearchQuery('');
    setCurrentPage(1);
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Modals & Popups
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);
  const [isAuditReportOpen, setIsAuditReportOpen] = useState(false);
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);

  // Edit Student Form State
  const [editName, setEditName] = useState('');
  const [editRoll, setEditRoll] = useState<number | ''>('');
  const [editStudentId, setEditStudentId] = useState('');
  const [isEditIdLocked, setIsEditIdLocked] = useState(true);
  const [editBatchId, setEditBatchId] = useState('class-11-a');
  const [editClass, setEditClass] = useState('XI');
  const [editGroup, setEditGroup] = useState('B-A');
  const [editSession, setEditSession] = useState('2026');
  const [editAssignedSubjects, setEditAssignedSubjects] = useState<string[]>([]);
  const [editReason, setEditReason] = useState('');

  // Add Student State
  const [newBatchId, setNewBatchId] = useState(activeBatchId || 'class-11-a');
  const [newName, setNewName] = useState('');
  const [newRoll, setNewRoll] = useState<number | ''>('');
  const [newCustomId, setNewCustomId] = useState('');
  const [newClass, setNewClass] = useState('XI');
  const [newGroup, setNewGroup] = useState('B-A');
  const [newSubject, setNewSubject] = useState('ICT');
  const [newSession, setNewSession] = useState('2026');
  const [hasManuallyEditedAddId, setHasManuallyEditedAddId] = useState(false);
  const [initialPassword, setInitialPassword] = useState('123456');

  // Accounts Management & Admin-assisted Reset (Requirement 2)
  const [accounts, setAccounts] = useState<StudentAccount[]>(() => loadStudentAccounts());
  const [selectedStudentForReset, setSelectedStudentForReset] = useState<string>('');
  const [resetNewPassword, setResetNewPassword] = useState<string>('123456');
  const [isResettingPass, setIsResettingPass] = useState<boolean>(false);

  // Feedback banner
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Effective subjects
  const effectiveSubjects = useMemo(() => {
    return subjects && subjects.length > 0 ? subjects : DEFAULT_SUBJECTS;
  }, [subjects]);

  const activeSubjects = useMemo(() => {
    return effectiveSubjects.filter((s) => s.isActive);
  }, [effectiveSubjects]);

  const allActiveSubjectIds = useMemo(() => {
    return activeSubjects.map((s) => s.id);
  }, [activeSubjects]);

  const [newAssignedSubjects, setNewAssignedSubjects] = useState<string[]>(() => allActiveSubjectIds);

  // Batch counts (accurately categorized by batch ID)
  const batchCounts = useMemo(() => {
    const counts: Record<string, number> = { 'class-11-a': 0, 'class-12-a': 0, 'class-12-b': 0 };
    students.forEach((s) => {
      const bId = getStudentBatchId(s);
      counts[bId] = (counts[bId] || 0) + 1;
    });
    return counts;
  }, [students]);

  // Suggested roll & ID for Add Student
  const suggestedRoll = useMemo(() => {
    const batchStudents = students.filter((s) => getStudentBatchId(s) === newBatchId);
    if (batchStudents.length === 0) return 1;
    const maxRoll = Math.max(...batchStudents.map((s) => s.roll || 0));
    return maxRoll + 1;
  }, [students, newBatchId]);

  const suggestedIdForAdd = useMemo(() => {
    const rollToUse = typeof newRoll === 'number' && newRoll > 0 ? newRoll : suggestedRoll;
    return generateSuggestedStudentId(rollToUse, newClass, newGroup);
  }, [newRoll, suggestedRoll, newClass, newGroup]);

  // Update auto ID for Add form when roll or batch changes
  useEffect(() => {
    if (!hasManuallyEditedAddId) {
      setNewCustomId(suggestedIdForAdd);
    }
  }, [suggestedIdForAdd, hasManuallyEditedAddId]);

  const handleBatchChangeForAdd = (batchId: string) => {
    setNewBatchId(batchId);
    const b = getBatchById(batchId);
    setNewClass(b.academicClass);
    setNewGroup(b.group);
    setHasManuallyEditedAddId(false);
  };

  // Copy helper
  const handleCopyId = (idToCopy: string) => {
    if (!idToCopy) return;
    try {
      navigator.clipboard.writeText(idToCopy);
      setCopiedId(idToCopy);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      setCopiedId(idToCopy);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students
      .filter((student) => {
        // 1. Batch Filter: filter student list by selected batch ID before rendering
        if (selectedBatchFilter && selectedBatchFilter !== 'all') {
          const sBatchId = getStudentBatchId(student);
          if (sBatchId !== selectedBatchFilter) return false;
        }

        // 2. Class Filter
        if (selectedClassFilter !== 'all') {
          const sClass = student.academicClass || 'XI';
          if (sClass !== selectedClassFilter) return false;
        }

        // 3. Status Filter (Active / Inactive)
        if (selectedStatusFilter !== 'all') {
          const acc = accounts.find((a) => a.studentId === student.id);
          const isInactive = acc?.status === 'inactive';
          if (selectedStatusFilter === 'active' && isInactive) return false;
          if (selectedStatusFilter === 'inactive' && !isInactive) return false;
        }

        // 4. Search Query
        if (!searchQuery.trim()) return true;
        const q = searchQuery.trim().toLowerCase();
        const nameMatch = student.name.toLowerCase().includes(q);
        const idMatch = (student.studentIdCode || '').toLowerCase().includes(q);
        const rollMatch = String(student.roll) === q;
        return nameMatch || idMatch || rollMatch;
      })
      .sort((a, b) => (a.roll || 0) - (b.roll || 0));
  }, [students, selectedBatchFilter, selectedClassFilter, selectedStatusFilter, searchQuery, accounts]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedBatchFilter, selectedClassFilter, selectedStatusFilter, searchQuery]);

  // Pagination calculation
  const totalPages = rowsPerPage === 0 ? 1 : Math.max(1, Math.ceil(filteredStudents.length / rowsPerPage));
  const paginatedStudents = useMemo(() => {
    if (rowsPerPage === 0) return filteredStudents;
    const startIndex = (currentPage - 1) * rowsPerPage;
    return filteredStudents.slice(startIndex, startIndex + rowsPerPage);
  }, [filteredStudents, currentPage, rowsPerPage]);

  // Handle Add Student Submit
  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      setFeedback({ type: 'error', message: 'অনুগ্রহ করে শিক্ষার্থীর নাম লিখুন।' });
      return;
    }

    const rollToUse = typeof newRoll === 'number' && newRoll > 0 ? newRoll : suggestedRoll;
    const finalStudentId = (newCustomId.trim() || suggestedIdForAdd).trim();

    // Validate format
    const formatValidation = validateStudentId(finalStudentId);
    if (!formatValidation.valid) {
      setFeedback({
        type: 'error',
        message: formatValidation.error || 'Student ID ফরম্যাট সঠিক নয়।',
      });
      return;
    }

    // Validate uniqueness
    if (!isStudentIdUnique(finalStudentId)) {
      setFeedback({
        type: 'error',
        message: 'এই Student ID ইতোমধ্যে বিদ্যমান। অনুগ্রহ করে একটি ভিন্ন ID দিন।',
      });
      return;
    }

    onAddStudent(
      newName.trim(),
      rollToUse,
      finalStudentId,
      newClass,
      newGroup,
      newSubject,
      newSession,
      newAssignedSubjects,
      newBatchId
    );

    // Create login account
    const tempStudent: Student = {
      id: `student-${Date.now()}`,
      roll: rollToUse,
      name: newName.trim(),
      studentIdCode: finalStudentId,
      batchId: newBatchId,
      academicClass: newClass,
      group: newGroup,
      subject: newSubject,
      session: newSession,
      assignedSubjectIds: newAssignedSubjects,
    };

    await createStudentAccount(tempStudent, initialPassword);
    setAccounts(loadStudentAccounts());

    setFeedback({
      type: 'success',
      message: `শিক্ষার্থী "${newName.trim()}" (ID: ${finalStudentId}) সফলভাবে যুক্ত করা হয়েছে!`,
    });

    // Reset Add Form
    setNewName('');
    setNewRoll('');
    setHasManuallyEditedAddId(false);

    // Switch to Student List to see newly added student
    setActiveTab('students');
    setTimeout(() => setFeedback(null), 4000);
  };

  // Start Edit
  const handleStartEdit = (student: Student) => {
    const sBatchId =
      student.batchId ||
      (student.academicClass === 'XII' ? (student.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
    setEditingStudent(student);
    setIsEditIdLocked(true);
    setEditName(student.name);
    setEditRoll(student.roll);
    setEditStudentId(student.studentIdCode || '');
    setEditBatchId(sBatchId);
    setEditClass(student.academicClass || 'XI');
    setEditGroup(student.group || 'B-A');
    setEditSession(student.session || '2026');
    setEditAssignedSubjects(
      Array.isArray(student.assignedSubjectIds) && student.assignedSubjectIds.length > 0
        ? student.assignedSubjectIds
        : allActiveSubjectIds
    );
    setEditReason('');
  };

  // Save Edit
  const handleSaveEdit = async () => {
    if (!editingStudent) return;
    if (!editName.trim()) {
      setFeedback({ type: 'error', message: 'শিক্ষার্থীর নাম খালি রাখা যাবে না।' });
      return;
    }

    const rollNum = typeof editRoll === 'number' && editRoll > 0 ? editRoll : editingStudent.roll;
    const finalStudentId = editStudentId.trim() || editingStudent.studentIdCode || '';

    // If ID was changed, validate
    if (finalStudentId !== editingStudent.studentIdCode) {
      const formatValidation = validateStudentId(finalStudentId);
      if (!formatValidation.valid) {
        setFeedback({ type: 'error', message: formatValidation.error || 'Student ID ফরম্যাট সঠিক নয়।' });
        return;
      }
      if (!isStudentIdUnique(finalStudentId, editingStudent.id)) {
        setFeedback({ type: 'error', message: 'এই Student ID ইতোমধ্যে অন্য শিক্ষার্থীর জন্য ব্যবহৃত হয়েছে।' });
        return;
      }
    }

    onUpdateStudent(
      editingStudent.id,
      editName.trim(),
      rollNum,
      finalStudentId,
      editClass,
      editGroup,
      editingStudent.subject || 'ICT',
      editSession,
      'Admin',
      editReason.trim() || 'Admin information update',
      editAssignedSubjects,
      editBatchId
    );

    // Sync login account
    if (finalStudentId !== editingStudent.studentIdCode) {
      await syncStudentIdAccount(editingStudent.id, finalStudentId);
    }
    setAccounts(loadStudentAccounts());

    setEditingStudent(null);
    setFeedback({
      type: 'success',
      message: `শিক্ষার্থী "${editName.trim()}"-এর তথ্য সফলভাবে আপডেট হয়েছে!`,
    });
    setTimeout(() => setFeedback(null), 3500);
  };

  // Toggle Account Active / Inactive
  const handleToggleStudentActive = (studentId: string) => {
    const currentAcc = accounts.find((a) => a.studentId === studentId);
    const newStatus = currentAcc?.status === 'inactive' ? 'active' : 'inactive';
    const res = adminToggleStudentStatus(studentId, newStatus);
    setAccounts(loadStudentAccounts());
    setFeedback({
      type: res.success ? 'success' : 'error',
      message: res.message,
    });
    setTimeout(() => setFeedback(null), 3000);
  };

  // Admin-assisted Reset feature
  const handleSelectStudentForReset = (studentId: string) => {
    setSelectedStudentForReset(studentId);
    setResetNewPassword('123456');
    const targetStudent = students.find((s) => s.id === studentId);
    if (targetStudent) {
      const dummyEmail = studentIdToDummyEmail(targetStudent.studentIdCode);
      setFeedback({
        type: 'success',
        message: `✓ শিক্ষার্থী "${targetStudent.name}" (${dummyEmail}) নির্বাচিত হয়েছে।`,
      });
      setTimeout(() => {
        setFeedback(null);
      }, 3000);
    }
  };

  const handleAdminResetPassword = async () => {
    if (!selectedStudentForReset) {
      setFeedback({ type: 'error', message: 'অনুগ্রহ করে শিক্ষার্থী নির্বাচন করুন।' });
      return;
    }
    const targetStudent = students.find((s) => s.id === selectedStudentForReset);
    if (!targetStudent) {
      setFeedback({ type: 'error', message: 'শিক্ষার্থী পাওয়া যায়নি।' });
      return;
    }
    const studentDummyEmail = studentIdToDummyEmail(targetStudent.studentIdCode);
    const newPassword = resetNewPassword.trim();

    if (!newPassword || newPassword.length < 6) {
      setFeedback({ type: 'error', message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' });
      return;
    }

    setIsResettingPass(true);

    try {
      const { data, error } = await supabase.rpc('admin_reset_student_password', {
        target_email: studentDummyEmail.trim().toLowerCase(),
        new_password: newPassword,
      });

      if (error) {
        setFeedback({
          type: 'error',
          message: 'সমস্যা হয়েছে: ' + error.message,
        });
        return;
      }

      const res = data as any;
      if (res && res.success === false) {
        setFeedback({
          type: 'error',
          message: res.message || 'পাসওয়ার্ড রিসেট করা যায়নি।',
        });
        return;
      }

      const successMsg = res?.message || 'পাসওয়ার্ড সফলভাবে রিসেট ও কার্যকর হয়েছে!';
      setFeedback({
        type: 'success',
        message: successMsg,
      });
      setResetNewPassword('');
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      console.error(err);
      setFeedback({
        type: 'error',
        message: 'সমস্যা হয়েছে: ' + (err?.message || 'নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। আবার চেষ্টা করুন।'),
      });
    } finally {
      setIsResettingPass(false);
    }
  };

  // Confirm delete
  const handleConfirmDelete = () => {
    if (studentToDelete) {
      onRemoveStudent(studentToDelete.id);
      setStudentToDelete(null);
      setFeedback({
        type: 'success',
        message: `শিক্ষার্থী "${studentToDelete.name}" সফলভাবে তালিকা থেকে অপসারিত হয়েছে।`,
      });
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="manage-students-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4"
      onClick={onClose}
    >
      <div
        id="manage-students-modal"
        className="bg-white rounded-3xl max-w-5xl w-full h-[92vh] sm:h-[88vh] max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ========================================================
            MODAL HEADER: TITLE, DEDICATED BATCH FILTER & ACTIONS
            ======================================================== */}
        <div className="p-3.5 sm:p-5 border-b border-slate-200 bg-slate-50/90 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shrink-0 shadow-md shadow-indigo-200">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                  Student Management
                </h3>
                <span className="text-xs font-bold text-slate-500 hidden sm:inline">• শিক্ষার্থী ব্যবস্থাপনা</span>
                {/* Dynamically updating student count badge */}
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black bg-indigo-100 text-indigo-900 border border-indigo-200 shadow-2xs">
                  <Users className="w-3 h-3 text-indigo-600" />
                  <span>{toBengaliNum(filteredStudents.length)} জন</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {selectedBatchFilter === 'all' ? (
                  <span>
                    মোট শিক্ষার্থী: <strong className="text-slate-900 font-bold">{toBengaliNum(students.length)}</strong> জন (সকল ব্যাচ)
                  </span>
                ) : (
                  <span>
                    নির্বাচিত ব্যাচে শিক্ষার্থী: <strong className="text-indigo-900 font-black">{toBengaliNum(filteredStudents.length)}</strong> জন
                    <span className="text-slate-500 font-normal"> (মোট {toBengaliNum(students.length)} জনের মধ্যে)</span>
                  </span>
                )}
                <span className="hidden md:inline"> • ব্যাচ-ভিত্তিক ফিল্টারিং ও নিরাপদ User ID কন্ট্রোল</span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {/* DEDICATED BATCH DROPDOWN FILTER IN THE HEADER */}
            <div className="flex items-center gap-2 bg-white border-2 border-indigo-200 hover:border-indigo-400 focus-within:border-indigo-600 focus-within:ring-2 focus-within:ring-indigo-100 rounded-2xl px-3 py-1.5 shadow-2xs transition-all">
              <div className="flex items-center gap-1.5 shrink-0 text-indigo-700">
                <Filter className="w-3.5 h-3.5" />
                <label htmlFor="header-batch-select" className="text-xs font-black cursor-pointer hidden xs:inline">
                  ব্যাচ:
                </label>
              </div>
              <select
                id="header-batch-select"
                name="batchFilter"
                data-testid="header-batch-select"
                value={selectedBatchFilter}
                onChange={(e) => handleBatchFilterChange(e.target.value)}
                className="bg-transparent text-xs font-extrabold text-slate-900 focus:outline-hidden cursor-pointer"
                title="সক্রিয় ব্যাচ অনুযায়ী শিক্ষার্থী তালিকা ফিল্টার করুন"
                aria-label="Filter students by selected batch"
              >
                <option value="all">সকল ব্যাচ (All Batches — {toBengaliNum(students.length)} জন)</option>
                <option value="class-11-a">Class 11 (একাদশ শ্রেণি — {toBengaliNum(batchCounts['class-11-a'] || 0)} জন)</option>
                <option value="class-12-a">Class 12 Batch A (দ্বাদশ শ্রেণি — ব্যাচ এ — {toBengaliNum(batchCounts['class-12-a'] || 0)} জন)</option>
                <option value="class-12-b">Class 12 Batch B (দ্বাদশ শ্রেণি — ব্যাচ বি — {toBengaliNum(batchCounts['class-12-b'] || 0)} জন)</option>
              </select>
            </div>

            {/* Quick Reset View Button in Header if batch or filters active */}
            {(selectedBatchFilter !== 'all' || searchQuery || selectedStatusFilter !== 'all') && (
              <button
                type="button"
                id="modal-header-reset-view-btn"
                onClick={handleResetView}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 transition-colors cursor-pointer"
                title="ভিউ ও ফিল্টার রিসেট করুন"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden sm:inline">রিসেট</span>
              </button>
            )}

            {onOpenAdminAccount && (
              <button
                type="button"
                id="modal-to-admin-account-btn"
                onClick={() => {
                  onClose();
                  onOpenAdminAccount();
                }}
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition-colors cursor-pointer"
                title="এডমিন পাসওয়ার্ড ও টিচার অ্যাকাউন্ট সেটিংস"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                <span>পাসওয়ার্ড সেটিংস</span>
              </button>
            )}

            <button
              type="button"
              id="manage-students-close-btn"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ========================================================
            NAVIGATION SUB-TABS (Clean Section Organization)
            ======================================================== */}
        <div className="flex items-center justify-between px-4 pt-2 pb-0 bg-slate-100/90 border-b border-slate-200 text-xs font-bold overflow-x-auto shrink-0 gap-2">
          <div className="flex items-center gap-1">
            {/* Tab 1: Student List */}
            <button
              type="button"
              id="subtab-students-list"
              onClick={() => setActiveTab('students')}
              className={`py-2 px-3.5 rounded-t-xl transition-all flex items-center gap-2 cursor-pointer border-t border-x ${
                activeTab === 'students'
                  ? 'bg-white text-indigo-900 border-slate-200 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/50'
              }`}
            >
              <Users className="w-4 h-4 text-indigo-600" />
              <span>শিক্ষার্থী তালিকা (Student List)</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-100 text-indigo-800 font-black">
                {selectedBatchFilter === 'all'
                  ? students.length
                  : `${filteredStudents.length} / ${students.length}`}
              </span>
            </button>

            {/* Tab 2: Add New Student */}
            <button
              type="button"
              id="subtab-add-student"
              onClick={() => setActiveTab('add')}
              className={`py-2 px-3.5 rounded-t-xl transition-all flex items-center gap-2 cursor-pointer border-t border-x ${
                activeTab === 'add'
                  ? 'bg-white text-emerald-900 border-slate-200 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/50'
              }`}
            >
              <UserPlus className="w-4 h-4 text-emerald-600" />
              <span>নতুন শিক্ষার্থী যোগ (Add Student)</span>
            </button>

            {/* Tab 3: Login Accounts */}
            <button
              type="button"
              id="subtab-student-accounts"
              onClick={() => setActiveTab('accounts')}
              className={`py-2 px-3.5 rounded-t-xl transition-all flex items-center gap-2 cursor-pointer border-t border-x ${
                activeTab === 'accounts'
                  ? 'bg-white text-blue-900 border-slate-200 shadow-2xs font-black'
                  : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/50'
              }`}
            >
              <Shield className="w-4 h-4 text-blue-600" />
              <span>লগইন অ্যাকাউন্টস (Accounts)</span>
            </button>
          </div>

          {/* Audit Report Action */}
          <button
            type="button"
            onClick={() => setIsAuditReportOpen(true)}
            className="mb-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 shadow-2xs shrink-0"
            title="দ্বাদশ শ্রেণির ব্যাচ এ ও বি তালিকা ভেরিফিকেশন রিপোর্ট দেখুন"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">ডাটাবেজ</span>
            <span>ভেরিফিকেশন রিপোর্ট</span>
          </button>
        </div>

        {/* Global Feedback Banner */}
        {feedback && (
          <div
            className={`mx-4 mt-3 p-3 rounded-2xl border text-xs font-bold flex items-center justify-between gap-2 shrink-0 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{feedback.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* ========================================================
            TAB 1: STUDENT LIST (Table Layout with Dedicated Scroll)
            ======================================================== */}
        {activeTab === 'students' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden p-4 space-y-3">
            {/* Filter Bar (Search + Batch Filter + Class Filter + Status) */}
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2.5 shrink-0">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                {/* Search Bar */}
                <div className="sm:col-span-6 relative flex items-center">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    id="student-search-input"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Student ID, রোল অথবা নাম দিয়ে খুঁজুন..."
                    className="w-full pl-9 pr-8 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 shadow-2xs"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Batch Dropdown Filter */}
                <div className="sm:col-span-3">
                  <select
                    id="student-batch-filter-select"
                    value={selectedBatchFilter}
                    onChange={(e) => handleBatchFilterChange(e.target.value)}
                    className="w-full py-2 px-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs"
                  >
                    <option value="all">সকল ব্যাচ (All Batches — {toBengaliNum(students.length)} জন)</option>
                    <option value="class-11-a">Class 11 (একাদশ শ্রেণি — {toBengaliNum(batchCounts['class-11-a'] || 0)} জন)</option>
                    <option value="class-12-a">Class 12 Batch A (দ্বাদশ শ্রেণি — ব্যাচ এ — {toBengaliNum(batchCounts['class-12-a'] || 0)} জন)</option>
                    <option value="class-12-b">Class 12 Batch B (দ্বাদশ শ্রেণি — ব্যাচ বি — {toBengaliNum(batchCounts['class-12-b'] || 0)} জন)</option>
                  </select>
                </div>

                {/* Status Filter */}
                <div className="sm:col-span-3">
                  <select
                    id="student-status-filter-select"
                    value={selectedStatusFilter}
                    onChange={(e) => setSelectedStatusFilter(e.target.value as any)}
                    className="w-full py-2 px-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs"
                  >
                    <option value="all">সকল অ্যাকাউন্ট স্ট্যাটাস</option>
                    <option value="active">সক্রিয় (Active)</option>
                    <option value="inactive">নিষ্ক্রিয় (Deactivated)</option>
                  </select>
                </div>
              </div>

              {/* Quick Batch Pills */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-200/60 text-xs font-bold">
                <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider mr-1">
                  দ্রুত নির্বাচন:
                </span>
                <button
                  type="button"
                  onClick={() => handleBatchFilterChange('all')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedBatchFilter === 'all'
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  সকল ব্যাচ ({students.length})
                </button>
                {BATCHES.map((b) => {
                  const isSel = selectedBatchFilter === b.id;
                  const label =
                    b.id === 'class-11-a'
                      ? 'Class 11'
                      : b.id === 'class-12-a'
                      ? 'Class 12 Batch A'
                      : 'Class 12 Batch B';
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => handleBatchFilterChange(b.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSel
                          ? 'bg-red-600 text-white shadow-2xs border border-red-500'
                          : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <span>{label}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[10px] ${isSel ? 'bg-red-800 text-white' : 'bg-slate-100 text-slate-600'}`}>
                        {batchCounts[b.id] || 0}
                      </span>
                    </button>
                  );
                })}

                <button
                  type="button"
                  onClick={() => setActiveTab('add')}
                  className="ml-auto inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-2xs transition-colors cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>নতুন শিক্ষার্থী যোগ</span>
                </button>
              </div>
            </div>

            {/* DEDICATED ACTIVE BATCH HEADER & STUDENT COUNT SUMMARY BAR */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2 bg-slate-100/90 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 shrink-0 shadow-2xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-slate-500 font-semibold">সক্রিয় ব্যাচ:</span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-950 font-black shadow-2xs">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      selectedBatchFilter === 'class-11-a'
                        ? 'bg-emerald-500'
                        : selectedBatchFilter === 'class-12-a'
                        ? 'bg-rose-500'
                        : selectedBatchFilter === 'class-12-b'
                        ? 'bg-blue-500'
                        : 'bg-slate-700'
                    }`}
                  />
                  <span>
                    {selectedBatchFilter === 'all'
                      ? 'সকল ব্যাচ (All Batches)'
                      : selectedBatchFilter === 'class-11-a'
                      ? 'Class 11 (একাদশ শ্রেণি — ব্যাচ এ)'
                      : selectedBatchFilter === 'class-12-a'
                      ? 'Class 12 Batch A (দ্বাদশ শ্রেণি — ব্যাচ এ)'
                      : 'Class 12 Batch B (দ্বাদশ শ্রেণি — ব্যাচ বি)'}
                  </span>
                </span>
                <span className="text-slate-600">
                  • প্রদর্শিত শিক্ষার্থী: <strong className="text-slate-900 font-black">{toBengaliNum(filteredStudents.length)}</strong> জন
                  {selectedBatchFilter !== 'all' && (
                    <span className="text-slate-500 font-medium ml-1">
                      (মোট ডাটাবেজ: {toBengaliNum(students.length)} জন)
                    </span>
                  )}
                </span>
              </div>

              {(selectedBatchFilter !== 'all' || searchQuery || selectedStatusFilter !== 'all') && (
                <button
                  type="button"
                  id="table-reset-view-btn"
                  onClick={handleResetView}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-200 border border-slate-300 shadow-2xs transition-colors cursor-pointer"
                  title="ফিল্টার রিসেট করে স্বাভাবিক ভিউতে ফিরে যান"
                >
                  <RotateCcw className="w-3 h-3 text-slate-500" />
                  <span>ভিউ রিসেট করুন (Reset View)</span>
                </button>
              )}
            </div>

            {/* DEDICATED SCROLLABLE STUDENT LIST CONTAINER (Section 5 & 6) */}
            <div
              ref={tableContainerRef}
              className="student-list-container flex-1 min-h-[220px] max-h-[60vh] overflow-y-auto overflow-x-auto border border-slate-200 rounded-2xl bg-white shadow-inner relative overscroll-contain touch-pan-x touch-pan-y"
              style={{ maxHeight: '60vh', WebkitOverflowScrolling: 'touch', overscrollBehavior: 'contain' }}
            >
              <table className="w-full text-left text-xs border-collapse min-w-[700px]">
                {/* STICKY TABLE HEADER */}
                <thead
                  className="sticky top-0 z-20 bg-slate-100/98 backdrop-blur-xs border-b border-slate-200 shadow-2xs text-[11px] font-black text-slate-700 uppercase tracking-wider"
                  style={{ position: 'sticky', top: 0, zIndex: 20 }}
                >
                  <tr style={{ position: 'sticky', top: 0 }}>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 text-center w-14 z-20" style={{ position: 'sticky', top: 0 }}>রোল</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 z-20" style={{ position: 'sticky', top: 0 }}>শিক্ষার্থীর নাম</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 z-20" style={{ position: 'sticky', top: 0 }}>Student ID (User ID)</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 text-center z-20" style={{ position: 'sticky', top: 0 }}>শ্রেণি</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 z-20" style={{ position: 'sticky', top: 0 }}>ব্যাচ</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 text-center z-20" style={{ position: 'sticky', top: 0 }}>স্ট্যাটাস</th>
                    <th className="sticky top-0 bg-slate-100/98 py-3 px-3 text-right z-20" style={{ position: 'sticky', top: 0 }}>কার্যক্রম (Action)</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100 font-medium">
                  {paginatedStudents.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-slate-500">
                        <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                        <p className="font-semibold text-sm">কোনো শিক্ষার্থী পাওয়া যায়নি</p>
                        <p className="text-xs text-slate-400 mt-0.5">অনুগ্রহ করে ফিল্টার বা সার্চ কুয়েরি পরিবর্তন করুন।</p>
                      </td>
                    </tr>
                  ) : (
                    paginatedStudents.map((student, idx) => {
                      const sBatch = getBatchById(getStudentBatchId(student));
                      const studentAcc = accounts.find((a) => a.studentId === student.id);
                      const isActive = studentAcc?.status !== 'inactive';
                      const isCopied = copiedId === student.studentIdCode;
                      const hasHistory = (student.idHistory?.length || 0) > 0;

                      return (
                        <tr
                          key={student.id}
                          className="hover:bg-indigo-50/50 transition-colors group"
                        >
                          {/* Roll */}
                          <td className="py-2.5 px-3 text-center">
                            <span className="inline-block w-7 h-7 rounded-lg bg-slate-100 text-slate-800 font-black text-xs leading-7 text-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                              {student.roll}
                            </span>
                          </td>

                          {/* Student Name */}
                          <td className="py-2.5 px-3 font-bold text-slate-900">
                            <div className="flex items-center gap-2">
                              <span>{student.name}</span>
                              {hasHistory && (
                                <span
                                  className="w-2 h-2 rounded-full bg-amber-500"
                                  title="আইডি পরিবর্তন হিস্ট্রি আছে"
                                />
                              )}
                            </div>
                          </td>

                          {/* Student ID Code */}
                          <td className="py-2.5 px-3">
                            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-slate-100 group-hover:bg-white text-indigo-950 font-mono font-black text-xs border border-slate-200 shadow-2xs">
                              <span>{student.studentIdCode}</span>
                              <button
                                type="button"
                                onClick={() => handleCopyId(student.studentIdCode)}
                                className="text-slate-400 hover:text-indigo-600 cursor-pointer p-0.5"
                                title="ID কপি করুন"
                              >
                                {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </td>

                          {/* Class / Group */}
                          <td className="py-2.5 px-3 text-center">
                            <span className="font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                              {student.academicClass || 'XI'} ({student.group || 'B-A'})
                            </span>
                          </td>

                          {/* Batch */}
                          <td className="py-2.5 px-3">
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700">
                              <span
                                className={`w-2 h-2 rounded-full ${
                                  sBatch.id === 'class-12-a'
                                    ? 'bg-rose-500'
                                    : sBatch.id === 'class-12-b'
                                    ? 'bg-blue-500'
                                    : 'bg-emerald-500'
                                }`}
                              />
                              <span>{sBatch.shortName}</span>
                            </span>
                          </td>

                          {/* Login Status */}
                          <td className="py-2.5 px-3 text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                                isActive
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-rose-50 text-rose-700 border border-rose-200'
                              }`}
                            >
                              {isActive ? 'Active' : 'Deactivated'}
                            </span>
                          </td>

                          {/* Actions: View / Edit / Deactivate / Delete */}
                          <td className="py-2.5 px-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              {/* [View] Button */}
                              <button
                                type="button"
                                title="বিস্তারিত তথ্য দেখুন"
                                onClick={() => setViewingStudent(student)}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                              >
                                <Eye className="w-3 h-3 text-slate-500" />
                                <span>View</span>
                              </button>

                              {/* [Edit] Button */}
                              <button
                                type="button"
                                title="নাম ও তথ্য সংশোধন করুন"
                                onClick={() => handleStartEdit(student)}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition-colors cursor-pointer"
                              >
                                <Pencil className="w-3 h-3 text-indigo-600" />
                                <span>Edit</span>
                              </button>

                              {/* [Admin Reset] Button */}
                              <button
                                type="button"
                                title="সরাসরি পাসওয়ার্ড সেট করুন (Admin-assisted Reset)"
                                onClick={() => {
                                  setSelectedStudentForReset(student.id);
                                  setActiveTab('accounts');
                                }}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition-colors cursor-pointer"
                              >
                                <KeyRound className="w-3 h-3 text-amber-600" />
                                <span>Reset</span>
                              </button>

                              {/* [Deactivate / Activate] Button */}
                              <button
                                type="button"
                                title={isActive ? 'লগইন নিষ্ক্রিয় করুন' : 'লগইন সক্রিয় করুন'}
                                onClick={() => handleToggleStudentActive(student.id)}
                                className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer border ${
                                  isActive
                                    ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-200'
                                    : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-200'
                                }`}
                              >
                                {isActive ? (
                                  <>
                                    <Lock className="w-3 h-3 text-amber-600" />
                                    <span>Deactivate</span>
                                  </>
                                ) : (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-600" />
                                    <span>Activate</span>
                                  </>
                                )}
                              </button>

                              {/* Delete */}
                              <button
                                type="button"
                                title="শিক্ষার্থী মুছে ফেলুন"
                                onClick={() => setStudentToDelete(student)}
                                className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>

              {/* SAFE BOTTOM PADDING TO PREVENT ROW CLIPPING */}
              <div className="h-6" />
            </div>

            {/* PAGINATION & RECORD CONTROLS (Section 10) */}
            <div className="flex flex-wrap items-center justify-between gap-3 px-2 pt-2 border-t border-slate-200 text-xs shrink-0">
              <div className="text-slate-600 font-medium">
                মোট <strong className="text-slate-900 font-black">{toBengaliNum(filteredStudents.length)}</strong> জন শিক্ষার্থীর মধ্যে{' '}
                {filteredStudents.length > 0 && (
                  <span>
                    <strong>
                      {toBengaliNum(rowsPerPage === 0 ? 1 : (currentPage - 1) * rowsPerPage + 1)}
                    </strong>
                    -
                    <strong>
                      {toBengaliNum(
                        rowsPerPage === 0
                          ? filteredStudents.length
                          : Math.min(currentPage * rowsPerPage, filteredStudents.length)
                      )}
                    </strong>{' '}
                    জন দেখাচ্ছে
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3">
                {/* Quick Toggle: Show All vs Paginated */}
                <button
                  type="button"
                  onClick={() => {
                    setRowsPerPage(rowsPerPage === 0 ? 15 : 0);
                    setCurrentPage(1);
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200"
                >
                  {rowsPerPage === 0 ? 'পেজ ভিউ (১৫ জন)' : 'সকল শিক্ষার্থী একসাথে (All)'}
                </button>

                {/* Rows per page selector */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 text-[11px]">প্রতি পেজে:</span>
                  <select
                    value={rowsPerPage}
                    onChange={(e) => {
                      setRowsPerPage(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    className="py-1 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-700 cursor-pointer"
                  >
                    <option value={0}>সকল (All)</option>
                    <option value={10}>10</option>
                    <option value={15}>15</option>
                    <option value={30}>30</option>
                    <option value={50}>50</option>
                  </select>
                </div>

                {/* Page Navigation */}
                {rowsPerPage > 0 && totalPages > 1 && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={currentPage <= 1}
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-2 py-1 text-xs font-bold text-slate-800">
                      {toBengaliNum(currentPage)} / {toBengaliNum(totalPages)}
                    </span>
                    <button
                      type="button"
                      disabled={currentPage >= totalPages}
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 2: ADD NEW STUDENT (Clean, Dedicated Form - Section 8)
            ======================================================== */}
        {activeTab === 'add' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200/80 mb-2">
              <h4 className="text-sm font-black text-emerald-950 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-emerald-700" />
                <span>নতুন শিক্ষার্থী অন্তর্ভুক্তি ফর্ম</span>
              </h4>
              <p className="text-xs text-emerald-800 mt-0.5">
                নির্বাচিত ব্যাচ অনুযায়ী স্বয়ংক্রিয়ভাবে সিরিয়াল ও Student ID প্রিফিক্স নির্ধারিত হবে।
              </p>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
                {/* 1. Batch Selection */}
                <div className="sm:col-span-4">
                  <label className="block text-xs font-black text-slate-800 mb-1">
                    ব্যাচ নির্বাচন (Batch) *
                  </label>
                  <select
                    value={newBatchId}
                    onChange={(e) => handleBatchChangeForAdd(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-indigo-300 rounded-xl text-xs font-black text-indigo-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-xs"
                  >
                    {BATCHES.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Roll Number */}
                <div className="sm:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    রোল (Roll) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    placeholder={`সুপারিশকৃত: ${suggestedRoll}`}
                    value={newRoll}
                    onChange={(e) => {
                      setNewRoll(e.target.value === '' ? '' : Number(e.target.value));
                      setHasManuallyEditedAddId(false);
                    }}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* 3. Student Name */}
                <div className="sm:col-span-5">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    শিক্ষার্থীর নাম (Student Name) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="শিক্ষার্থীর পূর্ণ নাম লিখুন..."
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Row 2: Student ID & Duplicate check */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
                <div className="sm:col-span-6">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-black text-indigo-950">
                      User ID / Student ID *
                    </label>
                    <span className="text-[10px] text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded">
                      স্বয়ংক্রিয় জেনারেট
                    </span>
                  </div>
                  <input
                    type="text"
                    required
                    value={newCustomId}
                    onChange={(e) => {
                      setNewCustomId(e.target.value);
                      setHasManuallyEditedAddId(true);
                    }}
                    className="w-full px-3 py-2 bg-white border-2 border-indigo-400 rounded-xl text-xs font-mono font-black text-indigo-950 uppercase tracking-tight shadow-xs"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    নির্দিষ্ট ফরম্যাট: <code className="font-bold text-indigo-700">CP/C-11/B-A 001</code> অথবা{' '}
                    <code className="font-bold text-indigo-700">CP/C-12/B-A 001</code>
                  </p>
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Class</label>
                  <select
                    value={newClass}
                    onChange={(e) => setNewClass(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="XI">XI (একাদশ)</option>
                    <option value="XII">XII (দ্বাদশ)</option>
                  </select>
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Initial Password</label>
                  <input
                    type="text"
                    value={initialPassword}
                    onChange={(e) => setInitialPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Assigned Subjects Checkboxes */}
              <div className="pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-black text-slate-800">
                    অ্যাসাইনকৃত বিষয়সমূহ (Assigned Subjects):
                  </label>
                  <div className="flex items-center gap-2 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setNewAssignedSubjects(allActiveSubjectIds)}
                      className="text-indigo-600 hover:underline font-bold cursor-pointer"
                    >
                      সকল বিষয় সিলেক্ট
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => setNewAssignedSubjects(['ict'])}
                      className="text-slate-500 hover:underline cursor-pointer"
                    >
                      শুধু ICT
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {activeSubjects.map((sub) => {
                    const isChecked = newAssignedSubjects.includes(sub.id);
                    return (
                      <label
                        key={sub.id}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer select-none ${
                          isChecked
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewAssignedSubjects([...newAssignedSubjects, sub.id]);
                            } else {
                              setNewAssignedSubjects(newAssignedSubjects.filter((id) => id !== sub.id));
                            }
                          }}
                          className="sr-only"
                        />
                        <span>{isChecked ? '✓' : '+'}</span>
                        <span>{sub.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('students')}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  বাতিল (Cancel)
                </button>
                <button
                  type="submit"
                  id="add-student-submit-btn"
                  className="px-5 py-2.5 rounded-xl text-xs font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-all cursor-pointer flex items-center gap-2"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>শিক্ষার্থী সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ========================================================
            TAB 3: LOGIN ACCOUNTS (Password Resets & Control)
            ======================================================== */}
        {activeTab === 'accounts' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden p-4 space-y-3">
            <div className="bg-blue-50/70 p-3 rounded-2xl border border-blue-200 flex items-center justify-between text-xs shrink-0">
              <div className="flex items-center gap-2 text-blue-950 font-bold">
                <Shield className="w-4 h-4 text-blue-700" />
                <span>Student Portal Login Accounts ({accounts.length} টি সক্রিয় অ্যাকাউন্ট)</span>
              </div>
              <span className="text-[11px] text-blue-700">ডিফল্ট পাসওয়ার্ড: 123456</span>
            </div>

            {/* ADMIN-ASSISTED RESET PANEL (Requirement 2) */}
            <div className="bg-amber-50/70 p-3 sm:p-3.5 rounded-2xl border border-amber-200/80 space-y-2.5 shrink-0 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-950 font-bold text-xs">
                  <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                    <KeyRound className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="font-black text-slate-900">Admin-assisted Reset (এডমিন সরাসরি পাসওয়ার্ড রিসেট)</span>
                    <span className="hidden sm:inline text-[11px] text-amber-800 font-medium ml-2">
                      (শিক্ষার্থী নির্বাচন করে নতুন পাসওয়ার্ড লিখুন এবং সরাসরি রিসেট করুন)
                    </span>
                  </div>
                </div>
              </div>

              {/* Student Select Dropdown */}
              <div className="pt-1">
                <select
                  id="admin-reset-student-select"
                  value={selectedStudentForReset}
                  onChange={(e) => handleSelectStudentForReset(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">-- শিক্ষার্থী নির্বাচন করুন ({students.length} জন) --</option>
                  {students.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.name} | Roll: {st.roll} | ID: {st.studentIdCode || 'N/A'} ({st.academicClass === 'XII' ? (st.group === 'B-B' ? 'Class 12 B' : 'Class 12 A') : 'Class 11'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Reset Form and Dummy Email Display */}
              {selectedStudentForReset ? (
                (() => {
                  const targetStudent = students.find((s) => s.id === selectedStudentForReset);
                  const dummyEmail = targetStudent ? studentIdToDummyEmail(targetStudent.studentIdCode) : '';
                  return (
                    <div className="space-y-2.5 pt-1 animate-fadeIn">
                      {/* Clearly display the selected student's dummy email */}
                      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 p-2.5 bg-white border border-amber-300/90 rounded-xl shadow-2xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider shrink-0">
                            Student Email:
                          </span>
                          <code className="text-xs sm:text-sm font-mono font-bold text-indigo-700 select-all truncate bg-indigo-50/80 px-2 py-0.5 rounded border border-indigo-100">
                            {dummyEmail}
                          </code>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (dummyEmail) {
                              navigator.clipboard.writeText(dummyEmail);
                              setCopiedId(dummyEmail);
                              setTimeout(() => setCopiedId(null), 2500);
                            }
                          }}
                          className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer shrink-0 shadow-2xs"
                        >
                          {copiedId === dummyEmail ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>কপি হয়েছে!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-500" />
                              <span>ইমেইল কপি</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* New Password Input & Reset Password Button */}
                      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-0.5">
                        <div className="flex-1 relative">
                          <input
                            type="text"
                            id="admin-reset-password-input"
                            value={resetNewPassword}
                            onChange={(e) => setResetNewPassword(e.target.value)}
                            placeholder="নতুন পাসওয়ার্ড লিখুন (New Password)"
                            className="w-full pl-3 pr-16 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500 shadow-2xs"
                          />
                          <button
                            type="button"
                            onClick={() => setResetNewPassword('123456')}
                            className="absolute inset-y-1 right-1 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-bold transition-colors cursor-pointer"
                            title="ডিফল্ট পাসওয়ার্ড 123456 লিখুন"
                          >
                            123456
                          </button>
                        </div>

                        <button
                          type="button"
                          id="admin-reset-password-submit-btn"
                          disabled={isResettingPass || !resetNewPassword.trim()}
                          onClick={handleAdminResetPassword}
                          className="px-4 py-2 rounded-xl text-xs font-black bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-950 transition-all cursor-pointer shadow-2xs flex items-center justify-center gap-1.5 shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                          <span>{isResettingPass ? 'রিসেট হচ্ছে...' : 'পাসওয়ার্ড রিসেট করুন'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="p-2.5 bg-amber-100/50 border border-dashed border-amber-300/80 rounded-xl text-xs text-amber-900 font-medium text-center">
                  পাসওয়ার্ড রিসেট করতে উপরের ড্রপডাউন থেকে একজন শিক্ষার্থী নির্বাচন করুন
                </div>
              )}
            </div>

            <div className="student-list-container flex-1 min-h-0 overflow-y-auto border border-slate-200 rounded-2xl bg-white shadow-inner overscroll-contain">
              <table className="w-full text-left text-xs border-collapse min-w-[650px]">
                <thead className="sticky top-0 z-10 bg-slate-100 border-b border-slate-200 text-[11px] font-black text-slate-700 uppercase">
                  <tr>
                    <th className="py-2.5 px-3">শিক্ষার্থীর নাম</th>
                    <th className="py-2.5 px-3">Login User ID</th>
                    <th className="py-2.5 px-3 text-center">স্ট্যাটাস</th>
                    <th className="py-2.5 px-3 text-center">সর্বশেষ লগইন</th>
                    <th className="py-2.5 px-3 text-right">পাসওয়ার্ড অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.map((student) => {
                    const acc = accounts.find((a) => a.studentId === student.id);
                    const isAct = acc?.status !== 'inactive';

                    return (
                      <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-3 font-bold text-slate-900">
                          {student.name} <span className="text-slate-400 font-normal">({student.roll})</span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-indigo-700">
                          {student.studentIdCode}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleStudentActive(student.id)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                              isAct ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                            }`}
                          >
                            {isAct ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Deactivated)'}
                          </button>
                        </td>
                        <td className="py-2.5 px-3 text-center text-slate-500 text-[11px]">
                          {acc?.lastLoginAt ? new Date(acc.lastLoginAt).toLocaleDateString('bn-BD') : '—'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleSelectStudentForReset(student.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition-colors cursor-pointer"
                          >
                            <KeyRound className="w-3 h-3 text-amber-700" />
                            <span>Reset Pass</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="h-6" />
            </div>
          </div>
        )}

        {/* ========================================================
            MODAL: EDIT STUDENT (Section 9 - Safe editing with locked ID)
            ======================================================== */}
        {editingStudent && (
          <div
            className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
            onClick={() => setEditingStudent(null)}
          >
            <div
              className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                    <Pencil className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-slate-900">শিক্ষার্থী তথ্য সংশোধন (Edit Student)</h4>
                    <span className="text-[11px] text-slate-500 font-mono font-bold">
                      Internal ID: {editingStudent.id} (অপরিবর্তনীয়)
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3.5 text-xs">
                {/* Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">শিক্ষার্থীর নাম *</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* Student ID with Lock Toggle (Section 9 Requirement) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                      <span>User ID / Student ID *</span>
                      {isEditIdLocked ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 text-[10px] font-bold">
                          <Lock className="w-2.5 h-2.5" /> লক করা
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 text-[10px] font-bold border border-rose-200">
                          <Unlock className="w-2.5 h-2.5" /> আনলক করা হয়েছে
                        </span>
                      )}
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsEditIdLocked(!isEditIdLocked)}
                      className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                    >
                      {isEditIdLocked ? 'আইডি আনলক করুন' : 'লক করুন'}
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    disabled={isEditIdLocked}
                    value={editStudentId}
                    onChange={(e) => setEditStudentId(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs font-mono font-black uppercase transition-all ${
                      isEditIdLocked
                        ? 'bg-slate-100 text-slate-500 border border-slate-300 cursor-not-allowed select-none'
                        : 'bg-white text-indigo-950 border-2 border-indigo-500 focus:outline-hidden focus:ring-2 focus:ring-indigo-500'
                    }`}
                  />
                  {!isEditIdLocked && (
                    <p className="text-[10px] text-rose-600 font-semibold mt-1">
                      ⚠️ সতর্কতা: User ID পরিবর্তন করলে শিক্ষার্থীর লগইন ক্রেডেনশিয়াল আপডেট হবে। পূর্বের পরীক্ষার ফলাফল অক্ষুণ্ণ থাকবে।
                    </p>
                  )}
                </div>

                {/* Roll & Batch */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">রোল (Roll)</label>
                    <input
                      type="number"
                      min="1"
                      value={editRoll}
                      onChange={(e) => setEditRoll(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">ব্যাচ (Batch)</label>
                    <select
                      value={editBatchId}
                      onChange={(e) => setEditBatchId(e.target.value)}
                      className="w-full px-2 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 cursor-pointer"
                    >
                      {BATCHES.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Edit Reason (Optional) */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">পরিবর্তনের কারণ (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. বানান সংশোধন / রোল আপডেট"
                    value={editReason}
                    onChange={(e) => setEditReason(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSaveEdit}
                  className="px-5 py-2 rounded-xl text-xs font-black bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>সংরক্ষণ করুন</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            MODAL: VIEW STUDENT DETAILS QUICK VIEW
            ======================================================== */}
        {viewingStudent && (
          <div
            className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setViewingStudent(null)}
          >
            <div
              className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 font-black text-sm flex items-center justify-center border border-indigo-100 shadow-2xs">
                    {toBengaliNum(viewingStudent.roll)}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-slate-900">{viewingStudent.name}</h4>
                    <span className="text-xs text-slate-500 font-mono font-bold">{viewingStudent.studentIdCode}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setViewingStudent(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">ব্যাচ (Batch):</span>
                  <strong className="text-slate-900">
                    {getBatchById(viewingStudent.batchId || (viewingStudent.academicClass === 'XII' ? (viewingStudent.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a')).name}
                  </strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">রোল (Roll):</span>
                  <strong className="text-slate-900">{viewingStudent.roll}</strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">ইউজার আইডি (User ID):</span>
                  <strong className="font-mono text-indigo-700">{viewingStudent.studentIdCode}</strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">অভ্যন্তরীণ আইডি (Internal ID):</span>
                  <span className="font-mono text-slate-600 font-bold bg-slate-100 px-2 py-0.5 rounded">
                    {viewingStudent.id} (অপরিবর্তনীয়)
                  </span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">সেশন (Session):</span>
                  <strong className="text-slate-900">{viewingStudent.session || '2026'}</strong>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">লগইন অ্যাকাউন্ট স্ট্যাটাস:</span>
                  {(() => {
                    const acc = accounts.find((a) => a.studentId === viewingStudent.id);
                    const isAct = acc?.status !== 'inactive';
                    return (
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${isAct ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'}`}>
                        {isAct ? 'সক্রিয় (Active)' : 'নিষ্ক্রিয় (Deactivated)'}
                      </span>
                    );
                  })()}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const s = viewingStudent;
                    setViewingStudent(null);
                    handleStartEdit(s);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  <span>এডিট করুন</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewingStudent(null)}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  বন্ধ
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            MODAL: DELETE STUDENT CONFIRMATION
            ======================================================== */}
        {studentToDelete && (
          <div
            className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setStudentToDelete(null)}
          >
            <div
              className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-3 animate-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
                <Trash2 className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-black text-slate-900">শিক্ষার্থী অপসারণ করতে চান?</h4>
              <p className="text-xs text-slate-500">
                আপনি কি নিশ্চিত যে <strong>&quot;{studentToDelete.name}&quot;</strong> (ID: {studentToDelete.studentIdCode})-কে তালিকা থেকে অপসারিত করতে চান?
              </p>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStudentToDelete(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  না, বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer"
                >
                  হ্যাঁ, মুছে ফেলুন
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            MODAL: DATABASE AUDIT & VERIFICATION REPORT
            ======================================================== */}
        <AuditReportModal
          isOpen={isAuditReportOpen}
          onClose={() => setIsAuditReportOpen(false)}
          students={students}
          exams={exams}
          onRefreshDatabase={onRefreshDatabase}
        />
      </div>
    </div>
  );
}
