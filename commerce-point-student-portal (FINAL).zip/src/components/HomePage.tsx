import { Users, FileCheck2, Calendar, Award, PlusCircle, ArrowRight, TrendingUp, UserPlus, KeyRound, BookOpen, GraduationCap, Shield } from 'lucide-react';
import { Exam, NavPage, Student, Subject, getBatchById } from '../types';
import { toBengaliNum } from '../data/initialData';
import { SubjectNav } from './SubjectNav';

interface HomePageProps {
  exams: Exam[];
  students: Student[];
  subjects?: Subject[];
  activeSubjectId?: string;
  activeBatchId?: string;
  onSelectBatch?: (batchId: string) => void;
  studentsCountByBatch?: Record<string, number>;
  allExamsForCounts?: Exam[];
  isAdmin?: boolean;
  onSelectSubject?: (subjectId: string) => void;
  onManageSubjects?: () => void;
  onNavigate: (page: NavPage) => void;
  onSelectExam: (exam: Exam) => void;
  onManageStudents: () => void;
  onOpenStaffManagement?: () => void;
  onOpenAdminAccount?: () => void;
}

export function HomePage({
  exams,
  students,
  subjects,
  activeSubjectId = 'ict',
  activeBatchId = 'class-11-a',
  onSelectBatch,
  studentsCountByBatch = {},
  allExamsForCounts = [],
  isAdmin = true,
  onSelectSubject,
  onManageSubjects,
  onNavigate,
  onSelectExam,
  onManageStudents,
  onOpenStaffManagement,
  onOpenAdminAccount,
}: HomePageProps) {
  // Active batch object
  const activeBatch = getBatchById(activeBatchId);

  // Sort exams by date descending for latest exam info
  const sortedExams = [...exams].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const totalStudents = students.length;
  const totalExams = exams.length;
  const latestExam = sortedExams.length > 0 ? sortedExams[0] : null;

  const currentSubject = subjects?.find((s) => s.id === activeSubjectId) || {
    id: 'ict',
    name: 'ICT',
    code: 'ICT-101',
    isActive: true,
    order: 1,
  };

  // Exam counts by subject for the pill badges
  const examCountsBySubject = (allExamsForCounts.length > 0 ? allExamsForCounts : exams).reduce(
    (acc, exam) => {
      const subId = exam.subjectId || 'ict';
      acc[subId] = (acc[subId] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );

  return (
    <div id="page-home" className="space-y-4 sm:space-y-5 pb-6">
      {/* Subject Navigation Bar */}
      {subjects && subjects.length > 0 && onSelectSubject && (
        <SubjectNav
          subjects={subjects}
          activeSubjectId={activeSubjectId}
          onSelectSubject={onSelectSubject}
          isAdmin={isAdmin}
          onOpenManageSubjects={onManageSubjects}
          examCountsBySubject={examCountsBySubject}
        />
      )}

      {/* Welcome Banner */}
      <div className="bg-gradient-to-br from-indigo-700 via-indigo-800 to-blue-950 text-white rounded-2xl p-5 sm:p-6 lg:p-7 shadow-md relative overflow-hidden border border-indigo-500/30">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 mb-2.5">
              {/* Borderless crisp logo in banner */}
              <img
                src="/commerce-point-logo.svg"
                alt="COMMERCE POINT Logo"
                className="w-10 h-10 sm:w-12 sm:h-12 object-contain shrink-0 drop-shadow-sm select-none"
                referrerPolicy="no-referrer"
              />

              {/* Active Batch Badge in Banner (Display only; selection is exclusively in Header) */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs sm:text-sm font-black bg-white/20 text-white shadow-xs border border-white/30 backdrop-blur-xs">
                <GraduationCap className="w-3.5 h-3.5 text-amber-300" />
                <span>{activeBatch.name}</span>
              </div>

              {/* Subject Pill in Banner */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs sm:text-sm font-black bg-amber-400 text-slate-950 shadow-xs border border-amber-300">
                <span>📚 বিষয়:</span>
                <span className="text-sm sm:text-base font-black tracking-tight">{currentSubject.name}</span>
              </div>

              <span className="text-xs font-semibold text-indigo-200 hidden sm:inline">
                শিক্ষক ড্যাশবোর্ড
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight flex flex-wrap items-center gap-2 mt-1">
              <span className="text-amber-300">{currentSubject.name}</span>
              <span>Student Progress</span>
            </h2>
            <p className="text-indigo-100 text-sm sm:text-base mt-1 max-w-xl font-medium">
              <strong className="text-white font-extrabold">{activeBatch.name}</strong>-এর {toBengaliNum(totalStudents)} জন শিক্ষার্থীর <strong className="text-amber-300 font-black">{currentSubject.name}</strong> বিষয়ের পরীক্ষার নম্বর সংরক্ষণ ও অগ্রগতির সহজ হিসাব।
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 items-center shrink-0">
            <button
              type="button"
              id="home-action-new-exam-btn"
              onClick={() => onNavigate('entry')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-indigo-700 font-bold text-sm shadow-xs hover:bg-indigo-50 transition-colors cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              নতুন নম্বর এন্ট্রি
            </button>
            <button
              type="button"
              id="home-action-monthly-btn"
              onClick={() => onNavigate('monthly')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold text-sm shadow-xs transition-colors cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-slate-900" />
              📅 মাসিক ফলাফল
            </button>
            <button
              type="button"
              id="home-action-progress-btn"
              onClick={() => onNavigate('progress')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-500/30 text-white font-medium text-sm hover:bg-indigo-500/50 transition-colors border border-white/20 cursor-pointer"
            >
              <TrendingUp className="w-4 h-4" />
              শিক্ষার্থীর অগ্রগতি
            </button>
            <button
              type="button"
              id="home-action-manage-students-btn"
              onClick={onManageStudents}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-indigo-500/30 text-white font-medium text-sm hover:bg-indigo-500/50 transition-colors border border-white/20 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              শিক্ষার্থী যোগ/বাদ
            </button>
            {onOpenStaffManagement && (
              <button
                type="button"
                id="home-action-manage-staff-btn"
                onClick={onOpenStaffManagement}
                className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-indigo-500/30 text-white font-medium text-sm hover:bg-indigo-500/50 transition-colors border border-white/20 cursor-pointer"
                title="স্টাফ ও অপারেটর ব্যবস্থাপনা"
              >
                <Shield className="w-4 h-4 text-amber-200" />
                স্টাফ ব্যবস্থাপনা
              </button>
            )}
            {onOpenAdminAccount && (
              <button
                type="button"
                id="home-action-admin-account-btn"
                onClick={onOpenAdminAccount}
                className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-amber-500/30 hover:bg-amber-500/50 text-white font-medium text-sm transition-colors border border-amber-300/30 cursor-pointer"
                title="এডমিন পাসওয়ার্ড পরিবর্তন ও অ্যাকাউন্ট সেটিংস"
              >
                <KeyRound className="w-4 h-4 text-amber-200" />
                পাসওয়ার্ড ও অ্যাকাউন্ট
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Primary 4 Required KPI Cards in 2x2 Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4 lg:gap-5">
        {/* Total Students */}
        <div
          id="stat-card-total-students"
          onClick={onManageStudents}
          className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs flex flex-col justify-between hover:border-indigo-300 cursor-pointer transition-colors group"
          title="শিক্ষার্থী যোগ বা বাদ দিতে ক্লিক করুন"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600 group-hover:text-indigo-600 transition-colors">
              মোট শিক্ষার্থী
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">
              {toBengaliNum(totalStudents)}
            </div>
            <p className="text-xs text-indigo-600 font-semibold mt-0.5 flex items-center gap-1">
              <span>যোগ / বাদ দিন</span>
              <ArrowRight className="w-3 h-3" />
            </p>
          </div>
        </div>

        {/* Total Exams */}
        <div
          id="stat-card-total-exams"
          onClick={() => onNavigate('results')}
          className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs flex flex-col justify-between hover:border-indigo-300 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600">মোট পরীক্ষা</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {toBengaliNum(totalExams)}
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">সংরক্ষিত পরীক্ষার সংখ্যা</p>
          </div>
        </div>

        {/* Latest Exam */}
        <div
          id="stat-card-latest-exam"
          onClick={() => latestExam && onSelectExam(latestExam)}
          className={`bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs flex flex-col justify-between ${
            latestExam ? 'hover:border-emerald-300 cursor-pointer' : ''
          } transition-colors`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600">সর্বশেষ পরীক্ষা</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div>
            {latestExam ? (
              <>
                <div className="text-base sm:text-lg font-bold text-slate-900 truncate" title={latestExam.name}>
                  {latestExam.name}
                </div>
                <p className="text-xs text-emerald-700 font-semibold mt-0.5">
                  তারিখ: {latestExam.date}
                </p>
              </>
            ) : (
              <div className="text-sm text-slate-400 font-medium">কোনো পরীক্ষা নেই</div>
            )}
          </div>
        </div>

        {/* Latest Exam Average */}
        <div
          id="stat-card-latest-avg"
          className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600">সর্বশেষ গড় নম্বর</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div>
            {latestExam ? (
              <>
                <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  {toBengaliNum(latestExam.average)}
                  <span className="text-xs font-normal text-slate-400 ml-1">
                    /{toBengaliNum(latestExam.totalFullMarks)}
                  </span>
                </div>
                <p className="text-xs text-amber-700 font-semibold mt-0.5">
                  গড় শতকরা: {toBengaliNum(latestExam.averagePercentage)}%
                </p>
              </>
            ) : (
              <div className="text-sm text-slate-400 font-medium">-</div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Exams Section */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between mb-3.5">
          <div>
            <h3 className="text-base font-bold text-slate-900">সাম্প্রতিক পরীক্ষা</h3>
            <p className="text-xs text-slate-500">ফলাফল দেখতে পরীক্ষায় চাপ দিন</p>
          </div>
          {exams.length > 0 && (
            <button
              type="button"
              id="home-view-all-results-link"
              onClick={() => onNavigate('results')}
              className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
            >
              সবগুলো দেখুন
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {sortedExams.length === 0 ? (
          <div className="py-8 text-center text-slate-400">
            <p className="text-sm">এখনো কোনো পরীক্ষা যোগ করা হয়নি।</p>
            <button
              type="button"
              onClick={() => onNavigate('entry')}
              className="mt-3 px-4 py-2 rounded-xl bg-indigo-50 text-indigo-600 font-medium text-xs hover:bg-indigo-100 transition-colors"
            >
              প্রথম পরীক্ষা যোগ করুন
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sortedExams.slice(0, 4).map((exam) => (
              <div
                key={exam.id}
                onClick={() => onSelectExam(exam)}
                className="py-3 px-2 flex items-center justify-between hover:bg-slate-50 rounded-xl cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="min-w-[60px] h-10 px-2.5 rounded-xl bg-gradient-to-r from-blue-950 to-indigo-950 text-amber-300 border border-blue-800 flex items-center justify-center font-black text-xs sm:text-sm shadow-xs shrink-0 tracking-tight"
                    title={currentSubject.name}
                  >
                    {currentSubject.name}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900 leading-tight">
                      {exam.name}
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      তারিখ: {exam.date} • পূর্ণমান: {toBengaliNum(exam.totalFullMarks)}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-bold text-indigo-600">
                    গড়: {toBengaliNum(exam.average)}
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-600">
                    {toBengaliNum(exam.averagePercentage)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
