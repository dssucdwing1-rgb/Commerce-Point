import React, { useState, useEffect, useMemo } from 'react';
import { Save, Calendar, FileText, CheckCircle2, AlertCircle, RotateCcw, BookOpen } from 'lucide-react';
import { Exam, Student, StudentMarkEntry, Subject } from '../types';
import {
  calculateGrade,
  getGradeBadgeColor,
  toBengaliNum,
} from '../data/initialData';

interface ExamEntryPageProps {
  editingExam?: Exam | null;
  students: Student[];
  currentSubject?: Subject;
  onSaveExam: (exam: Exam) => void;
  onCancelEdit?: () => void;
}

export function ExamEntryPage({
  editingExam,
  students,
  currentSubject,
  onSaveExam,
  onCancelEdit,
}: ExamEntryPageProps) {
  // Filter students enrolled in currentSubject
  const enrolledStudents = useMemo(() => {
    return students.filter((s) => {
      if (!currentSubject) return true;
      if (!s.assignedSubjectIds || s.assignedSubjectIds.length === 0) return true;
      return s.assignedSubjectIds.includes(currentSubject.id);
    });
  }, [students, currentSubject]);

  const studentsToDisplay = useMemo(() => {
    return enrolledStudents.length > 0 ? enrolledStudents : students;
  }, [enrolledStudents, students]);

  // Top fields
  const [examDate, setExamDate] = useState<string>(
    editingExam ? editingExam.date : new Date().toISOString().split('T')[0]
  );
  const [examName, setExamName] = useState<string>(editingExam ? editingExam.name : '');
  const [cqFullMarks, setCqFullMarks] = useState<number>(
    editingExam ? editingExam.cqFullMarks : 70
  );
  const [mcqFullMarks, setMcqFullMarks] = useState<number>(
    editingExam ? editingExam.mcqFullMarks : 30
  );

  // Student marks state: { [studentId]: { cq: number | ''; mcq: number | '' } }
  const [marks, setMarks] = useState<Record<string, { cq: number | ''; mcq: number | '' }>>(() => {
    const initialMarks: Record<string, { cq: number | ''; mcq: number | '' }> = {};
    if (editingExam) {
      studentsToDisplay.forEach((student) => {
        const entry = editingExam.marks[student.id];
        initialMarks[student.id] = {
          cq: entry !== undefined && entry.cq !== undefined ? entry.cq : '',
          mcq: entry !== undefined && entry.mcq !== undefined ? entry.mcq : '',
        };
      });
    } else {
      studentsToDisplay.forEach((student) => {
        initialMarks[student.id] = { cq: '', mcq: '' };
      });
    }
    return initialMarks;
  });

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Ensure students are sorted by roll
  const sortedStudents = useMemo(() => {
    return [...studentsToDisplay].sort((a, b) => a.roll - b.roll);
  }, [studentsToDisplay]);

  // Track editingExamId to avoid infinite loop when studentsToDisplay or internal marks update
  const editingExamId = editingExam ? editingExam.id : '__NEW_EXAM__';

  // Initialize or re-populate only when editingExam changes
  useEffect(() => {
    if (editingExam) {
      setExamDate(editingExam.date);
      setExamName(editingExam.name);
      setCqFullMarks(editingExam.cqFullMarks);
      setMcqFullMarks(editingExam.mcqFullMarks);

      const initialMarks: Record<string, { cq: number | ''; mcq: number | '' }> = {};
      studentsToDisplay.forEach((student) => {
        const entry = editingExam.marks[student.id];
        initialMarks[student.id] = {
          cq: entry !== undefined && entry.cq !== undefined ? entry.cq : '',
          mcq: entry !== undefined && entry.mcq !== undefined ? entry.mcq : '',
        };
      });
      setMarks(initialMarks);
    } else {
      // Clear form for fresh entry
      const initialMarks: Record<string, { cq: number | ''; mcq: number | '' }> = {};
      studentsToDisplay.forEach((student) => {
        initialMarks[student.id] = { cq: '', mcq: '' };
      });
      setMarks(initialMarks);
      setExamName('');
      setExamDate(new Date().toISOString().split('T')[0]);
    }
  }, [editingExamId]);

  const totalFullMarks = (Number(cqFullMarks) || 0) + (Number(mcqFullMarks) || 0);

  // Handle CQ/MCQ change
  const handleMarkChange = (
    studentId: string,
    field: 'cq' | 'mcq',
    valueStr: string
  ) => {
    let val: number | '' = '';
    if (valueStr.trim() !== '') {
      const num = Number(valueStr);
      if (!isNaN(num) && num >= 0) {
        val = num;
      } else {
        return;
      }
    }

    setMarks((prev) => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || { cq: '', mcq: '' }),
        [field]: val,
      },
    }));
  };

  // Quick fill all with a zero or clear
  const handleClearMarks = () => {
    const empty: Record<string, { cq: number | ''; mcq: number | '' }> = {};
    students.forEach((s) => {
      empty[s.id] = { cq: '', mcq: '' };
    });
    setMarks(empty);
  };

  // Submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!examName.trim()) {
      setErrorMessage('অনুগ্রহ করে পরীক্ষার নাম লিখুন (যেমন: Chapter 1 / অধ্যায় ১)');
      return;
    }

    if (totalFullMarks <= 0) {
      setErrorMessage('CQ এবং MCQ এর পূর্ণমান ০ এর বেশি হতে হবে।');
      return;
    }

    const calculatedMarks: Record<string, StudentMarkEntry> = {};
    let totalScoreSum = 0;
    let studentsWithMarksCount = 0;

    studentsToDisplay.forEach((student) => {
      const current = marks[student.id] || { cq: '', mcq: '' };
      const cqNum = current.cq === '' ? 0 : Number(current.cq);
      const mcqNum = current.mcq === '' ? 0 : Number(current.mcq);
      const studentTotal = cqNum + mcqNum;
      const percentage = Math.round((studentTotal / totalFullMarks) * 100);
      const grade = calculateGrade(percentage);

      if (current.cq !== '' || current.mcq !== '') {
        studentsWithMarksCount++;
      }

      calculatedMarks[student.id] = {
        studentId: student.id,
        studentName: student.name,
        cq: current.cq,
        mcq: current.mcq,
        total: studentTotal,
        percentage,
        grade,
      };

      totalScoreSum += studentTotal;
    });

    const studentCount = studentsToDisplay.length || 1;
    const average = Number((totalScoreSum / studentCount).toFixed(1));
    const averagePercentage = Math.round((average / totalFullMarks) * 100);

    const targetSubjectId = editingExam
      ? (editingExam.subjectId || currentSubject?.id || 'ict')
      : (currentSubject?.id || 'ict');

    const newExam: Exam = {
      id: editingExam ? editingExam.id : `exam-${Date.now()}`,
      subjectId: targetSubjectId,
      date: examDate,
      name: examName.trim(),
      cqFullMarks: Number(cqFullMarks) || 0,
      mcqFullMarks: Number(mcqFullMarks) || 0,
      totalFullMarks,
      marks: calculatedMarks,
      average,
      averagePercentage,
      createdAt: editingExam ? editingExam.createdAt : Date.now(),
    };

    onSaveExam(newExam);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
    }, 2500);
  };

  return (
    <div id="page-exam-entry" className="space-y-5 pb-8">
      {/* Subject Context Header Banner */}
      {currentSubject && (
        <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white px-4 py-2.5 rounded-2xl text-xs font-bold shadow-xs border border-indigo-500/30">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-amber-300" />
            <span className="text-indigo-200">বর্তমান বিষয়:</span>
            <span className="inline-block px-3 py-1 rounded-xl bg-amber-400 text-slate-950 text-sm sm:text-base font-black shadow-xs tracking-tight">
              {currentSubject.name}
            </span>
            <span className="text-indigo-300 font-semibold hidden sm:inline text-xs">({currentSubject.code})</span>
          </div>
          <span className="text-xs text-indigo-200 font-semibold bg-white/10 px-2.5 py-1 rounded-lg">
            তালিকাভুক্ত শিক্ষার্থী: <strong className="text-white font-extrabold">{toBengaliNum(studentsToDisplay.length)}</strong> জন
          </span>
        </div>
      )}

      {/* Title & Editing Status */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            {editingExam ? 'পরীক্ষা সম্পাদনা (Edit Exam)' : 'নতুন পরীক্ষার নম্বর এন্ট্রি'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            শিক্ষার্থীদের CQ এবং MCQ নম্বর প্রবেশ করান। মোট ও গ্রেড স্বয়ংক্রিয়ভাবে হিসাব হবে।
          </p>
        </div>

        {editingExam && onCancelEdit && (
          <button
            type="button"
            id="cancel-edit-exam-btn"
            onClick={onCancelEdit}
            className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100 transition-colors font-medium"
          >
            বাতিল করুন
          </button>
        )}
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2.5 text-sm font-semibold animate-fade-in shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>পরীক্ষার ফলাফল সফলভাবে সংরক্ষিত হয়েছে!</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2.5 text-sm font-semibold shadow-xs">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Top Configuration Card */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Exam Date */}
            <div>
              <label
                htmlFor="exam-date-input"
                className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5"
              >
                Exam Date (তারিখ)
              </label>
              <div className="relative">
                <input
                  type="date"
                  id="exam-date-input"
                  required
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                />
              </div>
            </div>

            {/* Exam Name */}
            <div>
              <label
                htmlFor="exam-name-input"
                className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5"
              >
                Exam Name (পরীক্ষার নাম)
              </label>
              <input
                type="text"
                id="exam-name-input"
                placeholder="যেমন: Chapter 1 / অধ্যায় ১ / Model Test"
                required
                value={examName}
                onChange={(e) => setExamName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Full Marks Configuration */}
          <div className="pt-3 border-t border-slate-100 grid grid-cols-3 gap-3">
            <div>
              <label
                htmlFor="cq-full-marks-input"
                className="block text-xs font-bold text-slate-600 mb-1"
              >
                CQ Full Marks
              </label>
              <input
                type="number"
                id="cq-full-marks-input"
                min="1"
                max="100"
                value={cqFullMarks}
                onChange={(e) => setCqFullMarks(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>

            <div>
              <label
                htmlFor="mcq-full-marks-input"
                className="block text-xs font-bold text-slate-600 mb-1"
              >
                MCQ Full Marks
              </label>
              <input
                type="number"
                id="mcq-full-marks-input"
                min="0"
                max="100"
                value={mcqFullMarks}
                onChange={(e) => setMcqFullMarks(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                সর্বমোট পূর্ণমান
              </label>
              <div className="w-full px-3 py-2 bg-indigo-50/70 border border-indigo-200 rounded-xl text-indigo-700 text-sm font-bold text-center">
                {toBengaliNum(totalFullMarks)}
              </div>
            </div>
          </div>
        </div>

        {/* Students Mark Entry Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-3.5 sm:p-4 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-800">
                {toBengaliNum(sortedStudents.length)} জন শিক্ষার্থীর নম্বর তালিকা
              </span>
              <span className="text-xs text-slate-500">
                (কেবল CQ ও MCQ লিখুন)
              </span>
            </div>
            <button
              type="button"
              onClick={handleClearMarks}
              className="text-xs text-slate-500 hover:text-rose-600 font-medium transition-colors"
            >
              সব খালি করুন
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm" id="marks-entry-table">
              <thead className="bg-slate-100/90 text-slate-700 text-xs font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-3 w-12 text-center">রোল</th>
                  <th className="py-2.5 px-3 min-w-[140px]">Student Name</th>
                  <th className="py-2.5 px-2 w-24 text-center">
                    CQ <span className="text-[10px] text-slate-500 font-normal">({cqFullMarks})</span>
                  </th>
                  <th className="py-2.5 px-2 w-24 text-center">
                    MCQ <span className="text-[10px] text-slate-500 font-normal">({mcqFullMarks})</span>
                  </th>
                  <th className="py-2.5 px-2 w-20 text-center">Total</th>
                  <th className="py-2.5 px-2 w-16 text-center">%</th>
                  <th className="py-2.5 px-3 w-20 text-center">Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedStudents.map((student) => {
                  const studentMark = marks[student.id] || { cq: '', mcq: '' };
                  const cqNum = studentMark.cq === '' ? 0 : Number(studentMark.cq);
                  const mcqNum = studentMark.mcq === '' ? 0 : Number(studentMark.mcq);
                  const total = cqNum + mcqNum;
                  const percentage = totalFullMarks > 0 ? Math.round((total / totalFullMarks) * 100) : 0;
                  const grade = calculateGrade(percentage);
                  const gradeBadge = getGradeBadgeColor(grade);

                  const cqOver = cqFullMarks > 0 && cqNum > cqFullMarks;
                  const mcqOver = mcqFullMarks > 0 && mcqNum > mcqFullMarks;

                  return (
                    <tr
                      key={student.id}
                      className="hover:bg-slate-50/70 transition-colors"
                    >
                      {/* Roll */}
                      <td className="py-2 px-3 text-center text-xs font-semibold text-slate-400">
                        {toBengaliNum(student.roll)}
                      </td>

                      {/* Student Name */}
                      <td className="py-2 px-3 font-semibold text-slate-900 whitespace-nowrap">
                        {student.name}
                      </td>

                      {/* CQ Input */}
                      <td className="py-1.5 px-2 text-center">
                        <input
                          type="number"
                          id={`cq-input-${student.id}`}
                          min="0"
                          max={cqFullMarks}
                          placeholder="0"
                          value={studentMark.cq}
                          onChange={(e) =>
                            handleMarkChange(student.id, 'cq', e.target.value)
                          }
                          className={`w-20 px-2 py-1.5 text-center text-sm font-semibold rounded-lg border ${
                            cqOver
                              ? 'border-rose-400 bg-rose-50 text-rose-700 ring-1 ring-rose-400'
                              : 'border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200'
                          } transition-all`}
                        />
                      </td>

                      {/* MCQ Input */}
                      <td className="py-1.5 px-2 text-center">
                        <input
                          type="number"
                          id={`mcq-input-${student.id}`}
                          min="0"
                          max={mcqFullMarks}
                          placeholder="0"
                          value={studentMark.mcq}
                          onChange={(e) =>
                            handleMarkChange(student.id, 'mcq', e.target.value)
                          }
                          className={`w-20 px-2 py-1.5 text-center text-sm font-semibold rounded-lg border ${
                            mcqOver
                              ? 'border-rose-400 bg-rose-50 text-rose-700 ring-1 ring-rose-400'
                              : 'border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200'
                          } transition-all`}
                        />
                      </td>

                      {/* Total = CQ + MCQ */}
                      <td className="py-2 px-2 text-center font-bold text-slate-900 text-sm">
                        {toBengaliNum(total)}
                      </td>

                      {/* Percentage */}
                      <td className="py-2 px-2 text-center text-xs font-semibold text-slate-600">
                        {toBengaliNum(percentage)}%
                      </td>

                      {/* Grade */}
                      <td className="py-2 px-3 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 text-xs font-bold rounded-md border ${gradeBadge.bg} ${gradeBadge.text} ${gradeBadge.border}`}
                        >
                          {grade}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Large SAVE EXAM Button */}
        <div className="pt-2">
          <button
            type="submit"
            id="save-exam-btn"
            className="w-full py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-extrabold text-base sm:text-lg flex items-center justify-center gap-2.5 shadow-lg shadow-indigo-600/25 transition-all transform active:scale-[0.99] cursor-pointer"
          >
            <Save className="w-5 h-5 sm:w-6 sm:h-6" />
            <span>SAVE EXAM (পরীক্ষা সংরক্ষণ করুন)</span>
          </button>
        </div>
      </form>
    </div>
  );
}
