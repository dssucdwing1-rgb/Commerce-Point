import React from 'react';
import { Plus, BookOpen, Layers } from 'lucide-react';
import { Subject } from '../types';

interface SubjectNavProps {
  subjects: Subject[];
  activeSubjectId: string;
  onSelectSubject: (subjectId: string) => void;
  isAdmin?: boolean;
  onOpenManageSubjects?: () => void;
  examCountsBySubject?: Record<string, number>;
}

export const SubjectNav: React.FC<SubjectNavProps> = ({
  subjects,
  activeSubjectId,
  onSelectSubject,
  isAdmin = false,
  onOpenManageSubjects,
  examCountsBySubject = {},
}) => {
  const activeSubjects = subjects.filter((s) => s.isActive);

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-2 sm:p-2.5 lg:p-3 shadow-xs" id="subject-navigation-bar">
      <div className="w-full flex flex-col md:flex-row md:items-center md:justify-between gap-2.5">
        {/* Subject pills list: horizontal swipe on mobile, flex-wrap without scrollbar on desktop */}
        <div className="w-full flex items-center gap-1.5 sm:gap-2 overflow-x-auto md:overflow-x-visible md:flex-wrap no-scrollbar py-0.5">
          <div className="flex items-center gap-1.5 text-xs sm:text-sm font-black text-indigo-900 bg-indigo-50 border border-indigo-200 px-2.5 sm:px-3 py-1.5 rounded-xl uppercase tracking-wider shrink-0 shadow-2xs">
            <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-700" />
            <span className="whitespace-nowrap">বিষয়:</span>
          </div>

          {activeSubjects.map((sub) => {
            const isActive = sub.id === activeSubjectId;
            const count = examCountsBySubject[sub.id] || 0;

            return (
              <button
                key={sub.id}
                type="button"
                id={`subject-tab-${sub.id}`}
                onClick={() => onSelectSubject(sub.id)}
                className={`group relative inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-3.5 lg:px-4 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm lg:text-base font-black transition-all cursor-pointer select-none shrink-0 ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-amber-300 shadow-md ring-2 ring-indigo-500 scale-102 border border-amber-400/30'
                    : 'bg-white text-slate-800 hover:bg-slate-100 hover:text-indigo-950 border-2 border-slate-200 hover:border-indigo-300 shadow-2xs'
                }`}
              >
                <span className="tracking-tight whitespace-nowrap">{sub.name}</span>
                {count > 0 && (
                  <span
                    className={`inline-flex items-center justify-center min-w-[18px] sm:min-w-[20px] h-4.5 sm:h-5 px-1 sm:px-1.5 rounded-full text-[10px] sm:text-xs font-black ${
                      isActive
                        ? 'bg-amber-400 text-slate-950 shadow-2xs'
                        : 'bg-slate-200 text-slate-700 group-hover:bg-indigo-100 group-hover:text-indigo-900'
                    }`}
                    title={`${count}টি পরীক্ষা সম্পন্ন`}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Admin Manage Subjects / Add Subject Button */}
        {isAdmin && onOpenManageSubjects && (
          <div className="flex items-center gap-1.5 shrink-0 self-end md:self-center pl-2 md:border-l md:border-slate-200">
            <button
              type="button"
              id="btn-manage-subjects"
              onClick={onOpenManageSubjects}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 transition-colors cursor-pointer shrink-0 shadow-2xs"
              title="বিষয়সমূহ পরিচালনা করুন বা নতুন বিষয় যোগ করুন"
            >
              <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-indigo-600" />
              <span className="whitespace-nowrap">বিষয় ব্যবস্থাপনা</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
