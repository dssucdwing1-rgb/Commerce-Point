import React, { useState } from 'react';
import { LogOut, Menu, User, Shield } from 'lucide-react';
import { AuthUser, NavPage, Subject, getBatchById } from '../types';
import { BatchSelector } from './BatchSelector';
import { AccountMenuDrawer } from './AccountMenuDrawer';

interface HeaderProps {
  studentsCount: number;
  currentSubject?: Subject;
  activeBatchId?: string;
  onSelectBatch?: (batchId: string) => void;
  studentsCountByBatch?: Record<string, number>;
  onManageStudents: (initialTab?: 'students' | 'add' | 'accounts') => void;
  onOpenStaffManagement?: () => void;
  onOpenAdminAccount?: () => void;
  onOpenManageSubjects?: () => void;
  onOpenAuditReport?: () => void;
  onNavigate?: (page: NavPage) => void;
  currentPage?: NavPage;
  currentUser?: AuthUser;
  onLogout?: () => void;
}

export function Header({
  studentsCount,
  currentSubject,
  activeBatchId = 'class-11-a',
  onSelectBatch,
  studentsCountByBatch,
  onManageStudents,
  onOpenStaffManagement,
  onOpenAdminAccount,
  onOpenManageSubjects,
  onOpenAuditReport,
  onNavigate = () => {},
  currentPage = 'home',
  currentUser,
  onLogout,
}: HeaderProps) {
  const [isAccountDrawerOpen, setIsAccountDrawerOpen] = useState(false);
  const activeBatch = getBatchById(activeBatchId);

  return (
    <>
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs" id="app-header">
        <div className="w-full max-w-[1400px] mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-2.5 flex items-center justify-between gap-3">
          {/* 1. Left: Logo & Brand (Borderless, Larger Logo & Clear Typography) */}
          <div
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 sm:gap-3.5 min-w-0 cursor-pointer group select-none shrink-0"
            title="COMMERCE POINT - হোমে ফিরে যান"
          >
            {/* COMMERCE POINT Logo: No border, enlarged, crisp and prominent */}
            <img
              src="/commerce-point-logo.svg"
              alt="COMMERCE POINT Logo"
              className="logo-image w-14 h-14 sm:w-18 sm:h-18 md:w-20 md:h-20 object-contain shrink-0 group-hover:scale-105 transition-transform"
              referrerPolicy="no-referrer"
            />

            <div className="min-w-0">
              <h1 className="text-base sm:text-2xl font-black text-red-600 tracking-tight leading-tight uppercase truncate">
                COMMERCE POINT
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                {currentSubject && (
                  <span className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-md sm:rounded-lg bg-blue-900 text-amber-300 font-black text-[10px] sm:text-xs border border-blue-950 shadow-2xs">
                    <span>📚</span>
                    <span className="tracking-tight">{currentSubject.name}</span>
                  </span>
                )}
                <span className="text-[11px] sm:text-xs text-slate-500 font-semibold leading-tight hidden xs:inline">
                  {currentUser?.name || 'শিক্ষক প্যানেল'}
                </span>
              </div>
            </div>
          </div>

          {/* 2. Right: [Batch Dropdown] [Account] [Logout] */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Batch Dropdown: Positioned directly beside Account button */}
            {activeBatchId && onSelectBatch && (
              <BatchSelector
                variant="header"
                activeBatchId={activeBatchId}
                onSelectBatch={onSelectBatch}
                studentsCountByBatch={studentsCountByBatch}
                isAdmin={currentUser?.role === 'admin'}
              />
            )}

            {/* Admin Staff Management Button */}
            {currentUser?.role === 'admin' && onOpenStaffManagement && (
              <button
                type="button"
                id="header-manage-staff-btn"
                onClick={onOpenStaffManagement}
                title="স্টাফ ও অপারেটর ব্যবস্থাপনা"
                className="hidden lg:inline-flex items-center gap-1.5 px-3 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 transition-colors cursor-pointer shrink-0 select-none"
              >
                <Shield className="w-4 h-4 text-indigo-700" />
                <span>স্টাফ ব্যবস্থাপনা</span>
              </button>
            )}

            {/* PRIMARY ACCOUNT BUTTON - Opens the organized Account Panel */}
            <button
              type="button"
              id="header-account-btn"
              onClick={() => setIsAccountDrawerOpen(true)}
              title="অ্যাকাউন্ট মেনু ও অপশন"
              className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-black bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white hover:from-slate-800 hover:to-indigo-900 transition-all shadow-xs border border-indigo-700/50 cursor-pointer shrink-0 select-none"
            >
              <User className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="font-extrabold tracking-tight">Account</span>
              <Menu className="w-3.5 h-3.5 text-indigo-200" />
            </button>

            {/* Quick Logout Button */}
            {onLogout && (
              <button
                type="button"
                id="header-logout-btn"
                onClick={onLogout}
                title="লগআউট করুন"
                className="inline-flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-slate-100 text-slate-700 border border-slate-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 transition-colors cursor-pointer shrink-0 select-none"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Logout</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Account Menu Drawer Panel */}
      <AccountMenuDrawer
        isOpen={isAccountDrawerOpen}
        onClose={() => setIsAccountDrawerOpen(false)}
        currentUser={currentUser}
        activeBatch={activeBatch}
        activeBatchId={activeBatchId}
        onSelectBatch={onSelectBatch}
        studentsCountByBatch={studentsCountByBatch}
        currentSubject={currentSubject}
        studentsCount={studentsCount}
        onNavigate={onNavigate}
        onOpenManageStudents={onManageStudents}
        onOpenStaffManagement={onOpenStaffManagement}
        onOpenManageSubjects={onOpenManageSubjects}
        onOpenAdminAccount={onOpenAdminAccount}
        onOpenAuditReport={onOpenAuditReport}
        onLogout={onLogout}
      />
    </>
  );
}
