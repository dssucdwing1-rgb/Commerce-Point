import { useState } from 'react';
import { X, Edit, Trash2, Calendar, Download, FileSpreadsheet, FileText, Loader2, BookOpen, Trophy } from 'lucide-react';
import { Exam, Student, Subject } from '../types';
import { getGradeBadgeColor, toBengaliNum } from '../data/initialData';
import { exportSingleExamToCsv, exportSingleExamToExcel } from '../services/excelExport';
import { exportSingleExamPdf } from '../services/pdfExport';
import { rankStudentsForExam } from '../utils/ranking';

interface ExamDetailModalProps {
  exam: Exam | null;
  students: Student[];
  subjects?: Subject[];
  onClose: () => void;
  onEdit: (exam: Exam) => void;
  onDelete: (exam: Exam) => void;
}

export function ExamDetailModal({
  exam,
  students,
  subjects,
  onClose,
  onEdit,
  onDelete,
}: ExamDetailModalProps) {
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  if (!exam) return null;

  const currentExamSubject = subjects?.find((s) => s.id === (exam.subjectId || 'ict'));

  // Rank students strictly by Total Marks descending using centralized ranking
  const rankedRows = rankStudentsForExam(exam, students);

  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      await exportSingleExamPdf(exam, students, currentExamSubject?.name);
    } catch (err) {
      console.error('Failed to export single exam PDF:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div
      id="exam-detail-backdrop"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        id="exam-detail-modal"
        className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 mb-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>{exam.date}</span>
              {currentExamSubject && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-blue-950 to-indigo-950 text-amber-300 font-black text-xs sm:text-sm border border-blue-800 shadow-xs">
                  <span>📚 বিষয়:</span>
                  <span>{currentExamSubject.name}</span>
                </span>
              )}
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
              {exam.name}
            </h3>
          </div>
          <button
            type="button"
            id="exam-detail-close-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick summary stats banner */}
        <div className="grid grid-cols-3 gap-2 p-3 sm:p-4 bg-indigo-50/50 border-b border-indigo-100/60 text-center">
          <div className="p-2 rounded-xl bg-white border border-indigo-100 shadow-2xs">
            <p className="text-xs text-slate-500 font-medium">পূর্ণমান (Full Marks)</p>
            <p className="text-base font-bold text-slate-900 mt-0.5">
              CQ: {toBengaliNum(exam.cqFullMarks)} | MCQ: {toBengaliNum(exam.mcqFullMarks)}
            </p>
          </div>
          <div className="p-2 rounded-xl bg-white border border-indigo-100 shadow-2xs">
            <p className="text-xs text-slate-500 font-medium">গড় নম্বর (Average)</p>
            <p className="text-base font-bold text-indigo-600 mt-0.5">
              {toBengaliNum(exam.average)} / {toBengaliNum(exam.totalFullMarks)}
            </p>
          </div>
          <div className="p-2 rounded-xl bg-white border border-indigo-100 shadow-2xs">
            <p className="text-xs text-slate-500 font-medium">গড় শতকরা</p>
            <p className="text-base font-bold text-emerald-600 mt-0.5">
              {toBengaliNum(exam.averagePercentage)}%
            </p>
          </div>
        </div>

        {/* Student Marks Table */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4">
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-700 text-xs uppercase font-semibold">
                <tr>
                  <th className="py-2.5 px-3 text-center w-14">ক্রম</th>
                  <th className="py-2.5 px-3">শিক্ষার্থী</th>
                  <th className="py-2.5 px-3">Student ID</th>
                  <th className="py-2.5 px-2 text-center w-12">রোল</th>
                  <th className="py-2.5 px-2 text-center">CQ</th>
                  <th className="py-2.5 px-2 text-center">MCQ</th>
                  <th className="py-2.5 px-2 text-center">মোট</th>
                  <th className="py-2.5 px-2 text-center">%</th>
                  <th className="py-2.5 px-3 text-center">গ্রেড</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rankedRows.map(({ student, position, positionBengali, isAbsent, cq, mcq, total, percentage, grade, roll }) => {
                  const gradeColor = getGradeBadgeColor(grade);
                  const studentIdCode = student.studentIdCode || `CP-${String(roll).padStart(3, '0')}`;

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Position / ক্রম */}
                      <td className="py-2 px-2.5 text-center whitespace-nowrap">
                        {isAbsent ? (
                          <span className="text-xs font-semibold text-rose-500">—</span>
                        ) : position === 1 ? (
                          <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs">
                            🥇 {positionBengali}
                          </span>
                        ) : position === 2 ? (
                          <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-black bg-slate-200 text-slate-800 border border-slate-300">
                            🥈 {positionBengali}
                          </span>
                        ) : position === 3 ? (
                          <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-black bg-orange-100 text-orange-800 border border-orange-200">
                            🥉 {positionBengali}
                          </span>
                        ) : (
                          <span className="text-xs font-bold text-slate-700 tabular-nums">
                            {positionBengali}
                          </span>
                        )}
                      </td>

                      {/* Student Name */}
                      <td className="py-2 px-3 font-semibold text-slate-900 whitespace-nowrap">
                        {student.name}
                      </td>

                      {/* Student ID */}
                      <td className="py-2 px-3 font-mono text-xs text-slate-600 whitespace-nowrap">
                        {studentIdCode}
                      </td>

                      {/* Roll */}
                      <td className="py-2 px-2 text-center text-xs font-semibold text-slate-500 tabular-nums">
                        {toBengaliNum(roll)}
                      </td>

                      {/* CQ */}
                      <td className="py-2 px-2 text-center text-slate-700">
                        {!isAbsent && cq !== '' ? toBengaliNum(cq) : '-'}
                      </td>

                      {/* MCQ */}
                      <td className="py-2 px-2 text-center text-slate-700">
                        {!isAbsent && mcq !== '' ? toBengaliNum(mcq) : '-'}
                      </td>

                      {/* Total */}
                      <td className="py-2 px-2 text-center font-bold text-slate-900">
                        {isAbsent ? (
                          <span className="text-xs text-rose-500 font-normal">অনুপস্থিত</span>
                        ) : (
                          toBengaliNum(total)
                        )}
                      </td>

                      {/* Percentage */}
                      <td className="py-2 px-2 text-center text-slate-600 text-xs">
                        {isAbsent ? '—' : `${toBengaliNum(percentage)}%`}
                      </td>

                      {/* Grade */}
                      <td className="py-2 px-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 text-xs font-bold rounded-md border ${gradeColor.bg} ${gradeColor.text} ${gradeColor.border}`}
                        >
                          {grade}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3 sm:p-4 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2.5">
          <button
            type="button"
            id="exam-detail-delete-btn"
            onClick={() => onDelete(exam)}
            className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 font-medium text-xs sm:text-sm transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            মুছে ফেলুন
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="exam-detail-export-pdf-btn"
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold text-xs sm:text-sm transition-colors shadow-xs disabled:opacity-50"
            >
              {isExportingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4 text-amber-300" />
              )}
              <span>PDF ডাউনলোড</span>
            </button>

            <button
              type="button"
              id="exam-detail-export-excel-btn"
              onClick={() => exportSingleExamToExcel(exam, students)}
              className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm transition-colors shadow-xs"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Excel ডাউনলোড
            </button>

            <button
              type="button"
              id="exam-detail-export-csv-btn"
              onClick={() => exportSingleExamToCsv(exam, students)}
              className="inline-flex items-center gap-1.5 py-2 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm transition-colors shadow-2xs"
            >
              <Download className="w-4 h-4 text-slate-500" />
              CSV
            </button>

            <button
              type="button"
              id="exam-detail-edit-btn"
              onClick={() => onEdit(exam)}
              className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 font-semibold text-xs sm:text-sm transition-colors shadow-xs"
            >
              <Edit className="w-4 h-4" />
              সম্পাদনা করুন
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
