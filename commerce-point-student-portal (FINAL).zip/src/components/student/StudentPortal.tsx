import React, { useState, useMemo } from 'react';
import {
  LogOut,
  GraduationCap,
  Calendar,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Award,
  FileText,
  User,
  Lock,
  Search,
  ArrowRight,
  ShieldCheck,
  KeyRound,
  AlertCircle,
  Eye,
  EyeOff,
  Check,
  Copy,
  BookOpen,
  Download,
  FileSpreadsheet,
  Menu,
} from 'lucide-react';
import { AccountMenuDrawer } from '../AccountMenuDrawer';
import { Student, Exam, AuthSession, StudentNavPage, Subject, getBatchById } from '../../types';
import { toBengaliNum, calculateGrade, getGradeBadgeColor, DEFAULT_SUBJECTS } from '../../data/initialData';
import { generateStudentReport, StudentProgressReportData } from '../report/reportData';
import { ProgressReportModal } from '../report/ProgressReportModal';
import { ReportTrendChart } from '../report/ReportTrendChart';
import { changeStudentPassword } from '../../services/authService';
import { updateCurrentUserPassword } from '../../services/supabaseAuth';
import { MonthlyResultCardModal } from '../monthly/MonthlyResultCardModal';
import { extractAvailableMonths, filterExamsByMonth, calculateStudentMonthlySummary } from '../monthly/monthUtils';
import { exportStudentMonthlyExcel } from '../../services/excelExport';
import { exportStudentMonthlyPdf } from '../../services/pdfExport';

interface StudentPortalProps {
  session: AuthSession;
  allExams: Exam[];
  subjects?: Subject[];
  allStudents?: Student[];
  onLogout: () => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({
  session,
  allExams,
  subjects,
  allStudents,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<StudentNavPage>('dashboard');
  const [isAccountDrawerOpen, setIsAccountDrawerOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [passwordFeedback, setPasswordFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [isChangingPass, setIsChangingPass] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Authenticated student record
  const student = session.user.student || {
    id: session.user.id,
    name: session.user.name,
    roll: parseInt(session.user.customStudentId?.replace(/\D/g, '') || '1', 10),
    studentIdCode: session.user.customStudentId || 'CP-001',
  };

  const studentIdCode = session.user.customStudentId || student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;

  // Batch of this logged-in student
  const studentBatchId = session.user.batchId || student.batchId || (student.academicClass === 'XII' ? (student.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
  const studentBatch = getBatchById(studentBatchId);

  // Isolate exams strictly to student's batch
  const batchExams = useMemo(() => {
    return allExams.filter((e) => (e.batchId || 'class-11-a') === studentBatchId);
  }, [allExams, studentBatchId]);

  // Isolate peer students strictly - RLS enforcement: only the logged-in student
  const batchStudents = useMemo(() => {
    return [student];
  }, [student]);

  // Available Months for Monthly Results (Section 1)
  const availableMonths = useMemo(() => extractAvailableMonths(batchExams), [batchExams]);
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(() => availableMonths[0]?.key || '2026-09');
  const [isMonthlyCardOpen, setIsMonthlyCardOpen] = useState(false);
  const [isExportingMonthlyExcel, setIsExportingMonthlyExcel] = useState(false);
  const [isExportingMonthlyPdf, setIsExportingMonthlyPdf] = useState(false);
  const [monthlyFeedback, setMonthlyFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleCopyStudentId = (idStr: string) => {
    if (!idStr) return;
    try {
      navigator.clipboard.writeText(idStr);
      setCopiedId(idStr);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      setCopiedId(idStr);
      setTimeout(() => setCopiedId(null), 2500);
    }
  };

  // Subject Enrollment & Switcher
  const effectiveSubjects = subjects && subjects.length > 0 ? subjects : DEFAULT_SUBJECTS;
  const activeSubjects = effectiveSubjects.filter((s) => s.isActive);
  const enrolledSubjectIds =
    student.assignedSubjectIds && student.assignedSubjectIds.length > 0
      ? student.assignedSubjectIds
      : activeSubjects.map((s) => s.id);

  const availableSubjects = useMemo(() => {
    const list = activeSubjects.filter((s) => enrolledSubjectIds.includes(s.id));
    return list.length > 0 ? list : activeSubjects;
  }, [activeSubjects, enrolledSubjectIds]);

  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(() => {
    return availableSubjects[0]?.id || 'ict';
  });

  const currentSubject = useMemo(() => {
    return availableSubjects.find((s) => s.id === selectedSubjectId) || availableSubjects[0] || {
      id: 'ict',
      name: 'ICT',
      code: 'ICT-101',
      isActive: true,
      order: 1,
    };
  }, [availableSubjects, selectedSubjectId]);

  // STRICT DATA ISOLATION: Filter exams strictly for this batch and the selected subject
  const currentSubjectExams = useMemo(() => {
    return batchExams.filter((e) => (e.subjectId || 'ict') === currentSubject.id);
  }, [batchExams, currentSubject.id]);

  // Calculate results strictly for THIS logged-in student in this subject
  const { studentResults, stats, sortedExamsAsc, chartData } = useMemo(() => {
    // Sort all exams by date ascending
    const sorted = [...currentSubjectExams].sort((a, b) => {
      const timeA = new Date(a.date).getTime();
      const timeB = new Date(b.date).getTime();
      if (timeA !== timeB) return timeA - timeB;
      return a.createdAt - b.createdAt;
    });

    const results: {
      examId: string;
      examName: string;
      date: string;
      fullMarks: number;
      cq: number | '';
      mcq: number | '';
      total: number;
      percentage: number;
      grade: string;
      isAbsent: boolean;
      status: string;
    }[] = [];

    const chartPoints: {
      sl: number;
      label: string;
      date: string;
      score: number;
      fullMarks: number;
      percentage: number;
      isAbsent: boolean;
    }[] = [];

    let totalMarksSum = 0;
    let totalFullMarksSum = 0;
    let attendedCount = 0;
    let highest = -Infinity;
    let lowest = Infinity;
    let highestFull = 50;
    let lowestFull = 50;

    sorted.forEach((exam, idx) => {
      const entry = exam.marks ? exam.marks[student.id] : undefined;
      const fullMarks = exam.totalFullMarks || (exam.cqFullMarks || 0) + (exam.mcqFullMarks || 0) || 50;

      const isAbsent =
        !entry ||
        (entry.cq === '' && entry.mcq === '') ||
        (entry.total === 0 && entry.cq === '' && entry.mcq === '');

      let status = 'Good';
      let grade = 'F';
      let pct = 0;

      if (isAbsent) {
        status = 'Absent';
      } else {
        attendedCount++;
        totalMarksSum += entry.total;
        totalFullMarksSum += fullMarks;
        pct = fullMarks > 0 ? Number(((entry.total / fullMarks) * 100).toFixed(1)) : entry.percentage;
        grade = calculateGrade(pct);

        if (pct >= 85) status = 'Excellent';
        else if (pct >= 75) status = 'Very Good';
        else if (pct >= 60) status = 'Good';
        else if (pct >= 40) status = 'Satisfactory';
        else status = 'Needs Improvement';

        if (entry.total > highest) {
          highest = entry.total;
          highestFull = fullMarks;
        }
        if (entry.total < lowest) {
          lowest = entry.total;
          lowestFull = fullMarks;
        }
      }

      // Compact date string e.g. 05-01-26
      const parts = exam.date.split('-');
      const shortDate = parts.length === 3 ? `${parts[2]}-${parts[1]}-${parts[0].slice(-2)}` : exam.date;

      results.push({
        examId: exam.id,
        examName: exam.name,
        date: exam.date,
        fullMarks,
        cq: entry ? entry.cq : '',
        mcq: entry ? entry.mcq : '',
        total: entry ? entry.total : 0,
        percentage: pct,
        grade,
        isAbsent,
        status,
      });

      chartPoints.push({
        sl: idx + 1,
        label: `E${idx + 1}`,
        date: shortDate,
        score: isAbsent ? 0 : entry?.total || 0,
        fullMarks,
        percentage: pct,
        isAbsent,
      });
    });

    const totalExams = sorted.length;
    const absentCount = totalExams - attendedCount;
    const averageScore = attendedCount > 0 ? Number((totalMarksSum / attendedCount).toFixed(1)) : 0;
    const overallPercentage =
      totalFullMarksSum > 0 ? Number(((totalMarksSum / totalFullMarksSum) * 100).toFixed(2)) : 0;
    const overallGrade = calculateGrade(overallPercentage);
    const attendanceRate = totalExams > 0 ? Number(((attendedCount / totalExams) * 100).toFixed(2)) : 0;

    return {
      studentResults: results,
      sortedExamsAsc: sorted,
      chartData: chartPoints,
      stats: {
        totalExams,
        attendedCount,
        absentCount,
        averageScore,
        overallPercentage,
        overallGrade,
        attendanceRate,
        highestScore: highest === -Infinity ? 0 : highest,
        highestFull,
        lowestScore: lowest === Infinity ? 0 : lowest,
        lowestFull,
      },
    };
  }, [allExams, student.id]);

  // Generate Report Data strictly for THIS logged-in student in the selected subject
  const reportData: StudentProgressReportData | null = useMemo(() => {
    return generateStudentReport(student, currentSubjectExams, {
      subjectName: currentSubject.name,
    });
  }, [student, currentSubjectExams, currentSubject.name]);

  // Recent exams (last 4, newest first)
  const recentExams = useMemo(() => {
    return [...studentResults].reverse().slice(0, 4);
  }, [studentResults]);

  // Filtered results for All Results tab
  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return studentResults;
    const q = searchQuery.toLowerCase();
    return studentResults.filter(
      (r) => r.examName.toLowerCase().includes(q) || r.date.includes(q) || r.status.toLowerCase().includes(q)
    );
  }, [studentResults, searchQuery]);

  // Handle password change submit
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordFeedback(null);

    if (!currentPassword) {
      setPasswordFeedback({ type: 'error', message: 'বর্তমান পাসওয়ার্ড প্রদান করুন।' });
      return;
    }
    if (!newPassword || newPassword.length < 4) {
      setPasswordFeedback({ type: 'error', message: 'নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordFeedback({ type: 'error', message: 'নতুন পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।' });
      return;
    }

    setIsChangingPass(true);
    try {
      const res = await updateCurrentUserPassword(currentPassword, newPassword, confirmPassword);
      if (res.success) {
        setPasswordFeedback({ type: 'success', message: 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setPasswordFeedback({ type: 'error', message: res.message });
      }
    } catch {
      setPasswordFeedback({ type: 'error', message: 'পাসওয়ার্ড পরিবর্তন করতে সমস্যা হয়েছে।' });
    } finally {
      setIsChangingPass(false);
    }
  };

  // Monthly Results Calculations
  const examsInSelectedMonth = useMemo(() => {
    return filterExamsByMonth(allExams, selectedMonthKey);
  }, [allExams, selectedMonthKey]);

  const selectedMonthOption = useMemo(() => {
    return availableMonths.find((m) => m.key === selectedMonthKey);
  }, [availableMonths, selectedMonthKey]);

  const monthLabel = selectedMonthOption ? selectedMonthOption.label : selectedMonthKey;

  const monthlySummary = useMemo(() => {
    return calculateStudentMonthlySummary(student, examsInSelectedMonth, effectiveSubjects);
  }, [student, examsInSelectedMonth, effectiveSubjects]);

  const handleDownloadStudentMonthlyExcel = async () => {
    try {
      setIsExportingMonthlyExcel(true);
      setMonthlyFeedback(null);
      await exportStudentMonthlyExcel(student, examsInSelectedMonth, monthLabel, effectiveSubjects);
      setMonthlyFeedback({ type: 'success', message: 'মাসিক ফলাফল এক্সেল ফাইল সফলভাবে ডাউনলোড হয়েছে।' });
      setTimeout(() => setMonthlyFeedback(null), 3000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'এক্সেল তৈরিতে সমস্যা হয়েছে।';
      setMonthlyFeedback({ type: 'error', message: msg });
    } finally {
      setIsExportingMonthlyExcel(false);
    }
  };

  const handleDownloadStudentMonthlyPdf = async () => {
    try {
      setIsExportingMonthlyPdf(true);
      setMonthlyFeedback({ type: 'success', message: 'মাসিক রেজাল্ট কার্ড PDF তৈরি হচ্ছে...' });
      await exportStudentMonthlyPdf(student, examsInSelectedMonth, monthLabel, effectiveSubjects, [student]);
      setMonthlyFeedback({ type: 'success', message: 'মাসিক রেজাল্ট কার্ড PDF প্রিভিউ খোলা হয়েছে।' });
      setTimeout(() => setMonthlyFeedback(null), 3500);
    } catch (err: unknown) {
      console.error('PDF error in student portal', err);
      const msg = err instanceof Error ? err.message : 'পিডিএফ তৈরিতে সমস্যা হয়েছে।';
      setMonthlyFeedback({ type: 'error', message: msg });
    } finally {
      setIsExportingMonthlyPdf(false);
    }
  };

  const gradeColor = getGradeBadgeColor(stats.overallGrade);

  return (
    <div id="student-portal-container" className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
        <div className="w-full max-w-[1400px] mx-auto px-3.5 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-3 sm:gap-3.5">
            <img
              src="/commerce-point-logo.svg"
              alt="COMMERCE POINT Logo"
              className="logo-image w-14 h-14 sm:w-18 sm:h-18 md:w-20 md:h-20 object-contain shrink-0"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight leading-tight">
                COMMERCE POINT
              </h1>
              <p className="text-xs font-bold text-red-600 tracking-wide mt-0.5">
                Student Portal • শিক্ষার্থী পোর্টাল
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden xs:inline-flex items-center gap-1.5 px-2.5 py-1 bg-red-50 border border-red-200 rounded-lg text-xs font-bold text-red-700">
              <GraduationCap className="w-3.5 h-3.5 text-red-600" />
              <span>{studentBatch.name}</span>
            </div>

            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>{student.name} ({studentIdCode})</span>
            </div>

            {/* Account Option Button */}
            <button
              type="button"
              id="student-account-menu-btn"
              onClick={() => setIsAccountDrawerOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white hover:from-slate-800 hover:to-indigo-900 transition-all shadow-xs border border-indigo-700/50 cursor-pointer"
              title="শিক্ষার্থী অ্যাকাউন্ট মেনু ও অপশন"
            >
              <User className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="font-extrabold tracking-tight">Account</span>
              <Menu className="w-3.5 h-3.5 text-indigo-200" />
            </button>

            <button
              type="button"
              id="student-logout-btn"
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-colors cursor-pointer"
              title="Logout from Student Portal"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="w-full max-w-[1400px] mx-auto px-3.5 sm:px-6 lg:px-8 border-t border-slate-100 flex items-center gap-2 sm:gap-4 overflow-x-auto text-xs font-bold">
          <button
            type="button"
            id="tab-student-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'dashboard'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Dashboard (ড্যাশবোর্ড)</span>
          </button>

          <button
            type="button"
            id="tab-student-results"
            onClick={() => setActiveTab('results')}
            className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'results'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Exam Results ({studentResults.length})</span>
          </button>

          <button
            type="button"
            id="tab-student-monthly"
            onClick={() => setActiveTab('monthly')}
            className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'monthly'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Monthly Results (মাসিক ফলাফল)</span>
          </button>

          <button
            type="button"
            id="tab-student-profile"
            onClick={() => setActiveTab('profile')}
            className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'profile'
                ? 'border-blue-900 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-4 h-4" />
            <span>My Profile & Security</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-[1400px] mx-auto px-3.5 sm:px-6 lg:px-8 py-5 flex-1 space-y-5">
        {/* Subject Switcher Bar for Multi-Subject Enrolled Student */}
        {availableSubjects.length > 1 && (
          <div className="bg-white rounded-2xl p-3 sm:p-3.5 border-2 border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs sm:text-sm font-black text-indigo-900 uppercase tracking-wider flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded-xl shadow-2xs">
                <BookOpen className="w-4 h-4 text-indigo-700" />
                <span>বিষয় নির্বাচন:</span>
              </span>
            </div>
            <div className="flex items-center gap-2 overflow-x-auto sm:overflow-x-visible sm:flex-wrap py-0.5 no-scrollbar">
              {availableSubjects.map((sub) => {
                const isSelected = sub.id === currentSubject.id;
                return (
                  <button
                    key={sub.id}
                    type="button"
                    onClick={() => setSelectedSubjectId(sub.id)}
                    className={`px-3.5 sm:px-4 py-2 rounded-xl text-sm sm:text-base font-black transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-2 ${
                      isSelected
                        ? 'bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-amber-300 shadow-md ring-2 ring-indigo-500 scale-102 border border-amber-400/30'
                        : 'bg-white text-slate-800 hover:bg-slate-100 hover:text-indigo-950 border-2 border-slate-200 hover:border-indigo-300 shadow-2xs'
                    }`}
                  >
                    <span>{sub.name}</span>
                    {isSelected && <span className="w-2 h-2 rounded-full bg-amber-400"></span>}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 1: DASHBOARD
            ======================================================== */}
        {activeTab === 'dashboard' && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* 6. Dashboard Header Greeting */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <span>Welcome, {student.name}</span>
                  <span className="text-2xl">👋</span>
                </h2>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-slate-600 font-semibold mt-1">
                  <div className="inline-flex items-center gap-1 bg-slate-900 text-white px-2 py-0.5 rounded font-mono text-xs font-bold shadow-2xs">
                    <span>ID: {studentIdCode}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyStudentId(studentIdCode)}
                      className="text-slate-300 hover:text-white p-0.5 cursor-pointer"
                      title="Student ID কপি করুন"
                    >
                      {copiedId === studentIdCode ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                  {copiedId === studentIdCode && (
                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                      ID Copied!
                    </span>
                  )}
                  <span>•</span>
                  <span>Class: <strong className="text-slate-900">{student.academicClass || 'XI'} ({student.group || 'B-A'})</strong></span>
                  <span>•</span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs border border-blue-950 shadow-2xs">
                    📚 {currentSubject.name}
                  </span>
                  <span>•</span>
                  <span>Session: <strong className="text-slate-900">{student.session || '2026'}</strong></span>
                </div>
              </div>

              {/* 12. Prominent My Progress Card Button */}
              <button
                type="button"
                id="btn-my-progress-card"
                onClick={() => setIsReportModalOpen(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 hover:from-blue-950 hover:to-indigo-950 active:scale-98 text-white font-extrabold text-sm shadow-md hover:shadow-lg transition-all cursor-pointer shrink-0"
              >
                <FileText className="w-4 h-4" />
                <span>📄 My Progress Card ({currentSubject.name})</span>
              </button>
            </div>

            {/* 7. Four Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
                <span className="text-xs font-bold text-slate-500 uppercase block">Total Exams</span>
                <div className="text-2xl font-black text-slate-900 mt-1">
                  {stats.totalExams}
                </div>
                <span className="text-xs text-slate-600 font-semibold">নির্ধারিত পরীক্ষা</span>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-emerald-200 shadow-2xs bg-emerald-50/20">
                <span className="text-xs font-bold text-emerald-700 uppercase block">Attended</span>
                <div className="text-2xl font-black text-emerald-800 mt-1">
                  {stats.attendedCount}
                </div>
                <span className="text-xs text-emerald-700 font-semibold">উপস্থিত পরীক্ষা</span>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-blue-200 shadow-2xs bg-blue-50/20">
                <span className="text-xs font-bold text-blue-700 uppercase block">Average</span>
                <div className="text-2xl font-black text-blue-900 mt-1">
                  {stats.overallPercentage.toFixed(1)}%
                </div>
                <span className="text-xs text-blue-700 font-semibold">গড় নম্বর শতকরা</span>
              </div>

              <div className="bg-white rounded-2xl p-4 border border-indigo-200 shadow-2xs bg-indigo-50/20">
                <span className="text-xs font-bold text-indigo-700 uppercase block">Attendance</span>
                <div className="text-2xl font-black text-indigo-900 mt-1">
                  {stats.attendanceRate.toFixed(1)}%
                </div>
                <span className="text-xs text-indigo-700 font-semibold">
                  {stats.absentCount > 0 ? `${stats.absentCount}টি অনুপস্থিত` : 'শতভাগ উপস্থিত'}
                </span>
              </div>
            </div>

            {/* 8. Overall Performance Banner */}
            <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 text-white rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
                <div className="space-y-2 text-center sm:text-left">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-white text-xs font-bold backdrop-blur-xs">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>Overall Performance (সার্বিক ফলাফল)</span>
                  </div>

                  <div className="flex items-baseline justify-center sm:justify-start gap-3">
                    <span className="text-4xl sm:text-5xl font-black text-amber-300 tracking-tight">
                      {stats.overallPercentage.toFixed(2)}%
                    </span>
                    <span className="text-xl font-bold text-emerald-400 bg-white/10 px-3 py-0.5 rounded-lg">
                      {stats.overallGrade}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-medium max-w-md">
                    ICT পাঠ্যক্রমে সকল অনুষ্ঠিত পরীক্ষার ভিত্তিতে সংগৃহীত নম্বর ও ধারাবাহিক অবস্থান।
                  </p>
                </div>

                {/* Score highlight badges */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-auto">
                  <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 text-center border border-white/15">
                    <span className="text-[10.5px] font-bold text-emerald-300 uppercase block">Highest Score</span>
                    <span className="text-lg font-black text-white">{stats.highestScore}/{stats.highestFull}</span>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 text-center border border-white/15">
                    <span className="text-[10.5px] font-bold text-slate-300 uppercase block">Lowest Score</span>
                    <span className="text-lg font-black text-white">{stats.lowestScore}/{stats.lowestFull}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 10. Performance Progress Line Chart */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-blue-900" />
                    <span>My Performance Progress (পরীক্ষার অগ্রগতির গ্রাফ)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    ক্রমানুসারে সকল পরীক্ষার প্রাপ্ত নম্বর ও ধারাবাহিক গতিপ্রকৃতি
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <ReportTrendChart data={chartData} compactMode={false} />
              </div>
            </div>

            {/* 11. Recent Exams Section */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
                    Recent Exams (সাম্প্রতিক পরীক্ষা)
                  </h3>
                  <p className="text-xs text-slate-500">সর্বশেষ অনুষ্ঠিত পরীক্ষার সারসংক্ষেপ</p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('results')}
                  className="inline-flex items-center gap-1 text-xs font-bold text-blue-900 hover:text-blue-950 cursor-pointer"
                >
                  <span>View All Results</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {recentExams.map((ex) => (
                  <div
                    key={ex.examId}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 flex items-center justify-between"
                  >
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 truncate max-w-[180px]">
                        {ex.examName}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">{ex.date}</p>
                    </div>

                    <div className="text-right">
                      {ex.isAbsent ? (
                        <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                          Absent
                        </span>
                      ) : (
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-extrabold text-blue-950">
                            {ex.total}/{ex.fullMarks}
                          </span>
                          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            {Math.round(ex.percentage)}%
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 2: ALL EXAM RESULTS
            ======================================================== */}
        {activeTab === 'results' && (
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-4 animate-in fade-in duration-150">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base sm:text-lg font-black text-slate-900">
                    All Examination Results (সকল পরীক্ষার ফলাফল)
                  </h2>
                  <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs border border-blue-950 shadow-2xs">
                    📚 {currentSubject.name}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  আপনার সকল পরীক্ষার বিস্তারিত নম্বর তালিকা (মোট {studentResults.length}টি পরীক্ষা)
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="পরীক্ষা খুঁজুন..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:border-blue-700"
                />
              </div>
            </div>

            {/* 9. Exam Result Table */}
            <div className="result-table-container w-full overflow-x-auto rounded-xl border border-slate-200 scrollbar-thin">
              <table className="result-table min-w-max w-full border-collapse text-[13px]">
                <thead>
                  <tr className="bg-slate-800 text-white font-bold text-xs">
                    <th className="py-2.5 px-2.5 text-center w-10">ক্রমিক</th>
                    <th className="py-2.5 px-3 text-left w-24">তারিখ</th>
                    <th className="py-2.5 px-3 text-left">পরীক্ষার নাম</th>
                    <th className="py-2.5 px-2.5 text-right w-16">পূর্ণমান</th>
                    <th className="py-2.5 px-2.5 text-right w-20">প্রাপ্ত নম্বর</th>
                    <th className="py-2.5 px-2 text-right w-16">Percentage</th>
                    <th className="py-2.5 px-3 text-center w-24">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredResults.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-xs text-slate-400 font-medium">
                        কোনো পরীক্ষার তথ্য খুঁজে পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredResults.map((row, idx) => (
                      <tr
                        key={row.examId}
                        className={
                          row.isAbsent
                            ? 'bg-rose-50/50'
                            : idx % 2 === 0
                            ? 'bg-white'
                            : 'bg-slate-50/70'
                        }
                      >
                        <td className="py-2 px-2.5 text-center font-bold text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-3 text-slate-600 font-medium whitespace-nowrap">
                          {row.date}
                        </td>
                        <td className="py-2 px-3 font-semibold text-slate-900">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="inline-block px-2 py-0.5 rounded-md bg-blue-900 text-amber-300 font-extrabold text-[11px] shadow-2xs border border-blue-950">
                              {currentSubject.name}
                            </span>
                            <span>{row.examName}</span>
                          </div>
                        </td>
                        <td className="py-2 px-2.5 text-right font-medium text-slate-600">
                          {row.fullMarks}
                        </td>
                        <td className="py-2 px-2.5 text-right font-black">
                          {row.isAbsent ? (
                            <span className="text-rose-600">Absent</span>
                          ) : (
                            <span className="text-blue-900">{row.total}</span>
                          )}
                        </td>
                        <td className="py-2 px-2 text-right font-bold text-slate-800">
                          {row.isAbsent ? '—' : `${Math.round(row.percentage)}%`}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10.5px] font-bold ${
                              row.isAbsent
                                ? 'bg-rose-100 text-rose-800'
                                : row.status === 'Excellent'
                                ? 'bg-emerald-100 text-emerald-800'
                                : row.status === 'Very Good'
                                ? 'bg-teal-100 text-teal-800'
                                : row.status === 'Good'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {row.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 3: MONTHLY RESULTS (মাসিক ফলাফল)
            ======================================================== */}
        {activeTab === 'monthly' && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* Header Control Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      মাসিক একাডেমিক মূল্যায়ন
                    </span>
                    <span className="text-xs text-slate-400 font-medium">Student Performance</span>
                  </div>
                  <h2 className="text-lg font-black text-slate-900">
                    📅 আমার মাসিক ফলাফল ({monthLabel})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    নির্বাচিত মাসের সকল বিষয়ের পরীক্ষা, গড় সাফল্য ও অফিশিয়াল মাসিক রেজাল্ট কার্ড।
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  {/* Month Selector */}
                  <div className="flex items-center bg-slate-100 border border-slate-300 rounded-xl px-3 py-1.5 text-xs">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600 mr-1.5" />
                    <select
                      value={selectedMonthKey}
                      onChange={(e) => setSelectedMonthKey(e.target.value)}
                      className="bg-transparent font-bold text-slate-900 focus:outline-hidden cursor-pointer"
                    >
                      {availableMonths.map((opt) => (
                        <option key={opt.key} value={opt.key}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Direct Download Monthly PDF Button */}
                  <button
                    type="button"
                    onClick={handleDownloadStudentMonthlyPdf}
                    disabled={isExportingMonthlyPdf || examsInSelectedMonth.length === 0}
                    className="py-1.5 px-3 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <FileText className="w-3.5 h-3.5 text-amber-300" />
                    <span>Download PDF</span>
                  </button>

                  {/* Download Monthly Excel Button */}
                  <button
                    type="button"
                    onClick={handleDownloadStudentMonthlyExcel}
                    disabled={isExportingMonthlyExcel || examsInSelectedMonth.length === 0}
                    className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Monthly Excel</span>
                  </button>

                  {/* Monthly Result Card View & Print Modal Button */}
                  <button
                    type="button"
                    onClick={() => setIsMonthlyCardOpen(true)}
                    className="py-1.5 px-3.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Award className="w-3.5 h-3.5 text-amber-300" />
                    <span>📄 রেজাল্ট কার্ড দেখুন</span>
                  </button>
                </div>
              </div>

              {monthlyFeedback && (
                <div
                  className={`mt-3 p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    monthlyFeedback.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  <Check className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{monthlyFeedback.message}</span>
                </div>
              )}
            </div>

            {/* Monthly Summary KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-slate-500 block text-xs font-medium">অংশগ্রহণ ও উপস্থিতি</span>
                <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  {toBengaliNum(monthlySummary.overall.attendedExams)} /{' '}
                  {toBengaliNum(monthlySummary.overall.totalExamsInMonth)}
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  উপস্থিতি: {toBengaliNum(monthlySummary.overall.participationRate)}%
                </span>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-slate-500 block text-xs font-medium">মাসিক মোট প্রাপ্ত</span>
                <div className="text-xl sm:text-2xl font-black text-blue-900 mt-1 tabular-nums">
                  {toBengaliNum(monthlySummary.overall.totalObtainedMarks)}
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  পূর্ণমান: {toBengaliNum(monthlySummary.overall.totalFullMarks)}
                </span>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                <span className="text-slate-500 block text-xs font-medium">মাসিক গড় ও শতকরা</span>
                <div className="text-xl sm:text-2xl font-black text-emerald-700 mt-1 tabular-nums">
                  {toBengaliNum(monthlySummary.overall.averageMarks)}
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  শতকরা: {toBengaliNum(monthlySummary.overall.averagePercentage)}%
                </span>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
                <span className="text-slate-500 block text-xs font-medium">মাসিক চূড়ান্ত গ্রেড</span>
                <div className="text-2xl font-black text-indigo-700 mt-0.5">
                  {monthlySummary.overall.overallGrade}
                </div>
                <span className="text-[11px] text-slate-400 font-medium">সামগ্রিক মূল্যায়ন</span>
              </div>
            </div>

            {/* Subject Summary Table */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-3">
              <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-indigo-600" />
                <span>বিষয়ভিত্তিক মূল্যায়ন সারসংক্ষেপ (Subject Performance in {monthLabel})</span>
              </h3>

              <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin">
                <table className="result-table min-w-max w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 text-[11px]">
                    <tr>
                      <th className="py-2.5 px-3">বিষয় (Subject)</th>
                      <th className="py-2.5 px-3 text-center">মোট পরীক্ষা</th>
                      <th className="py-2.5 px-3 text-center">উপস্থিতি</th>
                      <th className="py-2.5 px-3 text-center">গড় নম্বর</th>
                      <th className="py-2.5 px-3 text-center">সর্বোচ্চ</th>
                      <th className="py-2.5 px-3 text-center">সর্বনিম্ন</th>
                      <th className="py-2.5 px-3 text-center">গ্রেড</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {monthlySummary.subjectSummaries.map((sub, idx) => (
                      <tr key={sub.subjectId} className={idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                        <td className="py-2.5 px-3 font-bold text-slate-900">
                          <span className="inline-block px-3 py-1 rounded-xl bg-blue-900 text-amber-300 font-black text-xs sm:text-sm border border-blue-950 shadow-2xs">
                            {sub.subjectName}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center text-slate-700 tabular-nums">
                          {toBengaliNum(sub.examsCount)}
                        </td>
                        <td className="py-2.5 px-3 text-center text-slate-700 tabular-nums">
                          {toBengaliNum(sub.attendedCount)}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold text-blue-900 tabular-nums">
                          {sub.attendedCount > 0 ? toBengaliNum(sub.average) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-center text-emerald-700 font-bold tabular-nums">
                          {sub.attendedCount > 0 ? toBengaliNum(sub.highest) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-center text-amber-700 tabular-nums">
                          {sub.attendedCount > 0 ? toBengaliNum(sub.lowest) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold">
                          <span className="text-slate-800">{sub.grade}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Exam-by-Exam Table in Selected Month */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-3">
              <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span>মাসের সকল পরীক্ষা ভিত্তিক নম্বর (Detailed Examination Results)</span>
              </h3>

              <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin">
                <table className="result-table min-w-max w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 text-[11px]">
                    <tr>
                      <th className="py-2.5 px-3">তারিখ</th>
                      <th className="py-2.5 px-3">বিষয়</th>
                      <th className="py-2.5 px-3">পরীক্ষার নাম</th>
                      <th className="py-2.5 px-2 text-center">CQ</th>
                      <th className="py-2.5 px-2 text-center">MCQ</th>
                      <th className="py-2.5 px-3 text-center font-bold">মোট নম্বর</th>
                      <th className="py-2.5 px-2 text-center">পূর্ণমান</th>
                      <th className="py-2.5 px-2 text-center">শতকরা</th>
                      <th className="py-2.5 px-2.5 text-center">গ্রেড</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {monthlySummary.examEntries.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-slate-400">
                          {monthLabel}-এ কোনো পরীক্ষা পাওয়া যায়নি।
                        </td>
                      </tr>
                    ) : (
                      monthlySummary.examEntries.map((e, idx) => (
                        <tr key={e.examId || idx} className={idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                          <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">{e.date}</td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs shadow-2xs border border-blue-950">
                              {e.subjectName}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-800">{e.examName}</td>
                          <td className="py-2.5 px-2 text-center text-slate-600 tabular-nums">
                            {e.isAbsent ? '-' : e.cq !== '' ? toBengaliNum(e.cq) : '-'}
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-600 tabular-nums">
                            {e.isAbsent ? '-' : e.mcq !== '' ? toBengaliNum(e.mcq) : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-slate-900 tabular-nums">
                            {e.isAbsent ? (
                              <span className="text-rose-500 font-normal">অনুপস্থিত</span>
                            ) : (
                              toBengaliNum(e.total)
                            )}
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-500 tabular-nums">
                            {toBengaliNum(e.fullMarks)}
                          </td>
                          <td className="py-2.5 px-2 text-center font-semibold text-indigo-700 tabular-nums">
                            {e.isAbsent ? '-' : `${toBengaliNum(e.percentage)}%`}
                          </td>
                          <td className="py-2.5 px-2.5 text-center">
                            <span className="font-bold text-slate-800">{e.grade}</span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 4: MY PROFILE & CHANGE PASSWORD
            ======================================================== */}
        {activeTab === 'profile' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 animate-in fade-in duration-150">
            {/* 14. Student Profile Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <User className="w-5 h-5 text-blue-900" />
                <h2 className="text-base font-extrabold text-slate-900">
                  My Profile (শিক্ষার্থী তথ্য)
                </h2>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Student Name</span>
                  <span className="font-extrabold text-slate-900 text-sm">{student.name}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Student ID</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-extrabold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      {studentIdCode}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyStudentId(studentIdCode)}
                      className="p-1 text-slate-500 hover:text-blue-900 rounded bg-white border border-slate-200 cursor-pointer"
                      title="Student ID কপি করুন"
                    >
                      {copiedId === studentIdCode ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {copiedId === studentIdCode && (
                      <span className="text-[10px] text-emerald-600 font-bold">কপি হয়েছে</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Roll Number</span>
                  <span className="font-bold text-slate-800">{student.roll}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Class</span>
                  <span className="font-bold text-slate-800">{student.academicClass || 'XI'}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Group / Batch</span>
                  <span className="font-bold text-slate-800">{student.group || 'B-A'}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Subject</span>
                  <span className="font-bold text-slate-800">
                    {student.subject || 'ICT'} (তথ্য ও যোগাযোগ প্রযুক্তি)
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Academic Session</span>
                  <span className="font-bold text-slate-800">{student.session || '2026'}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 font-bold">Institution</span>
                  <span className="font-bold text-slate-800">COMMERCE POINT</span>
                </div>
              </div>
            </div>

            {/* 15. Change Password Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <KeyRound className="w-5 h-5 text-blue-900" />
                <h2 className="text-base font-extrabold text-slate-900">
                  Change Password (পাসওয়ার্ড পরিবর্তন)
                </h2>
              </div>

              {passwordFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    passwordFeedback.type === 'success'
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border border-rose-200 text-rose-800'
                  }`}
                >
                  {passwordFeedback.type === 'success' ? (
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{passwordFeedback.message}</span>
                </div>
              )}

              <form onSubmit={handlePasswordSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Current Password (বর্তমান পাসওয়ার্ড)
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPass ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-hidden focus:border-blue-700"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPass(!showCurrentPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showCurrentPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    New Password (নতুন পাসওয়ার্ড)
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPass ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="কমপক্ষে ৪ অক্ষর"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-hidden focus:border-blue-700"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPass(!showNewPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Confirm New Password (নতুন পাসওয়ার্ড নিশ্চিত করুন)
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="পুনরায় লিখুন"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-hidden focus:border-blue-700"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isChangingPass}
                  className="w-full py-2.5 px-4 bg-blue-900 hover:bg-blue-950 active:scale-98 text-white font-bold rounded-xl shadow-xs transition-all cursor-pointer disabled:opacity-50 mt-2"
                >
                  {isChangingPass ? 'আপডেট হচ্ছে...' : 'Update Password (পাসওয়ার্ড পরিবর্তন করুন)'}
                </button>
              </form>
            </div>
          </div>
        )}
      </main>

      {/* Progress Report PDF Modal (Strictly for this student only - no edit remark option) */}
      <ProgressReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        reportData={reportData}
        allExams={currentSubjectExams}
        student={student}
        subjectName={currentSubject.name}
        canEditRemark={false}
      />

      {/* Monthly Academic Result Card PDF & Print Modal */}
      <MonthlyResultCardModal
        isOpen={isMonthlyCardOpen}
        onClose={() => setIsMonthlyCardOpen(false)}
        student={student}
        examsInMonth={examsInSelectedMonth}
        monthLabel={monthLabel}
        subjects={effectiveSubjects}
        allStudents={batchStudents}
      />

      {/* Account Menu Drawer for Student */}
      <AccountMenuDrawer
        isOpen={isAccountDrawerOpen}
        onClose={() => setIsAccountDrawerOpen(false)}
        currentUser={{
          id: student.id,
          name: student.name,
          role: 'student',
          customStudentId: studentIdCode,
          batchId: studentBatchId,
          student: student,
        }}
        activeBatch={studentBatch}
        activeBatchId={studentBatchId}
        currentSubject={currentSubject}
        onSelectStudentTab={(tab) => {
          setActiveTab(tab);
          setIsAccountDrawerOpen(false);
        }}
        onDownloadStudentReport={() => {
          setIsAccountDrawerOpen(false);
          setIsReportModalOpen(true);
        }}
        onLogout={onLogout}
      />
    </div>
  );
};
