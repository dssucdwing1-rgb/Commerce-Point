import React, { useState } from 'react';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  Loader2,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { supabase } from '../../supabase';
import { buildAuthSessionWithRLS, mapSupabaseUserToAuthSession, logoutUser } from '../../services/supabaseAuth';
import { studentIdToDummyEmail } from '../../utils/authHelpers';
import { loadStudents, normalizeStudentId } from '../../services/storage';
import { AuthSession } from '../../types';
import { checkStaffIsActive } from '../../services/staffService';

interface LoginPageProps {
  onLoginSuccess: (session: AuthSession) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showHelper, setShowHelper] = useState(false);

  const previewDummyEmail = identifier.trim() ? studentIdToDummyEmail(identifier) : '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanId = identifier.trim();
    if (!cleanId || !password.trim()) {
      setErrorMessage('Student ID / Admin User এবং Password প্রদান করুন।');
      return;
    }

    setIsLoading(true);
    const dummyEmail = studentIdToDummyEmail(cleanId);

    try {
      // 1. First attempt signInWithPassword
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: dummyEmail,
        password: password,
      });

      if (!signInError && signInData?.user) {
        const userEmail = (signInData.user.email || dummyEmail).toLowerCase();
        if (userEmail.startsWith('staff') || cleanId.toLowerCase().startsWith('staff')) {
          const activeCheck = await checkStaffIsActive(userEmail);
          if (!activeCheck.isActive) {
            await logoutUser();
            setErrorMessage(activeCheck.reason || 'আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।');
            return;
          }
        }
        const session = await buildAuthSessionWithRLS(signInData.user, signInData.session?.access_token);
        onLoginSuccess(session);
        return;
      }

      // Handle network errors
      const signInMsg = (signInError?.message || '').toLowerCase();
      const errorCode = (signInError as any)?.code || '';
      const status = (signInError as any)?.status;

      if (
        signInMsg.includes('fetch') ||
        signInMsg.includes('network') ||
        signInMsg.includes('failed to fetch') ||
        status === 0
      ) {
        setErrorMessage('ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।');
        return;
      }

      // 2. If it fails because the user does not exist (e.g., "Invalid login credentials"),
      // immediately call signUp to register the student on the fly (Auto-Provisioning)
      const isUserNotFoundOrInvalidCredentials =
        errorCode === 'invalid_credentials' ||
        errorCode === 'user_not_found' ||
        signInMsg.includes('invalid login credentials') ||
        signInMsg.includes('invalid credentials') ||
        signInMsg.includes('user not found');

      if (isUserNotFoundOrInvalidCredentials) {
        // Collect student metadata from storage directory if matched
        const students = loadStudents();
        const matchedStudent = students.find((s) => {
          if (studentIdToDummyEmail(s.studentIdCode) === dummyEmail.toLowerCase()) return true;
          if (normalizeStudentId(s.studentIdCode) === normalizeStudentId(cleanId)) return true;
          return false;
        });

        let assignedRole: 'admin' | 'staff' | 'student' = 'student';
        if (cleanId.toLowerCase() === 'admin' || dummyEmail.startsWith('admin@')) {
          assignedRole = 'admin';
        } else if (cleanId.toLowerCase().startsWith('staff') || dummyEmail.startsWith('staff')) {
          assignedRole = 'staff';
        }

        const userMetadata: Record<string, any> = {
          studentIdCode: cleanId,
          role: assignedRole,
        };
        if (matchedStudent) {
          userMetadata.name = matchedStudent.name;
          userMetadata.roll = matchedStudent.roll;
          userMetadata.batchId = matchedStudent.batchId;
          userMetadata.academicClass = matchedStudent.academicClass;
          userMetadata.group = matchedStudent.group;
        }

        const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
          email: dummyEmail,
          password: password,
          options: {
            data: userMetadata,
          },
        });

        if (signUpError) {
          const signUpMsg = (signUpError.message || '').toLowerCase();
          // If already registered, it means user exists but entered wrong password during signIn
          if (signUpMsg.includes('already registered') || signUpMsg.includes('already exists')) {
            setErrorMessage('Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।');
            return;
          }
          if (signUpMsg.includes('fetch') || signUpMsg.includes('network')) {
            setErrorMessage('ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট সংযোগ চেক করে আবার চেষ্টা করুন।');
            return;
          }
          setErrorMessage(signUpError.message || 'নিবন্ধন বা লগইন প্রক্রিয়ায় সমস্যা দেখা দিয়েছে।');
          return;
        }

        // When user already exists and email confirmation is on, Supabase returns empty identities array
        if (signUpData?.user && signUpData.user.identities && signUpData.user.identities.length === 0) {
          setErrorMessage('Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।');
          return;
        }

        // 3. If signUp succeeds, the user is successfully logged in and their account is created
        if (signUpData?.user) {
          let activeAccessToken = signUpData.session?.access_token;
          if (!activeAccessToken) {
            // Attempt immediate follow-up signIn to grab active session token
            const { data: retrySignIn } = await supabase.auth.signInWithPassword({
              email: dummyEmail,
              password: password,
            });
            activeAccessToken = retrySignIn?.session?.access_token;
          }

          const userEmail = (signUpData.user.email || dummyEmail).toLowerCase();
          if (userEmail.startsWith('staff') || cleanId.toLowerCase().startsWith('staff')) {
            const activeCheck = await checkStaffIsActive(userEmail);
            if (!activeCheck.isActive) {
              await logoutUser();
              setErrorMessage(activeCheck.reason || 'আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।');
              return;
            }
          }

          const session = await buildAuthSessionWithRLS(signUpData.user, activeAccessToken);
          onLoginSuccess(session);
          return;
        }
      }

      if (signInMsg.includes('email not confirmed')) {
        setErrorMessage('অ্যাকাউন্টের ইমেইল এখনও নিশ্চিত বা সক্রিয় (Confirm) করা হয়নি। শিক্ষকের সাথে যোগাযোগ করুন।');
        return;
      }

      if (status === 429 || signInMsg.includes('rate limit') || signInMsg.includes('too many')) {
        setErrorMessage('অতিরিক্ত বার ভুল চেষ্টা করা হয়েছে। অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন।');
        return;
      }

      setErrorMessage(
        signInError?.message || 'Student ID অথবা পাসওয়ার্ড সঠিক নয়। অনুগ্রহ করে পুনরায় যাচাই করুন।'
      );
    } catch (err: any) {
      console.error('Login error:', err);
      setErrorMessage(
        err?.message?.includes('fetch')
          ? 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।'
          : 'লগইন করতে সমস্যা হচ্ছে। অনুগ্রহ করে তথ্য যাচাই করে পুনরায় চেষ্টা করুন।'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const fillQuickCredential = (id: string, pass: string) => {
    setIdentifier(id);
    setPassword(pass);
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col justify-center items-center px-4 py-8 sm:px-6 relative">
      <div className="w-full max-w-md relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-6 flex flex-col items-center">
          <div className="mb-3 transform hover:scale-105 transition-transform duration-300">
            <img
              src="/commerce-point-logo.svg"
              alt="Commerce Point Logo"
              className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 object-contain drop-shadow-sm"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-red-600 uppercase flex items-center justify-center gap-2">
            Commerce Point
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 font-semibold">
            Academic Performance & Management Portal
          </p>
          <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-slate-200 text-xs text-slate-600 font-medium shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Supabase Authentication System
          </div>
        </div>

        {/* Login Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm sm:shadow-md">
          <div className="mb-5 pb-3 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-900">অ্যাকাউন্টে প্রবেশ করুন</h2>
            <p className="text-xs text-slate-500 mt-0.5 font-medium">
              আপনার Student ID অথবা Admin User আইডি দিয়ে লগইন করুন
            </p>
          </div>

          {/* Bangla Error Notification Banner */}
          {errorMessage && (
            <div
              role="alert"
              className="mb-5 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-start gap-2.5 animate-fadeIn"
            >
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {/* The Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Field 1: Student ID / Admin User */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="identifier-input"
                  className="block text-xs font-bold text-slate-700 tracking-wide"
                >
                  Student ID / Admin User
                </label>
                <button
                  type="button"
                  onClick={() => setShowHelper(!showHelper)}
                  className="text-[11px] text-slate-500 hover:text-red-600 inline-flex items-center gap-1 transition-colors cursor-pointer font-medium"
                >
                  <HelpCircle className="w-3 h-3" />
                  সহায়তা
                </button>
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="identifier-input"
                  type="text"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="যেমন: CP/C-12/B-A 001 অথবা admin"
                  autoComplete="username"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 transition-all font-mono"
                  required
                />
              </div>

              {/* Sub-label showing behind-the-scenes dummy email format */}
              {previewDummyEmail && (
                <div className="mt-1.5 flex items-center gap-1 text-[11px] text-slate-500 font-mono truncate">
                  <span className="text-slate-400">Supabase Auth:</span>
                  <span className="text-slate-700 font-semibold truncate">{previewDummyEmail}</span>
                </div>
              )}
            </div>

            {/* Field 2: Password */}
            <div>
              <label
                htmlFor="password-input"
                className="block text-xs font-bold text-slate-700 mb-1.5 tracking-wide"
              >
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="পাসওয়ার্ড লিখুন"
                  autoComplete="current-password"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-50 border border-slate-300 text-slate-900 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-600 transition-all font-mono"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                  aria-label={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me Checkbox */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 bg-white text-red-600 focus:ring-red-500"
                />
                লগইন মনে রাখুন
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-sm shadow-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  যাচাই করা হচ্ছে...
                </>
              ) : (
                <>
                  লগইন করুন
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Pill Fillers (Assists Testing & Verification) */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <div className="text-[11px] text-slate-500 font-medium mb-2 flex items-center justify-between">
              <span>টেস্ট করার জন্য দ্রুত সিলেক্ট করুন:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => fillQuickCredential('admin', 'admin123')}
                className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-[11px] text-slate-700 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1 font-medium"
              >
                <ShieldCheck className="w-3 h-3 text-red-600" />
                Admin (admin)
              </button>
              <button
                type="button"
                onClick={() => fillQuickCredential('staff1', '123456')}
                className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-[11px] text-slate-700 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1 font-medium"
              >
                <CheckCircle2 className="w-3 h-3 text-amber-600" />
                Staff (staff1)
              </button>
              <button
                type="button"
                onClick={() => fillQuickCredential('CP/C-12/B-A 001', '123456')}
                className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-[11px] text-slate-700 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1 font-medium"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                দ্বাদশ Batch A: 001
              </button>
              <button
                type="button"
                onClick={() => fillQuickCredential('CP/C-11/B-A 001', '123456')}
                className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-[11px] text-slate-700 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1 font-medium"
              >
                <CheckCircle2 className="w-3 h-3 text-blue-600" />
                একাদশ Batch A: 001
              </button>
            </div>
          </div>

          {/* Collapsible Helper Card */}
          {showHelper && (
            <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1.5 animate-fadeIn">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-red-600" />
                Student ID ও Supabase লগইন নিয়মাবলী:
              </div>
              <ul className="list-disc pl-4 space-y-1 text-slate-600 text-[11px] leading-relaxed">
                <li>
                  শিক্ষার্থীরা তাদের আইডি কোড (যেমন: <code className="text-slate-800 bg-slate-200 px-1 py-0.5 rounded font-mono">CP/C-12/B-A 001</code>) লিখবেন।
                </li>
                <li>
                  সিস্টেম স্বয়ংক্রিয়ভাবে এটিকে <code className="text-slate-800 bg-slate-200 px-1 py-0.5 rounded font-mono">cpc12ba001@student.commercepoint.app</code> ইমেইলে রূপান্তর করে Supabase Auth যাচাই করবে।
                </li>
                <li>
                  শিক্ষক বা এডমিন ইউজারনেম হিসেবে <code className="text-slate-800 bg-slate-200 px-1 py-0.5 rounded font-mono">admin</code> ব্যবহার করবেন।
                </li>
                <li>
                  স্টাফ বা অপারেটর ইউজারনেম <code className="text-slate-800 bg-slate-200 px-1 py-0.5 rounded font-mono">staff1</code> অথবা <code className="text-slate-800 bg-slate-200 px-1 py-0.5 rounded font-mono">staff</code> লিখলে নম্বর এন্ট্রি প্যানেল খুলবে।
                </li>
              </ul>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="mt-6 text-center text-xs text-slate-400 font-medium">
          Commerce Point Academic System &bull; Secured with Supabase Cloud
        </div>
      </div>
    </div>
  );
};
