import React, { useEffect, useState } from 'react';
import { AuthSession, UserRole } from '../../types';
import { LoginPage } from './LoginPage';
import { supabase } from '../../supabase';
import { mapSupabaseUserToAuthSession } from '../../services/supabaseAuth';

interface ProtectedRouteProps {
  session: AuthSession | null;
  onLoginSuccess: (session: AuthSession) => void;
  allowedRoles?: UserRole[];
  children: React.ReactNode;
}

/**
 * Protected Route Wrapper
 * Guarantees that only authenticated users can access the child components.
 * Exclusively relies on supabase.auth.getSession() and supabase.auth.onAuthStateChange()
 * to determine if a user is logged in.
 */
export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  session: parentSession,
  onLoginSuccess,
  allowedRoles,
  children,
}) => {
  const [activeSession, setActiveSession] = useState<AuthSession | null>(parentSession);
  const [isVerifying, setIsVerifying] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;

    // 1. Exclusively verify active session with Supabase
    supabase.auth.getSession().then(({ data: { session: sbSession }, error }) => {
      if (!isMounted) return;
      if (error || !sbSession?.user) {
        setActiveSession(null);
      } else {
        const mapped = mapSupabaseUserToAuthSession(sbSession.user, sbSession.access_token);
        setActiveSession(mapped);
      }
      setIsVerifying(false);
    });

    // 2. Exclusively subscribe to Supabase Auth state changes
    const { data: authListener } = supabase.auth.onAuthStateChange((event, sbSession) => {
      if (!isMounted) return;
      if (event === 'SIGNED_OUT' || !sbSession?.user) {
        setActiveSession(null);
      } else {
        const mapped = mapSupabaseUserToAuthSession(sbSession.user, sbSession.access_token);
        setActiveSession(mapped);
      }
      setIsVerifying(false);
    });

    return () => {
      isMounted = false;
      authListener?.subscription.unsubscribe();
    };
  }, []);

  // Synchronize when parent updates session
  useEffect(() => {
    setActiveSession(parentSession);
  }, [parentSession]);

  // While checking Supabase session on initial mount
  if (isVerifying && !activeSession) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <img
            src="/commerce-point-logo.svg"
            alt="Commerce Point Logo"
            className="w-16 h-16 animate-pulse object-contain"
          />
          <div className="w-6 h-6 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  // If user is unauthenticated, redirect to Login Page
  if (!activeSession) {
    return <LoginPage onLoginSuccess={onLoginSuccess} />;
  }

  // If specific roles are required and user does not match
  if (allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(activeSession.user.role)) {
    return (
      <div className="min-h-screen bg-slate-100 text-slate-800 flex items-center justify-center p-6">
        <div className="max-w-md w-full p-6 bg-white rounded-2xl border border-slate-200 text-center shadow-sm">
          <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center mb-4 text-xl">
            ⚠️
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">অনুমতি নেই (Access Restricted)</h2>
          <p className="text-sm text-slate-500 mb-6">
            আপনার অ্যাকাউন্টের এই পেজে প্রবেশের অনুমতি নেই। অনুগ্রহ করে সঠিক অ্যাকাউন্ট দিয়ে লগইন করুন।
          </p>
          <button
            onClick={() => onLoginSuccess(null as any)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-semibold transition-all cursor-pointer"
          >
            লগইন পেজে ফিরে যান
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
