import React, { useState } from 'react';
import { GraduationCap, Check, ChevronDown, BookmarkCheck, Sparkles, Users } from 'lucide-react';
import { Batch, BATCHES } from '../types';
import { toBengaliNum } from '../data/initialData';
import { getDefaultBatchId, setDefaultBatchId } from '../services/storage';

interface BatchSelectorProps {
  activeBatchId: string;
  onSelectBatch: (batchId: string) => void;
  studentsCountByBatch?: Record<string, number>;
  isAdmin?: boolean;
  variant?: 'card' | 'compact' | 'header';
}

export const BatchSelector: React.FC<BatchSelectorProps> = ({
  activeBatchId,
  onSelectBatch,
  studentsCountByBatch = {},
  isAdmin = true,
  variant = 'card',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [defaultBatchId, setDefaultBatchIdState] = useState<string>(() => getDefaultBatchId());
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const activeBatch = BATCHES.find((b) => b.id === activeBatchId) || BATCHES[0];

  const handleSetDefault = (batchId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDefaultBatchId(batchId);
    setDefaultBatchIdState(batchId);
    const b = BATCHES.find((item) => item.id === batchId);
    setFeedbackMsg(`"${b?.name || batchId}" ডিফল্ট ব্যাচ হিসেবে নির্ধারিত হয়েছে!`);
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  // Header / Compact Variant for top navigation bar
  if (variant === 'header' || variant === 'compact') {
    return (
      <div className="relative inline-block text-left" id="header-batch-selector">
        <button
          type="button"
          id="header-batch-dropdown-btn"
          onClick={() => setIsOpen(!isOpen)}
          className="inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-black bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white shadow-xs border border-red-500/50 transition-all cursor-pointer select-none"
          title="ব্যাচ পরিবর্তন করুন"
        >
          <GraduationCap className="w-4 h-4 text-amber-300 shrink-0" />
          <span className="tracking-tight max-w-[130px] xs:max-w-[160px] sm:max-w-none truncate">
            {activeBatch.name}
          </span>
          <ChevronDown
            className={`w-3.5 h-3.5 text-white/90 transition-transform duration-200 shrink-0 ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {isOpen && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
              aria-hidden="true"
            />
            <div className="absolute right-0 mt-2 w-72 sm:w-80 max-w-[calc(100vw-1.5rem)] rounded-2xl bg-white shadow-2xl ring-1 ring-slate-900/10 border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3.5 py-2 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-red-600" />
                  ব্যাচ নির্বাচন করুন
                </span>
                <span className="text-[11px] font-semibold text-slate-500">
                  ৩টি ব্যাচ সক্রিয়
                </span>
              </div>

              <div className="p-1.5 space-y-1">
                {BATCHES.map((batch) => {
                  const isSelected = batch.id === activeBatchId;
                  const isDefault = batch.id === defaultBatchId;
                  const studentCount = studentsCountByBatch[batch.id];

                  return (
                    <button
                      key={batch.id}
                      id={`batch-option-${batch.id}`}
                      type="button"
                      onClick={() => {
                        onSelectBatch(batch.id);
                        setIsOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-colors cursor-pointer select-none ${
                        isSelected
                          ? 'bg-red-50 text-red-900 font-black border border-red-200'
                          : 'hover:bg-slate-50 text-slate-700 font-bold border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${
                            isSelected
                              ? 'bg-red-600 text-white font-black text-xs'
                              : 'bg-slate-100 text-slate-600 text-xs'
                          }`}
                        >
                          {batch.order}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs sm:text-sm font-black truncate">
                            {batch.name}
                          </div>
                          <div className="text-[11px] text-slate-500 font-normal">
                            {batch.academicClass === 'XII' ? 'এইচএসসি দ্বাদশ' : 'এইচএসসি একাদশ'} · {batch.group}
                            {studentCount !== undefined && ` · ${toBengaliNum(studentCount)} জন`}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0 ml-2">
                        {isDefault && (
                          <span
                            className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300"
                            title="ডিফল্ট ব্যাচ"
                          >
                            ডিফল্ট
                          </span>
                        )}
                        {isSelected && (
                          <Check className="w-4 h-4 text-red-600 shrink-0" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {isAdmin && (
                <div className="mt-1 pt-2 border-t border-slate-100 px-3 pb-1">
                  <button
                    type="button"
                    onClick={(e) => handleSetDefault(activeBatchId, e)}
                    className="w-full text-center text-xs font-bold text-indigo-700 hover:text-indigo-900 hover:bg-indigo-50 py-1.5 px-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <BookmarkCheck className="w-3.5 h-3.5 text-indigo-600" />
                    <span>বর্তমান ব্যাচকে ডিফল্ট হিসেবে সেট করুন</span>
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    );
  }

  // Full Responsive Card Variant for Home Page
  return (
    <div
      id="home-batch-selector-card"
      className="w-full bg-white rounded-2xl border-2 border-red-200/90 p-3 sm:p-4 shadow-xs relative overflow-hidden"
    >
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 sm:gap-4">
        {/* Left: Label and Current Batch Context */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-black text-red-700 uppercase tracking-wider">
                ব্যাচ নির্বাচন করুন
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-black bg-slate-100 text-slate-700 border border-slate-200">
                <Users className="w-3 h-3 text-slate-500" />
                <span>{toBengaliNum(studentsCountByBatch[activeBatchId] || 0)} জন শিক্ষার্থী</span>
              </span>
            </div>
            <div className="text-sm sm:text-base font-extrabold text-slate-900 mt-0.5">
              বর্তমান সক্রিয় ব্যাচ:{' '}
              <span className="text-red-600 font-black">{activeBatch.name}</span>
            </div>
          </div>
        </div>

        {/* Right: Batch Dropdown / Pill Selector */}
        <div className="flex flex-wrap items-center gap-2">
          {BATCHES.map((batch) => {
            const isSelected = batch.id === activeBatchId;
            const isDefault = batch.id === defaultBatchId;
            const count = studentsCountByBatch[batch.id];

            return (
              <button
                key={batch.id}
                type="button"
                id={`batch-btn-${batch.id}`}
                onClick={() => onSelectBatch(batch.id)}
                className={`relative inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer select-none shrink-0 ${
                  isSelected
                    ? 'bg-gradient-to-r from-red-600 via-red-700 to-rose-700 text-white shadow-md ring-2 ring-red-400 scale-102 border border-red-500'
                    : 'bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-red-950 border border-slate-200 hover:border-red-300 shadow-2xs'
                }`}
              >
                <span
                  className={`w-5 h-5 rounded-md flex items-center justify-center text-xs font-black shrink-0 ${
                    isSelected ? 'bg-white/25 text-white' : 'bg-slate-200/80 text-slate-700'
                  }`}
                >
                  {toBengaliNum(batch.order)}
                </span>
                <span>{batch.name}</span>

                {count !== undefined && (
                  <span
                    className={`inline-flex items-center justify-center px-1.5 py-0.5 rounded-md text-[10px] sm:text-xs font-black ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950 shadow-2xs'
                        : 'bg-white text-slate-600 border border-slate-200'
                    }`}
                  >
                    {toBengaliNum(count)} জন
                  </span>
                )}

                {isDefault && (
                  <span
                    className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
                      isSelected
                        ? 'bg-red-800 text-amber-300 border border-red-600'
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                    }`}
                    title="ডিফল্ট ব্যাচ"
                  >
                    ডিফল্ট
                  </span>
                )}
              </button>
            );
          })}

          {/* Admin: Set as Default Batch Button */}
          {isAdmin && activeBatchId !== defaultBatchId && (
            <button
              type="button"
              id="set-default-batch-btn"
              onClick={(e) => handleSetDefault(activeBatchId, e)}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100 transition-colors cursor-pointer"
              title="অ্যাপ খোলার সময় এই ব্যাচটি স্বয়ংক্রিয়ভাবে সক্রিয় থাকবে"
            >
              <BookmarkCheck className="w-3.5 h-3.5 text-amber-700" />
              <span>ডিফল্ট সেট করুন</span>
            </button>
          )}
        </div>
      </div>

      {feedbackMsg && (
        <div className="mt-2.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-1">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}
    </div>
  );
};
