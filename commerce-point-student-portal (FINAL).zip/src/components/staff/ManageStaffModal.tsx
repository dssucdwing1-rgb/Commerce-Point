import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Users,
  UserPlus,
  Shield,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  RefreshCw,
  Search,
  Lock,
  Phone,
  Mail,
  UserCheck,
  UserX,
  Sparkles,
  KeyRound,
  ShieldAlert,
} from 'lucide-react';
import { StaffMember } from '../../types';
import {
  fetchStaffMembers,
  createStaffMember,
  toggleStaffStatus,
  deleteStaffMember,
  validateStaffEmail,
} from '../../services/staffService';
import { toBengaliNum } from '../../data/initialData';

interface ManageStaffModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ManageStaffModal: React.FC<ManageStaffModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'list' | 'add'>('list');
  const [staffList, setStaffList] = useState<StaffMember[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Add Form State
  const [newName, setNewName] = useState<string>('');
  const [newEmail, setNewEmail] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [newPhone, setNewPhone] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Notice Banner State
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Delete Confirmation Modal State
  const [staffToDelete, setStaffToDelete] = useState<StaffMember | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Action in progress (e.g. toggling status)
  const [actionStaffId, setActionStaffId] = useState<string | null>(null);

  // Load staff on open
  useEffect(() => {
    if (isOpen) {
      loadData();
      setNotice(null);
    }
  }, [isOpen]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await fetchStaffMembers();
      setStaffList(data);
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  };

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        if (staffToDelete) {
          setStaffToDelete(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, staffToDelete, onClose]);

  // Lock scroll
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Auto suggest next staff email
  const suggestedEmail = useMemo(() => {
    let nextNum = 1;
    staffList.forEach((s) => {
      const match = s.email.match(/^staff(\d+)/i);
      if (match) {
        const n = parseInt(match[1], 10);
        if (n >= nextNum) nextNum = n + 1;
      }
    });
    return `staff${nextNum}@student.commercepoint.app`;
  }, [staffList]);

  // Filter staff by search
  const filteredStaff = useMemo(() => {
    if (!searchQuery.trim()) return staffList;
    const q = searchQuery.toLowerCase().trim();
    return staffList.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        (s.phone && s.phone.includes(q))
    );
  }, [staffList, searchQuery]);

  // Handle Add Staff
  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);

    const emailCheck = validateStaffEmail(newEmail);
    if (!emailCheck.isValid) {
      setNotice({ type: 'error', message: emailCheck.error || 'সঠিক স্টাফ ইমেইল দিন।' });
      return;
    }

    if (newPassword.trim().length < 6) {
      setNotice({ type: 'error', message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' });
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await createStaffMember({
        name: newName,
        email: newEmail,
        password: newPassword,
        phone: newPhone,
      });

      if (res.success) {
        setNotice({ type: 'success', message: res.message });
        setNewName('');
        setNewEmail('');
        setNewPassword('');
        setNewPhone('');
        await loadData();
        setActiveTab('list');
      } else {
        setNotice({ type: 'error', message: res.message });
      }
    } catch (err: any) {
      setNotice({ type: 'error', message: err?.message || 'স্টাফ যুক্ত করতে ত্রুটি হয়েছে।' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Toggle Active/Inactive
  const handleToggleStatus = async (staff: StaffMember) => {
    setActionStaffId(staff.id);
    setNotice(null);
    try {
      const res = await toggleStaffStatus(staff.id, staff.email, staff.is_active);
      if (res.success) {
        setNotice({ type: 'success', message: res.message });
        setStaffList((prev) =>
          prev.map((s) => (s.id === staff.id ? { ...s, is_active: res.newStatus } : s))
        );
      } else {
        setNotice({ type: 'error', message: res.message });
      }
    } catch (err: any) {
      setNotice({ type: 'error', message: err?.message || 'স্ট্যাটাস পরিবর্তনে সমস্যা হয়েছে।' });
    } finally {
      setActionStaffId(null);
    }
  };

  // Handle Delete Confirmation
  const handleConfirmDelete = async () => {
    if (!staffToDelete) return;
    setIsDeleting(true);
    setNotice(null);
    try {
      const res = await deleteStaffMember(staffToDelete.id, staffToDelete.email);
      if (res.success) {
        setNotice({ type: 'success', message: res.message });
        setStaffList((prev) => prev.filter((s) => s.id !== staffToDelete.id));
        setStaffToDelete(null);
      } else {
        setNotice({ type: 'error', message: res.message });
      }
    } catch (err: any) {
      setNotice({ type: 'error', message: err?.message || 'স্টাফ মুছতে সমস্যা হয়েছে।' });
    } finally {
      setIsDeleting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-slate-900"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-indigo-900/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/40 border border-indigo-400/30 flex items-center justify-center text-amber-300">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight leading-tight">
                  স্টাফ ব্যবস্থাপনা (Staff Management)
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-300/30">
                  অ্যাডমিন প্যানেল
                </span>
              </div>
              <p className="text-xs text-indigo-200 mt-0.5">
                অপারেটর ও স্টাফদের অ্যাকাউন্ট তৈরি, নিয়ন্ত্রণ ও সক্রিয়/নিষ্ক্রিয় করুন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={loadData}
              disabled={isLoading}
              title="রিফ্রেশ করুন"
              className="p-2 rounded-xl text-indigo-200 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-indigo-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notice Banner */}
        {notice && (
          <div
            className={`px-4 py-3 border-b flex items-center gap-2 text-xs font-bold shrink-0 ${
              notice.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            {notice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{notice.message}</span>
          </div>
        )}

        {/* Tab Controls */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 pt-3 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('list')}
              className={`pb-2.5 px-3 font-bold text-xs sm:text-sm flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
                activeTab === 'list'
                  ? 'border-indigo-600 text-indigo-700 font-black'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>স্টাফ তালিকা ({toBengaliNum(staffList.length)} জন)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('add');
                if (!newEmail) setNewEmail(suggestedEmail);
              }}
              className={`pb-2.5 px-3 font-bold text-xs sm:text-sm flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
                activeTab === 'add'
                  ? 'border-indigo-600 text-indigo-700 font-black'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>নতুন স্টাফ যোগ করুন</span>
            </button>
          </div>

          {activeTab === 'list' && (
            <div className="relative pb-2.5 w-48 sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="নাম, ইমেইল বা ফোন খুঁজুন..."
                className="w-full pl-8 pr-2.5 py-1 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50">
          {activeTab === 'list' ? (
            /* Staff List Table */
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100/90 border-b border-slate-200 text-slate-700 font-extrabold text-[11px] uppercase tracking-wider">
                      <th className="py-3 px-4">স্টাফের নাম</th>
                      <th className="py-3 px-4">ইমেইল ঠিকানা</th>
                      <th className="py-3 px-4">মোবাইল নম্বর</th>
                      <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                      <th className="py-3 px-4 text-right">পদক্ষেপ (Actions)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredStaff.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400 font-medium">
                          {searchQuery
                            ? 'কোনো মেলানো স্টাফ পাওয়া যায়নি।'
                            : 'কোনো স্টাফ অ্যাকাউন্ট পাওয়া যায়নি। উপরের "নতুন স্টাফ যোগ করুন" বাটনে ক্লিক করে যোগ করুন।'}
                        </td>
                      </tr>
                    ) : (
                      filteredStaff.map((staff) => {
                        const isActionInProgress = actionStaffId === staff.id;
                        return (
                          <tr
                            key={staff.id}
                            className={`hover:bg-slate-50/80 transition-colors ${
                              !staff.is_active ? 'bg-rose-50/20 opacity-80' : ''
                            }`}
                          >
                            {/* Name */}
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2.5">
                                <div
                                  className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                                    staff.is_active
                                      ? 'bg-indigo-100 text-indigo-700'
                                      : 'bg-rose-100 text-rose-700'
                                  }`}
                                >
                                  {staff.name.slice(0, 1).toUpperCase()}
                                </div>
                                <div>
                                  <div className="font-bold text-slate-900 text-xs sm:text-sm">
                                    {staff.name}
                                  </div>
                                  <span className="text-[10px] text-slate-400">অপারেটর</span>
                                </div>
                              </div>
                            </td>

                            {/* Email */}
                            <td className="py-3 px-4">
                              <div className="font-mono text-xs font-semibold text-indigo-700 flex items-center gap-1.5">
                                <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                <span>{staff.email}</span>
                              </div>
                            </td>

                            {/* Phone */}
                            <td className="py-3 px-4 text-slate-600 font-medium">
                              {staff.phone ? (
                                <div className="flex items-center gap-1">
                                  <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                                  <span>{staff.phone}</span>
                                </div>
                              ) : (
                                <span className="text-slate-400 italic">প্রদান করা হয়নি</span>
                              )}
                            </td>

                            {/* Status */}
                            <td className="py-3 px-4 text-center">
                              {staff.is_active ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                  <span>সক্রিয় (Active)</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-300">
                                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                                  <span>নিষ্ক্রিয় (Inactive)</span>
                                </span>
                              )}
                            </td>

                            {/* Actions */}
                            <td className="py-3 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                {/* Toggle Active/Inactive */}
                                <button
                                  type="button"
                                  onClick={() => handleToggleStatus(staff)}
                                  disabled={isActionInProgress}
                                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer disabled:opacity-50 ${
                                    staff.is_active
                                      ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-200'
                                      : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-200'
                                  }`}
                                  title={
                                    staff.is_active
                                      ? 'অ্যাকাউন্ট নিষ্ক্রিয় করুন (লগইন ব্লক)'
                                      : 'অ্যাকাউন্ট পুনরায় সক্রিয় করুন'
                                  }
                                >
                                  {staff.is_active ? (
                                    <>
                                      <UserX className="w-3.5 h-3.5" />
                                      <span>নিষ্ক্রিয় করুন</span>
                                    </>
                                  ) : (
                                    <>
                                      <UserCheck className="w-3.5 h-3.5" />
                                      <span>সক্রিয় করুন</span>
                                    </>
                                  )}
                                </button>

                                {/* Delete Staff Button */}
                                <button
                                  type="button"
                                  onClick={() => setStaffToDelete(staff)}
                                  className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition-colors cursor-pointer"
                                  title="স্টাফ অ্যাকাউন্ট মুছুন"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Add New Staff Form */
            <form
              onSubmit={handleAddStaff}
              className="max-w-xl mx-auto bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col gap-4"
            >
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span>নতুন স্টাফ অ্যাকাউন্ট নিবন্ধন</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    স্টাফের নাম, ইমেইল এবং অন্তত ৬ অক্ষরের পাসওয়ার্ড দিয়ে অ্যাকাউন্ট তৈরি করুন।
                  </p>
                </div>
              </div>

              {/* Staff Name */}
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">
                  স্টাফের পুরো নাম <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="যেমন: মোঃ কামরুল ইসলাম"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              {/* Staff Email */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    স্টাফ ইমেইল <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setNewEmail(suggestedEmail)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 underline cursor-pointer"
                  >
                    সাজেশন: {suggestedEmail}
                  </button>
                </div>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="staff1@student.commercepoint.app"
                    className="w-full pl-9 pr-3.5 py-2 text-xs font-mono font-medium bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  নোট: ইমেইলটি অবশ্যই "staff" দিয়ে শুরু হতে হবে (যেমন: staff1@student.commercepoint.app)।
                </p>
              </div>

              {/* Staff Password */}
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">
                  পাসওয়ার্ড <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন"
                    className="w-full pl-9 pr-10 py-2 text-xs font-medium bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Staff Phone */}
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">
                  মোবাইল নম্বর (ঐচ্ছিক)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="tel"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="যেমন: 01712345678"
                    className="w-full pl-9 pr-3.5 py-2 text-xs font-medium bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>তৈরি হচ্ছে...</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>স্টাফ অ্যাকাউন্ট তৈরি করুন</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info */}
        <div className="bg-slate-100 border-t border-slate-200 px-4 sm:px-6 py-2.5 text-[11px] text-slate-500 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-indigo-600" />
            <span>স্টাফ অ্যাকাউন্ট সিকিউরিটি: নিষ্ক্রিয় করা হলে তাৎক্ষণিকভাবে লগইন ও এন্ট্রি ব্লক হবে।</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="font-bold text-slate-700 hover:text-slate-900"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      {staffToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-rose-200 shadow-2xl p-5 max-w-md w-full animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-3">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-slate-900">
              স্টাফ অ্যাকাউন্ট স্থায়ীভাবে মুছে ফেলবেন?
            </h3>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              আপনি <strong>{staffToDelete.name}</strong> ({staffToDelete.email})-এর অ্যাকাউন্ট স্থায়ীভাবে মুছে ফেলতে যাচ্ছেন।
              মুছে ফেললে তিনি আর সিস্টেমে লগইন করতে পারবেন না।
            </p>
            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setStaffToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 border border-slate-200 cursor-pointer"
              >
                না, বাতিল
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>মুছে ফেলা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>হ্যাঁ, মুছে ফেলুন</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
