import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  LogOut,
  GraduationCap,
  BookOpen,
  Calendar,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  FileText,
  Search,
  Plus,
  Save,
  Clock,
  Layers,
  Sparkles,
  Users,
  Check,
  TrendingUp,
  Download,
  Shield,
  HelpCircle,
  KeyRound,
  ShieldAlert,
} from 'lucide-react';
import { Exam, Student, Subject, AuthSession, BATCHES, getBatchById, StudentMarkEntry } from '../../types';
import { toBengaliNum, calculateGrade, getGradeBadgeColor, DEFAULT_SUBJECTS } from '../../data/initialData';
import { supabase } from '../../supabase';
import { exportMonthlyMasterExcel, exportSingleExamToExcel } from '../../services/excelExport';
import { exportMonthlyMasterPdf, exportSingleExamPdf } from '../../services/pdfExport';
import { extractAvailableMonths, filterExamsByMonth } from '../monthly/monthUtils';
import { StaffChangePasswordModal } from './StaffChangePasswordModal';
import { checkStaffIsActive } from '../../services/staffService';

interface StaffDashboardProps {
  session: AuthSession;
  students: Student[];
  exams: Exam[];
  subjects: Subject[];
  activeBatchId: string;
  onSelectBatch: (batchId: string) => void;
  onSaveExam: (exam: Exam) => void;
  onLogout: () => void;
}

export const StaffDashboard: React.FC<StaffDashboardProps> = ({
  session,
  students,
  exams,
  subjects,
  activeBatchId,
  onSelectBatch,
  onSaveExam,
  onLogout,
}) => {
  // Current batch object
  const activeBatch = useMemo(() => getBatchById(activeBatchId), [activeBatchId]);

  // Active Subject selection
  const effectiveSubjects = subjects && subjects.length > 0 ? subjects : DEFAULT_SUBJECTS;
  const activeSubjects = effectiveSubjects.filter((s) => s.isActive);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(() => {
    return activeSubjects[0]?.id || 'ict';
  });

  const currentSubject = useMemo(() => {
    return activeSubjects.find((s) => s.id === selectedSubjectId) || activeSubjects[0] || {
      id: 'ict',
      name: 'ICT',
      code: 'ICT',
      isActive: true,
      order: 1,
    };
  }, [activeSubjects, selectedSubjectId]);

  // Students belonging strictly to this batch
  const batchStudents = useMemo(() => {
    return students
      .filter((s) => {
        const bId =
          s.batchId ||
          (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
        return bId === activeBatchId;
      })
      .sort((a, b) => a.roll - b.roll);
  }, [students, activeBatchId]);

  // Exams belonging strictly to this batch and selected subject
  const batchSubjectExams = useMemo(() => {
    return exams
      .filter(
        (e) =>
          (e.batchId || 'class-11-a') === activeBatchId &&
          (e.subjectId || 'ict') === currentSubject.id
      )
      .sort((a, b) => {
        const timeA = new Date(a.date).getTime();
        const timeB = new Date(b.date).getTime();
        if (timeA !== timeB) return timeB - timeA; // newest first
        return b.createdAt - a.createdAt;
      });
  }, [exams, activeBatchId, currentSubject.id]);

  // Currently selected Exam for marks entry
  const [selectedExamId, setSelectedExamId] = useState<string>('');

  // Keep selected exam valid
  useEffect(() => {
    if (batchSubjectExams.length > 0) {
      if (!selectedExamId || !batchSubjectExams.some((e) => e.id === selectedExamId)) {
        setSelectedExamId(batchSubjectExams[0].id);
      }
    } else {
      setSelectedExamId('');
    }
  }, [batchSubjectExams, selectedExamId]);

  const currentExam = useMemo(() => {
    return batchSubjectExams.find((e) => e.id === selectedExamId) || null;
  }, [batchSubjectExams, selectedExamId]);

  // Search query within students table
  const [searchQuery, setSearchQuery] = useState('');

  // New Exam Modal / Inline Form State
  const [isCreatingExam, setIsCreatingExam] = useState(false);
  const [newExamTitle, setNewExamTitle] = useState('');
  const [newExamDate, setNewExamDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newExamCqFull, setNewExamCqFull] = useState('35');
  const [newExamMcqFull, setNewExamMcqFull] = useState('15');
  const [createExamError, setCreateExamError] = useState<string | null>(null);

  // Live Auto-Save State
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('saved');
  const [saveMessage, setSaveMessage] = useState('সব নম্বর সংরক্ষিত (Live Auto-Saved)');
  const [isExporting, setIsExporting] = useState(false);
  const [exportNotice, setExportNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Staff Self Password Change & Active check
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isDeactivated, setIsDeactivated] = useState(false);

  useEffect(() => {
    const ident = session.user.username || session.user.id || '';
    checkStaffIsActive(ident).then((res) => {
      if (!res.isActive) {
        setIsDeactivated(true);
      }
    });
  }, [session]);

  // Available months for monthly download
  const batchExamsAll = useMemo(() => {
    return exams.filter((e) => (e.batchId || 'class-11-a') === activeBatchId);
  }, [exams, activeBatchId]);

  const availableMonths = useMemo(() => extractAvailableMonths(batchExamsAll), [batchExamsAll]);
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(() => availableMonths[0]?.key || '2026-09');

  // Filtered students by search
  const filteredStudents = useMemo(() => {
    if (!searchQuery.trim()) return batchStudents;
    const q = searchQuery.toLowerCase().trim();
    return batchStudents.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        String(s.roll).includes(q) ||
        (s.studentIdCode && s.studentIdCode.toLowerCase().includes(q))
    );
  }, [batchStudents, searchQuery]);

  // Statistics: Total Students vs Completed Marks Entries
  const stats = useMemo(() => {
    const totalStudents = batchStudents.length;
    if (!currentExam || !currentExam.marks) {
      return { totalStudents, completedCount: 0, pendingCount: totalStudents, percentage: 0 };
    }

    let completedCount = 0;
    batchStudents.forEach((s) => {
      const entry = currentExam.marks[s.id];
      if (entry && (entry.cq !== '' || entry.mcq !== '' || entry.total > 0)) {
        completedCount++;
      }
    });

    const pendingCount = Math.max(0, totalStudents - completedCount);
    const percentage = totalStudents > 0 ? Number(((completedCount / totalStudents) * 100).toFixed(1)) : 0;

    return { totalStudents, completedCount, pendingCount, percentage };
  }, [batchStudents, currentExam]);

  // Handle Mark Change with Live Auto-Save to Supabase and Local state
  const handleMarkChange = async (
    student: Student,
    field: 'cq' | 'mcq',
    valueStr: string
  ) => {
    if (!currentExam) return;

    if (isDeactivated) {
      alert('আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।');
      return;
    }

    const cleanVal = valueStr.trim();
    const maxVal = field === 'cq' ? currentExam.cqFullMarks : currentExam.mcqFullMarks;

    let parsedVal: number | '' = '';
    if (cleanVal !== '') {
      const num = Number(cleanVal);
      if (isNaN(num) || num < 0) return;
      if (num > maxVal) {
        parsedVal = maxVal; // Cap at max full marks
      } else {
        parsedVal = num;
      }
    }

    const currentEntry = currentExam.marks[student.id] || {
      studentId: student.id,
      studentName: student.name,
      cq: '',
      mcq: '',
      total: 0,
      percentage: 0,
      grade: 'F',
    };

    const newCq = field === 'cq' ? parsedVal : currentEntry.cq;
    const newMcq = field === 'mcq' ? parsedVal : currentEntry.mcq;

    const numCq = newCq === '' ? 0 : Number(newCq);
    const numMcq = newMcq === '' ? 0 : Number(newMcq);
    const newTotal = numCq + numMcq;

    const fullMarks = currentExam.totalFullMarks || (currentExam.cqFullMarks + currentExam.mcqFullMarks) || 50;
    const newPercentage = fullMarks > 0 ? Number(((newTotal / fullMarks) * 100).toFixed(1)) : 0;
    const newGrade = calculateGrade(newPercentage);

    const updatedEntry: StudentMarkEntry = {
      studentId: student.id,
      studentName: student.name,
      cq: newCq,
      mcq: newMcq,
      total: newTotal,
      percentage: newPercentage,
      grade: newGrade,
    };

    const updatedExam: Exam = {
      ...currentExam,
      marks: {
        ...currentExam.marks,
        [student.id]: updatedEntry,
      },
    };

    // Calculate updated exam average
    const markEntries = Object.values(updatedExam.marks);
    const attendedEntries = markEntries.filter((m) => m.cq !== '' || m.mcq !== '' || m.total > 0);
    const avgScore =
      attendedEntries.length > 0
        ? Number((attendedEntries.reduce((sum, m) => sum + m.total, 0) / attendedEntries.length).toFixed(1))
        : 0;
    updatedExam.average = avgScore;
    updatedExam.averagePercentage = fullMarks > 0 ? Number(((avgScore / fullMarks) * 100).toFixed(1)) : 0;

    // 1. Immediately save to parent and localStorage
    onSaveExam(updatedExam);

    // 2. Auto-save directly to Supabase exam_results table
    setSaveStatus('saving');
    setSaveMessage('সংরক্ষণ করা হচ্ছে...');

    try {
      // Upsert to Supabase exam_results
      const { error } = await supabase.from('exam_results').upsert(
        {
          student_id: student.id,
          subject: currentSubject.code || currentSubject.name,
          exam_title: currentExam.name,
          exam_date: currentExam.date,
          cq_marks: newCq === '' ? null : Number(newCq),
          mcq_marks: newMcq === '' ? null : Number(newMcq),
          total_marks: newTotal,
          highest_marks: fullMarks,
        },
        { onConflict: 'student_id,exam_title,exam_date' }
      );

      if (error) {
        // If conflict constraint is different, attempt direct insert/update
        await supabase.from('exam_results').insert({
          student_id: student.id,
          subject: currentSubject.code || currentSubject.name,
          exam_title: currentExam.name,
          exam_date: currentExam.date,
          cq_marks: newCq === '' ? null : Number(newCq),
          mcq_marks: newMcq === '' ? null : Number(newMcq),
          total_marks: newTotal,
          highest_marks: fullMarks,
        });
      }

      setSaveStatus('saved');
      setSaveMessage('সব নম্বর সংরক্ষিত (Live Auto-Saved to Supabase)');
    } catch (err) {
      console.warn('Live save to Supabase:', err);
      // Local state is already safe
      setSaveStatus('saved');
      setSaveMessage('নম্বর সংরক্ষিত হয়েছে');
    }
  };

  // Create New Exam for Staff
  const handleCreateNewExam = (e: React.FormEvent) => {
    e.preventDefault();
    setCreateExamError(null);

    const title = newExamTitle.trim();
    if (!title) {
      setCreateExamError('অনুগ্রহ করে পরীক্ষার শিরোনাম লিখুন।');
      return;
    }

    const cqFull = parseInt(newExamCqFull, 10) || 0;
    const mcqFull = parseInt(newExamMcqFull, 10) || 0;
    const totalFull = cqFull + mcqFull;

    if (totalFull <= 0) {
      setCreateExamError('পরীক্ষার পূর্ণমান ০ হতে পারে না।');
      return;
    }

    const newExam: Exam = {
      id: `exam_${Date.now()}`,
      batchId: activeBatchId,
      subjectId: currentSubject.id,
      name: title,
      date: newExamDate,
      cqFullMarks: cqFull,
      mcqFullMarks: mcqFull,
      totalFullMarks: totalFull,
      marks: {},
      average: 0,
      averagePercentage: 0,
      createdAt: Date.now(),
    };

    onSaveExam(newExam);
    setSelectedExamId(newExam.id);
    setIsCreatingExam(false);
    setNewExamTitle('');
    setSaveStatus('saved');
    setSaveMessage('নতুন পরীক্ষা সফলভাবে তৈরি হয়েছে!');
  };

  // Export Monthly Results in Excel format
  const handleExportMonthlyExcel = async () => {
    try {
      setIsExporting(true);
      setExportNotice(null);
      const selectedMonthOption = availableMonths.find((m) => m.key === selectedMonthKey);
      const label = selectedMonthOption ? selectedMonthOption.label : selectedMonthKey;

      const examsInMonth = filterExamsByMonth(batchExamsAll, selectedMonthKey);
      if (examsInMonth.length === 0) {
        setExportNotice({ type: 'error', message: 'নির্বাচিত মাসে কোনো পরীক্ষা পাওয়া যায়নি।' });
        return;
      }

      await exportMonthlyMasterExcel(examsInMonth, batchStudents, label, effectiveSubjects);
      setExportNotice({ type: 'success', message: 'মাসিক ফলাফল Excel ফাইল সফলভাবে ডাউনলোড হয়েছে।' });
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err: any) {
      setExportNotice({ type: 'error', message: err?.message || 'Excel ডাউনলোডে সমস্যা হয়েছে।' });
    } finally {
      setIsExporting(false);
    }
  };

  // Export Monthly Results in PDF format
  const handleExportMonthlyPdf = async () => {
    try {
      setIsExporting(true);
      setExportNotice(null);
      const selectedMonthOption = availableMonths.find((m) => m.key === selectedMonthKey);
      const label = selectedMonthOption ? selectedMonthOption.label : selectedMonthKey;

      const examsInMonth = filterExamsByMonth(batchExamsAll, selectedMonthKey);
      if (examsInMonth.length === 0) {
        setExportNotice({ type: 'error', message: 'নির্বাচিত মাসে কোনো পরীক্ষা পাওয়া যায়নি।' });
        return;
      }

      await exportMonthlyMasterPdf(examsInMonth, batchStudents, label, effectiveSubjects);
      setExportNotice({ type: 'success', message: 'মাসিক ফলাফল PDF প্রিভিউ তৈরি হয়েছে।' });
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err: any) {
      setExportNotice({ type: 'error', message: err?.message || 'PDF ডাউনলোডে সমস্যা হয়েছে।' });
    } finally {
      setIsExporting(false);
    }
  };

  // Export Current Exam in Excel format
  const handleExportCurrentExamExcel = async () => {
    if (!currentExam) return;
    try {
      setIsExporting(true);
      setExportNotice(null);
      await exportSingleExamToExcel(currentExam, batchStudents);
      setExportNotice({ type: 'success', message: 'পরীক্ষার মার্কশিট Excel ফাইল ডাউনলোড হয়েছে।' });
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err: any) {
      setExportNotice({ type: 'error', message: err?.message || 'Excel তৈরিতে সমস্যা হয়েছে।' });
    } finally {
      setIsExporting(false);
    }
  };

  // Export Current Exam in PDF format
  const handleExportCurrentExamPdf = async () => {
    if (!currentExam) return;
    try {
      setIsExporting(true);
      setExportNotice(null);
      await exportSingleExamPdf(currentExam, batchStudents);
      setExportNotice({ type: 'success', message: 'পরীক্ষার মার্কশিট PDF তৈরি হয়েছে।' });
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err: any) {
      setExportNotice({ type: 'error', message: err?.message || 'PDF তৈরিতে সমস্যা হয়েছে।' });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
        <div className="w-full max-w-[1400px] mx-auto px-3.5 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <img
              src="/commerce-point-logo.svg"
              alt="COMMERCE POINT Logo"
              className="w-12 h-12 sm:w-14 sm:h-14 object-contain shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight leading-tight">
                  COMMERCE POINT
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300">
                  Staff / Operator
                </span>
              </div>
              <p className="text-xs font-bold text-indigo-700 tracking-wide mt-0.5">
                পরীক্ষার নম্বর এন্ট্রি ও অপারেটর প্যানেল
              </p>
            </div>
          </div>

          {/* User info, Password Change & Logout */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>{session.user.name}</span>
            </div>

            {/* Staff Self Password Change Button */}
            <button
              type="button"
              onClick={() => setIsPasswordModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold transition-colors cursor-pointer"
              title="পাসওয়ার্ড পরিবর্তন করুন"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>পাসওয়ার্ড পরিবর্তন</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-colors cursor-pointer"
              title="Logout from Staff Portal"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-[1400px] mx-auto px-3.5 sm:px-6 lg:px-8 py-5 flex flex-col gap-5">
        {/* Deactivation Banner */}
        {isDeactivated && (
          <div className="p-4 rounded-xl border border-rose-300 bg-rose-50 text-rose-900 flex items-center gap-3 text-xs font-bold shadow-xs">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
            <div>
              <p className="font-black text-rose-950 text-sm">অ্যাকাউন্ট সাময়িকভাবে নিষ্ক্রিয়!</p>
              <p className="text-xs text-rose-800 mt-0.5">
                আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।
              </p>
            </div>
          </div>
        )}
        {/* Notice Banner */}
        {exportNotice && (
          <div
            className={`p-3.5 rounded-xl border flex items-center gap-2.5 text-xs font-bold transition-all shadow-xs ${
              exportNotice.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            {exportNotice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{exportNotice.message}</span>
          </div>
        )}

        {/* Top Control Bar: Batch, Subject & Exam Session Selectors */}
        <section className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col gap-4">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {/* Batch Selector */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                  <span>ব্যাচ / শ্রেণি</span>
                </label>
                <select
                  value={activeBatchId}
                  onChange={(e) => onSelectBatch(e.target.value)}
                  className="bg-slate-50 border border-slate-300 hover:border-indigo-500 text-slate-900 text-xs sm:text-sm font-bold rounded-xl px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden cursor-pointer"
                >
                  {BATCHES.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Subject Selector */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                  <span>বিষয় (Subject)</span>
                </label>
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="bg-slate-50 border border-slate-300 hover:border-indigo-500 text-slate-900 text-xs sm:text-sm font-bold rounded-xl px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden cursor-pointer"
                >
                  {activeSubjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              {/* Exam Selector */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                  <span>পরীক্ষা সেশন</span>
                </label>
                <select
                  value={selectedExamId}
                  onChange={(e) => setSelectedExamId(e.target.value)}
                  disabled={batchSubjectExams.length === 0}
                  className="bg-slate-50 border border-slate-300 hover:border-indigo-500 text-slate-900 text-xs sm:text-sm font-bold rounded-xl px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden cursor-pointer disabled:opacity-50 min-w-[200px]"
                >
                  {batchSubjectExams.length === 0 ? (
                    <option value="">কোনো পরীক্ষা নেই</option>
                  ) : (
                    batchSubjectExams.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.name} • {e.date} (পূর্ণমান: {e.totalFullMarks})
                      </option>
                    ))
                  )}
                </select>
              </div>
            </div>

            {/* Create New Exam Button */}
            <div className="flex items-center gap-2 self-end lg:self-center">
              <button
                type="button"
                onClick={() => setIsCreatingExam(!isCreatingExam)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>নতুন পরীক্ষা তৈরি করুন</span>
              </button>
            </div>
          </div>

          {/* New Exam Creation Form (Collapsible) */}
          {isCreatingExam && (
            <form
              onSubmit={handleCreateNewExam}
              className="mt-2 p-4 bg-indigo-50/60 border border-indigo-200 rounded-xl flex flex-col gap-3 animate-in fade-in duration-150"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-indigo-950 uppercase tracking-wide flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>নতুন পরীক্ষার সেশন যোগ করুন ({activeBatch.shortName} • {currentSubject.name})</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setIsCreatingExam(false)}
                  className="text-slate-400 hover:text-slate-700 text-xs font-bold"
                >
                  বাতিল
                </button>
              </div>

              {createExamError && (
                <p className="text-xs font-bold text-rose-600 bg-rose-50 border border-rose-200 px-3 py-1.5 rounded-lg">
                  {createExamError}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 mb-1 block">পরীক্ষার নাম / বিষয়বস্তু</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: ক্লাস টেস্ট ১ / অধ্যায় ৩"
                    value={newExamTitle}
                    onChange={(e) => setNewExamTitle(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 mb-1 block">পরীক্ষার তারিখ</label>
                  <input
                    type="date"
                    required
                    value={newExamDate}
                    onChange={(e) => setNewExamDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 mb-1 block">CQ পূর্ণমান</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={newExamCqFull}
                    onChange={(e) => setNewExamCqFull(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 mb-1 block">MCQ পূর্ণমান</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={newExamMcqFull}
                    onChange={(e) => setNewExamMcqFull(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold rounded-lg shadow-xs cursor-pointer transition-colors"
                >
                  পরীক্ষা তৈরি ও নির্বাচন করুন
                </button>
              </div>
            </form>
          )}
        </section>

        {/* Status Indicator Card: Total Students vs Completed Entries */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-indigo-600" />
              <span>ব্যাচের শিক্ষার্থী</span>
            </span>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
              {toBengaliNum(stats.totalStudents)} জন
            </div>
            <span className="text-[11px] text-slate-400 font-medium mt-0.5">{activeBatch.name}</span>
          </div>

          <div className="bg-white border border-emerald-200 rounded-2xl p-4 shadow-xs flex flex-col">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>নম্বর এন্ট্রি সম্পন্ন</span>
            </span>
            <div className="text-xl sm:text-2xl font-black text-emerald-700 mt-1">
              {toBengaliNum(stats.completedCount)} জন
            </div>
            <span className="text-[11px] text-emerald-600 font-medium mt-0.5">
              অগ্রগতি: {toBengaliNum(stats.percentage)}%
            </span>
          </div>

          <div className="bg-white border border-amber-200 rounded-2xl p-4 shadow-xs flex flex-col">
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>এন্ট্রি বাকি / পেন্ডিং</span>
            </span>
            <div className="text-xl sm:text-2xl font-black text-amber-700 mt-1">
              {toBengaliNum(stats.pendingCount)} জন
            </div>
            <span className="text-[11px] text-amber-600 font-medium mt-0.5">
              {stats.pendingCount === 0 ? 'সব এন্ট্রি সম্পন্ন' : 'নম্বর প্রদান বাকি'}
            </span>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                <span>লাইভ অটো-সেভ স্ট্যাটাস</span>
              </span>
              <div className="flex items-center gap-2 mt-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    saveStatus === 'saving'
                      ? 'bg-amber-500 animate-ping'
                      : saveStatus === 'error'
                      ? 'bg-rose-500'
                      : 'bg-emerald-500 animate-pulse'
                  }`}
                ></span>
                <span className="text-xs font-bold text-slate-800 line-clamp-1">{saveMessage}</span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-3">
              <div
                className="bg-emerald-500 h-full transition-all duration-300"
                style={{ width: `${stats.percentage}%` }}
              ></div>
            </div>
          </div>
        </section>

        {/* Marks Entry Table Section */}
        <section className="bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col overflow-hidden">
          {/* Table Header Controls */}
          <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
                <span>নম্বর এন্ট্রি ও এডিট শিট</span>
                {currentExam && (
                  <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-lg text-xs font-bold">
                    {currentExam.name} • CQ: {currentExam.cqFullMarks}, MCQ: {currentExam.mcqFullMarks}, Total: {currentExam.totalFullMarks}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                CQ ও MCQ ইনপুট দিন; মোট নম্বর এবং গ্রেড স্বয়ংক্রিয়ভাবে গণনা হয়ে Supabase-এ সেভ হবে।
              </p>
            </div>

            {/* Student Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="রোল, নাম বা আইডি দিয়ে খুঁজুন..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Table Container */}
          {!currentExam ? (
            <div className="p-12 text-center flex flex-col items-center justify-center gap-2 text-slate-400">
              <Calendar className="w-10 h-10 text-slate-300" />
              <p className="text-sm font-bold text-slate-600">কোনো পরীক্ষা নির্বাচিত নেই</p>
              <p className="text-xs text-slate-400">
                উপরের 'পরীক্ষা সেশন' ড্রপডাউন থেকে নির্বাচন করুন অথবা 'নতুন পরীক্ষা তৈরি করুন' বাটনে ক্লিক করুন।
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700 font-extrabold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4 w-16">রোল</th>
                    <th className="py-3 px-4 min-w-[140px]">শিক্ষার্থীর নাম</th>
                    <th className="py-3 px-4 w-36">স্টুডেন্ট আইডি</th>
                    <th className="py-3 px-4 w-28 text-center bg-indigo-50/50">
                      CQ (সর্বোচ্চ {currentExam.cqFullMarks})
                    </th>
                    <th className="py-3 px-4 w-28 text-center bg-indigo-50/50">
                      MCQ (সর্বোচ্চ {currentExam.mcqFullMarks})
                    </th>
                    <th className="py-3 px-4 w-24 text-center">মোট নম্বর</th>
                    <th className="py-3 px-4 w-24 text-center">গ্রেড</th>
                    <th className="py-3 px-4 w-28 text-center">স্ট্যাটাস</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredStudents.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400">
                        কোনো শিক্ষার্থী পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    filteredStudents.map((student) => {
                      const entry = currentExam.marks[student.id] || {
                        cq: '',
                        mcq: '',
                        total: 0,
                        percentage: 0,
                        grade: 'F',
                      };

                      const isAbsent =
                        entry.cq === '' && entry.mcq === '' && entry.total === 0;

                      return (
                        <tr
                          key={student.id}
                          className="hover:bg-indigo-50/30 transition-colors group"
                        >
                          <td className="py-2.5 px-4 font-black text-slate-900">
                            {toBengaliNum(student.roll)}
                          </td>
                          <td className="py-2.5 px-4 font-bold text-slate-900">
                            {student.name}
                          </td>
                          <td className="py-2.5 px-4 text-slate-600 font-mono text-[11px]">
                            {student.studentIdCode}
                          </td>

                          {/* CQ Input */}
                          <td className="py-2.5 px-3 text-center bg-indigo-50/20">
                            <input
                              type="number"
                              min="0"
                              max={currentExam.cqFullMarks}
                              value={entry.cq}
                              onChange={(e) =>
                                handleMarkChange(student, 'cq', e.target.value)
                              }
                              placeholder="0"
                              className="w-20 text-center font-bold text-xs bg-white border border-slate-300 rounded-lg py-1 px-1.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                            />
                          </td>

                          {/* MCQ Input */}
                          <td className="py-2.5 px-3 text-center bg-indigo-50/20">
                            <input
                              type="number"
                              min="0"
                              max={currentExam.mcqFullMarks}
                              value={entry.mcq}
                              onChange={(e) =>
                                handleMarkChange(student, 'mcq', e.target.value)
                              }
                              placeholder="0"
                              className="w-20 text-center font-bold text-xs bg-white border border-slate-300 rounded-lg py-1 px-1.5 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                            />
                          </td>

                          {/* Total Score */}
                          <td className="py-2.5 px-4 text-center">
                            <span className="font-black text-sm text-slate-900">
                              {toBengaliNum(entry.total)}
                            </span>
                            <span className="text-[10px] text-slate-400 block font-normal">
                              /{toBengaliNum(currentExam.totalFullMarks)}
                            </span>
                          </td>

                          {/* Grade */}
                          <td className="py-2.5 px-4 text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-black ${getGradeBadgeColor(
                                isAbsent ? 'F' : entry.grade
                              )}`}
                            >
                              {isAbsent ? 'F' : entry.grade}
                            </span>
                          </td>

                          {/* Status */}
                          <td className="py-2.5 px-4 text-center">
                            {isAbsent ? (
                              <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                                অনুপস্থিত
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center justify-center gap-1">
                                <Check className="w-3 h-3" />
                                <span>সংরক্ষিত</span>
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Export & Download Center for Staff */}
        <section className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Download className="w-4 h-4 text-indigo-600" />
                <span>ফলাফল ও মার্কশিট ডাউনলোড সেন্টার (Excel & PDF)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                মাসিক ফলাফল এবং পরীক্ষার পূর্ণাঙ্গ মার্কশিট অফিশিয়াল ফরম্যাটে সরাসরি এক্সেল ও পিডিএফ ফাইলে ডাউনলোড করুন।
              </p>
            </div>

            {/* Month Selector for Monthly Download */}
            <div className="flex items-center gap-2">
              <label className="text-[11px] font-bold text-slate-600">মাস নির্বাচন:</label>
              <select
                value={selectedMonthKey}
                onChange={(e) => setSelectedMonthKey(e.target.value)}
                className="bg-slate-50 border border-slate-300 text-slate-900 text-xs font-bold rounded-lg px-2.5 py-1.5 focus:outline-hidden cursor-pointer"
              >
                {availableMonths.map((m) => (
                  <option key={m.key} value={m.key}>
                    {m.label} ({toBengaliNum(m.examCount)} টি পরীক্ষা)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Monthly PDF */}
            <button
              type="button"
              onClick={handleExportMonthlyPdf}
              disabled={isExporting}
              className="p-3.5 rounded-xl border border-rose-200 bg-rose-50/50 hover:bg-rose-50 text-rose-900 flex items-center gap-3 transition-all cursor-pointer disabled:opacity-50"
            >
              <div className="w-9 h-9 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black">মাসিক রেজাল্ট PDF</div>
                <div className="text-[10px] text-rose-700">অফিশিয়াল প্রিন্ট ও রেজাল্ট শিট</div>
              </div>
            </button>

            {/* Monthly Excel */}
            <button
              type="button"
              onClick={handleExportMonthlyExcel}
              disabled={isExporting}
              className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-900 flex items-center gap-3 transition-all cursor-pointer disabled:opacity-50"
            >
              <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black">মাসিক ফলাফল Excel</div>
                <div className="text-[10px] text-emerald-700">সম্পূর্ণ এক্সেল স্প্রেডশিট</div>
              </div>
            </button>

            {/* Current Exam PDF */}
            <button
              type="button"
              onClick={handleExportCurrentExamPdf}
              disabled={isExporting || !currentExam}
              className="p-3.5 rounded-xl border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 text-indigo-900 flex items-center gap-3 transition-all cursor-pointer disabled:opacity-50"
            >
              <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black">পরীক্ষার মার্কশিট PDF</div>
                <div className="text-[10px] text-indigo-700">নির্বাচিত পরীক্ষার তালিকা</div>
              </div>
            </button>

            {/* Current Exam Excel */}
            <button
              type="button"
              onClick={handleExportCurrentExamExcel}
              disabled={isExporting || !currentExam}
              className="p-3.5 rounded-xl border border-teal-200 bg-teal-50/50 hover:bg-teal-50 text-teal-900 flex items-center gap-3 transition-all cursor-pointer disabled:opacity-50"
            >
              <div className="w-9 h-9 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black">পরীক্ষার মার্কশিট Excel</div>
                <div className="text-[10px] text-teal-700">নম্বরসহ এক্সেল ফাইল</div>
              </div>
            </button>
          </div>
        </section>

        {/* Staff Permissions & Privacy Policy Footer */}
        <div className="p-3 bg-slate-200/60 border border-slate-300/80 rounded-xl text-[11px] text-slate-600 flex items-center gap-2">
          <Shield className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            <strong>অপারেটর পলিসি:</strong> স্টাফ অ্যাকাউন্টে শুধুমাত্র নম্বর এন্ট্রি, এডিট এবং ফলাফল এক্সপোর্ট অনুমোদিত। শিক্ষার্থী ম্যানেজমেন্ট ও সিকিউরিটি পাসওয়ার্ড রিসেট অ্যাক্সেস অ্যাডমিন নিয়ন্ত্রণে সীমাবদ্ধ রাখা হয়েছে।
          </span>
        </div>
      </main>

      {/* Staff Self Password Change Modal */}
      <StaffChangePasswordModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        staffName={session.user.name}
        staffEmail={
          session.user.username
            ? session.user.username.includes('@')
              ? session.user.username
              : `${session.user.username}@student.commercepoint.app`
            : undefined
        }
      />
    </div>
  );
};
