import React, { useEffect, useState } from 'react';
import {
  X,
  User,
  Users,
  UserPlus,
  Shield,
  KeyRound,
  LogOut,
  BookOpen,
  FileCheck2,
  TrendingUp,
  Calendar,
  FileSpreadsheet,
  Award,
  ChevronRight,
  ShieldCheck,
  GraduationCap,
  Layers,
  Settings,
  LayoutDashboard,
  FileText,
  Lock,
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  Loader2,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { AuthUser, Batch, BATCHES, NavPage, Subject, StudentNavPage } from '../types';
import { toBengaliNum } from '../data/initialData';
import { updateCurrentUserPassword } from '../services/supabaseAuth';

interface AccountMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthUser;
  activeBatch?: Batch;
  activeBatchId?: string;
  onSelectBatch?: (batchId: string) => void;
  studentsCountByBatch?: Record<string, number>;
  currentSubject?: Subject;
  studentsCount?: number;
  onNavigate?: (page: NavPage) => void;
  onOpenManageStudents?: (initialTab?: 'students' | 'add' | 'accounts') => void;
  onOpenStaffManagement?: () => void;
  onOpenManageSubjects?: () => void;
  onOpenAdminAccount?: () => void;
  onOpenAuditReport?: () => void;
  onSelectStudentTab?: (tab: StudentNavPage) => void;
  onDownloadStudentReport?: () => void;
  onLogout?: () => void;
}

export const AccountMenuDrawer: React.FC<AccountMenuDrawerProps> = ({
  isOpen,
  onClose,
  currentUser,
  activeBatch,
  activeBatchId = 'class-11-a',
  onSelectBatch,
  studentsCountByBatch = {},
  currentSubject,
  studentsCount = 0,
  onNavigate,
  onOpenManageStudents,
  onOpenStaffManagement,
  onOpenManageSubjects,
  onOpenAdminAccount,
  onOpenAuditReport,
  onSelectStudentTab,
  onDownloadStudentReport,
  onLogout,
}) => {
  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Lock body scroll when drawer is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // State for Change Password form (Requirement 1)
  const [showChangePasswordForm, setShowChangePasswordForm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [isSubmittingPass, setIsSubmittingPass] = useState(false);
  const [passFeedback, setPassFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassFeedback(null);

    const curr = currentPassword.trim();
    const next = newPassword.trim();
    const conf = confirmPassword.trim();

    if (!curr) {
      setPassFeedback({ type: 'error', message: 'বর্তমান পাসওয়ার্ড প্রদান করুন।' });
      return;
    }
    if (!next || next.length < 6) {
      setPassFeedback({ type: 'error', message: 'নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' });
      return;
    }
    if (next !== conf) {
      setPassFeedback({ type: 'error', message: 'নতুন পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না।' });
      return;
    }
    if (next === curr) {
      setPassFeedback({ type: 'error', message: 'নতুন পাসওয়ার্ডটি বর্তমান পাসওয়ার্ডের চেয়ে ভিন্ন হতে হবে।' });
      return;
    }

    setIsSubmittingPass(true);
    try {
      const res = await updateCurrentUserPassword(curr, next, conf);
      if (res.success) {
        setPassFeedback({ type: 'success', message: res.message || 'পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setPassFeedback({ type: 'error', message: res.message || 'পাসওয়ার্ড পরিবর্তন করা সম্ভব হয়নি।' });
      }
    } catch {
      setPassFeedback({ type: 'error', message: 'ইন্টারনেট বা নেটওয়ার্ক সংযোগে সমস্যা হয়েছে। ইন্টারনেট চেক করে আবার চেষ্টা করুন।' });
    } finally {
      setIsSubmittingPass(false);
    }
  };

  if (!isOpen) return null;

  const role = currentUser?.role || 'admin';
  const roleBengali =
    role === 'admin' ? 'প্রধান এডমিন' : role === 'teacher' ? 'বিষয়ভিত্তিক শিক্ষক' : 'শিক্ষার্থী';

  return (
    <div
      id="account-drawer-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex justify-end transition-opacity duration-300 animate-in fade-in"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
      aria-label="Account Panel"
    >
      <div
        id="account-drawer-panel"
        className="w-full sm:w-[420px] md:w-[460px] max-w-full h-full bg-white shadow-2xl flex flex-col border-l border-slate-200 overflow-hidden transform transition-transform duration-300 ease-in-out animate-in slide-in-from-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ========================================================
            1. DRAWER HEADER (User Information & Role)
            ======================================================== */}
        <div className="p-4 sm:p-5 bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 text-white flex items-center justify-between shrink-0 shadow-sm border-b border-indigo-900/40">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center font-black text-amber-300 text-lg shadow-inner shrink-0">
              {currentUser?.name ? currentUser.name.slice(0, 1) : <User className="w-6 h-6 text-amber-300" />}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight text-white truncate">
                  {currentUser?.name || (role === 'admin' ? 'এডমিন ইউজার' : 'শিক্ষার্থী')}
                </h3>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white shadow-2xs shrink-0">
                  {roleBengali}
                </span>
              </div>
              <p className="text-xs text-indigo-200 truncate mt-0.5 font-medium">
                {role === 'student' ? (
                  <>
                    Student ID: <span className="font-mono text-amber-300 font-bold">{currentUser?.customStudentId || currentUser?.id}</span>
                  </>
                ) : (
                  <>
                    আইডি: <span className="font-mono text-amber-300">{currentUser?.username || 'admin'}</span>
                  </>
                )}
              </p>
            </div>
          </div>

          <button
            type="button"
            id="account-drawer-close-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            title="মেনু বন্ধ করুন (Esc)"
            aria-label="Close Account Menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ========================================================
            2. ACTIVE CONTEXT BADGE BAR
            ======================================================== */}
        <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-1.5 min-w-0">
            <GraduationCap className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="text-slate-500 font-semibold text-[11px]">বর্তমান ব্যাচ:</span>
            <span className="font-bold text-slate-800 truncate text-[11px]">
              {activeBatch?.name || 'একাদশ শ্রেণি'}
            </span>
          </div>
          {currentSubject && (
            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold text-[11px] border border-amber-200 shrink-0">
              📚 {currentSubject.name}
            </span>
          )}
        </div>

        {/* ========================================================
            3. SCROLLABLE NAVIGATION OPTIONS (Strictly by Role)
            ======================================================== */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {/* ======================================================
              A. ROLE: ADMIN OPTIONS
              ====================================================== */}
          {role === 'admin' && (
            <>
              {/* Dashboard / Home */}
              {onNavigate && (
                <button
                  type="button"
                  id="drawer-admin-dashboard-btn"
                  onClick={() => {
                    onClose();
                    onNavigate('home');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-200 text-slate-800 hover:text-indigo-900 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <LayoutDashboard className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Dashboard (হোম ড্যাশবোর্ড)</p>
                      <p className="text-[11px] text-slate-500">হোম পেজ ও সার্বিক তথ্য ওভারভিউ</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
                </button>
              )}

              {/* SECTION: STUDENT MANAGEMENT (শিক্ষার্থী ব্যবস্থাপনা) */}
              {onOpenManageStudents && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Student Management • শিক্ষার্থী ব্যবস্থাপনা</span>
                    </span>
                    <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                      {toBengaliNum(studentsCount)} জন
                    </span>
                  </div>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5 space-y-1">
                    {/* 1. Student List */}
                    <button
                      type="button"
                      id="drawer-student-list-btn"
                      onClick={() => {
                        onClose();
                        onOpenManageStudents('students');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-indigo-600 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          <Users className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Student List (শিক্ষার্থী তালিকা)</p>
                          <p className="text-[11px] text-slate-500">সকল ব্যাচের তালিকা, মসৃণ স্ক্রল, সার্চ ও ফিল্টার</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* 2. Add New Student */}
                    <button
                      type="button"
                      id="drawer-add-student-btn"
                      onClick={() => {
                        onClose();
                        onOpenManageStudents('add');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-emerald-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                          <UserPlus className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Add New Student (নতুন শিক্ষার্থী যোগ)</p>
                          <p className="text-[11px] text-slate-500">স্বয়ংক্রিয় Student ID জেনারেশন ও বিষয় নির্ধারণ</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* 3. Student Login Accounts */}
                    <button
                      type="button"
                      id="drawer-student-accounts-btn"
                      onClick={() => {
                        onClose();
                        onOpenManageStudents('accounts');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                          <Shield className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Student Login Accounts (লগইন অ্যাকাউন্টস)</p>
                          <p className="text-[11px] text-slate-500">পাসওয়ার্ড রিসেট ও লগইন নিয়ন্ত্রণ</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* 4. Batch Verification Audit */}
                    {onOpenAuditReport && (
                      <button
                        type="button"
                        id="drawer-audit-report-btn"
                        onClick={() => {
                          onClose();
                          onOpenAuditReport();
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-emerald-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                            <ShieldCheck className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold leading-tight">Database Audit Report (ভেরিফিকেশন)</p>
                            <p className="text-[11px] text-slate-500">দ্বাদশ শ্রেণির ব্যাচ এ ও বি তালিকা নিরীক্ষা</p>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 group-hover:translate-x-0.5 transition-all" />
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION: STAFF MANAGEMENT (স্টাফ ব্যবস্থাপনা) */}
              {onOpenStaffManagement && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Staff Management • স্টাফ ব্যবস্থাপনা</span>
                    </span>
                    <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                      অপারেটর নিয়ন্ত্রণ
                    </span>
                  </div>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5 space-y-1">
                    <button
                      type="button"
                      id="drawer-manage-staff-btn"
                      onClick={() => {
                        onClose();
                        onOpenStaffManagement();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-indigo-600 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          <Users className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Staff Management (স্টাফ ব্যবস্থাপনা)</p>
                          <p className="text-[11px] text-slate-500">নতুন স্টাফ তৈরি, সক্রিয়/নিষ্ক্রিয় ও ডিলিট করুন</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION: BATCH MANAGEMENT (ব্যাচ পরিবর্তন ও নিয়ন্ত্রণ) */}
              {onSelectBatch && (
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                    <GraduationCap className="w-3.5 h-3.5 text-slate-500" />
                    <span>Batch Management • ব্যাচ পরিবর্তন</span>
                  </span>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-2 space-y-1.5">
                    {BATCHES.map((batch) => {
                      const isSelected = (activeBatchId || 'class-11-a') === batch.id;
                      const count = studentsCountByBatch[batch.id] || 0;
                      return (
                        <button
                          key={batch.id}
                          type="button"
                          onClick={() => {
                            onSelectBatch(batch.id);
                            onClose();
                          }}
                          className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-red-600 text-white shadow-xs'
                              : 'bg-white hover:bg-slate-100 text-slate-800 border border-slate-200/80'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className={`w-2 h-2 rounded-full ${
                                isSelected ? 'bg-amber-300' : 'bg-slate-400'
                              }`}
                            />
                            <span>{batch.name}</span>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              isSelected ? 'bg-red-800 text-white' : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {toBengaliNum(count)} জন
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* SECTION: SUBJECT MANAGEMENT (বিষয় ব্যবস্থাপনা) */}
              {onOpenManageSubjects && (
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                    <BookOpen className="w-3.5 h-3.5 text-slate-500" />
                    <span>Subject Management • বিষয় ব্যবস্থাপনা</span>
                  </span>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5">
                    <button
                      type="button"
                      id="drawer-nav-subjects-btn"
                      onClick={() => {
                        onClose();
                        onOpenManageSubjects();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-indigo-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center shrink-0 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Manage Subjects (বিষয়সমূহ পরিচালনা)</p>
                          <p className="text-[11px] text-slate-500">নতুন বিষয় যুক্ত বা সক্রিয়/নিষ্ক্রিয় করুন</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-700 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION: EXAM & RESULT MANAGEMENT (পরীক্ষা ও ফলাফল) */}
              {onNavigate && (
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                    <Layers className="w-3.5 h-3.5 text-slate-500" />
                    <span>Exam & Result Management • পরীক্ষা ও ফলাফল</span>
                  </span>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5 space-y-1">
                    {/* Exam Entry */}
                    <button
                      type="button"
                      id="drawer-nav-entry-btn"
                      onClick={() => {
                        onClose();
                        onNavigate('entry');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 group-hover:bg-amber-500 group-hover:text-white transition-colors">
                          <FileCheck2 className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Exam Data Entry (নম্বর এন্ট্রি)</p>
                          <p className="text-[11px] text-slate-500">নতুন পরীক্ষা গ্রহণ ও CQ/MCQ নম্বর এন্ট্রি</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* All Results */}
                    <button
                      type="button"
                      id="drawer-nav-results-btn"
                      onClick={() => {
                        onClose();
                        onNavigate('results');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                          <Award className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">All Results (ফলাফল ও মেধাক্রম)</p>
                          <p className="text-[11px] text-slate-500">মেধাক্রম, পজিশন ও পরীক্ষার পূর্ণাঙ্গ শিট</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* Student Progress */}
                    <button
                      type="button"
                      id="drawer-nav-progress-btn"
                      onClick={() => {
                        onClose();
                        onNavigate('progress');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                          <TrendingUp className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Student Progress (শিক্ষার্থী অগ্রগতি)</p>
                          <p className="text-[11px] text-slate-500">গ্রাফ, ট্রেন্ড এবং ব্যক্তিভিত্তিক প্রগ্রেস কার্ড</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    {/* Monthly Result */}
                    <button
                      type="button"
                      id="drawer-nav-monthly-btn"
                      onClick={() => {
                        onClose();
                        onNavigate('monthly');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                          <Calendar className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Monthly Result & Summary (মাসিক ফলাফল)</p>
                          <p className="text-[11px] text-slate-500">মাসিক মাস্টার শিট ও সাবজেক্ট সামারি</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-700 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION: REPORTS & DOWNLOADS */}
              {onNavigate && (
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-slate-500" />
                    <span>Reports & Downloads • রিপোর্ট ও ডাউনলোড</span>
                  </span>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5 space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigate('monthly');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-emerald-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                          <FileSpreadsheet className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Excel Master Sheet & Reports</p>
                          <p className="text-[11px] text-slate-500">ব্যাচভিত্তিক মাসিক এক্সেল ফাইল ডাউনলোড</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 group-hover:translate-x-0.5 transition-all" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigate('monthly');
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-rose-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-800 flex items-center justify-center shrink-0 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                          <Award className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">PDF Academic Progress Cards</p>
                          <p className="text-[11px] text-slate-500">নিকোশ বাংলা ফন্টে প্রিন্টযোগ্য রেজাল্ট কার্ড</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-rose-700 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION: SETTINGS & SECURITY */}
              {onOpenAdminAccount && (
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                    <Settings className="w-3.5 h-3.5 text-slate-500" />
                    <span>Settings & Security • সেটিংস</span>
                  </span>

                  <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5">
                    <button
                      type="button"
                      id="drawer-admin-password-btn"
                      onClick={() => {
                        onClose();
                        onOpenAdminAccount();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-amber-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                          <KeyRound className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold leading-tight">Account Management (অ্যাকাউন্ট ও সিকিউরিটি)</p>
                          <p className="text-[11px] text-slate-500">প্রোফাইল, মোবাইল, ইমেইল, পাসওয়ার্ড ও রিকভারি সেটিংস</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* ======================================================
              B. ROLE: TEACHER OPTIONS
              ====================================================== */}
          {role === 'teacher' && (
            <>
              {/* Account Overview */}
              <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-3 space-y-1">
                <p className="text-xs font-bold text-slate-800">
                  শিক্ষক: <span className="text-indigo-700">{currentUser?.name}</span>
                </p>
                <p className="text-[11px] text-slate-500">
                  নির্ধারিত বিষয়: <span className="font-bold text-slate-700">{currentSubject?.name || 'ICT'}</span>
                </p>
              </div>

              {/* Assigned Students */}
              {onOpenManageStudents && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenManageStudents('students');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-200 text-slate-800 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Assigned Students (শিক্ষার্থী তালিকা)</p>
                      <p className="text-[11px] text-slate-500">{toBengaliNum(studentsCount)} জন শিক্ষার্থী</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-all" />
                </button>
              )}

              {/* Exam Entry */}
              {onNavigate && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigate('entry');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 border border-slate-200 text-slate-800 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <FileCheck2 className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Exam Data Entry (নম্বর এন্ট্রি)</p>
                      <p className="text-[11px] text-slate-500">নম্বর ইনপুট ও সংরক্ষণ</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-700 transition-all" />
                </button>
              )}

              {/* Student Progress */}
              {onNavigate && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigate('progress');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 text-slate-800 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Student Progress (শিক্ষার্থী অগ্রগতি)</p>
                      <p className="text-[11px] text-slate-500">গ্রাফ ও বিস্তারিত বিশ্লেষণ</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 transition-all" />
                </button>
              )}

              {/* Monthly Result */}
              {onNavigate && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigate('monthly');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-purple-50 border border-slate-200 text-slate-800 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Monthly Result (মাসিক ফলাফল)</p>
                      <p className="text-[11px] text-slate-500">মাসিক ফলাফল ও রিপোর্ট</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-purple-700 transition-all" />
                </button>
              )}

              {/* Password Settings */}
              {onOpenAdminAccount && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAdminAccount();
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 border border-slate-200 text-slate-800 transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <KeyRound className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">পাসওয়ার্ড পরিবর্তন</p>
                      <p className="text-[11px] text-slate-500">শিক্ষক লগইন পাসওয়ার্ড</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-700 transition-all" />
                </button>
              )}
            </>
          )}

          {/* ======================================================
              C. ROLE: STUDENT OPTIONS (Student Portal)
              ====================================================== */}
          {role === 'student' && (
            <div className="space-y-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5 px-1">
                <User className="w-3.5 h-3.5 text-indigo-600" />
                <span>Student Menu • শিক্ষার্থীর মেনু</span>
              </span>

              <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-1.5 space-y-1">
                {/* 1. My Profile */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectStudentTab?.('profile');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-indigo-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">My Profile (আমার প্রোফাইল)</p>
                      <p className="text-[11px] text-slate-500">আইডি, রোল, ব্যাচ ও পাসওয়ার্ড পরিবর্তন</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-all" />
                </button>

                {/* 2. My Subjects */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectStudentTab?.('dashboard');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-teal-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center shrink-0 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">My Subjects (আমার বিষয়সমূহ)</p>
                      <p className="text-[11px] text-slate-500">অনুমোদিত বিষয়ের তালিকা ও সুইচিং</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 transition-all" />
                </button>

                {/* 3. My Results */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectStudentTab?.('results');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-blue-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Award className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">My Results (আমার ফলাফল)</p>
                      <p className="text-[11px] text-slate-500">সকল পরীক্ষার বিস্তারিত নম্বর ও গ্রেড</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-all" />
                </button>

                {/* 4. My Progress */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectStudentTab?.('dashboard');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-emerald-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">My Progress (আমার অগ্রগতি)</p>
                      <p className="text-[11px] text-slate-500">পারফরম্যান্স গ্রাফ ও গড় স্কোর</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-all" />
                </button>

                {/* 5. Monthly Summary */}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectStudentTab?.('monthly');
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-purple-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold leading-tight">Monthly Summary (মাসিক ফলাফল)</p>
                      <p className="text-[11px] text-slate-500">মাসিক সারাংশ ও গ্রেড বিশ্লেষণ</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition-all" />
                </button>

                {/* 6. Download Progress Card */}
                {onDownloadStudentReport && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onDownloadStudentReport();
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white text-slate-800 hover:text-rose-700 hover:shadow-xs transition-all cursor-pointer text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold leading-tight">Download Progress Card (প্রগ্রেস কার্ড)</p>
                        <p className="text-[11px] text-slate-500">নিকোশ ফন্টে একাডেমিক রেজাল্ট শিট</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-rose-600 transition-all" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ======================================================
              D. COMMON: CHANGE PASSWORD FORM (Requirement 1)
              ====================================================== */}
          <div className="space-y-2 pt-2 border-t border-slate-200/80">
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Security • পাসওয়ার্ড পরিবর্তন</span>
              </span>
            </div>

            <div className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-2 sm:p-3 space-y-3">
              {/* Trigger Button */}
              <button
                type="button"
                id="drawer-toggle-change-pass-btn"
                onClick={() => {
                  setShowChangePasswordForm(!showChangePasswordForm);
                  setPassFeedback(null);
                }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-white hover:bg-slate-100/80 border border-slate-200/80 text-slate-800 transition-all cursor-pointer text-left group shadow-2xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold leading-tight text-slate-900">
                      Change Password (পাসওয়ার্ড পরিবর্তন)
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {showChangePasswordForm ? 'ফর্ম বন্ধ করতে ক্লিক করুন' : 'নিরাপদ উপায়ে পাসওয়ার্ড পরিবর্তন করুন'}
                    </p>
                  </div>
                </div>
                {showChangePasswordForm ? (
                  <ChevronUp className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
                )}
              </button>

              {/* The Change Password Form */}
              {showChangePasswordForm && (
                <form
                  onSubmit={handleChangePasswordSubmit}
                  className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-3 animate-in fade-in duration-150"
                >
                  {/* Feedback Message */}
                  {passFeedback && (
                    <div
                      role="alert"
                      className={`p-2.5 rounded-xl text-xs flex items-start gap-2 ${
                        passFeedback.type === 'success'
                          ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                          : 'bg-rose-50 border border-rose-200 text-rose-700'
                      }`}
                    >
                      {passFeedback.type === 'success' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 font-medium leading-relaxed">{passFeedback.message}</div>
                    </div>
                  )}

                  {/* 1. Current Password */}
                  <div>
                    <label
                      htmlFor="drawer-current-pass"
                      className="block text-xs font-bold text-slate-700 mb-1"
                    >
                      Current Password (বর্তমান পাসওয়ার্ড) *
                    </label>
                    <div className="relative">
                      <input
                        id="drawer-current-pass"
                        type={showCurrentPass ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="বর্তমান পাসওয়ার্ড লিখুন"
                        required
                        className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPass(!showCurrentPass)}
                        className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                        aria-label={showCurrentPass ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                      >
                        {showCurrentPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* 2. New Password */}
                  <div>
                    <label
                      htmlFor="drawer-new-pass"
                      className="block text-xs font-bold text-slate-700 mb-1"
                    >
                      New Password (নতুন পাসওয়ার্ড) *
                    </label>
                    <div className="relative">
                      <input
                        id="drawer-new-pass"
                        type={showNewPass ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="কমপক্ষে ৬ অক্ষরের নতুন পাসওয়ার্ড"
                        required
                        className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPass(!showNewPass)}
                        className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                        aria-label={showNewPass ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                      >
                        {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* 3. Confirm Password */}
                  <div>
                    <label
                      htmlFor="drawer-confirm-pass"
                      className="block text-xs font-bold text-slate-700 mb-1"
                    >
                      Confirm Password (কনফার্ম পাসওয়ার্ড) *
                    </label>
                    <div className="relative">
                      <input
                        id="drawer-confirm-pass"
                        type={showConfirmPass ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="পুনরায় নতুন পাসওয়ার্ড লিখুন"
                        required
                        className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPass(!showConfirmPass)}
                        className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                        aria-label={showConfirmPass ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                      >
                        {showConfirmPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-1 flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={isSubmittingPass}
                      className="flex-1 py-2 px-3 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {isSubmittingPass ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>আপডেট হচ্ছে...</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>পাসওয়ার্ড পরিবর্তন করুন</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowChangePasswordForm(false);
                        setPassFeedback(null);
                        setCurrentPassword('');
                        setNewPassword('');
                        setConfirmPassword('');
                      }}
                      className="py-2 px-3 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      বাতিল
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* ========================================================
            4. DRAWER FOOTER (Branding & Secure Logout)
            ======================================================== */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3 shrink-0">
          <div className="text-[11px] text-slate-500 leading-tight">
            <strong className="text-slate-700 block">COMMERCE POINT</strong>
            <span className="text-[10px] text-slate-400">Student Progress System</span>
          </div>

          {onLogout && (
            <button
              type="button"
              id="drawer-logout-btn"
              onClick={() => {
                onClose();
                onLogout();
              }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-600 hover:text-white hover:border-rose-600 transition-all shadow-2xs cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout (লগআউট)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
