import React, { useState } from 'react';
import { X, CheckCircle2, AlertTriangle, ShieldCheck, Copy, Check, RefreshCw, FileText, Users, Award } from 'lucide-react';
import { Student, Exam } from '../types';
import { auditAndValidateDatabase, FullAuditReport } from '../utils/studentAudit';
import { synchronizeAuthoritativeStudents, saveStudents, STUDENTS_CORRECTION_VERSION_KEY } from '../services/storage';
import { syncAndInitializeAccounts } from '../services/authService';

interface AuditReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  exams: Exam[];
  onRefreshDatabase?: () => void;
}

export const AuditReportModal: React.FC<AuditReportModalProps> = ({
  isOpen,
  onClose,
  students,
  exams,
  onRefreshDatabase,
}) => {
  const [copied, setCopied] = useState(false);
  const [isFixing, setIsFixing] = useState(false);
  const [fixSuccess, setFixSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const report: FullAuditReport = auditAndValidateDatabase(students, exams);

  const handleCopyText = () => {
    try {
      navigator.clipboard.writeText(report.summaryText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleForceResync = async () => {
    setIsFixing(true);
    try {
      const res = synchronizeAuthoritativeStudents(students);
      saveStudents(res.students);
      localStorage.setItem(STUDENTS_CORRECTION_VERSION_KEY, 'v8_authoritative_class12');
      await syncAndInitializeAccounts();
      if (onRefreshDatabase) {
        onRefreshDatabase();
      }
      setFixSuccess('Authoritative Student Data সফলভাবে সিঙ্ক ও আপডেট করা হয়েছে!');
      setTimeout(() => setFixSuccess(null), 3500);
    } catch (err) {
      console.error('Failed to sync authoritative students:', err);
    } finally {
      setIsFixing(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>Student Database Audit & Verification Report</span>
              </h3>
              <p className="text-xs text-slate-300 font-medium">
                COMMERCE POINT — দ্বাদশ শ্রেণি ব্যাচ এ ও বি ডাটাবেজ ভেরিফিকেশন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Fix Success Notification */}
          {fixSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{fixSuccess}</span>
            </div>
          )}

          {/* Overall Status Banner */}
          {report.overallValid ? (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-black text-emerald-950">
                  ভেরিফিকেশন স্ট্যাটাস: ১০০% সঠিক ও সম্পূর্ণ
                </h4>
                <p className="text-xs text-emerald-700 mt-0.5">
                  দ্বাদশ শ্রেণির ব্যাচ এ (৩১ জন) এবং ব্যাচ বি (১৩ জন)-এর সকল শিক্ষার্থীর নাম, রোল ও User ID নির্ধারিত তালিকা অনুযায়ী হুবহু মিলেছে।
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-black text-amber-950">
                  সতর্কতা: ডাটাবেজে কিছু অমিল শনাক্ত করা হয়েছে
                </h4>
                <p className="text-xs text-amber-700 mt-0.5">
                  নিচের রিপোর্টটি দেখুন এবং প্রয়োজনে &apos;Auto-Sync Authoritative Data&apos; বাটনে চাপুন।
                </p>
              </div>
            </div>
          )}

          {/* Cards for Class 12 Batch A and Batch B */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Batch A Card */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600 inline-block"></span>
                  <span>Class 12 — Batch A</span>
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                  CP/C-12/B-A 001 - 031
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Expected Students:</span>
                  <strong className="text-slate-900">{report.class12A.expectedStudents}</strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Correct Students:</span>
                  <strong className={report.class12A.correctStudents === 31 ? 'text-emerald-700' : 'text-amber-700'}>
                    {report.class12A.correctStudents}
                  </strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Missing Students:</span>
                  <strong className={report.class12A.missingStudents === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12A.missingStudents}
                  </strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Duplicate User IDs:</span>
                  <strong className={report.class12A.duplicateUserIds === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12A.duplicateUserIds}
                  </strong>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600">Incorrect Batch Mapping:</span>
                  <strong className={report.class12A.incorrectBatchMapping === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12A.incorrectBatchMapping}
                  </strong>
                </div>
              </div>
            </div>

            {/* Batch B Card */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
                  <span>Class 12 — Batch B</span>
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  CP/C-12/B-B 001 - 013
                </span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Expected Students:</span>
                  <strong className="text-slate-900">{report.class12B.expectedStudents}</strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Correct Students:</span>
                  <strong className={report.class12B.correctStudents === 13 ? 'text-emerald-700' : 'text-amber-700'}>
                    {report.class12B.correctStudents}
                  </strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Missing Students:</span>
                  <strong className={report.class12B.missingStudents === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12B.missingStudents}
                  </strong>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-600">Duplicate User IDs:</span>
                  <strong className={report.class12B.duplicateUserIds === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12B.duplicateUserIds}
                  </strong>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600">Incorrect Batch Mapping:</span>
                  <strong className={report.class12B.incorrectBatchMapping === 0 ? 'text-emerald-700' : 'text-rose-700'}>
                    {report.class12B.incorrectBatchMapping}
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* Class 11 Status */}
          <div className="p-3 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              <span className="font-bold text-slate-800">Class 11 — Batch A (একাদশ শ্রেণি):</span>
              <span className="text-slate-600">{report.class11Count} জন শিক্ষার্থী</span>
            </div>
            <span className="inline-flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
              <Check className="w-3 h-3" /> সম্পূর্ণ অক্ষত ও অপরিবর্তিত
            </span>
          </div>

          {/* Mismatches details (if any) */}
          {(report.class12A.mismatches.length > 0 || report.class12B.mismatches.length > 0) && (
            <div className="p-3.5 rounded-xl border border-rose-200 bg-rose-50/50 space-y-2">
              <h5 className="text-xs font-bold text-rose-900">শনাক্তকৃত সমস্যাসমূহ (Mismatches):</h5>
              <div className="space-y-1.5 text-[11px] max-h-40 overflow-y-auto">
                {report.class12A.mismatches.map((m) => (
                  <div key={`a-${m.roll}`} className="p-1.5 bg-white rounded border border-rose-200 text-rose-800">
                    <strong>Batch A [Roll {m.roll}]:</strong> {m.issue} (প্রত্যাশিত: {m.expectedName}, {m.expectedUserId})
                  </div>
                ))}
                {report.class12B.mismatches.map((m) => (
                  <div key={`b-${m.roll}`} className="p-1.5 bg-white rounded border border-rose-200 text-rose-800">
                    <strong>Batch B [Roll {m.roll}]:</strong> {m.issue} (প্রত্যাশিত: {m.expectedName}, {m.expectedUserId})
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Authoritative Text Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>Verification Output Text (Section 7 Format):</span>
              </label>
              <button
                type="button"
                onClick={handleCopyText}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Report'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-900 text-slate-100 text-[11px] font-mono whitespace-pre overflow-x-auto shadow-inner">
              {report.summaryText}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleForceResync}
            disabled={isFixing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            title="Authoritative ডেটাসেট অনুযায়ী ক্লাস ১২-এর নাম ও আইডি পুনরায় সিঙ্ক করুন"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFixing ? 'animate-spin' : ''}`} />
            <span>{isFixing ? 'সিঙ্ক হচ্ছে...' : 'Auto-Sync Authoritative Data'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
          >
            বন্ধ করুন (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
