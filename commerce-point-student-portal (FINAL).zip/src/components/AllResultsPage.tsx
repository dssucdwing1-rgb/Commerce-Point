import React, { useState } from 'react';
import {
  ClipboardList,
  PlusCircle,
  Trash2,
  Edit,
  Eye,
  Calendar,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertCircle,
  Loader2,
  TableProperties,
} from 'lucide-react';
import { Exam, Student, AuthUser, Subject } from '../types';
import { toBengaliNum } from '../data/initialData';
import {
  exportAllExamsToExcel,
  exportAllExamsToCsv,
  exportSingleExamToExcel,
  exportSingleExamToCsv,
  exportMasterResultExcel,
} from '../services/excelExport';

interface AllResultsPageProps {
  exams: Exam[];
  students: Student[];
  currentUser?: AuthUser;
  currentSubject?: Subject;
  onOpenExam: (exam: Exam) => void;
  onEditExam: (exam: Exam) => void;
  onDeleteExam: (exam: Exam) => void;
  onNewExam: () => void;
}

export function AllResultsPage({
  exams,
  students,
  currentUser,
  currentSubject,
  onOpenExam,
  onEditExam,
  onDeleteExam,
  onNewExam,
}: AllResultsPageProps) {
  const [exportingType, setExportingType] = useState<string | null>(null);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // Check if current user has Teacher/Admin privileges
  const isTeacher = currentUser?.role === 'admin';

  // Sort exams by date descending (latest first) for listing
  const sortedExams = [...exams].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const showToast = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification((prev) => (prev?.message === message ? null : prev));
    }, 4000);
  };

  // 1. Export All Results to Excel (.xlsx)
  const handleExportAllExcel = async () => {
    if (exams.length === 0) {
      showToast('error', 'Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
      return;
    }
    try {
      setExportingType('all-excel');
      await new Promise((r) => setTimeout(r, 200)); // Smooth loading transition
      await exportAllExamsToExcel(exams, students);
      showToast('success', 'Excel Downloaded Successfully! সকল ফলাফল এক্সেল ফাইল ডাউনলোড হয়েছে।');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'এক্সেল ডাউনলোড করার সময় সমস্যা হয়েছে।';
      showToast('error', msg);
    } finally {
      setExportingType(null);
    }
  };

  // 2. Export All Results to CSV
  const handleExportAllCsv = async () => {
    if (exams.length === 0) {
      showToast('error', 'Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
      return;
    }
    try {
      setExportingType('all-csv');
      await new Promise((r) => setTimeout(r, 200));
      exportAllExamsToCsv(exams, students);
      showToast('success', 'CSV Downloaded Successfully! সকল ফলাফল CSV ফাইল ডাউনলোড হয়েছে।');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'CSV ডাউনলোড করার সময় সমস্যা হয়েছে।';
      showToast('error', msg);
    } finally {
      setExportingType(null);
    }
  };

  // 3. Export Teacher-Only Master Result Excel
  const handleExportMasterExcel = async () => {
    if (!isTeacher) {
      showToast('error', 'শুধুমাত্র শিক্ষকগণ মাস্টার এক্সেল ডাউনলোড করতে পারবেন।');
      return;
    }
    if (exams.length === 0) {
      showToast('error', 'Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।');
      return;
    }
    try {
      setExportingType('master-excel');
      await new Promise((r) => setTimeout(r, 300));
      await exportMasterResultExcel(exams, students, currentUser?.role);
      showToast('success', 'Excel Downloaded Successfully! সকল শিক্ষার্থীর পূর্ণাঙ্গ মাস্টার এক্সেল শীট ডাউনলোড হয়েছে।');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'মাস্টার এক্সেল ডাউনলোড করার সময় সমস্যা হয়েছে।';
      showToast('error', msg);
    } finally {
      setExportingType(null);
    }
  };

  // 4. Export Single Exam to Excel (.xlsx)
  const handleExportSingleExcel = async (exam: Exam) => {
    try {
      setExportingType(`single-excel-${exam.id}`);
      await new Promise((r) => setTimeout(r, 150));
      await exportSingleExamToExcel(exam, students);
      showToast('success', `Excel Downloaded Successfully! "${exam.name}" পরীক্ষার এক্সেল ফাইল ডাউনলোড হয়েছে।`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'এই পরীক্ষার জন্য কোনো ফলাফল পাওয়া যায়নি।';
      showToast('error', msg);
    } finally {
      setExportingType(null);
    }
  };

  // 5. Export Single Exam to CSV
  const handleExportSingleCsv = (exam: Exam) => {
    try {
      setExportingType(`single-csv-${exam.id}`);
      exportSingleExamToCsv(exam, students);
      showToast('success', `CSV Downloaded Successfully! "${exam.name}" পরীক্ষার CSV ফাইল ডাউনলোড হয়েছে।`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'এই পরীক্ষার জন্য কোনো ফলাফল পাওয়া যায়নি।';
      showToast('error', msg);
    } finally {
      setExportingType(null);
    }
  };

  return (
    <div id="page-all-results" className="space-y-5 pb-8 relative">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-5 right-5 z-50 max-w-md animate-fade-in shadow-xl rounded-xl overflow-hidden pointer-events-auto">
          <div
            className={`flex items-center gap-3 px-4 py-3 border text-sm font-semibold ${
              notification.type === 'success'
                ? 'bg-emerald-900/95 text-emerald-100 border-emerald-700'
                : 'bg-rose-900/95 text-rose-100 border-rose-700'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span className="flex-1">{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="text-xs uppercase font-bold text-slate-300 hover:text-white ml-2"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <h2 className="text-xl font-bold text-slate-900">
              সকল ফলাফল (All Results)
            </h2>
            {currentSubject && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-blue-950 to-indigo-950 text-amber-300 font-black text-sm sm:text-base border border-blue-800 shadow-xs">
                <span>📚</span>
                <span>{currentSubject.name}</span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            সংরক্ষিত সকল পরীক্ষার ফলাফল ও বিশদ তালিকা। এক্সেল অথবা CSV ফরম্যাটে ডাউনলোড করুন।
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            id="all-results-new-exam-btn"
            onClick={onNewExam}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            নতুন পরীক্ষা
          </button>
        </div>
      </div>

      {/* ========================================================
          1. CSV EXPORT / EXCEL DOWNLOAD SECTION (At Top of Page)
          ======================================================== */}
      <div
        id="all-results-export-section"
        className="bg-gradient-to-br from-emerald-50/90 via-teal-50/70 to-slate-50 border border-emerald-200/90 rounded-2xl p-4 sm:p-5 shadow-2xs space-y-3.5"
      >
        <div className="flex items-start sm:items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                📥 CSV Export / Excel Download
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                সিস্টেমে সংরক্ষিত সকল শিক্ষার্থীর ফলাফল ও পরীক্ষার ডেটা এক্সেল শিটে সংরক্ষণ করুন।
              </p>
            </div>
          </div>

          {isTeacher && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
              Teacher Verified
            </span>
          )}
        </div>

        {/* Export Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 pt-1 border-t border-emerald-100/80">
          {/* Button 1: All Results Excel (.xlsx) */}
          <button
            type="button"
            id="export-all-excel-btn"
            onClick={handleExportAllExcel}
            disabled={exportingType !== null || exams.length === 0}
            title="সকল শিক্ষার্থীর সকল পরীক্ষার ফলাফল সমন্বিত Excel ফাইলে ডাউনলোড করুন"
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold text-xs sm:text-sm shadow-xs transition-colors"
          >
            {exportingType === 'all-excel' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Excel তৈরি হচ্ছে...</span>
              </>
            ) : (
              <>
                <FileSpreadsheet className="w-4 h-4" />
                <span>সকল ফলাফল Excel ডাউনলোড</span>
              </>
            )}
          </button>

          {/* Button 2: All Results CSV */}
          <button
            type="button"
            id="export-all-csv-btn"
            onClick={handleExportAllCsv}
            disabled={exportingType !== null || exams.length === 0}
            title="সকল পরীক্ষার ফলাফল UTF-8 এনকোডেড CSV ফাইল হিসেবে ডাউনলোড করুন"
            className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm shadow-2xs transition-colors"
          >
            {exportingType === 'all-csv' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
                <span>CSV প্রস্তুত হচ্ছে...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-slate-500" />
                <span>CSV ডাউনলোড</span>
              </>
            )}
          </button>

          {/* Button 3: Teacher-Only Complete Result Excel (Master Result Sheet: 1 Row = 1 Student, Dual-tier Headers, Print-Formatted) */}
          {isTeacher && (
            <button
              type="button"
              id="export-master-excel-btn"
              onClick={handleExportMasterExcel}
              disabled={exportingType !== null || exams.length === 0}
              title="শিক্ষকদের জন্য এক্সক্লুসিভ Complete Result Excel: দুই স্তরের হেডার (Exam Name/Date ও CQ, MCQ, Total), তারিখ অনুযায়ী সাজানো, এবং প্রিন্ট-রেডি ফরম্যাট"
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-700 to-indigo-900 hover:from-indigo-800 hover:to-indigo-950 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm shadow-xs transition-colors cursor-pointer"
            >
              {exportingType === 'master-excel' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Preparing Master Excel...</span>
                </>
              ) : (
                <>
                  <TableProperties className="w-4 h-4 text-indigo-200" />
                  <span>📊 Complete Result Excel (Master Sheet)</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* ========================================================
          2. EXAMS LIST TABLE (With Individual Exam Excel Download)
          ======================================================== */}
      {sortedExams.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center shadow-2xs space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <ClipboardList className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">
            কোনো সংরক্ষিত পরীক্ষা নেই
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            নতুন পরীক্ষার নম্বর এন্ট্রি পেজ থেকে একটি পরীক্ষা যোগ করুন।
          </p>
          <button
            type="button"
            onClick={onNewExam}
            className="mt-2 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 text-white font-medium text-xs hover:bg-indigo-700 transition-colors shadow-xs"
          >
            পরীক্ষা এন্ট্রি শুরু করুন
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-3.5 sm:p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              মোট সংরক্ষিত পরীক্ষা: {toBengaliNum(sortedExams.length)}টি
            </span>
            <span className="text-xs text-slate-500">
              সারিতে ক্লিক করে বিস্তারিত দেখুন
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm" id="all-results-table">
              <thead className="bg-slate-100/90 text-slate-700 text-xs uppercase font-bold tracking-wider">
                <tr>
                  <th className="py-3 px-4 w-28 whitespace-nowrap">তারিখ (Date)</th>
                  <th className="py-3 px-4 min-w-[160px]">পরীক্ষার নাম (Exam Name)</th>
                  <th className="py-3 px-4 text-center w-28">Average (গড়)</th>
                  <th className="py-3 px-4 text-center min-w-[200px]">অ্যাকশন (Actions)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedExams.map((exam) => (
                  <tr
                    key={exam.id}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    onClick={() => onOpenExam(exam)}
                  >
                    {/* Date */}
                    <td className="py-3.5 px-4 text-xs font-semibold text-slate-600 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{exam.date}</span>
                      </div>
                    </td>

                    {/* Exam Name */}
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      <div className="flex flex-wrap items-center gap-2">
                        {currentSubject && (
                          <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-extrabold text-xs shadow-2xs shrink-0 border border-blue-950">
                            {currentSubject.name}
                          </span>
                        )}
                        <span className="text-sm font-bold text-slate-900">{exam.name}</span>
                        <span className="text-xs font-normal text-slate-400 hidden sm:inline">
                          (পূর্ণমান: {toBengaliNum(exam.totalFullMarks)})
                        </span>
                      </div>
                    </td>

                    {/* Average */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className="font-extrabold text-indigo-700 text-sm">
                          {toBengaliNum(exam.average)}
                        </span>
                        <span className="text-[11px] font-semibold text-emerald-600">
                          {toBengaliNum(exam.averagePercentage)}%
                        </span>
                      </div>
                    </td>

                    {/* Actions: View, 📥 Excel, CSV, Edit, Delete */}
                    <td
                      className="py-3.5 px-4 text-center"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        {/* 1. View Modal */}
                        <button
                          type="button"
                          title="বিস্তারিত ফলাফল দেখুন"
                          onClick={() => onOpenExam(exam)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* 2. Dedicated Individual Excel Download Button */}
                        <button
                          type="button"
                          id={`export-excel-${exam.id}`}
                          title="এই পরীক্ষার Excel ফাইল ডাউনলোড করুন (.xlsx)"
                          onClick={() => handleExportSingleExcel(exam)}
                          disabled={exportingType !== null}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white border border-emerald-200 text-xs font-bold transition-all shadow-2xs disabled:opacity-50"
                        >
                          {exportingType === `single-excel-${exam.id}` ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <FileSpreadsheet className="w-3.5 h-3.5" />
                          )}
                          <span>Excel</span>
                        </button>

                        {/* 3. Single CSV Download */}
                        <button
                          type="button"
                          id={`export-csv-${exam.id}`}
                          title="এই পরীক্ষার CSV ফাইল ডাউনলোড করুন"
                          onClick={() => handleExportSingleCsv(exam)}
                          disabled={exportingType !== null}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* 4. Edit */}
                        <button
                          type="button"
                          title="নম্বর সম্পাদনা করুন"
                          onClick={() => onEditExam(exam)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        {/* 5. Delete */}
                        <button
                          type="button"
                          title="মুছে ফেলুন"
                          onClick={() => onDeleteExam(exam)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
