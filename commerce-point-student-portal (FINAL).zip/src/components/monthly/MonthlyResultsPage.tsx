import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Download,
  Table,
  Filter,
  ArrowUpDown,
  BookOpen,
  User,
  CheckCircle2,
  FileSpreadsheet,
  Award,
  TrendingUp,
  Search,
  Eye,
  Trash2,
  Edit3,
  ExternalLink,
  ChevronDown,
  Clock,
  Sparkles,
  BarChart3,
  Users,
} from 'lucide-react';
import { Exam, Student, Subject, MonthOption, StudentMarkEntry } from '../../types';
import {
  extractAvailableMonths,
  filterExamsByMonth,
  formatMonthLabel,
  calculateStudentMonthlySummary,
} from './monthUtils';
import {
  exportMonthlyMasterExcel,
  exportSingleExamToExcel,
  exportStudentMonthlyExcel,
  exportSubjectMonthlyExcel,
  formatDisplayDate,
} from '../../services/excelExport';
import { exportMonthlyMasterPdf, exportStudentMonthlyPdf } from '../../services/pdfExport';
import { toBengaliNum, calculateGrade, getGradeBadgeColor } from '../../data/initialData';
import { rankStudentsForSubjectMonth } from '../../utils/ranking';
import { MonthlyMasterResultSheetModal } from './MonthlyMasterResultSheetModal';
import { MonthlyResultCardModal } from './MonthlyResultCardModal';
import { StudentMonthlyProgressAnalysis } from './StudentMonthlyProgressAnalysis';

interface MonthlyResultsPageProps {
  exams: Exam[];
  students: Student[];
  subjects: Subject[];
  onSelectExam?: (exam: Exam) => void;
  onEditExam?: (exam: Exam) => void;
  onDeleteExam?: (examId: string) => void;
  onNavigateToEntry?: () => void;
}

type MonthlyTab = 'exams' | 'student-analysis' | 'subject-summary' | 'subject-result' | 'student-result';

export const MonthlyResultsPage: React.FC<MonthlyResultsPageProps> = ({
  exams,
  students,
  subjects,
  onSelectExam,
  onEditExam,
  onDeleteExam,
  onNavigateToEntry,
}) => {
  // 1. Available Months extracted from exams
  const availableMonths = useMemo(() => extractAvailableMonths(exams), [exams]);

  // Selected Month state
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(() => {
    return availableMonths[0]?.key || '2026-09';
  });

  // Active Sub-Tab
  const [activeTab, setActiveTab] = useState<MonthlyTab>('exams');

  // Modals state
  const [isMasterSheetOpen, setIsMasterSheetOpen] = useState(false);
  const [selectedStudentForCard, setSelectedStudentForCard] = useState<Student | null>(null);

  // Filters for Exams Tab
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc'); // asc = date ascending, desc = latest first

  // Subject-wise Monthly Result sub-tab selection
  const [selectedSubjectIdForResult, setSelectedSubjectIdForResult] = useState<string>(() => {
    return subjects[0]?.id || 'ict';
  });

  // Student-wise Monthly Result sub-tab selection
  const [selectedStudentIdForResult, setSelectedStudentIdForResult] = useState<string>(() => {
    return students[0]?.id || '';
  });

  // Action feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isExportingMaster, setIsExportingMaster] = useState(false);
  const [isExportingMasterPdf, setIsExportingMasterPdf] = useState(false);

  // 2. Data in current selected month
  const examsInSelectedMonth = useMemo(() => {
    return filterExamsByMonth(exams, selectedMonthKey);
  }, [exams, selectedMonthKey]);

  const selectedMonthOption = useMemo(() => {
    return availableMonths.find((m) => m.key === selectedMonthKey) || formatMonthLabel(selectedMonthKey);
  }, [availableMonths, selectedMonthKey]);

  const monthLabel = 'label' in selectedMonthOption ? selectedMonthOption.label : selectedMonthOption.en;
  const monthBengaliLabel =
    'bengaliLabel' in selectedMonthOption ? selectedMonthOption.bengaliLabel : selectedMonthOption.bn;

  // Map subjects
  const subjectMap = useMemo(() => {
    const map = new Map<string, Subject>();
    subjects.forEach((s) => map.set(s.id, s));
    return map;
  }, [subjects]);

  // 3. Summary Statistics (Section 2)
  const stats = useMemo(() => {
    const totalExams = examsInSelectedMonth.length;
    const distinctSubjectIds = new Set(examsInSelectedMonth.map((e) => e.subjectId || 'ict'));
    const totalStudents = students.length;

    let totalEntries = 0;
    let sumPercentages = 0;
    let countedExams = 0;

    examsInSelectedMonth.forEach((exam) => {
      if (exam.marks) {
        (Object.values(exam.marks) as StudentMarkEntry[]).forEach((mark) => {
          if (mark && (mark.cq !== '' || mark.mcq !== '')) {
            totalEntries++;
          }
        });
      }
      if (exam.averagePercentage > 0) {
        sumPercentages += exam.averagePercentage;
        countedExams++;
      }
    });

    const batchAveragePercentage = countedExams > 0 ? Math.round(sumPercentages / countedExams) : 0;

    return {
      totalExams,
      subjectsExamined: distinctSubjectIds.size,
      totalStudents,
      totalResultEntries: totalEntries,
      batchAveragePercentage,
    };
  }, [examsInSelectedMonth, students]);

  // 4. Filtered & Sorted exams for Tab 1
  const filteredExams = useMemo(() => {
    let list = [...examsInSelectedMonth];

    if (selectedSubjectFilter !== 'all') {
      list = list.filter((e) => (e.subjectId || 'ict') === selectedSubjectFilter);
    }

    if (dateFilter.trim()) {
      list = list.filter((e) => e.date.includes(dateFilter.trim()));
    }

    list.sort((a, b) => {
      const diff = new Date(a.date).getTime() - new Date(b.date).getTime();
      return sortOrder === 'asc' ? diff : -diff;
    });

    return list;
  }, [examsInSelectedMonth, selectedSubjectFilter, dateFilter, sortOrder]);

  // 5. Subject Summary (Section 4)
  const subjectSummaries = useMemo(() => {
    const map = new Map<string, { examsCount: number; sumAvg: number; subject: Subject }>();

    examsInSelectedMonth.forEach((exam) => {
      const subId = exam.subjectId || 'ict';
      const subObj = subjectMap.get(subId) || {
        id: subId,
        name: subId.toUpperCase(),
        code: subId.toUpperCase(),
        isActive: true,
      };

      if (!map.has(subId)) {
        map.set(subId, { examsCount: 0, sumAvg: 0, subject: subObj });
      }

      const item = map.get(subId)!;
      item.examsCount++;
      item.sumAvg += exam.averagePercentage || 0;
    });

    return Array.from(map.values()).map(({ examsCount, sumAvg, subject }) => ({
      subject,
      examsCount,
      avgPercentage: examsCount > 0 ? Math.round(sumAvg / examsCount) : 0,
    }));
  }, [examsInSelectedMonth, subjectMap]);

  // 6. Selected Student Summary for Tab 4
  const selectedStudent = useMemo(() => {
    return students.find((s) => s.id === selectedStudentIdForResult) || students[0] || null;
  }, [students, selectedStudentIdForResult]);

  const studentMonthlySummary = useMemo(() => {
    if (!selectedStudent) return null;
    return calculateStudentMonthlySummary(selectedStudent, examsInSelectedMonth, subjects);
  }, [selectedStudent, examsInSelectedMonth, subjects]);

  // Handlers for Exports
  const handleExportMonthlyMasterExcel = async () => {
    try {
      setIsExportingMaster(true);
      setFeedback(null);
      await exportMonthlyMasterExcel(examsInSelectedMonth, students, monthLabel, subjects);
      setFeedback({ type: 'success', message: `${monthLabel}-এর মাস্টার এক্সেল সফলভাবে ডাউনলোড হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Excel export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    } finally {
      setIsExportingMaster(false);
    }
  };

  const handleExportMonthlyMasterPdf = async () => {
    try {
      setIsExportingMasterPdf(true);
      setFeedback({ type: 'success', message: `${monthLabel}-এর সম্পূর্ণ মাস্টার রেজাল্ট শিট PDF তৈরি হচ্ছে...` });
      await exportMonthlyMasterPdf(examsInSelectedMonth, students, monthLabel, subjects);
      setFeedback({ type: 'success', message: `${monthLabel}-এর মাস্টার রেজাল্ট শিট PDF প্রিভিউ খোলা হয়েছে।` });
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: unknown) {
      console.error('PDF export error:', err);
      const errorMsg = err instanceof Error ? err.message : 'PDF export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    } finally {
      setIsExportingMasterPdf(false);
    }
  };

  const handleExportSingleExam = async (exam: Exam) => {
    try {
      await exportSingleExamToExcel(exam, students);
      setFeedback({ type: 'success', message: `"${exam.name}" পরীক্ষার এক্সেল ফাইল ডাউনলোড হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'ফাইল তৈরিতে সমস্যা হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    }
  };

  const handleExportStudentMonthly = async () => {
    if (!selectedStudent) return;
    try {
      await exportStudentMonthlyExcel(selectedStudent, examsInSelectedMonth, monthLabel, subjects);
      setFeedback({ type: 'success', message: `${selectedStudent.name}-এর মাসিক এক্সেল ডাউনলোড হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'ফাইল তৈরিতে সমস্যা হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    }
  };

  const handleExportSubjectMonthly = async () => {
    const sub = subjectMap.get(selectedSubjectIdForResult);
    if (!sub) return;
    try {
      await exportSubjectMonthlyExcel(sub, examsInSelectedMonth, students, monthLabel);
      setFeedback({ type: 'success', message: `${sub.name} বিষয়ের মাসিক এক্সেল ডাউনলোড হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'ফাইল তৈরিতে সমস্যা হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Banner & Control Area */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                মাসিক ফলাফল ব্যবস্থাপনা (Monthly Results)
              </span>
              <span className="text-xs text-slate-400 font-medium">Academic Module</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              📅 মাসিক পরীক্ষা ও সমন্বিত ফলাফল
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              নির্দিষ্ট মাসের সকল পরীক্ষা, বিষয়ভিত্তিক মূল্যায়ন, মাস্টার রেজাল্ট শিট ও এক্সেল রপ্তানি।
            </p>
          </div>

          {/* Month Selector + Master Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Dynamic Month Selector */}
            <div className="relative">
              <label htmlFor="select-month-dropdown" className="sr-only">
                Select Month
              </label>
              <div className="flex items-center bg-slate-100 hover:bg-slate-200/80 border border-slate-300 rounded-xl px-3 py-2 transition-all cursor-pointer">
                <Calendar className="w-4 h-4 text-indigo-600 mr-2 shrink-0" />
                <select
                  id="select-month-dropdown"
                  value={selectedMonthKey}
                  onChange={(e) => setSelectedMonthKey(e.target.value)}
                  className="bg-transparent text-sm font-bold text-slate-800 pr-4 focus:outline-hidden cursor-pointer"
                >
                  {availableMonths.map((opt) => (
                    <option key={opt.key} value={opt.key}>
                      {opt.label} ({toBengaliNum(opt.examCount)}টি পরীক্ষা)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Access to Student Monthly Progress Analysis */}
            <button
              type="button"
              id="btn-goto-student-monthly-analysis"
              onClick={() => setActiveTab('student-analysis')}
              className={`py-2 px-3.5 font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 ${
                activeTab === 'student-analysis'
                  ? 'bg-amber-400 text-blue-950 shadow-sm ring-2 ring-amber-300'
                  : 'bg-indigo-800 hover:bg-indigo-900 text-white'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>⭐ শিক্ষার্থীর অগ্রগতি বিশ্লেষণ</span>
            </button>

            {/* Master Sheet Button */}
            <button
              type="button"
              id="btn-generate-monthly-sheet"
              onClick={() => setIsMasterSheetOpen(true)}
              className="py-2 px-3.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98"
            >
              <Table className="w-4 h-4 text-indigo-300" />
              <span>📊 Master Result Sheet</span>
            </button>

            {/* Download Monthly PDF Button */}
            <button
              type="button"
              id="btn-download-monthly-pdf"
              onClick={handleExportMonthlyMasterPdf}
              disabled={isExportingMasterPdf || examsInSelectedMonth.length === 0}
              className="py-2 px-3.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-300" />
              <span>📄 Download Master PDF</span>
            </button>

            {/* Download Monthly Excel Button */}
            <button
              type="button"
              id="btn-download-monthly-excel"
              onClick={handleExportMonthlyMasterExcel}
              disabled={isExportingMaster || examsInSelectedMonth.length === 0}
              className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
              <span>📥 Download Monthly Excel</span>
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`mt-4 p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              feedback.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{feedback.message}</span>
          </div>
        )}
      </div>

      {/* 2. Monthly Summary Cards (Section 2) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">মাসের মোট পরীক্ষা</span>
            <BookOpen className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {toBengaliNum(stats.totalExams)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">
            {monthLabel}
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">পরীক্ষা হওয়া বিষয়</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {toBengaliNum(stats.subjectsExamined)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">টি বিষয়ে পরীক্ষা</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">মোট শিক্ষার্থী</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {toBengaliNum(stats.totalStudents)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">নিবন্ধিত শিক্ষার্থী</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">ফলাফল এন্ট্রি সংখ্যা</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 tabular-nums">
            {toBengaliNum(stats.totalResultEntries)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">টি মার্কস রেকর্ড</span>
        </div>

        <div className="col-span-2 sm:col-span-1 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">গড় ব্যাচ শতকরা</span>
            <TrendingUp className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-indigo-700 tabular-nums">
            {stats.batchAveragePercentage > 0 ? `${toBengaliNum(stats.batchAveragePercentage)}%` : '-'}
          </div>
          <span className="text-[11px] text-slate-500 font-medium">মাসিক গড় সাফল্য</span>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-1.5 flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('exams')}
          className={`py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'exams'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>মাসের সকল পরীক্ষা ({toBengaliNum(examsInSelectedMonth.length)})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('student-analysis')}
          className={`py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'student-analysis'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>শিক্ষার্থীর মাসিক অগ্রগতি (Analysis)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('subject-summary')}
          className={`py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'subject-summary'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>বিষয়ভিত্তিক সারসংক্ষেপ ({toBengaliNum(subjectSummaries.length)})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('subject-result')}
          className={`py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'subject-result'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>বিষয়ভিত্তিক ফলাফল শিট</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('student-result')}
          className={`py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'student-result'
              ? 'bg-blue-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <User className="w-4 h-4" />
          <span>শিক্ষার্থীর মাসিক ফলাফল ও রেজাল্ট কার্ড</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: ALL EXAMS IN MONTH (Sections 3, 5, 6, 12) */}
      {/* ========================================================================= */}
      {activeTab === 'exams' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Filters Bar (Sections 5 & 6) */}
          <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Subject Filter (Section 5) */}
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-500 font-medium">বিষয়:</span>
                <select
                  value={selectedSubjectFilter}
                  onChange={(e) => setSelectedSubjectFilter(e.target.value)}
                  className="bg-transparent font-bold text-slate-800 focus:outline-hidden cursor-pointer"
                >
                  <option value="all">All Subjects (সকল বিষয়)</option>
                  {subjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date Filter (Section 6) */}
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
                <Search className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="text"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  placeholder="তারিখ দিয়ে খুঁজুন (e.g. 05)..."
                  className="bg-transparent font-medium text-slate-800 focus:outline-hidden w-40 text-xs"
                />
              </div>

              {/* Sort Order Toggle (Section 3) */}
              <button
                type="button"
                onClick={() => setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'))}
                className="flex items-center gap-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700 transition-all cursor-pointer"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-indigo-600" />
                <span>
                  {sortOrder === 'asc' ? 'তারিখ অনুযায়ী (Ascending)' : 'সর্বশেষ পরীক্ষা আগে (Latest First)'}
                </span>
              </button>
            </div>

            <div className="text-xs text-slate-500">
              ফলাফল: <strong className="text-slate-800">{toBengaliNum(filteredExams.length)}</strong>টি পরীক্ষা
            </div>
          </div>

          {/* Table (Section 3 & 12) */}
          <div className="result-table-container w-full overflow-x-auto scrollbar-thin">
            <table className="result-table min-w-max w-full text-left border-collapse text-xs">
              <thead className="bg-slate-100/80 text-slate-700 font-semibold border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="py-3 px-4">তারিখ (Date)</th>
                  <th className="py-3 px-4">বিষয় (Subject)</th>
                  <th className="py-3 px-4">পরীক্ষার নাম (Exam Name)</th>
                  <th className="py-3 px-4 text-center">পূর্ণমান (Marks)</th>
                  <th className="py-3 px-4 text-center">উপস্থিত শিক্ষার্থী</th>
                  <th className="py-3 px-4 text-center">গড় নম্বর ও শতকরা</th>
                  <th className="py-3 px-4 text-right">কার্যক্রম (Action)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredExams.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      এই মাসে কোনো পরীক্ষার তথ্য পাওয়া যায়নি।
                    </td>
                  </tr>
                ) : (
                  filteredExams.map((exam, idx) => {
                    const subObj = subjectMap.get(exam.subjectId || 'ict');
                    const subName = subObj ? subObj.name : (exam.subjectId || 'ICT').toUpperCase();

                    // Calculate attended count
                    let attended = 0;
                    if (exam.marks) {
                      (Object.values(exam.marks) as StudentMarkEntry[]).forEach((m) => {
                        if (m && (m.cq !== '' || m.mcq !== '')) attended++;
                      });
                    }

                    return (
                      <tr
                        key={exam.id}
                        className={`hover:bg-indigo-50/30 transition-colors ${
                          idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'
                        }`}
                      >
                        <td className="py-3 px-4 text-slate-700 whitespace-nowrap font-bold">
                          {formatDisplayDate(exam.date)}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="inline-block px-3 py-1 rounded-xl text-xs sm:text-sm font-black bg-blue-900 text-amber-300 border border-blue-950 shadow-2xs tracking-wide">
                            {subName}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900">
                          {exam.name}
                        </td>
                        <td className="py-3 px-4 text-center text-slate-600 tabular-nums">
                          CQ: {toBengaliNum(exam.cqFullMarks)} + MCQ: {toBengaliNum(exam.mcqFullMarks)} ={' '}
                          <strong className="text-slate-800">{toBengaliNum(exam.totalFullMarks)}</strong>
                        </td>
                        <td className="py-3 px-4 text-center text-slate-700 tabular-nums">
                          <strong className="text-slate-900">{toBengaliNum(attended)}</strong> /{' '}
                          {toBengaliNum(students.length)} জন
                        </td>
                        <td className="py-3 px-4 text-center tabular-nums">
                          <span className="font-bold text-slate-900">{toBengaliNum(exam.average)}</span>{' '}
                          <span className="text-[11px] text-indigo-600 font-semibold">
                            ({toBengaliNum(exam.averagePercentage)}%)
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* View / Modal */}
                            {onSelectExam && (
                              <button
                                type="button"
                                onClick={() => onSelectExam(exam)}
                                title="পরীক্ষার বিবরণ ও ফলাফল দেখুন"
                                className="p-1.5 text-indigo-600 hover:text-indigo-900 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                            )}

                            {/* Edit */}
                            {onEditExam && (
                              <button
                                type="button"
                                onClick={() => onEditExam(exam)}
                                title="পরীক্ষা সম্পাদনা করুন"
                                className="p-1.5 text-blue-600 hover:text-blue-900 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                            )}

                            {/* Download Single Exam Excel (Section 12) */}
                            <button
                              type="button"
                              onClick={() => handleExportSingleExam(exam)}
                              title="শুধুমাত্র এই পরীক্ষার এক্সেল ডাউনলোড করুন"
                              className="py-1 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Excel</span>
                            </button>

                            {/* Delete */}
                            {onDeleteExam && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (window.confirm(`আপনি কি "${exam.name}" পরীক্ষাটি ডিলিট করতে চান?`)) {
                                    onDeleteExam(exam.id);
                                  }
                                }}
                                title="পরীক্ষা মুছে ফেলুন"
                                className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* NEW TAB: STUDENT MONTHLY PROGRESS ANALYSIS */}
      {/* ========================================================================= */}
      {activeTab === 'student-analysis' && (
        <StudentMonthlyProgressAnalysis
          exams={exams}
          students={students}
          subjects={subjects}
          initialSelectedMonthKey={selectedMonthKey}
          initialSelectedStudentId={selectedStudentIdForResult || (students[0]?.id || '')}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 2: SUBJECT SUMMARY & MATRIX (Section 4 & 24) */}
      {/* ========================================================================= */}
      {activeTab === 'subject-summary' && (
        <div className="space-y-5">
          {/* Subject Exam Counts Table (Section 4) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  {monthLabel} – Subject Summary (বিষয়ভিত্তিক পরীক্ষার সংখ্যা)
                </h3>
                <p className="text-xs text-slate-500">
                  নির্বাচিত মাসে কোন বিষয়ে কতটি পরীক্ষা অনুষ্ঠিত হয়েছে এবং গড় সাফল্য।
                </p>
              </div>

              <span className="text-xs font-bold bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg border border-indigo-200">
                মোট {toBengaliNum(subjectSummaries.length)}টি বিষয়
              </span>
            </div>

            <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin">
              <table className="result-table min-w-max w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4">Subject (বিষয়)</th>
                    <th className="py-2.5 px-4 text-center">Number of Exams (পরীক্ষার সংখ্যা)</th>
                    <th className="py-2.5 px-4 text-center">গড় সাফল্য (Average %)</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {subjectSummaries.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-slate-400">
                        এই মাসে কোনো বিষয়ের পরীক্ষা নেই।
                      </td>
                    </tr>
                  ) : (
                    subjectSummaries.map((item, idx) => (
                      <tr key={item.subject.id} className={idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                        <td className="py-3 px-4 font-bold text-slate-900">
                          <div className="flex items-center gap-2">
                            <span className="inline-block px-3 py-1 rounded-xl bg-blue-900 text-amber-300 font-black text-sm sm:text-base border border-blue-950 shadow-2xs">
                              {item.subject.name}
                            </span>
                            {item.subject.bengaliName && item.subject.bengaliName !== item.subject.name && (
                              <span className="text-slate-500 text-xs font-semibold">
                                ({item.subject.bengaliName})
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-center font-bold text-slate-800 text-sm tabular-nums">
                          {toBengaliNum(item.examsCount)}
                        </td>
                        <td className="py-3 px-4 text-center font-semibold text-indigo-700 tabular-nums">
                          {toBengaliNum(item.avgPercentage)}%
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedSubjectIdForResult(item.subject.id);
                              setActiveTab('subject-result');
                            }}
                            className="py-1 px-3 bg-blue-50 hover:bg-blue-100 text-blue-900 rounded-lg text-xs font-bold transition-all cursor-pointer"
                          >
                            ফলাফল দেখুন →
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Academic Timeline / Matrix (Section 24) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
            <h3 className="font-bold text-slate-900 text-base mb-1">
              🗓️ {monthLabel} – পরীক্ষার পূর্ণাঙ্গ সময়সূচি (Examination Timeline)
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              তারিখ অনুযায়ী সকল পরীক্ষা এবং বিষয়ভিত্তিক তালিকা।
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {examsInSelectedMonth
                .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                .map((exam) => {
                  const subObj = subjectMap.get(exam.subjectId || 'ict');
                  const subName = subObj ? subObj.name : (exam.subjectId || 'ICT').toUpperCase();
                  return (
                    <div
                      key={exam.id}
                      className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-indigo-300 transition-all shadow-2xs"
                    >
                      <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                        <span className="font-bold text-indigo-700 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{formatDisplayDate(exam.date)}</span>
                        </span>
                        <span className="px-2.5 py-1 bg-blue-900 text-amber-300 rounded-lg text-xs font-black shadow-2xs border border-blue-950">
                          {subName}
                        </span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm line-clamp-1">{exam.name}</h4>
                      <div className="mt-2 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-600">
                        <span>পূর্ণমান: {toBengaliNum(exam.totalFullMarks)}</span>
                        <span>গড়: {toBengaliNum(exam.averagePercentage)}%</span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: SUBJECT MONTHLY RESULT (Section 13) */}
      {/* ========================================================================= */}
      {activeTab === 'subject-result' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                📊 বিষয়ভিত্তিক মাসিক ফলাফল শিট (Subject-wise Monthly Result)
              </h3>
              <p className="text-xs text-slate-500">
                নির্দিষ্ট বিষয়ে নির্বাচিত মাসে অনুষ্ঠিত সকল পরীক্ষার ফলাফল এবং মাসিক গড় নম্বর।
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Select Subject Dropdown */}
              <div className="flex items-center bg-slate-100 border border-slate-300 rounded-xl px-3 py-1.5 text-xs">
                <span className="text-slate-500 font-semibold mr-1.5">বিষয়:</span>
                <select
                  value={selectedSubjectIdForResult}
                  onChange={(e) => setSelectedSubjectIdForResult(e.target.value)}
                  className="bg-transparent font-bold text-slate-900 focus:outline-hidden cursor-pointer"
                >
                  {subjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Download Subject Excel */}
              <button
                type="button"
                onClick={handleExportSubjectMonthly}
                className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Subject Excel</span>
              </button>
            </div>
          </div>

          {/* Render Subject Result Table */}
          {(() => {
            const subjectExams = examsInSelectedMonth
              .filter((e) => (e.subjectId || 'ict') === selectedSubjectIdForResult)
              .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

            if (subjectExams.length === 0) {
              return (
                <div className="py-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  নির্বাচিত বিষয়ের জন্য {monthLabel}-এ কোনো পরীক্ষা পাওয়া যায়নি।
                </div>
              );
            }

            // Merit-based sorting: Total Marks descending, highest first, resolved by CQ/MCQ or roll
            const rankedStudents = rankStudentsForSubjectMonth(subjectExams, students);
            const isCompactTable = rankedStudents.length > 15;
            const cellPy = isCompactTable ? 'py-0.5' : 'py-1';
            const thPy = isCompactTable ? 'py-1' : 'py-1.5';

            return (
              <div className="space-y-2">
                <div className="px-3 py-1 bg-blue-50/80 border border-blue-200/60 rounded-lg flex items-center justify-between text-xs text-blue-900">
                  <span className="font-medium flex items-center gap-1.5">
                    <span>↔</span>
                    <span>সব কলাম দেখতে ডানে-বামে স্ক্রোল করুন (Scroll horizontally to view all results)</span>
                  </span>
                  <span className="text-[11px] text-blue-700 hidden sm:inline">মেধাক্রম, রোল ও নাম বামে স্থির থাকবে</span>
                </div>

                <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin shadow-2xs">
                  <table className="result-table min-w-max w-full text-left text-xs border-collapse leading-tight">
                    <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 text-[11px] sticky top-0 z-20 shadow-2xs">
                      <tr>
                        {/* 1st Column: মেধাক্রম / Position */}
                        <th className={`${thPy} px-2 border-r border-slate-200 sticky left-0 z-30 bg-slate-100 text-center font-bold text-amber-700 w-16 min-w-[64px] max-w-[64px]`}>
                          মেধাক্রম / Position
                        </th>
                        <th className={`${thPy} px-2 border-r border-slate-200 sticky left-[64px] z-30 bg-slate-100 w-12 min-w-[48px] max-w-[48px] text-center`}>
                          রোল
                        </th>
                        <th className={`${thPy} px-3 border-r border-slate-200 sticky left-[112px] z-30 bg-slate-100 w-[145px] min-w-[145px] max-w-[145px]`}>
                          শিক্ষার্থীর নাম
                        </th>
                        <th className={`${thPy} px-3 border-r border-slate-200 sticky left-[257px] z-30 bg-slate-100 w-[130px] min-w-[130px] max-w-[130px] shadow-[2px_0_4px_-1px_rgba(0,0,0,0.08)]`}>
                          Student ID
                        </th>
                        {subjectExams.map((exam) => (
                          <th
                            key={exam.id}
                            className={`${thPy} px-3 border-r border-slate-200 text-center whitespace-nowrap min-w-[140px]`}
                          >
                            <div>{formatDisplayDate(exam.date)}</div>
                            <div className="text-[10px] text-slate-500 font-normal">
                              {exam.name.slice(0, 20)} ({toBengaliNum(exam.totalFullMarks)})
                            </div>
                          </th>
                        ))}
                        <th className={`${thPy} px-3 border-r border-slate-200 text-center w-24 min-w-[80px]`}>উপস্থিতি</th>
                        <th className={`${thPy} px-3 border-r border-slate-200 text-center font-bold text-blue-900 w-28 min-w-[90px]`}>
                          মোট নম্বর
                        </th>
                        <th className={`${thPy} px-3 border-r border-slate-200 text-center font-bold text-blue-900 w-28 min-w-[90px]`}>
                          Monthly Average
                        </th>
                        <th className={`${thPy} px-3 text-center w-20 min-w-[70px]`}>শতকরা</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {rankedStudents.map((ranked, idx) => {
                        const st = ranked.student;
                        const studentIdCode = st.studentIdCode || `CP-${String(st.roll).padStart(3, '0')}`;
                        let attended = 0;
                        let sumMarks = 0;
                        let sumFull = 0;

                        subjectExams.forEach((e) => {
                          const mark = e.marks ? e.marks[st.id] : undefined;
                          if (mark && (mark.cq !== '' || mark.mcq !== '')) {
                            attended++;
                            sumMarks += mark.total;
                            sumFull += e.totalFullMarks;
                          }
                        });

                        const avg = attended > 0 ? Number((sumMarks / attended).toFixed(1)) : 0;
                        const pct = sumFull > 0 ? Math.round((sumMarks / sumFull) * 100) : 0;
                        const rowBgClass = idx % 2 === 1 ? 'bg-slate-50/90' : 'bg-white';

                        return (
                          <tr
                            key={st.id}
                            className={`hover:bg-indigo-50/30 transition-colors leading-tight ${rowBgClass}`}
                          >
                            {/* 1st Column: মেধাক্রম / Position */}
                            <td className={`${cellPy} px-1.5 border-r border-slate-200 text-center font-bold sticky left-0 z-10 ${rowBgClass} w-16 min-w-[64px] max-w-[64px]`}>
                              {ranked.isAbsent ? (
                                <span className="text-slate-400 font-semibold">—</span>
                              ) : ranked.position === 1 ? (
                                <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs">
                                  🥇 {ranked.positionBengali}
                                </span>
                              ) : ranked.position === 2 ? (
                                <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-slate-200 text-slate-800 border border-slate-300 shadow-2xs">
                                  🥈 {ranked.positionBengali}
                                </span>
                              ) : ranked.position === 3 ? (
                                <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-amber-50 text-amber-800 border border-amber-200 shadow-2xs">
                                  🥉 {ranked.positionBengali}
                                </span>
                              ) : (
                                <span className="font-bold text-slate-700">{ranked.positionBengali}</span>
                              )}
                            </td>
                            <td className={`${cellPy} px-2 border-r border-slate-200 text-center text-slate-700 font-bold tabular-nums sticky left-[64px] z-10 ${rowBgClass} w-12 min-w-[48px] max-w-[48px]`}>
                              {toBengaliNum(st.roll)}
                            </td>
                            <td className={`${cellPy} px-3 border-r border-slate-200 font-bold text-slate-900 whitespace-nowrap sticky left-[112px] z-10 ${rowBgClass} w-[145px] min-w-[145px] max-w-[145px]`}>
                              {st.name}
                            </td>
                            <td className={`${cellPy} px-3 border-r border-slate-200 font-mono text-slate-700 whitespace-nowrap sticky left-[257px] z-10 ${rowBgClass} w-[130px] min-w-[130px] max-w-[130px] shadow-[2px_0_4px_-1px_rgba(0,0,0,0.06)]`}>
                              {studentIdCode}
                            </td>

                            {subjectExams.map((exam) => {
                              const mark = exam.marks ? exam.marks[st.id] : undefined;
                              const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');
                              return (
                                <td
                                  key={`${st.id}-${exam.id}`}
                                  className={`${cellPy} px-3 border-r border-slate-200 text-center tabular-nums font-semibold`}
                                >
                                  {isAbsent ? (
                                    <span className="text-[10px] text-rose-500 font-normal">অনুপস্থিত</span>
                                  ) : (
                                    <span className="text-slate-800">{toBengaliNum(mark.total)}</span>
                                  )}
                                </td>
                              );
                            })}

                            <td className={`${cellPy} px-3 border-r border-slate-200 text-center text-slate-600 tabular-nums`}>
                              {toBengaliNum(attended)} / {toBengaliNum(subjectExams.length)}
                            </td>
                            <td className={`${cellPy} px-3 border-r border-slate-200 text-center font-bold text-slate-900 tabular-nums`}>
                              {attended > 0 ? toBengaliNum(sumMarks) : '-'}
                            </td>
                            <td className={`${cellPy} px-3 border-r border-slate-200 text-center font-bold text-blue-900 tabular-nums`}>
                              {attended > 0 ? toBengaliNum(avg) : '-'}
                            </td>
                            <td className={`${cellPy} px-3 text-center font-bold text-emerald-700 tabular-nums`}>
                              {attended > 0 ? `${toBengaliNum(pct)}%` : '-'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: STUDENT MONTHLY RESULT & RESULT CARD (Sections 14, 15, 16, 17) */}
      {/* ========================================================================= */}
      {activeTab === 'student-result' && (
        <div className="space-y-5">
          {/* Student Selector Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                👤 একজন শিক্ষার্থীর মাসিক ফলাফল (Student Monthly Result)
              </h3>
              <p className="text-xs text-slate-500">
                নির্দিষ্ট মাসে একজন শিক্ষার্থী যে যে বিষয়ের পরীক্ষায় অংশ নিয়েছে সব বিষয় একত্রে।
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {/* Select Student Dropdown */}
              <div className="flex items-center bg-slate-100 border border-slate-300 rounded-xl px-3 py-1.5 text-xs">
                <span className="text-slate-500 font-semibold mr-1.5">শিক্ষার্থী:</span>
                <select
                  value={selectedStudentIdForResult}
                  onChange={(e) => setSelectedStudentIdForResult(e.target.value)}
                  className="bg-transparent font-bold text-slate-900 focus:outline-hidden cursor-pointer max-w-[200px]"
                >
                  {students.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.roll}. {st.name} ({st.studentIdCode || `CP-${st.roll}`})
                    </option>
                  ))}
                </select>
              </div>

              {/* Download Student Excel (Section 26-B) */}
              <button
                type="button"
                onClick={handleExportStudentMonthly}
                className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Student Monthly Excel</span>
              </button>

              {/* View / Download Result Card PDF (Section 15 & 18) */}
              {selectedStudent && (
                <button
                  type="button"
                  onClick={() => setSelectedStudentForCard(selectedStudent)}
                  className="py-1.5 px-3.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Award className="w-3.5 h-3.5 text-amber-300" />
                  <span>📄 রেজাল্ট কার্ড (PDF)</span>
                </button>
              )}

              {/* Quick switch to full Analysis & Charts */}
              <button
                type="button"
                onClick={() => setActiveTab('student-analysis')}
                className="py-1.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                title="পূর্ণাঙ্গ গ্রাফ, চার্ট ও বিষয়ভিত্তিক বিস্তারিত মাসিক অগ্রগতি"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>অগ্রগতি চার্ট ও ট্রেন্ড</span>
              </button>
            </div>
          </div>

          {/* Student Overview & Stats */}
          {selectedStudent && studentMonthlySummary && (
            <div className="space-y-5">
              {/* Overall Performance Card (Section 17) */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                  <div>
                    <span className="text-xs text-slate-400 font-semibold uppercase">Student Profile</span>
                    <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                      <span>{selectedStudent.name}</span>
                      <span className="text-xs font-mono font-bold px-2 py-0.5 bg-slate-100 rounded-md text-slate-700">
                        {selectedStudent.studentIdCode || `CP-${selectedStudent.roll}`}
                      </span>
                    </h2>
                    <p className="text-xs text-slate-500">
                      শ্রেণি: {selectedStudent.academicClass || 'XI'} · রোল: {toBengaliNum(selectedStudent.roll)} · সেশন:{' '}
                      {selectedStudent.session || '2026'}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-500 font-medium block">মাসিক চূড়ান্ত গ্রেড</span>
                    <span className="text-2xl font-black text-indigo-700">
                      {studentMonthlySummary.overall.overallGrade}
                    </span>
                  </div>
                </div>

                {/* Performance KPI Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">অংশগ্রহণ ও উপস্থিতি</span>
                    <span className="font-bold text-slate-900 text-sm">
                      {toBengaliNum(studentMonthlySummary.overall.attendedExams)} /{' '}
                      {toBengaliNum(studentMonthlySummary.overall.totalExamsInMonth)}{' '}
                      <span className="text-xs font-normal text-slate-500">
                        ({toBengaliNum(studentMonthlySummary.overall.participationRate)}%)
                      </span>
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">মাসিক গড় নম্বর</span>
                    <span className="font-bold text-blue-900 text-sm tabular-nums">
                      {toBengaliNum(studentMonthlySummary.overall.averageMarks)}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">মাসিক গড় শতকরা</span>
                    <span className="font-bold text-emerald-700 text-sm tabular-nums">
                      {toBengaliNum(studentMonthlySummary.overall.averagePercentage)}%
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px]">সর্বোচ্চ / সর্বনিম্ন নম্বর</span>
                    <span className="font-bold text-slate-900 text-sm tabular-nums">
                      {toBengaliNum(studentMonthlySummary.overall.highestMarks)} /{' '}
                      {toBengaliNum(studentMonthlySummary.overall.lowestMarks)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Subject Performance Summary Table (Section 14 & 16) */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-3.5 sm:p-4">
                <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider mb-2.5 flex items-center gap-2">
                  <Award className="w-4 h-4 text-indigo-600" />
                  <span>বিষয়ভিত্তিক মাসিক ফলাফল (Subject Performance)</span>
                </h3>

                <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin">
                  <table className="result-table min-w-max w-full text-left text-xs border-collapse leading-tight">
                    <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-1.5 px-3">Subject (বিষয়)</th>
                        <th className="py-1.5 px-3 text-center">Exams (পরীক্ষা)</th>
                        <th className="py-1.5 px-3 text-center">Average (গড় নম্বর)</th>
                        <th className="py-1.5 px-3 text-center">Highest (সর্বোচ্চ)</th>
                        <th className="py-1.5 px-3 text-center">Lowest (সর্বনিম্ন)</th>
                        <th className="py-1.5 px-3 text-center">Grade (গ্রেড)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {studentMonthlySummary.subjectSummaries.map((sub, idx) => (
                        <tr key={sub.subjectId} className={`leading-tight ${idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}`}>
                          <td className="py-1 px-3 font-bold text-slate-900">
                            <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs border border-blue-950 shadow-2xs">
                              {sub.subjectName}
                            </span>
                          </td>
                          <td className="py-1 px-3 text-center text-slate-700 tabular-nums">
                            {toBengaliNum(sub.attendedCount)} / {toBengaliNum(sub.examsCount)}
                          </td>
                          <td className="py-1 px-3 text-center font-bold text-blue-900 tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.average) : '-'}
                          </td>
                          <td className="py-1 px-3 text-center text-emerald-700 font-bold tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.highest) : '-'}
                          </td>
                          <td className="py-1 px-3 text-center text-amber-700 tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.lowest) : '-'}
                          </td>
                          <td className="py-1 px-3 text-center font-bold">
                            <span className="text-slate-800">{sub.grade}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Detailed Exam-by-Exam Table for this Student */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-3.5 sm:p-4">
                <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wider mb-2.5 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  <span>পরীক্ষা ভিত্তিক বিস্তারিত নম্বর (Detailed Exam Breakdown)</span>
                </h3>

                <div className="result-table-container w-full overflow-x-auto border border-slate-200 rounded-xl scrollbar-thin">
                  <table className="result-table min-w-max w-full text-left text-xs border-collapse leading-tight">
                    <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="py-1.5 px-3">তারিখ</th>
                        <th className="py-1.5 px-3">বিষয়</th>
                        <th className="py-1.5 px-3">পরীক্ষার নাম</th>
                        <th className="py-1.5 px-2 text-center">CQ</th>
                        <th className="py-1.5 px-2 text-center">MCQ</th>
                        <th className="py-1.5 px-3 text-center font-bold">মোট নম্বর</th>
                        <th className="py-1.5 px-2 text-center">পূর্ণমান</th>
                        <th className="py-1.5 px-2 text-center">শতকরা</th>
                        <th className="py-1.5 px-2.5 text-center">গ্রেড</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {studentMonthlySummary.examEntries.map((e, idx) => (
                        <tr key={e.examId || idx} className={`leading-tight ${idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}`}>
                          <td className="py-1 px-3 text-slate-600 whitespace-nowrap">{formatDisplayDate(e.date)}</td>
                          <td className="py-1 px-3 whitespace-nowrap">
                            <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs shadow-2xs border border-blue-950">
                              {e.subjectName}
                            </span>
                          </td>
                          <td className="py-1 px-3 text-slate-800">{e.examName}</td>
                          <td className="py-1 px-2 text-center text-slate-600 tabular-nums">
                            {e.isAbsent ? '-' : e.cq !== '' ? toBengaliNum(e.cq) : '-'}
                          </td>
                          <td className="py-1 px-2 text-center text-slate-600 tabular-nums">
                            {e.isAbsent ? '-' : e.mcq !== '' ? toBengaliNum(e.mcq) : '-'}
                          </td>
                          <td className="py-1 px-3 text-center font-bold text-slate-900 tabular-nums">
                            {e.isAbsent ? (
                              <span className="text-rose-500 font-normal">অনুপস্থিত</span>
                            ) : (
                              toBengaliNum(e.total)
                            )}
                          </td>
                          <td className="py-1 px-2 text-center text-slate-500 tabular-nums">
                            {toBengaliNum(e.fullMarks)}
                          </td>
                          <td className="py-1 px-2 text-center font-semibold text-indigo-700 tabular-nums">
                            {e.isAbsent ? '-' : `${toBengaliNum(e.percentage)}%`}
                          </td>
                          <td className="py-1 px-2.5 text-center">
                            <span className="font-bold text-slate-800">{e.grade}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Master Result Sheet Modal (Sections 7, 8, 9, 10, 11) */}
      <MonthlyMasterResultSheetModal
        isOpen={isMasterSheetOpen}
        onClose={() => setIsMasterSheetOpen(false)}
        examsInMonth={examsInSelectedMonth}
        students={students}
        monthLabel={monthLabel}
        subjects={subjects}
      />

      {/* Monthly Academic Result Card Modal (Sections 15 - 20) */}
      {selectedStudentForCard && (
        <MonthlyResultCardModal
          isOpen={!!selectedStudentForCard}
          onClose={() => setSelectedStudentForCard(null)}
          student={selectedStudentForCard}
          examsInMonth={examsInSelectedMonth}
          monthLabel={monthLabel}
          subjects={subjects}
        />
      )}
    </div>
  );
};
