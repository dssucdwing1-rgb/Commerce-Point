import React, { useState } from 'react';
import {
  X,
  Download,
  FileText,
  Search,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Loader2,
  Table,
  ArrowRightLeft,
  Trophy,
} from 'lucide-react';
import { Exam, Student, Subject } from '../../types';
import { exportMonthlyMasterExcel, formatDisplayDate } from '../../services/excelExport';
import { exportMonthlyMasterPdf } from '../../services/pdfExport';
import { toBengaliNum } from '../../data/initialData';
import { rankStudentsForMonthlyMaster } from '../../utils/ranking';
import { COMMERCE_POINT_LOGO_BASE64 } from '../../styles/pdfPrintStyles';

interface MonthlyMasterResultSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  examsInMonth: Exam[];
  students: Student[];
  monthLabel: string;
  subjects: Subject[];
}

export const MonthlyMasterResultSheetModal: React.FC<MonthlyMasterResultSheetModalProps> = ({
  isOpen,
  onClose,
  examsInMonth,
  students,
  monthLabel,
  subjects,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isExportingExcel, setIsExportingExcel] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  // Sort exams chronologically
  const sortedExams = [...examsInMonth].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  // Rank students strictly by Total Obtained Marks descending across all exams in month
  const rankedStudents = rankStudentsForMonthlyMaster(sortedExams, students);
  const isCompact = rankedStudents.length > 15;
  const cellPy = isCompact ? 'py-0.5' : 'py-1';
  const thPy = isCompact ? 'py-1' : 'py-1.5';

  // Filter students by search
  const filteredStudents = rankedStudents.filter((r) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const id = (r.student.studentIdCode || '').toLowerCase();
    return r.student.name.toLowerCase().includes(q) || id.includes(q) || String(r.student.roll).includes(q);
  });

  const handleExportExcel = async () => {
    try {
      setIsExportingExcel(true);
      setFeedback(null);
      await exportMonthlyMasterExcel(examsInMonth, students, monthLabel, subjects);
      setFeedback({ type: 'success', message: 'Monthly Master Result Excel সফলভাবে ডাউনলোড হয়েছে।' });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Excel export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    } finally {
      setIsExportingExcel(false);
    }
  };

  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      setFeedback({ type: 'success', message: 'সম্পূর্ণ মাসিক রেজাল্ট শিট পিডিএফ প্রস্তুত হচ্ছে...' });
      await exportMonthlyMasterPdf(examsInMonth, students, monthLabel, subjects);
      setFeedback({ type: 'success', message: 'Monthly Master Result PDF প্রিভিউ খোলা হয়েছে। রিভিউ করে ডাউনলোড করুন।' });
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: unknown) {
      console.error('Master PDF generation error:', err);
      const errorMsg = err instanceof Error ? err.message : 'PDF export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: errorMsg });
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white w-full max-w-[1450px] xl:max-w-[1550px] rounded-2xl shadow-2xl flex flex-col max-h-[96vh] overflow-hidden border border-slate-200">
        {/* Top Header */}
        <div className="px-4 py-3 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 p-1 flex items-center justify-center shrink-0 border border-white/20 shadow-xs">
              <img src={COMMERCE_POINT_LOGO_BASE64} alt="COMMERCE POINT Logo" className="w-full h-full object-contain" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                মাসিক মাস্টার রেজাল্ট শিট (Monthly Master Examination Result Sheet)
              </h2>
              <p className="text-xs text-slate-300">
                মাস: <span className="text-amber-400 font-bold">{monthLabel}</span> · মোট পরীক্ষা: {toBengaliNum(sortedExams.length)}টি · শিক্ষার্থী: {toBengaliNum(students.length)} জন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Download Master PDF Button */}
            <button
              type="button"
              onClick={handleExportPdf}
              disabled={isExportingPdf || isExportingExcel}
              className="py-1.5 px-3 sm:px-3.5 bg-blue-700 hover:bg-blue-600 text-white font-semibold text-xs sm:text-sm rounded-lg flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
              title="সম্পূর্ণ মাস্টার রেজাল্ট শিট PDF ডাউনলোড করুন"
            >
              {isExportingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>পিডিএফ তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 text-amber-300" />
                  <span>Download Master PDF</span>
                </>
              )}
            </button>

            {/* Download Master Excel Button */}
            <button
              type="button"
              onClick={handleExportExcel}
              disabled={isExportingExcel || isExportingPdf}
              className="py-1.5 px-3 sm:px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm rounded-lg flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
              title="সম্পূর্ণ মাস্টার রেজাল্ট শিট Excel ডাউনলোড করুন"
            >
              {isExportingExcel ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>এক্সেল তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Master Excel</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Feedback message banner */}
        {feedback && (
          <div
            className={`px-4 py-2 text-xs font-semibold flex items-center gap-1.5 shrink-0 ${
              feedback.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200' : 'bg-rose-50 text-rose-800 border-b border-rose-200'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Search & Meta Bar with Horizontal Scroll Notice */}
        <div className="px-4 py-2 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="relative w-full max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="শিক্ষার্থীর নাম বা Student ID দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium focus:outline-hidden focus:border-indigo-600"
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-blue-900 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200/70">
            <ArrowRightLeft className="w-3.5 h-3.5 text-blue-700 animate-pulse" />
            <span className="font-medium">
              ডানে-বামে স্ক্রোল করুন (Scroll horizontally to view all results)
            </span>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span>
              প্রদর্শিত শিক্ষার্থী: <strong className="text-slate-800">{toBengaliNum(filteredStudents.length)}</strong> জন
            </span>
          </div>
        </div>

        {/* Master Sheet Table Container with Full Horizontal & Vertical Scrolling */}
        <div className="flex-1 overflow-auto p-3">
          <div className="result-table-container w-full overflow-x-auto overflow-y-auto max-h-[calc(88vh-140px)] border border-slate-200 rounded-xl relative shadow-xs scrollbar-thin">
            <table className="result-table min-w-max w-full text-left border-collapse text-xs">
              <thead className="sticky top-0 z-30 shadow-xs">
                {/* Level 1 Header: Groups */}
                <tr className="bg-slate-900 text-white font-semibold text-[11px]">
                  {/* Sticky Position Column */}
                  <th
                    rowSpan={2}
                    className={`${thPy} px-2 border-r border-slate-700 sticky left-0 z-40 bg-slate-900 w-[78px] min-w-[78px] max-w-[78px] text-center text-amber-300 font-bold`}
                  >
                    মেধাক্রম / Position
                  </th>

                  {/* Sticky Student Name Column */}
                  <th
                    rowSpan={2}
                    className={`${thPy} px-3 border-r border-slate-700 sticky left-[78px] z-40 bg-slate-900 w-[145px] min-w-[145px] max-w-[145px]`}
                  >
                    শিক্ষার্থীর নাম
                  </th>

                  {/* Sticky Student ID Column */}
                  <th
                    rowSpan={2}
                    className={`${thPy} px-3 border-r border-slate-700 sticky left-[223px] z-40 bg-slate-900 w-[130px] min-w-[130px] max-w-[130px] shadow-[2px_0_5px_-1px_rgba(0,0,0,0.35)]`}
                  >
                    Student ID
                  </th>

                  {/* Roll Column */}
                  <th
                    rowSpan={2}
                    className={`${thPy} px-2 border-r border-slate-700 text-center w-12 min-w-[48px] bg-slate-900`}
                  >
                    রোল
                  </th>

                  {/* Exam Columns (Grouped by 3 sub-columns CQ, MCQ, Total) */}
                  {sortedExams.map((exam) => {
                    const sub = subjectMap.get(exam.subjectId || 'ict');
                    const subName = sub ? sub.name : (exam.subjectId || 'ICT').toUpperCase();
                    return (
                      <th
                        key={exam.id}
                        colSpan={3}
                        className="py-2 px-2 text-center border-r border-slate-700 border-b border-slate-700 whitespace-nowrap bg-slate-800 min-w-[180px]"
                      >
                        <div className="flex items-center justify-center gap-1.5 mb-1">
                          <span className="px-2 py-0.5 rounded-md bg-blue-950 text-amber-300 font-black text-xs border border-amber-400/40 shadow-2xs">
                            {subName}
                          </span>
                          <span className="text-slate-300 text-[11px] font-semibold">· {formatDisplayDate(exam.date)}</span>
                        </div>
                        <div className="text-[10px] text-slate-300 font-normal truncate max-w-[200px] mx-auto">
                          {exam.name} ({toBengaliNum(exam.totalFullMarks)})
                        </div>
                      </th>
                    );
                  })}

                  {/* Monthly Summary Statistics Header */}
                  <th
                    colSpan={4}
                    className="py-2 px-3 text-center border-b border-slate-700 bg-slate-800 text-amber-300 font-bold min-w-[240px]"
                  >
                    মাসিক মূল্যায়ন ও পরিসংখ্যান
                  </th>
                </tr>

                {/* Level 2 Sub-Header: CQ, MCQ, Total */}
                <tr className="bg-slate-800 text-slate-200 font-medium text-[10px]">
                  {sortedExams.map((exam) => (
                    <React.Fragment key={`${exam.id}-sub`}>
                      <th className="py-1.5 px-1.5 text-center border-r border-slate-700 w-[58px] min-w-[58px]">
                        CQ ({toBengaliNum(exam.cqFullMarks)})
                      </th>
                      <th className="py-1.5 px-1.5 text-center border-r border-slate-700 w-[58px] min-w-[58px]">
                        MCQ ({toBengaliNum(exam.mcqFullMarks)})
                      </th>
                      <th className="py-1.5 px-1.5 text-center border-r border-slate-700 w-[64px] min-w-[64px] font-bold text-white bg-slate-700/60">
                        Total ({toBengaliNum(exam.totalFullMarks)})
                      </th>
                    </React.Fragment>
                  ))}

                  <th className="py-1.5 px-2 text-center border-r border-slate-700 w-14 min-w-[56px]">উপস্থিত</th>
                  <th className="py-1.5 px-2 text-center border-r border-slate-700 w-16 min-w-[64px]">মোট প্রাপ্ত</th>
                  <th className="py-1.5 px-2 text-center border-r border-slate-700 w-14 min-w-[56px]">গড় নম্বর</th>
                  <th className="py-1.5 px-2 text-center w-16 min-w-[64px] font-bold text-amber-300">গড় শতকরা</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-200 bg-white font-medium">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td
                      colSpan={4 + sortedExams.length * 3 + 4}
                      className="py-10 text-center text-slate-400 font-normal"
                    >
                      কোনো শিক্ষার্থীর তথ্য পাওয়া যায়নি।
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((ranked, idx) => {
                    const st = ranked.student;
                    const studentIdCode = st.studentIdCode || `CP-${String(st.roll).padStart(3, '0')}`;
                    let attended = 0;
                    let totalObtained = 0;
                    let totalFull = 0;

                    const rowBgClass = idx % 2 === 1 ? 'bg-slate-50' : 'bg-white';

                    return (
                      <tr
                        key={st.id}
                        className={`hover:bg-indigo-50/50 transition-colors leading-tight ${rowBgClass}`}
                      >
                        {/* Sticky Position with solid background */}
                        <td className={`${cellPy} px-1.5 border-r border-slate-200 sticky left-0 z-20 ${rowBgClass} text-center font-bold text-slate-800 whitespace-nowrap w-[60px] min-w-[60px] max-w-[60px]`}>
                          {ranked.isAbsent ? (
                            <span className="text-slate-400 font-semibold">—</span>
                          ) : ranked.position === 1 ? (
                            <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs">
                              🥇 {ranked.positionBengali}
                            </span>
                          ) : ranked.position === 2 ? (
                            <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-slate-200 text-slate-800 border border-slate-300 shadow-2xs">
                              🥈 {ranked.positionBengali}
                            </span>
                          ) : ranked.position === 3 ? (
                            <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[11px] font-black bg-amber-50 text-amber-800 border border-amber-200 shadow-2xs">
                              🥉 {ranked.positionBengali}
                            </span>
                          ) : (
                            <span className="font-bold text-slate-700">{ranked.positionBengali}</span>
                          )}
                        </td>

                        {/* Sticky Student Name with solid background */}
                        <td className={`${cellPy} px-3 border-r border-slate-200 sticky left-[60px] z-20 ${rowBgClass} font-bold text-slate-900 whitespace-nowrap w-[145px] min-w-[145px] max-w-[145px]`}>
                          {st.name}
                        </td>

                        {/* Sticky Student ID with solid background and separation shadow */}
                        <td className={`${cellPy} px-3 border-r border-slate-200 sticky left-[205px] z-20 ${rowBgClass} font-mono font-semibold text-slate-700 whitespace-nowrap w-[130px] min-w-[130px] max-w-[130px] shadow-[2px_0_4px_-1px_rgba(0,0,0,0.06)]`}>
                          {studentIdCode}
                        </td>

                        {/* Roll */}
                        <td className={`${cellPy} px-2 border-r border-slate-200 text-center text-slate-500 tabular-nums w-12 min-w-[48px]`}>
                          {toBengaliNum(st.roll)}
                        </td>

                        {/* Exam Marks Columns */}
                        {sortedExams.map((exam) => {
                          const mark = exam.marks ? exam.marks[st.id] : undefined;
                          const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

                          if (!isAbsent && mark) {
                            attended++;
                            totalObtained += mark.total;
                            totalFull += exam.totalFullMarks;
                          }

                          return (
                            <React.Fragment key={`${st.id}-${exam.id}`}>
                              <td className={`${cellPy} px-1.5 text-center border-r border-slate-200 text-slate-600 tabular-nums w-[58px] min-w-[58px]`}>
                                {!isAbsent && mark && mark.cq !== '' ? toBengaliNum(mark.cq) : '-'}
                              </td>
                              <td className={`${cellPy} px-1.5 text-center border-r border-slate-200 text-slate-600 tabular-nums w-[58px] min-w-[58px]`}>
                                {!isAbsent && mark && mark.mcq !== '' ? toBengaliNum(mark.mcq) : '-'}
                              </td>
                              <td className={`${cellPy} px-1.5 text-center border-r border-slate-200 font-bold tabular-nums bg-slate-50/50 w-[64px] min-w-[64px]`}>
                                {isAbsent ? (
                                  <span className="text-[10px] text-rose-500 font-normal">অনুপস্থিত</span>
                                ) : (
                                  <span className="text-slate-900">{toBengaliNum(mark.total)}</span>
                                )}
                              </td>
                            </React.Fragment>
                          );
                        })}

                        {/* Monthly Summary Stats */}
                        <td className={`${cellPy} px-2 text-center border-r border-slate-200 text-slate-700 tabular-nums w-14 min-w-[56px]`}>
                          {toBengaliNum(attended)} / {toBengaliNum(sortedExams.length)}
                        </td>
                        <td className={`${cellPy} px-2 text-center border-r border-slate-200 font-bold text-slate-900 tabular-nums w-16 min-w-[64px] bg-slate-100/50`}>
                          {attended > 0 ? toBengaliNum(totalObtained) : '-'}
                        </td>
                        <td className={`${cellPy} px-2 text-center border-r border-slate-200 font-semibold text-blue-900 tabular-nums w-14 min-w-[56px]`}>
                          {attended > 0 ? toBengaliNum(Number((totalObtained / attended).toFixed(1))) : '-'}
                        </td>
                        <td className={`${cellPy} px-2 text-center font-bold text-emerald-700 tabular-nums w-16 min-w-[64px] bg-emerald-50/40`}>
                          {totalFull > 0
                            ? `${toBengaliNum(Math.round((totalObtained / totalFull) * 100))}%`
                            : '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <div>
            মোট কলাম: <strong className="text-slate-700">{toBengaliNum(sortedExams.length)}</strong>টি পরীক্ষা · মোট শিক্ষার্থী:{' '}
            <strong className="text-slate-700">{toBengaliNum(filteredStudents.length)}</strong> জন
          </div>
          <button
            type="button"
            onClick={onClose}
            className="py-1 px-4 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-lg cursor-pointer transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
