import React, { useRef, useState } from 'react';
import {
  X,
  Printer,
  Download,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Loader2,
  Award,
  BookOpen,
  Trophy,
} from 'lucide-react';
import { Student, Exam, Subject } from '../../types';
import { calculateStudentMonthlySummary, StudentMonthlySummary } from './monthUtils';
import { toBengaliNum, getGradeBadgeColor } from '../../data/initialData';
import { exportStudentMonthlyPdf } from '../../services/pdfExport';
import { getStudentMonthlyPosition, getStudentExamPosition } from '../../utils/ranking';
import { COMMERCE_POINT_LOGO_BASE64 } from '../../styles/pdfPrintStyles';

interface MonthlyResultCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student;
  examsInMonth: Exam[];
  monthLabel: string;
  subjects: Subject[];
  allStudents?: Student[];
}

export const MonthlyResultCardModal: React.FC<MonthlyResultCardModalProps> = ({
  isOpen,
  onClose,
  student,
  examsInMonth,
  monthLabel,
  subjects,
  allStudents,
}) => {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen || !student) return null;

  const summary: StudentMonthlySummary = calculateStudentMonthlySummary(student, examsInMonth, subjects);

  const studentIdCode = student.studentIdCode || `CP-${String(student.roll).padStart(3, '0')}`;

  const monthlyRank = allStudents && allStudents.length > 0
    ? getStudentMonthlyPosition(student.id, examsInMonth, allStudents)
    : null;

  const handleDownloadPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      setFeedback({ type: 'success', message: 'সম্পূর্ণ মাসিক রেজাল্ট কার্ড পিডিএফ প্রস্তুত হচ্ছে...' });

      await exportStudentMonthlyPdf(student, examsInMonth, monthLabel, subjects, allStudents);

      setFeedback({ type: 'success', message: 'মাসিক রেজাল্ট কার্ড PDF প্রিভিউ খোলা হয়েছে।' });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err) {
      console.error('PDF error', err);
      setFeedback({ type: 'error', message: 'পিডিএফ তৈরি করতে সমস্যা হয়েছে।' });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const overallGradeColor = getGradeBadgeColor(summary.overall.overallGrade);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl flex flex-col max-h-[94vh] overflow-hidden border border-slate-200">
        {/* Top Modal Controls */}
        <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                মাসিক ফলাফল বিবরণী (Monthly Academic Result Card)
              </h2>
              <p className="text-xs text-slate-300">
                {student.name} · {studentIdCode} · {monthLabel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="py-1.5 px-3 sm:px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm rounded-lg flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>তৈরি হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download PDF</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Feedback message banner */}
        {feedback && (
          <div
            className={`px-4 py-2 text-xs font-semibold flex items-center gap-1.5 shrink-0 ${
              feedback.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Scrollable Printable Container */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-slate-100/60 flex justify-center">
          <div
            ref={cardRef}
            id="monthly-card-print-area"
            className="printable-result-card print-page w-full max-w-[760px] bg-white border border-slate-300 p-5 sm:p-7 rounded-xl shadow-sm text-slate-900 font-sans flex flex-col justify-between"
            style={{ breakInside: 'avoid', pageBreakInside: 'avoid', minHeight: '840px' }}
          >
            {/* 1. Header Banner */}
            <div className="border-b-2 border-slate-800 pb-4 mb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl bg-red-50 border border-red-200 p-1 flex items-center justify-center shrink-0">
                  <img src={COMMERCE_POINT_LOGO_BASE64} alt="COMMERCE POINT Logo" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-tight">
                    COMMERCE POINT
                  </h1>
                  <p className="text-xs text-slate-600 font-medium">
                    HSC & Coaching Academic Care · Monthly Evaluation System
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-slate-900 text-white font-bold text-xs uppercase px-2.5 py-1 rounded">
                  Monthly Result Card
                </span>
                <p className="text-xs font-bold text-slate-700 mt-1">
                  মাস: <span className="text-blue-900">{monthLabel}</span>
                </p>
              </div>
            </div>

            {/* 2. Student Information Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 sm:p-4 mb-4 grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
              <div>
                <span className="text-slate-500 block text-[11px]">শিক্ষার্থীর নাম</span>
                <span className="font-bold text-slate-900 text-sm">{student.name}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">Student ID</span>
                <span className="font-mono font-bold text-slate-900 text-xs sm:text-sm">{studentIdCode}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">শ্রেণি ও রোল</span>
                <span className="font-bold text-slate-900 text-sm">
                  {student.academicClass || 'XI'} · রোল: {toBengaliNum(student.roll)}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">গ্রুপ ও সেশন</span>
                <span className="font-bold text-slate-900 text-sm">
                  {student.group || 'B-A'} · সেশন: {student.session || '2026'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">মাসিক অবস্থান</span>
                <span className="font-black text-blue-900 text-sm">
                  {monthlyRank && monthlyRank.positionBengali !== '—'
                    ? `${monthlyRank.positionBengali} / ${toBengaliNum(allStudents?.length || 0)}`
                    : '—'}
                </span>
              </div>
            </div>

            {/* 3. Detailed Examination List */}
            <div className="mb-5">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center justify-between border-b border-slate-200 pb-1">
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-blue-900" />
                  <span>মাসিক পরীক্ষা ভিত্তিক ফলাফল (Exam Results in {monthLabel})</span>
                </span>
                {monthlyRank && monthlyRank.positionBengali !== '—' && (
                  <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    মেধা অবস্থান: {monthlyRank.positionBengali}
                  </span>
                )}
              </h3>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs print-compact-table" style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}>
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 text-[11px]">
                    <tr>
                      <th className="py-1.5 px-2">তারিখ</th>
                      <th className="py-1.5 px-2">বিষয়</th>
                      <th className="py-1.5 px-2">পরীক্ষার নাম</th>
                      <th className="py-1.5 px-2 text-center text-blue-950 font-bold bg-slate-200/60">অবস্থান</th>
                      <th className="py-1.5 px-2 text-center">CQ</th>
                      <th className="py-1.5 px-2 text-center">MCQ</th>
                      <th className="py-1.5 px-2 text-center font-bold">মোট নম্বর</th>
                      <th className="py-1.5 px-2 text-center">পূর্ণমান</th>
                      <th className="py-1.5 px-2 text-center">শতকরা</th>
                      <th className="py-1.5 px-2 text-center">গ্রেড</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {summary.examEntries.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="py-6 text-center text-slate-400">
                          এই মাসে কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।
                        </td>
                      </tr>
                    ) : (
                      summary.examEntries.map((entry, idx) => {
                        const targetExam = examsInMonth.find((e) => e.id === entry.examId);
                        let examPosStr = '—';
                        if (allStudents && targetExam) {
                          const p = getStudentExamPosition(student.id, targetExam, allStudents);
                          examPosStr = p.positionBengali;
                        }

                        return (
                          <tr
                            key={entry.examId || idx}
                            className={idx % 2 === 1 ? 'bg-slate-50/50' : ''}
                            style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}
                          >
                            <td className="py-1 px-2 text-slate-600 whitespace-nowrap">{entry.date}</td>
                            <td className="py-1 px-2 whitespace-nowrap">
                              <span className="inline-block px-2 py-0.5 rounded-md bg-blue-900 text-amber-300 font-black text-xs shadow-2xs">
                                {entry.subjectName}
                              </span>
                            </td>
                            <td className="py-1 px-2 text-slate-900">{entry.examName}</td>
                            <td className="py-1 px-2 text-center font-bold text-blue-900 bg-slate-100/60">
                              {examPosStr}
                            </td>
                            <td className="py-1 px-2 text-center text-slate-700 tabular-nums">
                              {entry.isAbsent ? '-' : entry.cq !== '' ? entry.cq : '-'}
                            </td>
                            <td className="py-1 px-2 text-center text-slate-700 tabular-nums">
                              {entry.isAbsent ? '-' : entry.mcq !== '' ? entry.mcq : '-'}
                            </td>
                            <td className="py-1 px-2 text-center font-bold text-slate-900 tabular-nums">
                              {entry.isAbsent ? <span className="text-rose-600">অনুপস্থিত</span> : entry.total}
                            </td>
                            <td className="py-1 px-2 text-center text-slate-500 tabular-nums">{entry.fullMarks}</td>
                            <td className="py-1 px-2 text-center text-slate-700 tabular-nums">
                              {entry.isAbsent ? '-' : `${entry.percentage}%`}
                            </td>
                            <td className="py-1 px-2 text-center">
                              <span
                                className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  entry.grade === 'A+' || entry.grade === 'A'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : entry.grade === 'Absent'
                                    ? 'bg-rose-100 text-rose-800'
                                    : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {entry.grade}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 4. Subject Summary (Section 16) */}
            <div className="mb-5">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                <Award className="w-3.5 h-3.5 text-blue-900" />
                <span>মাসিক বিষয়ভিত্তিক সারসংক্ষেপ (Monthly Subject Performance)</span>
              </h3>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs print-compact-table" style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}>
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200 text-[11px]">
                    <tr>
                      <th className="py-1.5 px-2.5">বিষয় (Subject)</th>
                      <th className="py-1.5 px-2 text-center">মোট পরীক্ষা</th>
                      <th className="py-1.5 px-2 text-center">অংশগ্রহণ</th>
                      <th className="py-1.5 px-2 text-center">গড় নম্বর</th>
                      <th className="py-1.5 px-2 text-center">সর্বোচ্চ</th>
                      <th className="py-1.5 px-2 text-center">সর্বনিম্ন</th>
                      <th className="py-1.5 px-2 text-center">বিষয় গ্রেড</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {summary.subjectSummaries.map((sub, idx) => (
                      <tr
                        key={sub.subjectId || idx}
                        className={idx % 2 === 1 ? 'bg-slate-50/50' : ''}
                        style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}
                      >
                        <td className="py-1 px-2.5 font-bold text-slate-900">
                          <span className="inline-block px-2 py-0.5 rounded-md bg-blue-50 text-blue-950 font-black text-xs border border-blue-200">
                            {sub.subjectName}
                          </span>
                        </td>
                        <td className="py-1 px-2 text-center text-slate-700 tabular-nums">
                          {toBengaliNum(sub.examsCount)}
                        </td>
                        <td className="py-1 px-2 text-center text-slate-700 tabular-nums">
                          {toBengaliNum(sub.attendedCount)}
                        </td>
                        <td className="py-1 px-2 text-center font-bold text-slate-900 tabular-nums">
                          {sub.attendedCount > 0 ? sub.average : '-'}
                        </td>
                        <td className="py-1 px-2 text-center text-emerald-700 font-bold tabular-nums">
                          {sub.attendedCount > 0 ? sub.highest : '-'}
                        </td>
                        <td className="py-1 px-2 text-center text-amber-700 tabular-nums">
                          {sub.attendedCount > 0 ? sub.lowest : '-'}
                        </td>
                        <td className="py-1 px-2 text-center font-bold">
                          <span className="text-slate-800">{sub.grade}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 5. Monthly Overall Performance (Section 17) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 mb-5" style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}>
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5">
                মাসিক সামগ্রিক মূল্যায়ন (Monthly Overall Performance Summary)
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">মোট পরীক্ষা ও উপস্থিতি</span>
                  <span className="font-bold text-slate-900 text-sm">
                    {toBengaliNum(summary.overall.attendedExams)} / {toBengaliNum(summary.overall.totalExamsInMonth)}{' '}
                    <span className="text-xs text-slate-500 font-normal">
                      ({toBengaliNum(summary.overall.participationRate)}%)
                    </span>
                  </span>
                </div>

                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">মোট প্রাপ্ত নম্বর</span>
                  <span className="font-bold text-slate-900 text-sm tabular-nums">
                    {toBengaliNum(summary.overall.totalObtainedMarks)}{' '}
                    <span className="text-xs text-slate-500 font-normal">
                      / {toBengaliNum(summary.overall.totalFullMarks)}
                    </span>
                  </span>
                </div>

                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">মাসিক গড় ও শতকরা</span>
                  <span className="font-bold text-blue-900 text-sm tabular-nums">
                    {toBengaliNum(summary.overall.averageMarks)}{' '}
                    <span className="text-xs text-slate-500 font-normal">
                      ({toBengaliNum(summary.overall.averagePercentage)}%)
                    </span>
                  </span>
                </div>

                <div className="bg-white p-2 rounded-lg border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-slate-500 block text-[11px]">চূড়ান্ত গ্রেড</span>
                    <span className="text-xs text-slate-600 font-medium">মাসিক মূল্যায়ন</span>
                  </div>
                  <span
                    className={`text-lg font-black px-2.5 py-0.5 rounded-lg border ${overallGradeColor.bg} ${overallGradeColor.text} ${overallGradeColor.border}`}
                  >
                    {summary.overall.overallGrade}
                  </span>
                </div>
              </div>
            </div>

            {/* 6. Teacher Signature Block (margin-top: 8px for single page fit) */}
            <div
              style={{ pageBreakBefore: 'avoid', breakBefore: 'avoid', pageBreakInside: 'avoid', breakInside: 'avoid', marginTop: '8px' }}
              className="teacher-signature-block pt-3 border-t border-slate-200 flex items-end justify-between text-xs text-slate-800 mt-2 w-full"
            >
              <div className="text-center w-44">
                <div className="border-t border-dotted border-slate-500 w-full mb-1.5"></div>
                <span className="font-bold text-xs text-slate-900 block">শ্রেণি শিক্ষকের স্বাক্ষর</span>
                <span className="text-[10px] text-slate-500">COMMERCE POINT</span>
              </div>
              <div className="text-center text-[10px] text-slate-400">
                Printed from COMMERCE POINT ERP
              </div>
              <div className="text-center w-52">
                <div className="border-t border-dotted border-slate-500 w-full mb-1.5"></div>
                <span className="font-bold text-xs text-slate-900 block">পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</span>
                <span className="text-[10px] text-slate-500">COMMERCE POINT ACADEMY</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
