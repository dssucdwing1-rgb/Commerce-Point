import React, { useState, useMemo } from 'react';
import {
  User,
  Calendar,
  BookOpen,
  Award,
  TrendingUp,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  BarChart3,
  Layers,
  ArrowUpRight,
  Sparkles,
  ChevronDown,
  Filter,
  Search,
  RotateCcw,
  Clock,
  Printer,
} from 'lucide-react';
import { Exam, Student, Subject } from '../../types';
import { toBengaliNum, calculateGrade, getGradeBadgeColor } from '../../data/initialData';
import { formatDisplayDate, exportStudentMonthlyProgressExcel } from '../../services/excelExport';
import { exportStudentMonthlyProgressReportPdf } from '../../services/pdfExport';
import { getStudentExamPosition, getStudentMonthlyPosition } from '../../utils/ranking';
import { extractAvailableMonths, formatMonthLabel } from './monthUtils';

interface StudentMonthlyProgressAnalysisProps {
  exams: Exam[];
  students: Student[];
  subjects: Subject[];
  initialSelectedStudentId?: string;
  initialSelectedMonthKey?: string;
}

export const StudentMonthlyProgressAnalysis: React.FC<StudentMonthlyProgressAnalysisProps> = ({
  exams,
  students,
  subjects,
  initialSelectedStudentId = '',
  initialSelectedMonthKey = 'all',
}) => {
  // 1. Filter States
  const [selectedStudentId, setSelectedStudentId] = useState<string>(initialSelectedStudentId);
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(initialSelectedMonthKey);
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [selectedYearFilter, setSelectedYearFilter] = useState<string>('all');
  const [chartSubjectFilter, setChartSubjectFilter] = useState<string>('all');

  // Export states & feedback
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingCompletePdf, setIsExportingCompletePdf] = useState(false);
  const [isExportingExcel, setIsExportingExcel] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // 2. Extract Available Months & Years dynamically from Exams
  const availableMonths = useMemo(() => extractAvailableMonths(exams), [exams]);

  const availableYears = useMemo(() => {
    const years = new Set<string>();
    exams.forEach((exam) => {
      if (exam.date) {
        const y = exam.date.substring(0, 4);
        if (y) years.add(y);
      }
    });
    return Array.from(years).sort().reverse();
  }, [exams]);

  // Subject Map for fast lookup
  const subjectMap = useMemo(() => {
    const map = new Map<string, Subject>();
    subjects.forEach((s) => map.set(s.id, s));
    return map;
  }, [subjects]);

  // 3. Selected Student Object
  const selectedStudent = useMemo(() => {
    if (!selectedStudentId) return null;
    return students.find((s) => s.id === selectedStudentId) || null;
  }, [students, selectedStudentId]);

  // 4. Month Label for Display
  const currentMonthLabel = useMemo(() => {
    if (selectedMonthKey === 'all') {
      return selectedYearFilter !== 'all' ? `সকল মাস (${selectedYearFilter})` : 'সকল মাস (All Months)';
    }
    const found = availableMonths.find((m) => m.key === selectedMonthKey);
    if (found) return found.label;
    const f = formatMonthLabel(selectedMonthKey);
    return f.en || selectedMonthKey;
  }, [selectedMonthKey, selectedYearFilter, availableMonths]);

  // 5. Filter Exams according to Month, Year, and Student availability
  const relevantExams = useMemo(() => {
    return exams.filter((exam) => {
      // Year filter
      if (selectedYearFilter !== 'all') {
        const y = exam.date.substring(0, 4);
        if (y !== selectedYearFilter) return false;
      }
      // Month filter
      if (selectedMonthKey !== 'all') {
        const mKey = exam.date.substring(0, 7);
        if (mKey !== selectedMonthKey) return false;
      }
      return true;
    });
  }, [exams, selectedMonthKey, selectedYearFilter]);

  // 6. Chronologically sorted exams where the student participated or had marks recorded
  const studentExams = useMemo(() => {
    if (!selectedStudent) return [];

    let list = [...relevantExams];

    // Subject Filter
    if (selectedSubjectFilter !== 'all') {
      list = list.filter((e) => (e.subjectId || 'ict') === selectedSubjectFilter);
    }

    // Sort ascending by date
    list.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    return list;
  }, [relevantExams, selectedStudent, selectedSubjectFilter]);

  // 7. Student's Performance Aggregation for this Filtered Set
  const studentPerformance = useMemo(() => {
    if (!selectedStudent || studentExams.length === 0) {
      return null;
    }

    let attendedCount = 0;
    let absentCount = 0;
    let totalObtainedMarks = 0;
    let totalFullMarks = 0;
    let highestMarks = 0;
    let lowestMarks = 999999;
    const distinctSubjectIds = new Set<string>();

    // Detailed exam rows with ranking
    const examRows = studentExams.map((exam) => {
      const subId = exam.subjectId || 'ict';
      distinctSubjectIds.add(subId);
      const subObj = subjectMap.get(subId);
      const subjectName = subObj ? subObj.name : subId.toUpperCase();

      const mark = exam.marks ? exam.marks[selectedStudent.id] : undefined;
      const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');

      // Get rank
      const examRank = getStudentExamPosition(selectedStudent.id, exam, students);

      const cq = mark && mark.cq !== '' ? Number(mark.cq) : '';
      const mcq = mark && mark.mcq !== '' ? Number(mark.mcq) : '';
      const total = mark && !isAbsent ? Number(mark.total) || 0 : 0;
      const fullMarks = exam.totalFullMarks || 50;
      const percentage = mark && !isAbsent ? Number(mark.percentage) || 0 : 0;
      const grade = mark && !isAbsent ? mark.grade || calculateGrade(percentage) : 'Absent';

      if (!isAbsent && mark) {
        attendedCount++;
        totalObtainedMarks += total;
        totalFullMarks += fullMarks;
        if (total > highestMarks) highestMarks = total;
        if (total < lowestMarks) lowestMarks = total;
      } else {
        absentCount++;
      }

      return {
        examId: exam.id,
        date: exam.date,
        monthKey: exam.date.substring(0, 7),
        subjectId: subId,
        subjectName,
        examName: exam.name,
        cq,
        mcq,
        total,
        fullMarks,
        percentage,
        grade,
        isAbsent,
        positionDisplay: examRank.positionDisplay,
        positionBengali: examRank.positionBengali,
        positionNum: examRank.position,
      };
    });

    if (lowestMarks === 999999) lowestMarks = 0;
    const averageMarks = attendedCount > 0 ? Number((totalObtainedMarks / attendedCount).toFixed(1)) : 0;
    const averagePercentage = totalFullMarks > 0 ? Math.round((totalObtainedMarks / totalFullMarks) * 100) : 0;
    const participationRate = studentExams.length > 0 ? Math.round((attendedCount / studentExams.length) * 100) : 0;
    const overallGrade = attendedCount === 0 ? 'Absent' : calculateGrade(averagePercentage);

    // Subject-wise Grouping
    const subjectStatsMap = new Map<string, {
      subjectId: string;
      subjectName: string;
      examsCount: number;
      attendedCount: number;
      cqTotal: number;
      mcqTotal: number;
      obtainedTotal: number;
      fullTotal: number;
      positions: number[];
    }>();

    examRows.forEach((r) => {
      if (!subjectStatsMap.has(r.subjectId)) {
        subjectStatsMap.set(r.subjectId, {
          subjectId: r.subjectId,
          subjectName: r.subjectName,
          examsCount: 0,
          attendedCount: 0,
          cqTotal: 0,
          mcqTotal: 0,
          obtainedTotal: 0,
          fullTotal: 0,
          positions: [],
        });
      }
      const st = subjectStatsMap.get(r.subjectId)!;
      st.examsCount++;
      if (!r.isAbsent) {
        st.attendedCount++;
        if (typeof r.cq === 'number') st.cqTotal += r.cq;
        if (typeof r.mcq === 'number') st.mcqTotal += r.mcq;
        st.obtainedTotal += r.total;
        st.fullTotal += r.fullMarks;
        if (r.positionNum !== null) st.positions.push(r.positionNum);
      }
    });

    const subjectSummaries = Array.from(subjectStatsMap.values()).map((s) => {
      const avg = s.attendedCount > 0 ? Number((s.obtainedTotal / s.attendedCount).toFixed(1)) : 0;
      const pct = s.fullTotal > 0 ? Math.round((s.obtainedTotal / s.fullTotal) * 100) : 0;
      const grade = s.attendedCount > 0 ? calculateGrade(pct) : 'Absent';
      const bestPos = s.positions.length > 0 ? Math.min(...s.positions) : null;
      return {
        ...s,
        average: avg,
        percentage: pct,
        grade,
        bestPositionBengali: bestPos !== null ? toBengaliNum(bestPos) : '—',
      };
    });

    // Overall Monthly Position across batch
    let overallMonthlyPosStr = '—';
    if (students.length > 0 && studentExams.length > 0) {
      const pos = getStudentMonthlyPosition(selectedStudent.id, studentExams, students);
      overallMonthlyPosStr = pos.positionBengali !== '—'
        ? `${pos.positionBengali} / ${toBengaliNum(students.length)}`
        : '—';
    }

    return {
      totalExamsCount: studentExams.length,
      attendedCount,
      absentCount,
      participationRate,
      distinctSubjectsCount: distinctSubjectIds.size,
      totalObtainedMarks,
      totalFullMarks,
      averageMarks,
      averagePercentage,
      highestMarks,
      lowestMarks,
      overallGrade,
      overallMonthlyPosStr,
      examRows,
      subjectSummaries,
    };
  }, [studentExams, selectedStudent, students, subjectMap]);

  // 8. Multi-Month Trend & Comparison for this Student (All Available Months)
  const studentMultiMonthData = useMemo(() => {
    if (!selectedStudent) return [];

    // Take all exams for this student
    const allExamRows = exams
      .filter((exam) => {
        if (selectedYearFilter !== 'all') {
          return exam.date.substring(0, 4) === selectedYearFilter;
        }
        return true;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map((exam) => {
        const subId = exam.subjectId || 'ict';
        const subObj = subjectMap.get(subId);
        const subjectName = subObj ? subObj.name : subId.toUpperCase();
        const monthKey = exam.date.substring(0, 7);

        const mark = exam.marks ? exam.marks[selectedStudent.id] : undefined;
        const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');
        const examRank = getStudentExamPosition(selectedStudent.id, exam, students);

        const total = mark && !isAbsent ? Number(mark.total) || 0 : 0;
        const percentage = mark && !isAbsent ? Number(mark.percentage) || 0 : 0;

        return {
          examId: exam.id,
          monthKey,
          monthLabel: formatMonthLabel(monthKey).en,
          subjectId: subId,
          subjectName,
          examName: exam.name,
          date: exam.date,
          total,
          fullMarks: exam.totalFullMarks,
          percentage,
          isAbsent,
          positionBengali: examRank.positionBengali,
          positionNum: examRank.position,
        };
      });

    return allExamRows;
  }, [exams, selectedStudent, selectedYearFilter, students, subjectMap]);

  // 9. Subject-wise Monthly Trend (Grouped by Subject then Month)
  const subjectMonthlyTrend = useMemo(() => {
    if (!selectedStudent || studentMultiMonthData.length === 0) return [];

    const map = new Map<string, {
      subjectId: string;
      subjectName: string;
      months: {
        monthKey: string;
        monthLabel: string;
        totalMarks: number;
        fullMarks: number;
        avgPct: number;
        bestPosition: string;
        examCount: number;
      }[];
    }>();

    // Group by subject and month
    const grouped = new Map<string, {
      subjectId: string;
      subjectName: string;
      monthKey: string;
      total: number;
      full: number;
      positions: number[];
      count: number;
    }>();

    studentMultiMonthData.forEach((row) => {
      const groupKey = `${row.subjectId}_${row.monthKey}`;
      if (!grouped.has(groupKey)) {
        grouped.set(groupKey, {
          subjectId: row.subjectId,
          subjectName: row.subjectName,
          monthKey: row.monthKey,
          total: 0,
          full: 0,
          positions: [],
          count: 0,
        });
      }
      const item = grouped.get(groupKey)!;
      item.count++;
      if (!row.isAbsent) {
        item.total += row.total;
        item.full += row.fullMarks;
        if (row.positionNum !== null) item.positions.push(row.positionNum);
      }
    });

    grouped.forEach((item) => {
      if (!map.has(item.subjectId)) {
        map.set(item.subjectId, {
          subjectId: item.subjectId,
          subjectName: item.subjectName,
          months: [],
        });
      }
      const avgPct = item.full > 0 ? Math.round((item.total / item.full) * 100) : 0;
      const bestPos = item.positions.length > 0 ? toBengaliNum(Math.min(...item.positions)) : '—';
      map.get(item.subjectId)!.months.push({
        monthKey: item.monthKey,
        monthLabel: formatMonthLabel(item.monthKey).en,
        totalMarks: item.total,
        fullMarks: item.full,
        avgPct,
        bestPosition: bestPos,
        examCount: item.count,
      });
    });

    return Array.from(map.values());
  }, [studentMultiMonthData, selectedStudent]);

  // 10. Chart Data Points (Filtered by Chart Subject Filter)
  const chartData = useMemo(() => {
    if (!studentPerformance) return [];

    let rows = studentPerformance.examRows;
    if (chartSubjectFilter !== 'all') {
      rows = rows.filter((r) => r.subjectId === chartSubjectFilter);
    }

    return rows.map((r, i) => ({
      sl: i + 1,
      label: r.examName.length > 14 ? r.examName.substring(0, 14) + '...' : r.examName,
      fullExamName: r.examName,
      subjectName: r.subjectName,
      date: formatDisplayDate(r.date),
      score: r.isAbsent ? 0 : r.total,
      fullMarks: r.fullMarks,
      percentage: r.isAbsent ? 0 : r.percentage,
      isAbsent: r.isAbsent,
      positionBengali: r.positionBengali,
    }));
  }, [studentPerformance, chartSubjectFilter]);

  // Export Handlers
  const handleDownloadMonthlyPdf = async () => {
    if (!selectedStudent || studentExams.length === 0) return;
    try {
      setIsExportingPdf(true);
      setFeedback(null);
      await exportStudentMonthlyProgressReportPdf(
        selectedStudent,
        studentExams,
        currentMonthLabel,
        subjects,
        students,
        false
      );
      setFeedback({ type: 'success', message: `${selectedStudent.name}-এর মাসিক প্রগ্রেস PDF প্রিভিউ খোলা হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'PDF export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: msg });
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleDownloadCompletePdf = async () => {
    if (!selectedStudent) return;
    try {
      setIsExportingCompletePdf(true);
      setFeedback(null);
      // All exams for this student across all months
      const allStudentExams = exams.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      await exportStudentMonthlyProgressReportPdf(
        selectedStudent,
        allStudentExams,
        'সকল মাস ও বিষয় (Complete Academic Record)',
        subjects,
        students,
        true
      );
      setFeedback({ type: 'success', message: `${selectedStudent.name}-এর সার্বিক কমপ্লিট প্রগ্রেস PDF প্রিভিউ খোলা হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Complete PDF export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: msg });
    } finally {
      setIsExportingCompletePdf(false);
    }
  };

  const handleDownloadExcel = async () => {
    if (!selectedStudent || studentExams.length === 0) return;
    try {
      setIsExportingExcel(true);
      setFeedback(null);
      await exportStudentMonthlyProgressExcel(
        selectedStudent,
        studentExams,
        currentMonthLabel,
        subjects,
        students
      );
      setFeedback({ type: 'success', message: `${selectedStudent.name}-এর মাসিক প্রগ্রেস Excel সফলভাবে ডাউনলোড হয়েছে।` });
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Excel export এ ত্রুটি হয়েছে।';
      setFeedback({ type: 'error', message: msg });
    } finally {
      setIsExportingExcel(false);
    }
  };

  const handleResetFilters = () => {
    setSelectedMonthKey('all');
    setSelectedSubjectFilter('all');
    setSelectedYearFilter('all');
    setChartSubjectFilter('all');
  };

  return (
    <div className="space-y-6" id="student-monthly-progress-analysis-section">
      {/* 1. Header Banner & Filter Controls Bar */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 sm:p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-800/80 border border-blue-700/60 text-amber-300 text-xs font-black uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Student Monthly Progress Analysis</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
                <span>শিক্ষার্থীর মাসিক অগ্রগতি বিশ্লেষণ</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
                শিক্ষার্থী নির্বাচন করে তার নির্দিষ্ট মাসভিত্তিক বা সামগ্রিক মেধা অবস্থান, বিষয়ভিত্তিক ফলাফল, পারফরম্যান্স ট্রেন্ড ও প্রগ্রেস চার্ট পর্যবেক্ষণ করুন।
              </p>
            </div>

            {/* Quick Export Actions if student is selected */}
            {selectedStudent && studentPerformance && (
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  id="btn-download-monthly-progress-pdf"
                  onClick={handleDownloadMonthlyPdf}
                  disabled={isExportingPdf}
                  className="py-2 px-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                  title="নির্বাচিত মাসের PDF ডাউনলোড করুন"
                >
                  <Printer className="w-4 h-4 text-amber-300" />
                  <span>{isExportingPdf ? 'তৈরি হচ্ছে...' : 'Download Monthly PDF'}</span>
                </button>

                <button
                  type="button"
                  id="btn-download-monthly-progress-excel"
                  onClick={handleDownloadExcel}
                  disabled={isExportingExcel}
                  className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                  title="3-Sheet Excel ডাউনলোড করুন"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                  <span>{isExportingExcel ? 'এক্সপোর্ট হচ্ছে...' : 'Download Excel'}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* 2. Interactive Filter Row */}
        <div className="p-4 sm:p-5 bg-slate-50/90 border-t border-slate-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Filter 1: Student Selection (Primary) */}
            <div className="space-y-1">
              <label htmlFor="progress-student-select" className="block text-xs font-bold text-slate-700">
                শিক্ষার্থী নির্বাচন (Student) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <select
                  id="progress-student-select"
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-blue-900 focus:outline-hidden cursor-pointer shadow-2xs"
                >
                  <option value="">-- শিক্ষার্থী নির্বাচন করুন --</option>
                  {students.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.name} — {st.studentIdCode || `CP-${String(st.roll).padStart(3, '0')}`} (রোল: {toBengaliNum(st.roll)})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Filter 2: Month Selection (with All Months) */}
            <div className="space-y-1">
              <label htmlFor="progress-month-select" className="block text-xs font-bold text-slate-700">
                মাস নির্বাচন (Month)
              </label>
              <div className="relative">
                <select
                  id="progress-month-select"
                  value={selectedMonthKey}
                  onChange={(e) => setSelectedMonthKey(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-blue-900 focus:outline-hidden cursor-pointer shadow-2xs"
                >
                  <option value="all">সকল মাস (All Months)</option>
                  {availableMonths.map((opt) => (
                    <option key={opt.key} value={opt.key}>
                      {opt.label} ({toBengaliNum(opt.examCount)}টি পরীক্ষা)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Filter 3: Subject Filter (Optional) */}
            <div className="space-y-1">
              <label htmlFor="progress-subject-select" className="block text-xs font-bold text-slate-700">
                বিষয় ফিল্টার (Subject)
              </label>
              <div className="relative">
                <select
                  id="progress-subject-select"
                  value={selectedSubjectFilter}
                  onChange={(e) => setSelectedSubjectFilter(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-blue-900 focus:outline-hidden cursor-pointer shadow-2xs"
                >
                  <option value="all">All Subjects (সকল বিষয়)</option>
                  {subjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Filter 4: Year Filter & Reset */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label htmlFor="progress-year-select" className="block text-xs font-bold text-slate-700">
                  বছর (Year)
                </label>
                {(selectedMonthKey !== 'all' || selectedSubjectFilter !== 'all' || selectedYearFilter !== 'all') && (
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="text-[11px] font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>রিসেট</span>
                  </button>
                )}
              </div>
              <div className="relative">
                <select
                  id="progress-year-select"
                  value={selectedYearFilter}
                  onChange={(e) => setSelectedYearFilter(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-900 focus:ring-2 focus:ring-blue-900 focus:outline-hidden cursor-pointer shadow-2xs"
                >
                  <option value="all">All Years (সকল বছর)</option>
                  {availableYears.map((yr) => (
                    <option key={yr} value={yr}>
                      {yr}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Feedback message banner */}
          {feedback && (
            <div
              className={`mt-4 p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{feedback.message}</span>
            </div>
          )}
        </div>
      </div>

      {/* When NO student is selected */}
      {!selectedStudent && (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-900 flex items-center justify-center mx-auto mb-4 border border-blue-100">
            <User className="w-8 h-8" />
          </div>
          <h3 className="text-base sm:text-lg font-black text-slate-800 mb-1">
            কোনো শিক্ষার্থী নির্বাচিত হয়নি
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mb-6">
            উপরে ড্রপডাউন থেকে একজন শিক্ষার্থী নির্বাচন করুন। শিক্ষার্থীর ঐ মাসের সকল বিষয়ভিত্তিক পরীক্ষা, মেধা অবস্থান ও গ্রাফ চার্ট স্বয়ংক্রিয়ভাবে প্রদর্শিত হবে।
          </p>

          <div className="pt-4 border-t border-slate-100 max-w-xl mx-auto">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-3">
              দ্রুত শিক্ষার্থী বাছাই করুন
            </span>
            <div className="flex flex-wrap justify-center gap-2">
              {students.slice(0, 8).map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setSelectedStudentId(st.id)}
                  className="py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-900 hover:border-blue-200 border border-slate-200 text-xs font-bold text-slate-700 transition-all cursor-pointer"
                >
                  {st.name} ({st.roll})
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* When student IS selected */}
      {selectedStudent && (
        <>
          {/* If no exams found for this filter */}
          {(!studentPerformance || studentPerformance.totalExamsCount === 0) ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center shadow-xs">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3 border border-amber-200">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-800 mb-1">
                নির্বাচিত ফিল্টারে কোনো পরীক্ষার তথ্য পাওয়া যায়নি
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                শিক্ষার্থী: <span className="font-bold text-slate-700">{selectedStudent.name}</span>, সময়কাল:{' '}
                <span className="font-bold text-slate-700">{currentMonthLabel}</span>। অনুগ্রহ করে অন্য মাস বা বিষয় নির্বাচন করুন।
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* SECTION A: STUDENT INFO & MONTHLY OVERALL SUMMARY (Section 5) */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                {/* Profile Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3 mb-5">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-semibold mb-1">
                      <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-900 border border-blue-200 font-bold">
                        {currentMonthLabel}
                      </span>
                      <span>·</span>
                      <span>একাডেমিক মূল্যায়ন বিবরণী</span>
                    </div>
                    <h3 className="text-xl font-black text-slate-900 flex flex-wrap items-center gap-2">
                      <span>{selectedStudent.name}</span>
                      <span className="text-xs font-mono font-bold px-2.5 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-slate-700">
                        {selectedStudent.studentIdCode || `CP-${String(selectedStudent.roll).padStart(3, '0')}`}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      শ্রেণি: <span className="font-bold text-slate-700">{selectedStudent.academicClass || 'XI'}</span> · রোল:{' '}
                      <span className="font-bold text-slate-700">{toBengaliNum(selectedStudent.roll)}</span> · গ্রুপ:{' '}
                      <span className="font-bold text-slate-700">{selectedStudent.group || 'B-A'}</span> · সেশন:{' '}
                      <span className="font-bold text-slate-700">{selectedStudent.session || '2026'}</span>
                    </p>
                  </div>

                  {/* Monthly Rank & Grade Pill */}
                  <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-3 sm:px-4">
                    <div className="text-right">
                      <span className="text-[11px] text-slate-500 font-bold block">সার্বিক মেধা অবস্থান</span>
                      <span className="text-lg font-black text-blue-900">
                        {studentPerformance.overallMonthlyPosStr}
                      </span>
                    </div>
                    <div className="h-8 w-px bg-slate-200"></div>
                    <div className="text-center">
                      <span className="text-[11px] text-slate-500 font-bold block">গ্রেড</span>
                      <span
                        className={`text-lg font-black ${
                          studentPerformance.overallGrade === 'A+' || studentPerformance.overallGrade === 'A'
                            ? 'text-emerald-600'
                            : studentPerformance.overallGrade === 'Absent'
                            ? 'text-rose-600'
                            : 'text-indigo-600'
                        }`}
                      >
                        {studentPerformance.overallGrade}
                      </span>
                    </div>
                  </div>
                </div>

                {/* KPI Metrics Grid (Section 5) */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">বিষয় ও পরীক্ষা</span>
                    <span className="font-black text-slate-900 text-base sm:text-lg block mt-0.5">
                      {toBengaliNum(studentPerformance.distinctSubjectsCount)} বিষয় / {toBengaliNum(studentPerformance.totalExamsCount)} Exam
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">নির্ধারিত পরীক্ষা</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">উপস্থিতি ও অংশগ্রহণ</span>
                    <span className="font-black text-emerald-700 text-base sm:text-lg block mt-0.5">
                      {toBengaliNum(studentPerformance.attendedCount)} / {toBengaliNum(studentPerformance.totalExamsCount)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      অনুপস্থিত: {toBengaliNum(studentPerformance.absentCount)}টি ({toBengaliNum(studentPerformance.participationRate)}%)
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">মোট প্রাপ্ত নম্বর</span>
                    <span className="font-black text-blue-900 text-base sm:text-lg block mt-0.5 tabular-nums">
                      {toBengaliNum(studentPerformance.totalObtainedMarks)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      পূর্ণমান: {toBengaliNum(studentPerformance.totalFullMarks)}
                    </span>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">গড় নম্বর (Average)</span>
                    <span className="font-black text-indigo-700 text-base sm:text-lg block mt-0.5 tabular-nums">
                      {toBengaliNum(studentPerformance.averageMarks)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">প্রতি পরীক্ষায় গড়</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">গড় শতকরা (%)</span>
                    <span className="font-black text-purple-700 text-base sm:text-lg block mt-0.5 tabular-nums">
                      {toBengaliNum(studentPerformance.averagePercentage)}%
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">মাসিক গড় সাফল্য</span>
                  </div>

                  <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80">
                    <span className="text-slate-500 block text-[11px] font-semibold">সর্বোচ্চ / সর্বনিম্ন</span>
                    <span className="font-black text-slate-900 text-base sm:text-lg block mt-0.5 tabular-nums">
                      {toBengaliNum(studentPerformance.highestMarks)} / {toBengaliNum(studentPerformance.lowestMarks)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">প্রাপ্ত স্কোরের ব্যাপ্তি</span>
                  </div>
                </div>
              </div>

              {/* SECTION B: SUBJECT-WISE MONTHLY PERFORMANCE TABLE (Section 4 & 6) */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2 mb-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Award className="w-4 h-4 text-indigo-600" />
                    <span>বিষয়ভিত্তিক মাসিক ফলাফল (Subject-wise Monthly Performance)</span>
                  </h3>
                  <span className="text-xs text-slate-500 font-medium">
                    মোট {toBengaliNum(studentPerformance.subjectSummaries.length)}টি বিষয়ে পরীক্ষা অনুষ্ঠিত
                  </span>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-4">Subject (বিষয়)</th>
                        <th className="py-3 px-3 text-center">Exam (পরীক্ষা)</th>
                        <th className="py-3 px-3 text-center">CQ মোট</th>
                        <th className="py-3 px-3 text-center">MCQ মোট</th>
                        <th className="py-3 px-3 text-center font-bold">Total (প্রাপ্ত মোট)</th>
                        <th className="py-3 px-3 text-center">পূর্ণমান</th>
                        <th className="py-3 px-3 text-center">শতকরা (%)</th>
                        <th className="py-3 px-3 text-center text-amber-700 bg-amber-50/70 font-black">Position (অবস্থান)</th>
                        <th className="py-3 px-3 text-center">Grade</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {studentPerformance.subjectSummaries.map((sub, idx) => (
                        <tr key={sub.subjectId} className={idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                          <td className="py-3 px-4">
                            <span className="inline-block px-3 py-1 rounded-xl bg-blue-900 text-amber-300 font-black text-xs shadow-2xs border border-blue-950">
                              {sub.subjectName}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-center text-slate-700 tabular-nums">
                            {toBengaliNum(sub.attendedCount)} / {toBengaliNum(sub.examsCount)}
                          </td>
                          <td className="py-3 px-3 text-center text-slate-600 tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.cqTotal) : '—'}
                          </td>
                          <td className="py-3 px-3 text-center text-slate-600 tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.mcqTotal) : '—'}
                          </td>
                          <td className="py-3 px-3 text-center font-black text-slate-900 text-sm tabular-nums">
                            {sub.attendedCount > 0 ? toBengaliNum(sub.obtainedTotal) : <span className="text-rose-600">অনুপস্থিত</span>}
                          </td>
                          <td className="py-3 px-3 text-center text-slate-500 tabular-nums">
                            {toBengaliNum(sub.fullTotal)}
                          </td>
                          <td className="py-3 px-3 text-center font-bold text-indigo-700 tabular-nums">
                            {sub.attendedCount > 0 ? `${toBengaliNum(sub.percentage)}%` : '—'}
                          </td>
                          <td className="py-3 px-3 text-center font-black text-amber-700 bg-amber-50/50 text-xs">
                            {sub.bestPositionBengali}
                          </td>
                          <td className="py-3 px-3 text-center font-bold">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                                sub.grade === 'A+' || sub.grade === 'A'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : sub.grade === 'Absent'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {sub.grade}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SECTION C: SUBJECT-WISE DETAILED EXAM BREAKDOWN TABLE (Section 6) */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2 mb-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-indigo-600" />
                    <span>পরীক্ষা ভিত্তিক বিস্তারিত ফলাফল ও মেধা অবস্থান (Detailed Exam Breakdown)</span>
                  </h3>
                  <span className="text-xs text-slate-500 font-medium">
                    মোট {toBengaliNum(studentPerformance.examRows.length)}টি পরীক্ষা
                  </span>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-3 px-3.5 whitespace-nowrap">তারিখ</th>
                        <th className="py-3 px-3 whitespace-nowrap">বিষয়</th>
                        <th className="py-3 px-3.5 min-w-[150px]">পরীক্ষার নাম</th>
                        <th className="py-3 px-2 text-center text-amber-700 bg-amber-50/70 font-black">অবস্থান</th>
                        <th className="py-3 px-2.5 text-center">CQ</th>
                        <th className="py-3 px-2.5 text-center">MCQ</th>
                        <th className="py-3 px-3 text-center font-bold">মোট নম্বর</th>
                        <th className="py-3 px-2.5 text-center">পূর্ণমান</th>
                        <th className="py-3 px-2.5 text-center">শতকরা</th>
                        <th className="py-3 px-3 text-center">গ্রেড</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {studentPerformance.examRows.map((r, idx) => (
                        <tr key={r.examId || idx} className={idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                          <td className="py-3 px-3.5 text-slate-600 whitespace-nowrap">{formatDisplayDate(r.date)}</td>
                          <td className="py-3 px-3 whitespace-nowrap">
                            <span className="inline-block px-2.5 py-0.5 rounded-lg bg-blue-900 text-amber-300 font-black text-xs shadow-2xs border border-blue-950">
                              {r.subjectName}
                            </span>
                          </td>
                          <td className="py-3 px-3.5 font-bold text-slate-900">{r.examName}</td>
                          <td className="py-3 px-2 text-center font-black text-amber-700 bg-amber-50/50 text-xs">
                            {r.positionBengali}
                          </td>
                          <td className="py-3 px-2.5 text-center text-slate-700 tabular-nums">
                            {r.isAbsent ? '-' : r.cq !== '' ? toBengaliNum(r.cq) : '-'}
                          </td>
                          <td className="py-3 px-2.5 text-center text-slate-700 tabular-nums">
                            {r.isAbsent ? '-' : r.mcq !== '' ? toBengaliNum(r.mcq) : '-'}
                          </td>
                          <td className="py-3 px-3 text-center font-black text-slate-900 text-sm tabular-nums">
                            {r.isAbsent ? <span className="text-rose-600">অনুপস্থিত</span> : toBengaliNum(r.total)}
                          </td>
                          <td className="py-3 px-2.5 text-center text-slate-500 tabular-nums">{toBengaliNum(r.fullMarks)}</td>
                          <td className="py-3 px-2.5 text-center font-bold text-indigo-700 tabular-nums">
                            {r.isAbsent ? '-' : `${toBengaliNum(r.percentage)}%`}
                          </td>
                          <td className="py-3 px-3 text-center font-bold">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                                r.grade === 'A+' || r.grade === 'A'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : r.grade === 'Absent'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {r.grade}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SECTION D: PROGRESS CHART (Month/Exam vs Marks / Percentage Trend) (Section 9) */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-3 mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-indigo-600" />
                      <span>মাসিক পারফরম্যান্স ট্রেন্ড চার্ট (Progress Chart)</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      পরীক্ষার তারিখ ও প্রাপ্ত শতকরা/নম্বরের পরিবর্তন ধারা
                    </p>
                  </div>

                  {/* Chart Subject Filter Pills */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setChartSubjectFilter('all')}
                      className={`py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        chartSubjectFilter === 'all'
                          ? 'bg-blue-900 text-white shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      All Subjects
                    </button>
                    {subjects.map((sub) => (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setChartSubjectFilter(sub.id)}
                        className={`py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          chartSubjectFilter === sub.id
                            ? 'bg-blue-900 text-white shadow-2xs'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {sub.name}
                      </button>
                    ))}
                  </div>
                </div>

                {chartData.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    এই বিষয়ের কোনো চার্ট ডেটা পাওয়া যায়নি।
                  </div>
                ) : (
                  <div className="w-full bg-slate-50/70 border border-slate-200 rounded-2xl p-4">
                    {/* SVG Chart */}
                    {(() => {
                      const svgWidth = 680;
                      const svgHeight = 180;
                      const padLeft = 36;
                      const padRight = 30;
                      const padTop = 20;
                      const padBottom = 35;
                      const chartW = svgWidth - padLeft - padRight;
                      const chartH = svgHeight - padTop - padBottom;

                      const maxScore = Math.max(
                        ...chartData.map((d) => (d.isAbsent ? 0 : d.score)),
                        ...chartData.map((d) => d.fullMarks || 50),
                        50
                      );
                      const yMax = Math.ceil(maxScore / 10) * 10;
                      const yTicks = [0, Math.round(yMax / 2), yMax];

                      const n = chartData.length;
                      const points = chartData.map((d, i) => {
                        const x = n === 1 ? padLeft + chartW / 2 : padLeft + (i / (n - 1)) * chartW;
                        const yVal = d.isAbsent ? 0 : d.score;
                        const y = padTop + chartH - (yVal / yMax) * chartH;
                        return { ...d, x, y };
                      });

                      const attendedPoints = points.filter((p) => !p.isAbsent);
                      const polylinePoints = attendedPoints.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

                      let areaPath = '';
                      if (attendedPoints.length > 1) {
                        const firstP = attendedPoints[0];
                        const lastP = attendedPoints[attendedPoints.length - 1];
                        const bottomY = padTop + chartH;
                        areaPath = `M ${firstP.x.toFixed(1)},${bottomY} L ${polylinePoints.replace(/ /g, ' L ')} L ${lastP.x.toFixed(1)},${bottomY} Z`;
                      }

                      return (
                        <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto block select-none">
                          <defs>
                            <linearGradient id="monthlyTrendGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.25" />
                              <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.0" />
                            </linearGradient>
                          </defs>

                          {/* Grid lines and Y labels */}
                          {yTicks.map((val) => {
                            const y = padTop + chartH - (val / yMax) * chartH;
                            return (
                              <g key={val}>
                                <line
                                  x1={padLeft}
                                  y1={y}
                                  x2={svgWidth - padRight}
                                  y2={y}
                                  stroke="#cbd5e1"
                                  strokeWidth="1"
                                  strokeDasharray="3 3"
                                />
                                <text
                                  x={padLeft - 6}
                                  y={y + 3}
                                  textAnchor="end"
                                  fontSize="9"
                                  fill="#64748b"
                                  fontFamily="sans-serif"
                                >
                                  {toBengaliNum(val)}
                                </text>
                              </g>
                            );
                          })}

                          {/* Area Fill */}
                          {areaPath && <path d={areaPath} fill="url(#monthlyTrendGrad)" />}

                          {/* Polyline Line */}
                          {polylinePoints && (
                            <polyline
                              fill="none"
                              stroke="#1e3a8a"
                              strokeWidth="2.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              points={polylinePoints}
                            />
                          )}

                          {/* Data points */}
                          {points.map((p, i) => (
                            <g key={i}>
                              <circle
                                cx={p.x}
                                cy={p.y}
                                r={p.isAbsent ? 4 : 5}
                                fill={p.isAbsent ? '#ef4444' : '#1e3a8a'}
                                stroke="#ffffff"
                                strokeWidth="2"
                              />
                              {!p.isAbsent && (
                                <text
                                  x={p.x}
                                  y={p.y - 8}
                                  textAnchor="middle"
                                  fontSize="8.5"
                                  fontWeight="bold"
                                  fill="#1e3a8a"
                                  fontFamily="sans-serif"
                                >
                                  {toBengaliNum(p.score)} ({toBengaliNum(p.percentage)}%)
                                </text>
                              )}
                              <text
                                x={p.x}
                                y={padTop + chartH + 14}
                                textAnchor="middle"
                                fontSize="8.5"
                                fontWeight="600"
                                fill="#475569"
                                fontFamily="sans-serif"
                              >
                                {p.date}
                              </text>
                            </g>
                          ))}
                        </svg>
                      );
                    })()}
                  </div>
                )}
              </div>

              {/* SECTION E: MULTI-MONTH PROGRESS COMPARISON (Section 7) */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2 mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <Layers className="w-4 h-4 text-indigo-600" />
                      <span>মাসভিত্তিক অগ্রগতি তুলনা (Multi-Month Progress Comparison)</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      শিক্ষার্থীর বিভিন্ন মাসের সকল পরীক্ষার তুলনামূলক পারফরম্যান্স
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl max-h-[360px] scrollbar-thin">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 sticky top-0 z-10 shadow-2xs">
                      <tr>
                        <th className="py-2.5 px-3">Month (মাস)</th>
                        <th className="py-2.5 px-3">Subject (বিষয়)</th>
                        <th className="py-2.5 px-3">Exam (পরীক্ষা)</th>
                        <th className="py-2.5 px-3 text-center">Total (মোট)</th>
                        <th className="py-2.5 px-3 text-center">Percentage (%)</th>
                        <th className="py-2.5 px-3 text-center text-amber-700 bg-amber-50/70 font-black">Position (অবস্থান)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {studentMultiMonthData.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-6 text-center text-slate-400">
                            কোনো পরীক্ষার তথ্য নেই।
                          </td>
                        </tr>
                      ) : (
                        studentMultiMonthData.map((row, idx) => (
                          <tr key={row.examId || idx} className={idx % 2 === 1 ? 'bg-slate-50/60' : 'bg-white'}>
                            <td className="py-2.5 px-3 font-bold text-slate-800 whitespace-nowrap">
                              {row.monthLabel}
                            </td>
                            <td className="py-2.5 px-3 whitespace-nowrap">
                              <span className="inline-block px-2.5 py-0.5 rounded-md bg-blue-900 text-amber-300 font-black text-xs">
                                {row.subjectName}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-800">{row.examName}</td>
                            <td className="py-2.5 px-3 text-center font-bold text-slate-900 tabular-nums">
                              {row.isAbsent ? <span className="text-rose-600">অনুপস্থিত</span> : toBengaliNum(row.total)}
                            </td>
                            <td className="py-2.5 px-3 text-center font-bold text-indigo-700 tabular-nums">
                              {row.isAbsent ? '-' : `${toBengaliNum(row.percentage)}%`}
                            </td>
                            <td className="py-2.5 px-3 text-center font-black text-amber-700 bg-amber-50/50">
                              {row.positionBengali}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SECTION F: SUBJECT-WISE MONTHLY TREND (Section 8) */}
              {subjectMonthlyTrend.length > 0 && (
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 sm:p-6">
                  <div className="pb-3 border-b border-slate-200 mb-4">
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-indigo-600" />
                      <span>বিষয়ভিত্তিক ধারাবাহিক অগ্রগতি (Subject-wise Monthly Trend)</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      প্রতিটি বিষয়ের ক্ষেত্রে মাস অনুযায়ী প্রাপ্ত নম্বর ও মেধা অবস্থানের পরিবর্তন
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {subjectMonthlyTrend.map((subTrend) => (
                      <div key={subTrend.subjectId} className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
                        <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-200">
                          <span className="font-black text-xs uppercase px-2.5 py-1 rounded-lg bg-blue-900 text-amber-300">
                            {subTrend.subjectName} Progress
                          </span>
                          <span className="text-[11px] font-bold text-slate-500">
                            {toBengaliNum(subTrend.months.length)}টি মাস
                          </span>
                        </div>

                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="text-slate-400 font-semibold border-b border-slate-200 text-[11px]">
                              <th className="py-1.5 px-2">Month</th>
                              <th className="py-1.5 px-2 text-center">Total</th>
                              <th className="py-1.5 px-2 text-center">Avg %</th>
                              <th className="py-1.5 px-2 text-center text-amber-700 font-bold">Position</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200/60 font-medium">
                            {subTrend.months.map((m, mIdx) => (
                              <tr key={m.monthKey || mIdx}>
                                <td className="py-2 px-2 text-slate-800 font-bold">{m.monthLabel}</td>
                                <td className="py-2 px-2 text-center font-bold text-slate-900 tabular-nums">
                                  {toBengaliNum(m.totalMarks)}
                                </td>
                                <td className="py-2 px-2 text-center text-indigo-700 font-bold tabular-nums">
                                  {toBengaliNum(m.avgPct)}%
                                </td>
                                <td className="py-2 px-2 text-center font-black text-amber-700 bg-amber-50/70 rounded">
                                  {m.bestPosition}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* SECTION G: EXPORT ACTION BUTTONS (Section 12, 13, 14, 20) */}
              <div className="bg-slate-100 rounded-3xl border border-slate-200 p-5 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-bold text-slate-800 block">
                    অফিশিয়াল ডকুমেন্ট এক্সপোর্ট (Official Export)
                  </span>
                  <span className="text-[11px] text-slate-500">
                    মাসিক ফলাফল বিবরণী PDF ও 3-Sheet সমৃদ্ধ Master Excel ডাউনলোড করুন।
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleDownloadMonthlyPdf}
                    disabled={isExportingPdf}
                    className="py-2.5 px-4 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                  >
                    <Printer className="w-4 h-4 text-amber-300" />
                    <span>Download Monthly Progress PDF</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadCompletePdf}
                    disabled={isExportingCompletePdf}
                    className="py-2.5 px-4 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                  >
                    <Download className="w-4 h-4 text-indigo-200" />
                    <span>Download Complete Monthly Progress</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadExcel}
                    disabled={isExportingExcel}
                    className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-50"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                    <span>Download Monthly Progress Excel</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
