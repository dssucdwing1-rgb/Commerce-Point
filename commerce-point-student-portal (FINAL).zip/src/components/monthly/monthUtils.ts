import { Exam, MonthOption, Student, Subject } from '../../types';
import { calculateGrade, toBengaliNum } from '../../data/initialData';

export const BENGALI_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

export const ENGLISH_MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export function getBengaliMonthName(monthNum: number): string {
  if (monthNum >= 1 && monthNum <= 12) {
    return BENGALI_MONTHS[monthNum - 1];
  }
  return '';
}

export function getEnglishMonthName(monthNum: number): string {
  if (monthNum >= 1 && monthNum <= 12) {
    return ENGLISH_MONTHS[monthNum - 1];
  }
  return '';
}

/**
 * Format a monthKey like "2026-09" to human readable labels
 */
export function formatMonthLabel(monthKey: string): { en: string; bn: string; year: number; month: number } {
  try {
    const [yearStr, monthStr] = monthKey.split('-');
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10);
    const en = `${getEnglishMonthName(month)} ${year}`;
    const bn = `${getBengaliMonthName(month)} ${toBengaliNum(year)}`;
    return { en, bn, year, month };
  } catch {
    return { en: monthKey, bn: monthKey, year: 2026, month: 1 };
  }
}

/**
 * Automatically derives unique available months from the exams in storage/database
 */
export function extractAvailableMonths(exams: Exam[]): MonthOption[] {
  const monthCountMap = new Map<string, number>();

  exams.forEach((exam) => {
    if (exam.date && exam.date.includes('-')) {
      const parts = exam.date.split('-');
      if (parts.length >= 2) {
        const key = `${parts[0]}-${parts[1].padStart(2, '0')}`;
        monthCountMap.set(key, (monthCountMap.get(key) || 0) + 1);
      }
    }
  });

  // If no exams yet, add current year and month
  if (monthCountMap.size === 0) {
    const now = new Date();
    const curKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    monthCountMap.set(curKey, 0);
  }

  // Sort months newest first (descending)
  const sortedKeys = Array.from(monthCountMap.keys()).sort((a, b) => b.localeCompare(a));

  return sortedKeys.map((key) => {
    const { en, bn, year, month } = formatMonthLabel(key);
    return {
      year,
      month,
      key,
      label: en,
      bengaliLabel: bn,
      examCount: monthCountMap.get(key) || 0,
    };
  });
}

/**
 * Filter exams belonging to a specific monthKey (e.g. "2026-09")
 */
export function filterExamsByMonth(exams: Exam[], monthKey: string): Exam[] {
  if (!monthKey) return exams;
  return exams.filter((exam) => exam.date && exam.date.startsWith(monthKey));
}

export interface StudentMonthlyExamEntry {
  examId: string;
  examName: string;
  subjectId: string;
  subjectName: string;
  subjectBengaliName: string;
  date: string;
  cq: number | '';
  mcq: number | '';
  total: number;
  fullMarks: number;
  cqFull: number;
  mcqFull: number;
  percentage: number;
  grade: string;
  isAbsent: boolean;
}

export interface SubjectMonthlyStat {
  subjectId: string;
  subjectName: string;
  subjectBengaliName: string;
  examsCount: number;
  attendedCount: number;
  totalObtained: number;
  totalFullMarks: number;
  average: number;
  averagePercentage: number;
  highest: number;
  lowest: number;
  grade: string;
}

export interface StudentMonthlySummary {
  student: Student;
  monthKey: string;
  monthLabelEn: string;
  monthLabelBn: string;
  examEntries: StudentMonthlyExamEntry[];
  subjectSummaries: SubjectMonthlyStat[];
  overall: {
    totalExamsInMonth: number;
    attendedExams: number;
    participationRate: number;
    totalObtainedMarks: number;
    totalFullMarks: number;
    averageMarks: number;
    averagePercentage: number;
    highestMarks: number;
    lowestMarks: number;
    subjectsCount: number;
    overallGrade: string;
  };
}

/**
 * Calculates a single student's performance across all subjects for a given month
 */
export function calculateStudentMonthlySummary(
  student: Student,
  examsInMonth: Exam[],
  subjects: Subject[]
): StudentMonthlySummary {
  const { en, bn } = formatMonthLabel(examsInMonth[0]?.date ? examsInMonth[0].date.substring(0, 7) : '2026-09');

  // Map subjects for quick lookup
  const subjectMap = new Map<string, Subject>();
  subjects.forEach((s) => subjectMap.set(s.id, s));

  // Sort exams chronologically (oldest to newest)
  const sortedExams = [...examsInMonth].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const examEntries: StudentMonthlyExamEntry[] = [];
  const subjectGroupMap = new Map<
    string,
    {
      subject: Subject;
      entries: StudentMonthlyExamEntry[];
    }
  >();

  let totalObtainedMarks = 0;
  let totalFullMarksAttended = 0;
  let attendedExams = 0;
  let highestMarks = -Infinity;
  let lowestMarks = Infinity;

  sortedExams.forEach((exam) => {
    const subId = exam.subjectId || 'ict';
    const subObj = subjectMap.get(subId) || {
      id: subId,
      name: subId.toUpperCase(),
      code: subId.toUpperCase(),
      bengaliName: subId.toUpperCase(),
      isActive: true,
    };

    const mark = exam.marks ? exam.marks[student.id] : undefined;
    const isAbsent = !mark || (mark.cq === '' && mark.mcq === '');
    const cq = mark && mark.cq !== '' ? mark.cq : '';
    const mcq = mark && mark.mcq !== '' ? mark.mcq : '';
    const total = mark && !isAbsent ? mark.total : 0;
    const fullMarks = exam.totalFullMarks || (exam.cqFullMarks || 0) + (exam.mcqFullMarks || 0) || 100;
    const percentage = !isAbsent && fullMarks > 0 ? Math.round((total / fullMarks) * 100) : 0;
    const grade = isAbsent ? 'Absent' : calculateGrade(percentage);

    if (!isAbsent) {
      attendedExams++;
      totalObtainedMarks += total;
      totalFullMarksAttended += fullMarks;
      if (total > highestMarks) highestMarks = total;
      if (total < lowestMarks) lowestMarks = total;
    }

    const entry: StudentMonthlyExamEntry = {
      examId: exam.id,
      examName: exam.name,
      subjectId: subId,
      subjectName: subObj.name,
      subjectBengaliName: subObj.bengaliName || subObj.name,
      date: exam.date,
      cq,
      mcq,
      total,
      fullMarks,
      cqFull: exam.cqFullMarks,
      mcqFull: exam.mcqFullMarks,
      percentage,
      grade,
      isAbsent,
    };

    examEntries.push(entry);

    if (!subjectGroupMap.has(subId)) {
      subjectGroupMap.set(subId, {
        subject: subObj,
        entries: [],
      });
    }
    subjectGroupMap.get(subId)!.entries.push(entry);
  });

  // Calculate Subject Summaries
  const subjectSummaries: SubjectMonthlyStat[] = [];
  subjectGroupMap.forEach(({ subject, entries }) => {
    const attendedList = entries.filter((e) => !e.isAbsent);
    const attendedCount = attendedList.length;
    let sumObtained = 0;
    let sumFull = 0;
    let maxMark = -Infinity;
    let minMark = Infinity;

    attendedList.forEach((e) => {
      sumObtained += e.total;
      sumFull += e.fullMarks;
      if (e.total > maxMark) maxMark = e.total;
      if (e.total < minMark) minMark = e.total;
    });

    const average = attendedCount > 0 ? Number((sumObtained / attendedCount).toFixed(1)) : 0;
    const averagePercentage = sumFull > 0 ? Math.round((sumObtained / sumFull) * 100) : 0;
    const grade = attendedCount > 0 ? calculateGrade(averagePercentage) : 'N/A';

    subjectSummaries.push({
      subjectId: subject.id,
      subjectName: subject.name,
      subjectBengaliName: subject.bengaliName || subject.name,
      examsCount: entries.length,
      attendedCount,
      totalObtained: sumObtained,
      totalFullMarks: sumFull,
      average,
      averagePercentage,
      highest: maxMark !== -Infinity ? maxMark : 0,
      lowest: minMark !== Infinity ? minMark : 0,
      grade,
    });
  });

  const totalExamsInMonth = sortedExams.length;
  const participationRate = totalExamsInMonth > 0 ? Math.round((attendedExams / totalExamsInMonth) * 100) : 0;
  const averageMarks = attendedExams > 0 ? Number((totalObtainedMarks / attendedExams).toFixed(1)) : 0;
  const averagePercentage =
    totalFullMarksAttended > 0 ? Math.round((totalObtainedMarks / totalFullMarksAttended) * 100) : 0;
  const overallGrade = attendedExams > 0 ? calculateGrade(averagePercentage) : 'N/A';

  return {
    student,
    monthKey: examsInMonth[0]?.date ? examsInMonth[0].date.substring(0, 7) : '',
    monthLabelEn: en,
    monthLabelBn: bn,
    examEntries,
    subjectSummaries,
    overall: {
      totalExamsInMonth,
      attendedExams,
      participationRate,
      totalObtainedMarks,
      totalFullMarks: totalFullMarksAttended,
      averageMarks,
      averagePercentage,
      highestMarks: highestMarks !== -Infinity ? highestMarks : 0,
      lowestMarks: lowestMarks !== Infinity ? lowestMarks : 0,
      subjectsCount: subjectSummaries.length,
      overallGrade,
    },
  };
}
