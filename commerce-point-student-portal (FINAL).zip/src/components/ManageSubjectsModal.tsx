import React, { useState } from 'react';
import { X, Plus, BookOpen, Check, Pencil, AlertCircle, CheckCircle2, RotateCcw, Power } from 'lucide-react';
import { Subject, Exam } from '../types';
import { addSubject, updateSubject, toggleSubjectStatus } from '../services/storage';

interface ManageSubjectsModalProps {
  isOpen: boolean;
  onClose: () => void;
  subjects: Subject[];
  exams: Exam[];
  onSubjectsUpdated: (updatedSubjects: Subject[]) => void;
  activeSubjectId: string;
  onSelectSubject: (subjectId: string) => void;
}

export const ManageSubjectsModal: React.FC<ManageSubjectsModalProps> = ({
  isOpen,
  onClose,
  subjects,
  exams,
  onSubjectsUpdated,
  activeSubjectId,
  onSelectSubject,
}) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [bengaliName, setBengaliName] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Inline edit state
  const [editingSubjectId, setEditingSubjectId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editCode, setEditCode] = useState('');
  const [editBengaliName, setEditBengaliName] = useState('');

  if (!isOpen) return null;

  // Calculate exam count per subject
  const examCountMap: Record<string, number> = {};
  exams.forEach((e) => {
    const subId = e.subjectId || 'ict';
    examCountMap[subId] = (examCountMap[subId] || 0) + 1;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFeedback({ type: 'error', message: 'অনুগ্রহ করে বিষয়ের নাম লিখুন।' });
      return;
    }

    const res = addSubject({
      name: name.trim(),
      code: code.trim() || undefined,
      bengaliName: bengaliName.trim() || undefined,
    });

    if (!res.success) {
      setFeedback({ type: 'error', message: res.error || 'বিষয় যোগ করতে ব্যর্থ হয়েছে।' });
      return;
    }

    onSubjectsUpdated(res.subjects);
    setName('');
    setCode('');
    setBengaliName('');
    setFeedback({
      type: 'success',
      message: `"${res.subject?.name}" সফলভাবে নতুন বিষয় হিসেবে যুক্ত করা হয়েছে।`,
    });
    setTimeout(() => setFeedback(null), 3500);
  };

  const handleStartEdit = (sub: Subject) => {
    setEditingSubjectId(sub.id);
    setEditName(sub.name);
    setEditCode(sub.code);
    setEditBengaliName(sub.bengaliName || '');
  };

  const handleSaveEdit = (subId: string) => {
    if (!editName.trim()) {
      setFeedback({ type: 'error', message: 'অনুগ্রহ করে বিষয়ের নাম লিখুন।' });
      return;
    }

    const res = updateSubject(subId, {
      name: editName.trim(),
      code: editCode.trim(),
      bengaliName: editBengaliName.trim(),
    });

    if (res.success) {
      onSubjectsUpdated(res.subjects);
      setEditingSubjectId(null);
      setFeedback({ type: 'success', message: 'বিষয় সংক্রান্ত তথ্য সফলভাবে আপডেট হয়েছে।' });
      setTimeout(() => setFeedback(null), 3500);
    } else {
      setFeedback({ type: 'error', message: res.error || 'আপডেট করতে ব্যর্থ হয়েছে।' });
    }
  };

  const handleToggle = (subId: string) => {
    const updated = toggleSubjectStatus(subId);
    onSubjectsUpdated(updated);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                বিষয় ব্যবস্থাপনা (Subject Management)
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                নতুন বিষয় যোগ, নাম পরিবর্তন ও অ্যাক্টিভেশন পরিচালনা করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`mx-4 mt-3 p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Add Subject Form */}
        <div className="p-4 border-b border-slate-200 bg-indigo-50/50">
          <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900 uppercase tracking-wider mb-2">
            <Plus className="w-3.5 h-3.5 text-indigo-600" />
            <span>নতুন বিষয় যোগ করুন</span>
          </div>

          <form onSubmit={handleAddSubmit} className="space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              <div className="sm:col-span-5">
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                  বিষয়ের নাম (Name) *
                </label>
                <input
                  type="text"
                  placeholder="e.g. সমাজবিজ্ঞান বা ফিন্যান্স"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                  কোড (Code)
                </label>
                <input
                  type="text"
                  placeholder="e.g. SOC / FIN"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 uppercase focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="sm:col-span-4 flex items-end">
                <button
                  type="submit"
                  className="w-full py-1.5 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>যুক্ত করুন</span>
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Subjects List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-slate-700">
              সকল বিষয়ের তালিকা ({subjects.length}টি)
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              অ্যাক্টিভ বিষয়গুলো হোমপেজ ও ন্যাভিগেশনে প্রদর্শিত হবে
            </span>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-2xs">
            {subjects.map((sub) => {
              const isCurrent = sub.id === activeSubjectId;
              const isEditing = editingSubjectId === sub.id;
              const examCount = examCountMap[sub.id] || 0;

              if (isEditing) {
                return (
                  <div key={sub.id} className="p-3 bg-indigo-50/80 space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                          বিষয়ের নাম
                        </label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                          কোড
                        </label>
                        <input
                          type="text"
                          value={editCode}
                          onChange={(e) => setEditCode(e.target.value)}
                          className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 uppercase"
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setEditingSubjectId(null)}
                        className="px-2.5 py-1 rounded border border-slate-300 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                      >
                        বাতিল
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(sub.id)}
                        className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" />
                        <span>সংরক্ষণ</span>
                      </button>
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={sub.id}
                  className={`p-3 flex items-center justify-between gap-2 transition-colors ${
                    isCurrent ? 'bg-slate-50' : 'hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${
                        sub.isActive
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      {sub.code || sub.name.substring(0, 3)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">{sub.name}</span>
                        {isCurrent && (
                          <span className="px-1.5 py-0.25 rounded text-[10px] font-black bg-slate-900 text-white">
                            বর্তমান
                          </span>
                        )}
                        {!sub.isActive && (
                          <span className="px-1.5 py-0.25 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            নিষ্ক্রিয়
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        কোড: <strong>{sub.code}</strong> • পরীক্ষা: <strong>{examCount}</strong>টি
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Switch to this subject button */}
                    {!isCurrent && sub.isActive && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectSubject(sub.id);
                          onClose();
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors cursor-pointer"
                      >
                        ওপেন করুন
                      </button>
                    )}

                    {/* Edit button */}
                    <button
                      type="button"
                      onClick={() => handleStartEdit(sub)}
                      title="বিষয়ের নাম ও কোড সম্পাদনা"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 transition-colors cursor-pointer"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>

                    {/* Active Toggle button (only non-ICT default subjects can be toggled) */}
                    {sub.id !== 'ict' && (
                      <button
                        type="button"
                        onClick={() => handleToggle(sub.id)}
                        title={sub.isActive ? 'নিষ্ক্রিয় করুন' : 'সক্রিয় করুন'}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          sub.isActive
                            ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border-emerald-200'
                            : 'text-slate-400 bg-slate-100 hover:bg-slate-200 border-slate-200'
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500 font-medium">
          <span>মোট সক্রিয় বিষয়: {subjects.filter((s) => s.isActive).length}টি</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            সম্পন্ন
          </button>
        </div>
      </div>
    </div>
  );
};
