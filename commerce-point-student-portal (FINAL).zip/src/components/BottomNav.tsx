import { Home, PenLine, TrendingUp, ClipboardList, Calendar } from 'lucide-react';
import { NavPage } from '../types';

interface BottomNavProps {
  currentPage: NavPage;
  onSelectPage: (page: NavPage) => void;
}

export function BottomNav({ currentPage, onSelectPage }: BottomNavProps) {
  const navItems = [
    {
      id: 'home' as NavPage,
      label: 'হোম',
      sublabel: 'Home',
      icon: Home,
    },
    {
      id: 'entry' as NavPage,
      label: 'এন্ট্রি',
      sublabel: 'Entry',
      icon: PenLine,
    },
    {
      id: 'monthly' as NavPage,
      label: 'মাসিক',
      sublabel: 'Monthly',
      icon: Calendar,
      highlight: true,
    },
    {
      id: 'results' as NavPage,
      label: 'ফলাফল',
      sublabel: 'Results',
      icon: ClipboardList,
    },
    {
      id: 'progress' as NavPage,
      label: 'অগ্রগতি',
      sublabel: 'Progress',
      icon: TrendingUp,
    },
  ];

  return (
    <nav
      id="bottom-navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 py-1.5 px-3 sm:px-4 safe-area-bottom shadow-lg"
    >
      <div className="w-full max-w-xl md:max-w-2xl mx-auto grid grid-cols-5 gap-0.5 sm:gap-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          return (
            <button
              key={item.id}
              id={`nav-tab-${item.id}`}
              onClick={() => onSelectPage(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-0.5 sm:px-1 rounded-xl transition-all cursor-pointer ${
                isActive
                  ? 'text-indigo-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-colors ${
                  isActive ? 'bg-indigo-50 text-indigo-600' : ''
                }`}
              >
                <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span className="text-[10px] sm:text-[11px] leading-tight mt-0.5 whitespace-nowrap">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
