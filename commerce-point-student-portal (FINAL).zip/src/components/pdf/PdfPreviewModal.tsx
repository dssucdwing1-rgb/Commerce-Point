import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  Download,
  Printer,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Expand,
  Shrink,
  CheckCircle2,
  FileText,
  Layers,
  FileCheck,
  Check,
} from 'lucide-react';
import { usePdfPreview } from '../../services/pdfPreviewContext';
import { toBengaliNum } from '../../data/initialData';

export const PdfPreviewModal: React.FC = () => {
  const { isOpen, previewData, closePdfPreview } = usePdfPreview();

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [zoom, setZoom] = useState<number>(100); // Percentage: 40% - 250%
  const [viewMode, setViewMode] = useState<'single' | 'continuous' | 'iframe'>('single');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const scrollAreaRef = useRef<HTMLDivElement | null>(null);

  const totalPages = previewData?.totalPages || previewData?.pageImages?.length || 1;
  const isLandscape = previewData?.orientation === 'landscape';

  // Reset page and zoom when a new PDF is opened
  useEffect(() => {
    if (isOpen) {
      setCurrentPage(1);
      setDownloadSuccess(false);
      // Sensible initial zoom based on screen size and orientation
      const screenWidth = window.innerWidth;
      if (screenWidth < 640) {
        setZoom(isLandscape ? 55 : 65);
      } else if (screenWidth < 1024) {
        setZoom(isLandscape ? 70 : 80);
      } else {
        setZoom(isLandscape ? 85 : 95);
      }
    }
  }, [isOpen, previewData, isLandscape]);

  // Handle Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if focused in an input/textarea
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;

      if (e.key === 'Escape') {
        closePdfPreview();
      } else if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        if (currentPage < totalPages) {
          setCurrentPage((prev) => prev + 1);
        }
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        if (currentPage > 1) {
          setCurrentPage((prev) => prev - 1);
        }
      } else if (e.key === '+' || e.key === '=') {
        handleZoomIn();
      } else if (e.key === '-' || e.key === '_') {
        handleZoomOut();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentPage, totalPages, closePdfPreview]);

  // Handle Fullscreen toggle
  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;

    if (!document.fullscreenElement) {
      if (el.requestFullscreen) {
        el.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
      }
    }
  }, []);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Zoom helpers
  const handleZoomIn = () => {
    setZoom((prev) => Math.min(250, prev + 15));
  };

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(40, prev - 15));
  };

  const handleFitToWidth = () => {
    if (!scrollAreaRef.current) return;
    const viewportWidth = scrollAreaRef.current.clientWidth - 48; // padding
    const baseWidth = isLandscape ? 1120 : 794;
    const calculatedZoom = Math.round((viewportWidth / baseWidth) * 100);
    setZoom(Math.max(40, Math.min(200, calculatedZoom)));
  };

  const handleFitToPage = () => {
    if (!scrollAreaRef.current) return;
    const viewportHeight = scrollAreaRef.current.clientHeight - 48;
    const viewportWidth = scrollAreaRef.current.clientWidth - 48;
    const baseHeight = isLandscape ? 792 : 1120;
    const baseWidth = isLandscape ? 1120 : 794;

    const zoomH = (viewportHeight / baseHeight) * 100;
    const zoomW = (viewportWidth / baseWidth) * 100;
    const calculatedZoom = Math.round(Math.min(zoomH, zoomW));
    setZoom(Math.max(40, Math.min(180, calculatedZoom)));
  };

  // Download exact same PDF Blob without regenerating!
  const handleDownloadPdf = () => {
    if (!previewData) return;

    try {
      const url = previewData.objectUrl || URL.createObjectURL(previewData.blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = previewData.fileName || 'COMMERCE_POINT_Document.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Download error:', err);
    }
  };

  // High-fidelity vector print directly using native browser engine
  const handleVectorPrint = () => {
    if (!previewData) return;
    if (previewData.onPrint) {
      previewData.onPrint();
    } else {
      window.print();
    }
  };

  if (!isOpen || !previewData) return null;

  const pageImages = previewData.pageImages || [];
  const pageHtmls = previewData.pageHtmls || [];
  const hasPageHtmls = pageHtmls.length > 0;
  const currentPageImg = pageImages[currentPage - 1];
  const currentPageHtml = pageHtmls[currentPage - 1];

  // Base A4 dimensions in pt:
  // Portrait: 595.28pt x 841.89pt
  // Landscape: 841.89pt x 595.28pt
  const baseWidthPt = isLandscape ? 841.89 : 595.28;
  const baseHeightPt = isLandscape ? 595.28 : 841.89;
  const scaleRatio = zoom / 100;

  return (
    <div
      ref={containerRef}
      id="pdf-preview-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col text-slate-100 font-sans select-none animate-fadeIn"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pdf-preview-title"
    >
      {/* ========================================================
          1. TOP NAVIGATION & CONTROLS TOOLBAR
          ======================================================== */}
      <header className="bg-slate-900 border-b border-slate-800 px-3 sm:px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 shrink-0 shadow-lg">
        {/* Left: Document Info */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3
                id="pdf-preview-title"
                className="text-xs sm:text-sm font-extrabold text-white truncate max-w-[220px] sm:max-w-[340px]"
                title={previewData.title}
              >
                {previewData.title || 'PDF প্রিভিউ ও ডাউনলোড'}
              </h3>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 shrink-0">
                {isLandscape ? 'A4 Landscape' : 'A4 Portrait'}
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 shrink-0">
                {toBengaliNum(totalPages)} পৃষ্ঠা
              </span>
            </div>
            <p className="text-[10px] text-slate-400 truncate max-w-[260px] sm:max-w-[420px]" title={previewData.fileName}>
              {previewData.fileName}
            </p>
          </div>
        </div>

        {/* Center: Viewer Controls (Pagination & Zoom) */}
        <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800 shadow-inner">
          {/* Page Navigation */}
          {totalPages > 1 && (
            <>
              <button
                type="button"
                id="pdf-preview-prev-page"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1 || viewMode === 'continuous'}
                title="পূর্ববর্তী পৃষ্ঠা (Left Arrow)"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-slate-300 cursor-pointer transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="px-2 text-xs font-bold text-slate-200 whitespace-nowrap min-w-[70px] text-center">
                পৃষ্ঠা {toBengaliNum(currentPage)} / {toBengaliNum(totalPages)}
              </div>

              <button
                type="button"
                id="pdf-preview-next-page"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages || viewMode === 'continuous'}
                title="পরবর্তী পৃষ্ঠা (Right Arrow)"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-slate-300 cursor-pointer transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <div className="h-4 w-px bg-slate-800 mx-0.5" />
            </>
          )}

          {/* Zoom Controls */}
          {viewMode !== 'iframe' && (
            <>
              <button
                type="button"
                id="pdf-preview-zoom-out"
                onClick={handleZoomOut}
                disabled={zoom <= 40}
                title="Zoom Out (-)"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 cursor-pointer transition-colors"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              <button
                type="button"
                id="pdf-preview-reset-zoom"
                onClick={() => setZoom(100)}
                title="Reset Zoom to 100%"
                className="px-1.5 py-0.5 text-[11px] font-bold text-slate-300 hover:text-white hover:bg-slate-800 rounded min-w-[46px] text-center cursor-pointer transition-colors"
              >
                {zoom}%
              </button>

              <button
                type="button"
                id="pdf-preview-zoom-in"
                onClick={handleZoomIn}
                disabled={zoom >= 250}
                title="Zoom In (+)"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-30 cursor-pointer transition-colors"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              <div className="hidden lg:flex items-center gap-1">
                <div className="h-4 w-px bg-slate-800 mx-0.5" />

                <button
                  type="button"
                  id="pdf-preview-fit-width"
                  onClick={handleFitToWidth}
                  title="Fit to Width (উইন্ডোর প্রস্থ অনুযায়ী মেলানো)"
                  className="px-2 py-1 text-[11px] font-bold text-slate-300 hover:text-white hover:bg-slate-800 rounded cursor-pointer transition-colors flex items-center gap-1"
                >
                  <Maximize2 className="w-3 h-3" />
                  <span>Fit Width</span>
                </button>

                <button
                  type="button"
                  id="pdf-preview-fit-page"
                  onClick={handleFitToPage}
                  title="Fit to Page (সম্পূর্ণ পৃষ্ঠা ফিট করা)"
                  className="px-2 py-1 text-[11px] font-bold text-slate-300 hover:text-white hover:bg-slate-800 rounded cursor-pointer transition-colors flex items-center gap-1"
                >
                  <Minimize2 className="w-3 h-3" />
                  <span>Fit Page</span>
                </button>
              </div>
            </>
          )}

          {/* View Mode Toggle */}
          {totalPages > 1 && (
            <>
              <div className="h-4 w-px bg-slate-800 mx-0.5 hidden sm:block" />
              <button
                type="button"
                id="pdf-preview-toggle-viewmode"
                onClick={() => setViewMode(viewMode === 'single' ? 'continuous' : 'single')}
                title={viewMode === 'single' ? 'সকল পৃষ্ঠা একসঙ্গে দেখুন (Continuous Scroll)' : 'একক পৃষ্ঠা মোড (Single Page)'}
                className={`hidden sm:inline-flex items-center gap-1 px-2 py-1 text-[11px] font-bold rounded cursor-pointer transition-colors ${
                  viewMode === 'continuous'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>{viewMode === 'continuous' ? 'সকল পৃষ্ঠা' : 'একক পৃষ্ঠা'}</span>
              </button>
            </>
          )}
        </div>

        {/* Right: Actions (Download & Close) */}
        <div className="flex items-center gap-2">
          {/* Fullscreen Toggle */}
          <button
            type="button"
            id="pdf-preview-toggle-fullscreen"
            onClick={toggleFullscreen}
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer hidden md:flex items-center justify-center"
          >
            {isFullscreen ? <Shrink className="w-4 h-4" /> : <Expand className="w-4 h-4" />}
          </button>

          {/* Vector Print / Save as PDF Button */}
          <button
            type="button"
            id="pdf-preview-vector-print-btn"
            onClick={handleVectorPrint}
            title="ব্রাউজারের ভেক্টর প্রিন্ট ইঞ্জিন (Save as PDF) ব্যবহার করে ১০০% শার্প ভেক্টর PDF তৈরি বা প্রিন্ট করুন"
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-98 text-emerald-300 hover:text-emerald-200 border border-emerald-500/40 font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4 shrink-0 text-emerald-400" />
            <span className="hidden sm:inline">🖨️ Print / Vector PDF</span>
            <span className="sm:hidden">Print</span>
          </button>

          {/* Download PDF Button */}
          <button
            type="button"
            id="pdf-preview-download-btn"
            onClick={handleDownloadPdf}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 active:scale-98 text-white font-black text-xs sm:text-sm shadow-md hover:shadow-indigo-500/25 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>⬇ Download PDF</span>
          </button>

          {/* Close Button */}
          <button
            type="button"
            id="pdf-preview-close-btn"
            onClick={closePdfPreview}
            title="Close Preview (Esc)"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* ========================================================
          2. DOWNLOAD SUCCESS FEEDBACK TOAST
          ======================================================== */}
      {downloadSuccess && (
        <div
          id="pdf-download-success-toast"
          className="bg-emerald-600 text-white px-4 py-2.5 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-md animate-slideDown shrink-0"
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>"{previewData.fileName}" সফলভাবে ডাউনলোড হয়েছে!</span>
        </div>
      )}

      {/* ========================================================
          3. MAIN DOCUMENT VIEWPORT
          ======================================================== */}
      <main
        ref={scrollAreaRef}
        id="pdf-preview-canvas-viewport"
        className="flex-1 overflow-auto bg-slate-950 p-4 sm:p-8 flex justify-center items-start"
      >
        {viewMode === 'iframe' && previewData.objectUrl ? (
          <div className="w-full h-full max-w-5xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-700">
            <iframe
              src={previewData.objectUrl}
              title={previewData.title}
              className="w-full h-full border-0"
            />
          </div>
        ) : viewMode === 'continuous' ? (
          /* Continuous All Pages Mode */
          <div className="flex flex-col items-center gap-6 pb-12 select-text">
            {hasPageHtmls
              ? pageHtmls.map((html, idx) => (
                  <div
                    key={idx}
                    className="relative bg-white shadow-2xl transition-all duration-75 border border-slate-300 overflow-hidden rounded-xs"
                    style={{
                      width: `${baseWidthPt * scaleRatio}pt`,
                      height: `${baseHeightPt * scaleRatio}pt`,
                      minWidth: `${baseWidthPt * scaleRatio}pt`,
                      minHeight: `${baseHeightPt * scaleRatio}pt`,
                    }}
                  >
                    <div className="absolute top-2 left-2 px-2.5 py-1 rounded bg-slate-900/90 text-white text-[11px] font-extrabold z-20 backdrop-blur-xs shadow-md border border-slate-700 pointer-events-none">
                      পৃষ্ঠা {toBengaliNum(idx + 1)} / {toBengaliNum(totalPages)}
                    </div>
                    <div
                      style={{
                        width: `${baseWidthPt}pt`,
                        height: `${baseHeightPt}pt`,
                        transform: `scale(${scaleRatio})`,
                        transformOrigin: 'top left',
                      }}
                      dangerouslySetInnerHTML={{ __html: html }}
                    />
                  </div>
                ))
              : pageImages.map((imgSrc, idx) => (
                  <div
                    key={idx}
                    className="relative bg-white rounded-xs shadow-2xl transition-all duration-150 border border-slate-200"
                    style={{
                      width: `${((isLandscape ? 1120 : 794) * zoom) / 100}px`,
                      minHeight: `${((isLandscape ? 792 : 1120) * zoom) / 100}px`,
                    }}
                  >
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-slate-900/80 text-white text-[10px] font-bold z-10 backdrop-blur-xs">
                      পৃষ্ঠা {toBengaliNum(idx + 1)} / {toBengaliNum(totalPages)}
                    </div>
                    <img
                      src={imgSrc}
                      alt={`Page ${idx + 1}`}
                      className="w-full h-auto block select-none pointer-events-none"
                      loading="eager"
                    />
                  </div>
                ))}
          </div>
        ) : (
          /* Single Page Mode */
          <div className="flex flex-col items-center pb-12 select-text">
            {hasPageHtmls ? (
              <div
                className="relative bg-white shadow-2xl transition-all duration-75 border border-slate-300 overflow-hidden rounded-xs"
                style={{
                  width: `${baseWidthPt * scaleRatio}pt`,
                  height: `${baseHeightPt * scaleRatio}pt`,
                  minWidth: `${baseWidthPt * scaleRatio}pt`,
                  minHeight: `${baseHeightPt * scaleRatio}pt`,
                }}
              >
                {totalPages > 1 && (
                  <div className="absolute top-2 left-2 px-2.5 py-1 rounded bg-slate-900/90 text-white text-[11px] font-extrabold z-20 backdrop-blur-xs shadow-md border border-slate-700 pointer-events-none">
                    পৃষ্ঠা {toBengaliNum(currentPage)} / {toBengaliNum(totalPages)}
                  </div>
                )}
                {currentPageHtml ? (
                  <div
                    style={{
                      width: `${baseWidthPt}pt`,
                      height: `${baseHeightPt}pt`,
                      transform: `scale(${scaleRatio})`,
                      transformOrigin: 'top left',
                    }}
                    dangerouslySetInnerHTML={{ __html: currentPageHtml }}
                  />
                ) : (
                  <div className="w-full min-h-[400px] flex items-center justify-center text-slate-400 text-sm">
                    পৃষ্ঠা লোড হচ্ছে...
                  </div>
                )}
              </div>
            ) : (
              <div
                className="relative bg-white rounded-xs shadow-2xl transition-all duration-150 border border-slate-200"
                style={{
                  width: `${((isLandscape ? 1120 : 794) * zoom) / 100}px`,
                  minHeight: `${((isLandscape ? 792 : 1120) * zoom) / 100}px`,
                }}
              >
                {totalPages > 1 && (
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-slate-900/80 text-white text-[10px] font-bold z-10 backdrop-blur-xs">
                    পৃষ্ঠা {toBengaliNum(currentPage)} / {toBengaliNum(totalPages)}
                  </div>
                )}
                {currentPageImg ? (
                  <img
                    src={currentPageImg}
                    alt={`Page ${currentPage}`}
                    className="w-full h-auto block select-none pointer-events-none"
                    loading="eager"
                  />
                ) : (
                  <div className="w-full min-h-[400px] flex items-center justify-center text-slate-400 text-sm">
                    পৃষ্ঠা লোড হচ্ছে...
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* ========================================================
          4. BOTTOM STATUS BAR
          ======================================================== */}
      <footer className="bg-slate-900/90 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <Check className="w-3.5 h-3.5" />
            <span>Nikosh Font Embedded · Vector Sharpness · 300+ DPI Equivalent</span>
          </span>
          <span className="hidden sm:inline text-slate-600">•</span>
          <span className="hidden sm:inline text-slate-400">
            High-Resolution Vector Documents
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setViewMode(viewMode === 'iframe' ? 'single' : 'iframe')}
              className="text-[10px] font-semibold text-blue-400 hover:text-blue-300 underline cursor-pointer"
            >
              {viewMode === 'iframe' ? 'পেজ ভিউয়ে ফিরুন' : 'ব্রাউজার PDF ফ্রেম দেখুন'}
            </button>
          </div>
          <span className="text-slate-400 font-mono">
            {isLandscape ? 'A4 ল্যান্ডস্কেপ (297×210 mm)' : 'A4 পোর্ট্রেট (210×297 mm)'}
          </span>
          <span className="hidden sm:inline text-slate-400">জুম: {zoom}%</span>
        </div>
      </footer>
    </div>
  );
};
