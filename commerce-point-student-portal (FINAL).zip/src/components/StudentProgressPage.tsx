import React, { useState, useMemo } from 'react';
import {
  User,
  ChevronDown,
  TrendingUp,
  Award,
  Calendar,
  BarChart3,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Sparkles,
  Trophy,
  Medal,
  FileText,
  AlertCircle,
  Copy,
  Check,
  FileSpreadsheet,
  Loader2,
  CheckCircle2,
} from 'lucide-react';
import { Exam, Student, AuthUser, Subject } from '../types';
import {
  calculateGrade,
  getGradeBadgeColor,
  toBengaliNum,
} from '../data/initialData';
import { ProgressReportModal } from './report/ProgressReportModal';
import { generateStudentReport, StudentProgressReportData } from './report/reportData';
import { exportMasterResultExcel } from '../services/excelExport';
import { getStudentExamPosition } from '../utils/ranking';

interface StudentProgressPageProps {
  exams: Exam[];
  students: Student[];
  currentUser?: AuthUser;
  currentSubject?: Subject;
}

interface StudentExamRow {
  examId: string;
  date: string;
  examName: string;
  positionBengali: string;
  cq: number | '';
  mcq: number | '';
  total: number;
  percentage: number;
  grade: string;
  totalFullMarks: number;
}

interface TopStudent {
  student: Student;
  rank: number;
  averageScore: number;
  averagePercentage: number;
  overallGrade: string;
  examsCount: number;
  totalMarksScored: number;
}

export function StudentProgressPage({
  exams,
  students,
  currentUser,
  currentSubject,
}: StudentProgressPageProps) {
  // Sort students by roll
  const sortedStudents = useMemo(() => {
    return [...students].sort((a, b) => a.roll - b.roll);
  }, [students]);

  // Default to first student id or '1'
  const [selectedStudentId, setSelectedStudentId] = useState<string>(() => {
    return sortedStudents[0]?.id || '1';
  });

  // Keep selected student valid if students change
  const selectedStudent = useMemo(() => {
    const found = sortedStudents.find((s) => s.id === selectedStudentId);
    return found || sortedStudents[0] || { id: '1', name: 'মুসকান', roll: 1 };
  }, [sortedStudents, selectedStudentId]);

  // Report modal states
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportNotice, setReportNotice] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Master Excel export state
  const [isExportingMaster, setIsExportingMaster] = useState(false);
  const [masterNotice, setMasterNotice] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const isTeacher = currentUser?.role === 'admin';

  const handleExportMasterExcel = async () => {
    if (!isTeacher) {
      setMasterNotice({
        type: 'error',
        message: 'শুধুমাত্র শিক্ষকগণ মাস্টার এক্সেল ডাউনলোড করতে পারবেন।',
      });
      setTimeout(() => setMasterNotice(null), 4000);
      return;
    }
    if (exams.length === 0) {
      setMasterNotice({
        type: 'error',
        message: 'Export করার মতো কোনো পরীক্ষার ফলাফল পাওয়া যায়নি।',
      });
      setTimeout(() => setMasterNotice(null), 4000);
      return;
    }
    try {
      setIsExportingMaster(true);
      await new Promise((r) => setTimeout(r, 250));
      await exportMasterResultExcel(exams, students, currentUser?.role);
      setMasterNotice({
        type: 'success',
        message: 'Excel Downloaded Successfully! মাস্টার এক্সেল শীট ডাউনলোড হয়েছে।',
      });
      setTimeout(() => setMasterNotice(null), 4000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'মাস্টার এক্সেল ডাউনলোড করার সময় সমস্যা হয়েছে।';
      setMasterNotice({ type: 'error', message: msg });
      setTimeout(() => setMasterNotice(null), 4000);
    } finally {
      setIsExportingMaster(false);
    }
  };

  const handleCopyStudentId = (idStr: string) => {
    if (!idStr) return;
    try {
      navigator.clipboard.writeText(idStr);
      setCopiedId(idStr);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      setCopiedId(idStr);
      setTimeout(() => setCopiedId(null), 2500);
    }
  };

  // Generate complete report data dynamically from actual exam and student state
  const reportData: StudentProgressReportData | null = useMemo(() => {
    return generateStudentReport(selectedStudent, exams, {
      subjectName: currentSubject?.name || 'ICT',
    });
  }, [selectedStudent, exams, currentSubject]);

  const handleOpenReportModal = () => {
    if (!selectedStudent || students.length === 0) {
      setReportNotice('Please select a student first.');
      setTimeout(() => setReportNotice(null), 4000);
      return;
    }
    if (!reportData || reportData.totalExams === 0) {
      setReportNotice('এই শিক্ষার্থীর জন্য এখনো কোনো পরীক্ষার তথ্য পাওয়া যায়নি।');
      setTimeout(() => setReportNotice(null), 4000);
      return;
    }
    setReportNotice(null);
    setIsReportModalOpen(true);
  };

  // Top 3 students by average mark calculation
  const topStudents: TopStudent[] = useMemo(() => {
    if (exams.length === 0 || students.length === 0) return [];

    const list: {
      student: Student;
      averageScore: number;
      averagePercentage: number;
      overallGrade: string;
      examsCount: number;
      totalMarksScored: number;
    }[] = [];

    students.forEach((student) => {
      let examsCount = 0;
      let totalMarksSum = 0;
      let percentageSum = 0;

      exams.forEach((exam) => {
        const entry = exam.marks[student.id];
        if (entry !== undefined && entry.total !== undefined) {
          examsCount++;
          totalMarksSum += entry.total;
          percentageSum += entry.percentage;
        }
      });

      if (examsCount > 0) {
        const averageScore = Number((totalMarksSum / examsCount).toFixed(1));
        const averagePercentage = Math.round(percentageSum / examsCount);
        const overallGrade = calculateGrade(averagePercentage);

        list.push({
          student,
          averageScore,
          averagePercentage,
          overallGrade,
          examsCount,
          totalMarksScored: totalMarksSum,
        });
      }
    });

    // Sort by averagePercentage DESC, then averageScore DESC, then roll ASC
    list.sort((a, b) => {
      if (b.averagePercentage !== a.averagePercentage) {
        return b.averagePercentage - a.averagePercentage;
      }
      if (b.averageScore !== a.averageScore) {
        return b.averageScore - a.averageScore;
      }
      return a.student.roll - b.student.roll;
    });

    return list.slice(0, 3).map((item, idx) => ({
      ...item,
      rank: idx + 1,
    }));
  }, [exams, students]);

  // Sort ALL exams by date from OLDEST to NEWEST as specified:
  // "Automatically sort results by exam date from oldest to newest."
  const studentResults: StudentExamRow[] = useMemo(() => {
    const sorted = [...exams].sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      if (dateA !== dateB) return dateA - dateB;
      return a.createdAt - b.createdAt;
    });

    const rows: StudentExamRow[] = [];

    sorted.forEach((exam) => {
      const markEntry = exam.marks[selectedStudent.id];
      if (markEntry) {
        const examRank = getStudentExamPosition(selectedStudent.id, exam, students);
        rows.push({
          examId: exam.id,
          date: exam.date,
          examName: exam.name,
          positionBengali: examRank.positionBengali,
          cq: markEntry.cq,
          mcq: markEntry.mcq,
          total: markEntry.total,
          percentage: markEntry.percentage,
          grade: markEntry.grade,
          totalFullMarks: exam.totalFullMarks,
        });
      }
    });

    return rows;
  }, [exams, selectedStudent.id, students]);

  // Statistics calculation
  const stats = useMemo(() => {
    if (studentResults.length === 0) return null;

    const totalExams = studentResults.length;
    let cqSum = 0;
    let mcqSum = 0;
    let totalMarksSum = 0;
    let percentageSum = 0;

    let highest = -Infinity;
    let lowest = Infinity;

    studentResults.forEach((r) => {
      const cqVal = r.cq === '' ? 0 : Number(r.cq);
      const mcqVal = r.mcq === '' ? 0 : Number(r.mcq);
      cqSum += cqVal;
      mcqSum += mcqVal;
      totalMarksSum += r.total;
      percentageSum += r.percentage;

      if (r.total > highest) highest = r.total;
      if (r.total < lowest) lowest = r.total;
    });

    const cqAverage = Number((cqSum / totalExams).toFixed(1));
    const mcqAverage = Number((mcqSum / totalExams).toFixed(1));
    const totalAverage = Number((totalMarksSum / totalExams).toFixed(1));
    const averagePercentage = Math.round(percentageSum / totalExams);
    const overallGrade = calculateGrade(averagePercentage);

    return {
      totalExams,
      cqAverage,
      mcqAverage,
      totalAverage,
      averagePercentage,
      overallGrade,
      highestScore: highest === -Infinity ? 0 : highest,
      lowestScore: lowest === Infinity ? 0 : lowest,
    };
  }, [studentResults]);

  return (
    <div id="page-student-progress" className="space-y-6 pb-10">
      {/* Top 3 Performers Visual Summary */}
      {topStudents.length > 0 && (
        <section
          id="top-performers-summary"
          className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-3.5"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shrink-0">
                <Trophy className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-tight flex items-center gap-1.5">
                  <span>শীর্ষ ৩ শিক্ষার্থী (Top 3 Performers)</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                    গড় নম্বর
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  গড় নম্বরের ভিত্তিতে সর্বোচ্চ ফলাফল অর্জনকারী সেরা ৩ জন শিক্ষার্থী
                </p>
              </div>
            </div>

            <span className="text-[11px] text-slate-400 self-start sm:self-auto italic">
              *কার্ডে ক্লিক করে শিক্ষার্থীর বিস্তারিত দেখুন
            </span>
          </div>

          {/* Top 3 Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {topStudents.map((top) => {
              const isSelected = selectedStudent.id === top.student.id;
              const gradeColors = getGradeBadgeColor(top.overallGrade);

              // Distinct visual styling per rank (Gold, Silver, Bronze)
              const rankConfig =
                top.rank === 1
                  ? {
                      border: 'border-amber-300 hover:border-amber-400',
                      bg: 'bg-gradient-to-b from-amber-50/70 via-white to-white',
                      badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
                      label: '১ম স্থান',
                      subLabel: '1st',
                      icon: <Trophy className="w-4 h-4 text-amber-500 shrink-0" />,
                    }
                  : top.rank === 2
                  ? {
                      border: 'border-slate-300 hover:border-slate-400',
                      bg: 'bg-gradient-to-b from-slate-50/70 via-white to-white',
                      badgeBg: 'bg-slate-100 text-slate-700 border-slate-200',
                      label: '২য় স্থান',
                      subLabel: '2nd',
                      icon: <Medal className="w-4 h-4 text-slate-400 shrink-0" />,
                    }
                  : {
                      border: 'border-amber-700/25 hover:border-amber-700/40',
                      bg: 'bg-gradient-to-b from-amber-50/40 via-white to-white',
                      badgeBg: 'bg-amber-50 text-amber-900 border-amber-200',
                      label: '৩য় স্থান',
                      subLabel: '3rd',
                      icon: <Medal className="w-4 h-4 text-amber-700 shrink-0" />,
                    };

              return (
                <div
                  key={top.student.id}
                  id={`top-student-card-rank-${top.rank}`}
                  onClick={() => setSelectedStudentId(top.student.id)}
                  className={`relative p-3.5 rounded-xl border ${rankConfig.border} ${rankConfig.bg} transition-all duration-150 cursor-pointer shadow-2xs flex flex-col justify-between gap-3 ${
                    isSelected
                      ? 'ring-2 ring-indigo-600 border-indigo-600 shadow-xs'
                      : 'hover:shadow-xs'
                  }`}
                  title={`${top.student.name}-এর বিস্তারিত ফলাফল দেখতে ক্লিক করুন`}
                >
                  {/* Top Bar: Rank Badge + Grade */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold border ${rankConfig.badgeBg}`}
                    >
                      {rankConfig.icon}
                      <span>
                        {rankConfig.label} ({rankConfig.subLabel})
                      </span>
                    </span>

                    <span
                      className={`inline-block px-2 py-0.5 text-xs font-extrabold rounded-md border ${gradeColors.bg} ${gradeColors.text} ${gradeColors.border}`}
                    >
                      {top.overallGrade}
                    </span>
                  </div>

                  {/* Student Name & Roll */}
                  <div>
                    <h3 className="text-base font-bold text-slate-900 leading-tight">
                      {top.student.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      রোল: <span className="font-semibold text-slate-700">{toBengaliNum(top.student.roll)}</span>
                    </p>
                  </div>

                  {/* Metrics Row */}
                  <div className="pt-2 border-t border-slate-100/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-slate-500 block text-xs font-semibold">গড় নম্বর</span>
                      <span className="font-extrabold text-slate-900 text-sm">
                        {toBengaliNum(top.averageScore)}
                      </span>
                    </div>

                    <div className="text-center">
                      <span className="text-slate-500 block text-xs font-semibold">শতাংশ</span>
                      <span className="font-extrabold text-indigo-600 text-sm">
                        {toBengaliNum(top.averagePercentage)}%
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-slate-500 block text-xs font-semibold">মোট পরীক্ষা</span>
                      <span className="font-bold text-slate-700">
                        {toBengaliNum(top.examsCount)}টি
                      </span>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="text-xs font-semibold text-indigo-600 flex items-center justify-center gap-1 bg-indigo-50/80 py-1.5 rounded-md">
                      <span>✓ বর্তমানে নির্বাচিত</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Top Header & Dropdown Section */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 uppercase tracking-wider">
            <TrendingUp className="w-4 h-4" />
            <span>Student Progress (শিক্ষার্থীর অগ্রগতি)</span>
          </div>
          {currentSubject && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-blue-950 to-indigo-950 text-amber-300 font-black text-xs sm:text-sm border border-blue-800 shadow-xs">
              <span>📚 বিষয়:</span>
              <span className="text-sm font-black tracking-tight">{currentSubject.name}</span>
            </div>
          )}
        </div>

        <label
          htmlFor="student-select-dropdown"
          className="block text-sm font-bold text-slate-800 mb-2"
        >
          Select Student ▼ (শিক্ষার্থী নির্বাচন করুন)
        </label>

        {/* Dropdown with students */}
        <div className="relative">
          <select
            id="student-select-dropdown"
            value={selectedStudent.id}
            onChange={(e) => setSelectedStudentId(e.target.value)}
            className="w-full appearance-none bg-slate-50 border-2 border-indigo-200 hover:border-indigo-400 focus:border-indigo-600 rounded-xl px-4 py-3.5 pr-10 text-base font-bold text-slate-900 focus:outline-hidden focus:bg-white shadow-xs cursor-pointer transition-colors"
          >
            {sortedStudents.map((student) => (
              <option key={student.id} value={student.id} className="py-2">
                {student.studentIdCode ? `[${student.studentIdCode}] ` : ''}রোল {toBengaliNum(student.roll)} : {student.name}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-indigo-600">
            <ChevronDown className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>

        {/* Current Student Profile Banner */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 font-extrabold flex items-center justify-center text-sm border border-indigo-200 shrink-0">
              {toBengaliNum(selectedStudent.roll)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 leading-tight">
                  {selectedStudent.name}
                </h3>
                {selectedStudent.studentIdCode && (
                  <div className="inline-flex items-center gap-1 bg-slate-900 text-white px-2 py-0.5 rounded font-mono text-xs font-bold shadow-2xs">
                    <span>{selectedStudent.studentIdCode}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyStudentId(selectedStudent.studentIdCode || '')}
                      className="text-slate-300 hover:text-white p-0.5 transition-colors cursor-pointer"
                      title="Student ID কপি করুন"
                    >
                      {copiedId === selectedStudent.studentIdCode ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                )}
                {copiedId === selectedStudent.studentIdCode && (
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                    কপি হয়েছে!
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                রোল: {toBengaliNum(selectedStudent.roll)} • শ্রেণি: {selectedStudent.academicClass || 'XI'} ({selectedStudent.group || 'B-A'}) • সেশন: {selectedStudent.session || '2026'} • মোট পরীক্ষা: {toBengaliNum(studentResults.length)}টি
              </p>
            </div>
          </div>

          {stats && (
            <div className="text-right">
              <span className="text-xs text-slate-500 font-medium block">সর্বমোট গ্রেড</span>
              <span
                className={`inline-block px-3 py-0.5 text-sm font-extrabold rounded-md border ${
                  getGradeBadgeColor(stats.overallGrade).bg
                } ${getGradeBadgeColor(stats.overallGrade).text} ${
                  getGradeBadgeColor(stats.overallGrade).border
                }`}
              >
                {stats.overallGrade} ({toBengaliNum(stats.averagePercentage)}%)
              </span>
            </div>
          )}
        </div>

        {/* Generate Academic Progress Report Card & Teacher-only Master Result Excel */}
        <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-medium">
            {studentResults.length > 0
              ? 'শিক্ষার্থীর ফলাফল, চার্ট ও বিশ্লেষণসহ প্রিন্ট-রেডি একাডেমিক প্রগ্রেস রিপোর্ট তৈরি করুন'
              : 'পরীক্ষার তথ্য সংরক্ষণের পর রিপোর্ট ডাউনলোড করা যাবে'}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Teacher Exclusive Master Result Sheet Button */}
            {isTeacher && (
              <button
                type="button"
                id="progress-export-master-excel-btn"
                onClick={handleExportMasterExcel}
                disabled={isExportingMaster || exams.length === 0}
                title="শিক্ষকদের জন্য: সকল শিক্ষার্থীর সকল পরীক্ষার CQ, MCQ এবং Total সম্বলিত পূর্ণাঙ্গ মাস্টার এক্সেল শীট"
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs sm:text-sm shadow-xs hover:shadow-md transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
              >
                {isExportingMaster ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Preparing Excel...</span>
                  </>
                ) : (
                  <>
                    <FileSpreadsheet className="w-4 h-4" />
                    <span>📊 Complete Result Excel</span>
                  </>
                )}
              </button>
            )}

            <button
              type="button"
              id="generate-progress-card-btn"
              onClick={handleOpenReportModal}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 hover:from-blue-950 hover:to-indigo-950 active:scale-98 text-white font-bold text-xs sm:text-sm shadow-sm hover:shadow-md transition-all cursor-pointer shrink-0"
            >
              <FileText className="w-4 h-4" />
              <span>📄 Generate Progress Card</span>
            </button>
          </div>
        </div>

        {/* Master Excel Feedback Notice */}
        {masterNotice && (
          <div
            id="master-excel-notice"
            className={`mt-3 p-3 rounded-xl border text-xs font-semibold flex items-center justify-between gap-2 shadow-2xs ${
              masterNotice.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {masterNotice.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              )}
              <span>{masterNotice.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setMasterNotice(null)}
              className="text-xs uppercase font-bold hover:opacity-75"
            >
              ✕
            </button>
          </div>
        )}

        {/* Empty data notification when user clicks generate without exams */}
        {reportNotice && (
          <div
            id="empty-report-warning"
            className="mt-3 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold flex items-center gap-2 shadow-2xs"
          >
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
            <span>{reportNotice}</span>
          </div>
        )}
      </div>

      {/* When no exams exist for this student */}
      {studentResults.length === 0 ? (
        <div
          id="no-result-message"
          className="bg-white rounded-2xl p-8 border border-slate-200 text-center shadow-2xs space-y-3"
        >
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Clock className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-slate-700">
            এই শিক্ষার্থীর কোনো পরীক্ষার ফলাফল এখনো নেই।
          </p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            পরীক্ষার নম্বর এন্ট্রি পেজে গিয়ে নতুন পরীক্ষা সংরক্ষণ করলে এখানে ফলাফল চলে আসবে।
          </p>
        </div>
      ) : (
        <>
          {/* Table of ALL exam results */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-3.5 sm:p-4 bg-slate-50/90 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900">
                  সকল পরীক্ষার ফলাফল বিবরণী
                </h4>
                <p className="text-xs text-slate-500">
                  তারিখ অনুযায়ী ক্রমানুসারে সাজানো (পুরাতন থেকে নতুন)
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                {toBengaliNum(studentResults.length)}টি পরীক্ষা
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm" id="student-progress-table">
                <thead className="bg-slate-100/90 text-slate-700 text-xs uppercase font-bold tracking-wider">
                  <tr>
                    <th className="py-2.5 px-3 whitespace-nowrap">Date</th>
                    <th className="py-2.5 px-3 min-w-[130px]">Exam</th>
                    <th className="py-2.5 px-2 text-center w-16 text-amber-700 bg-amber-50/70 font-black">অবস্থান</th>
                    <th className="py-2.5 px-2 text-center w-16">CQ</th>
                    <th className="py-2.5 px-2 text-center w-16">MCQ</th>
                    <th className="py-2.5 px-2 text-center w-20">Total</th>
                    <th className="py-2.5 px-2 text-center w-16">%</th>
                    <th className="py-2.5 px-3 text-center w-20">Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {studentResults.map((result, idx) => {
                    const gradeColor = getGradeBadgeColor(result.grade);
                    return (
                      <tr
                        key={result.examId || idx}
                        className="hover:bg-slate-50/80 transition-colors"
                      >
                        {/* Date */}
                        <td className="py-2.5 px-3 text-xs font-medium text-slate-600 whitespace-nowrap">
                          {result.date}
                        </td>

                        {/* Exam Name */}
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {currentSubject && (
                              <span className="inline-block px-2 py-0.5 rounded-md bg-blue-900 text-amber-300 font-extrabold text-[11px] shadow-2xs border border-blue-950">
                                {currentSubject.name}
                              </span>
                            )}
                            <span>{result.examName}</span>
                          </div>
                        </td>

                        {/* Position / Rank in Exam */}
                        <td className="py-2.5 px-2 text-center font-bold text-xs text-blue-950 bg-slate-50/70">
                          {result.positionBengali}
                        </td>

                        {/* CQ */}
                        <td className="py-2.5 px-2 text-center text-slate-700 font-medium">
                          {result.cq !== '' ? toBengaliNum(result.cq) : '-'}
                        </td>

                        {/* MCQ */}
                        <td className="py-2.5 px-2 text-center text-slate-700 font-medium">
                          {result.mcq !== '' ? toBengaliNum(result.mcq) : '-'}
                        </td>

                        {/* Total */}
                        <td className="py-2.5 px-2 text-center font-bold text-indigo-700 text-sm">
                          {toBengaliNum(result.total)}
                        </td>

                        {/* Percentage */}
                        <td className="py-2.5 px-2 text-center text-xs font-semibold text-slate-600">
                          {toBengaliNum(result.percentage)}%
                        </td>

                        {/* Grade */}
                        <td className="py-2.5 px-3 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 text-xs font-bold rounded-md border ${gradeColor.bg} ${gradeColor.text} ${gradeColor.border}`}
                          >
                            {result.grade}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* REQUIRED STATISTICS SECTION */}
          {stats && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                  <BarChart3 className="w-4 h-4 text-indigo-600" />
                  <span>সামগ্রিক পরিসংখ্যান (Overall Statistics)</span>
                </h4>
              </div>

              <div
                id="student-statistics-grid"
                className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3"
              >
                {/* Total Exams */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">Total Exams</span>
                  <span className="text-xs text-slate-400 font-normal">মোট পরীক্ষা</span>
                  <p className="text-2xl font-bold text-slate-900 mt-1">
                    {toBengaliNum(stats.totalExams)}
                  </p>
                </div>

                {/* CQ Average */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">CQ Average</span>
                  <span className="text-xs text-slate-400 font-normal">গড় সিকিউ</span>
                  <p className="text-2xl font-bold text-indigo-600 mt-1">
                    {toBengaliNum(stats.cqAverage)}
                  </p>
                </div>

                {/* MCQ Average */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">MCQ Average</span>
                  <span className="text-xs text-slate-400 font-normal">গড় এমসিকিউ</span>
                  <p className="text-2xl font-bold text-teal-600 mt-1">
                    {toBengaliNum(stats.mcqAverage)}
                  </p>
                </div>

                {/* Total Average */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">Total Average</span>
                  <span className="text-xs text-slate-400 font-normal">গড় মোট নম্বর</span>
                  <p className="text-2xl font-bold text-blue-600 mt-1">
                    {toBengaliNum(stats.totalAverage)}
                  </p>
                </div>

                {/* Average Percentage */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">
                    Average Percentage
                  </span>
                  <span className="text-xs text-slate-400 font-normal">গড় শতকরা</span>
                  <p className="text-2xl font-bold text-emerald-600 mt-1">
                    {toBengaliNum(stats.averagePercentage)}%
                  </p>
                </div>

                {/* Overall Grade */}
                <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
                  <span className="text-xs font-semibold text-slate-500 block">Overall Grade</span>
                  <span className="text-xs text-slate-400 font-normal">সর্বমোট গ্রেড</span>
                  <p className="text-2xl font-black text-indigo-700 mt-1">
                    {stats.overallGrade}
                  </p>
                </div>

                {/* Highest Score */}
                <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-800 block">
                      Highest Score
                    </span>
                    <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                  </div>
                  <span className="text-xs text-emerald-600 font-normal">সর্বোচ্চ নম্বর</span>
                  <p className="text-2xl font-bold text-emerald-700 mt-1">
                    {toBengaliNum(stats.highestScore)}
                  </p>
                </div>

                {/* Lowest Score */}
                <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-200 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-rose-800 block">Lowest Score</span>
                    <ArrowDownRight className="w-4 h-4 text-rose-600" />
                  </div>
                  <span className="text-xs text-rose-600 font-normal">সর্বনিম্ন নম্বর</span>
                  <p className="text-2xl font-bold text-rose-700 mt-1">
                    {toBengaliNum(stats.lowestScore)}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* SIMPLE PROGRESS LINE CHART */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-indigo-600" />
                  <span>অগ্রগতি রেখাচিত্র (Progress Line Chart)</span>
                </h4>
                <p className="text-xs text-slate-500">
                  সময়ের সাথে শিক্ষার্থীর মোট নম্বরের পরিবর্তন (Total Marks over time)
                </p>
              </div>

              {stats && (
                <div className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-100">
                  গড়: {toBengaliNum(stats.totalAverage)}
                </div>
              )}
            </div>

            {/* Custom SVG Line Chart */}
            <StudentLineChart results={studentResults} average={stats?.totalAverage ?? 0} />
          </div>
        </>
      )}

      {/* Professional Academic Progress Report Modal (Teachers can edit remarks) */}
      <ProgressReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        reportData={reportData}
        allExams={exams}
        student={selectedStudent}
        subjectName={currentSubject?.name || 'ICT'}
        canEditRemark={isTeacher}
      />
    </div>
  );
}

// Clean SVG Line Chart Component
function StudentLineChart({
  results,
  average,
}: {
  results: StudentExamRow[];
  average: number;
}) {
  if (results.length === 0) return null;

  // Find max mark for y-axis scaling
  const maxPossible = Math.max(...results.map((r) => r.totalFullMarks || 100), 100);
  const maxScore = Math.max(...results.map((r) => r.total), 10);
  const chartMax = Math.min(maxPossible, Math.max(100, Math.ceil(maxScore / 10) * 10));

  const width = 600;
  const height = 240;
  const paddingLeft = 45;
  const paddingRight = 35;
  const paddingTop = 30;
  const paddingBottom = 45;

  const innerWidth = width - paddingLeft - paddingRight;
  const innerHeight = height - paddingTop - paddingBottom;

  // X coordinate calculation
  const getX = (index: number) => {
    if (results.length === 1) return paddingLeft + innerWidth / 2;
    return paddingLeft + (index / (results.length - 1)) * innerWidth;
  };

  // Y coordinate calculation
  const getY = (val: number) => {
    return paddingTop + innerHeight - (val / chartMax) * innerHeight;
  };

  // Generate SVG path for line
  const points = results.map((r, i) => ({
    x: getX(i),
    y: getY(r.total),
    val: r.total,
    date: r.date,
    name: r.examName,
    grade: r.grade,
  }));

  const linePathD = points.reduce((acc, pt, i) => {
    return i === 0 ? `M ${pt.x},${pt.y}` : `${acc} L ${pt.x},${pt.y}`;
  }, '');

  // Fill area under line
  const areaPathD =
    points.length > 0
      ? `${linePathD} L ${points[points.length - 1].x},${paddingTop + innerHeight} L ${
          points[0].x
        },${paddingTop + innerHeight} Z`
      : '';

  // Average line Y
  const avgY = getY(average);

  // Y-axis grid ticks (e.g. 0, 25, 50, 75, 100)
  const yTicks = [0, Math.round(chartMax * 0.25), Math.round(chartMax * 0.5), Math.round(chartMax * 0.75), chartMax];

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[460px] relative">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible select-none"
        >
          <defs>
            {/* Soft gradient fill under the line */}
            <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#4f46e5" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Horizontal Grid lines */}
          {yTicks.map((tickVal) => {
            const y = getY(tickVal);
            return (
              <g key={tickVal}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#e2e8f0"
                  strokeWidth="1"
                  strokeDasharray={tickVal === 0 ? 'none' : '3 3'}
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="10"
                  fill="#94a3b8"
                  fontWeight="500"
                >
                  {toBengaliNum(tickVal)}
                </text>
              </g>
            );
          })}

          {/* Average Dashed Reference Line */}
          {results.length > 1 && (
            <g>
              <line
                x1={paddingLeft}
                y1={avgY}
                x2={width - paddingRight}
                y2={avgY}
                stroke="#10b981"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />
              <text
                x={width - paddingRight + 5}
                y={avgY + 3}
                fontSize="9"
                fill="#059669"
                fontWeight="600"
              >
                গড় ({toBengaliNum(average)})
              </text>
            </g>
          )}

          {/* Area Fill */}
          {areaPathD && <path d={areaPathD} fill="url(#chartGradient)" />}

          {/* Main Progress Line */}
          {linePathD && (
            <path
              d={linePathD}
              fill="none"
              stroke="#4f46e5"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Data Points and Labels */}
          {points.map((pt, idx) => (
            <g key={idx} className="group">
              {/* Vertical guideline */}
              <line
                x1={pt.x}
                y1={pt.y}
                x2={pt.x}
                y2={paddingTop + innerHeight}
                stroke="#cbd5e1"
                strokeWidth="1"
                strokeDasharray="2 2"
              />

              {/* Point outer ring */}
              <circle
                cx={pt.x}
                cy={pt.y}
                r="6"
                fill="#ffffff"
                stroke="#4f46e5"
                strokeWidth="2.5"
              />

              {/* Score Value Label above point */}
              <rect
                x={pt.x - 16}
                y={pt.y - 24}
                width="32"
                height="16"
                rx="4"
                fill="#1e1b4b"
              />
              <text
                x={pt.x}
                y={pt.y - 13}
                textAnchor="middle"
                fontSize="10"
                fill="#ffffff"
                fontWeight="bold"
              >
                {toBengaliNum(pt.val)}
              </text>

              {/* X-axis Exam Name/Date */}
              <text
                x={pt.x}
                y={paddingTop + innerHeight + 16}
                textAnchor="middle"
                fontSize="11"
                fill="#1e293b"
                fontWeight="600"
              >
                {pt.name.length > 14 ? pt.name.slice(0, 12) + '...' : pt.name}
              </text>
              <text
                x={pt.x}
                y={paddingTop + innerHeight + 30}
                textAnchor="middle"
                fontSize="9"
                fill="#64748b"
              >
                {pt.date}
              </text>
            </g>
          ))}
        </svg>

        {/* Legend */}
        <div className="mt-2 flex items-center justify-center gap-6 text-xs text-slate-500 font-medium">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-indigo-600 inline-block"></span>
            <span>মোট নম্বর (Total Marks)</span>
          </div>
          {results.length > 1 && (
            <div className="flex items-center gap-2">
              <span className="w-4 h-0.5 border-t-2 border-dashed border-emerald-500 inline-block"></span>
              <span>শিক্ষার্থীর গড় নম্বর (Average)</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
