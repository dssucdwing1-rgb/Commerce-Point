import { Student, Exam } from '../../types';
import { calculateGrade } from '../../data/initialData';

export interface ExamReportRow {
  sl: number;
  examId: string;
  dateStr: string; // e.g. "05 Jan 2026"
  rawDate: string; // YYYY-MM-DD
  examName: string;
  fullMarks: number;
  obtainedMarksStr: string; // "42" or "Absent"
  obtainedScore: number | null;
  percentageStr: string; // "84%" or "—"
  percentageNum: number | null;
  status: 'Excellent' | 'Very Good' | 'Good' | 'Satisfactory' | 'Needs Improvement' | 'Absent';
  statusBadgeClass: string;
  isAbsent: boolean;
}

export type ReportType = 'complete' | 'monthly';

export interface StudentProgressReportData {
  reportType: ReportType;
  selectedMonth?: string; // e.g. "2026-08"
  selectedMonthLabel?: string; // e.g. "Aug 2026"
  student: Student;
  studentIdFormatted: string; // e.g. "CP/C-11/B-A 001"
  studentGroup: string; // e.g. "B-A"
  academicClass: string; // e.g. "XII"
  subject: string; // e.g. "ICT"
  academicSession: string; // e.g. "2026"
  reportDateStr: string; // e.g. "22 Sep 2026"
  totalExams: number;
  attendedExams: number;
  absentExams: number;
  attendanceRate: number; // e.g. 91.67
  totalFullMarks: number; // for attended exams
  totalObtainedMarks: number;
  averageScore: number;
  overallPercentage: number;
  overallGrade: string;
  overallStatus: 'Excellent' | 'Very Good' | 'Good' | 'Satisfactory' | 'Needs Improvement';
  highestScore: number;
  highestFullMarks: number;
  highestScoreFormatted: string; // e.g. "48 / 50"
  highestExamName: string;
  lowestScore: number;
  lowestFullMarks: number;
  lowestScoreFormatted: string; // e.g. "32 / 50"
  lowestExamName: string;
  firstExamScore: number | null;
  latestExamScore: number | null;
  trend: 'Improving' | 'Stable' | 'Declining';
  trendLabelBn: string;
  strengths: string[];
  improvements: string[];
  examRows: ExamReportRow[];
  chartData: {
    sl: number;
    label: string;
    date: string;
    score: number;
    fullMarks: number;
    percentage: number;
    isAbsent: boolean;
  }[];
}

// Format date into standard academic format: "05 Jan 2026"
export const MONTH_NAMES_SHORT = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

export function getAvailableMonths(exams: Exam[]): { key: string; label: string }[] {
  const monthMap = new Map<string, string>();
  exams.forEach((e) => {
    if (e.date && e.date.length >= 7) {
      const key = e.date.substring(0, 7); // "YYYY-MM"
      if (!monthMap.has(key)) {
        const parts = key.split('-');
        const year = parts[0];
        const monthIdx = parseInt(parts[1], 10) - 1;
        const monthName = MONTH_NAMES_SHORT[monthIdx] || parts[1];
        monthMap.set(key, `${monthName} ${year}`);
      }
    }
  });

  return Array.from(monthMap.entries())
    .sort((a, b) => b[0].localeCompare(a[0])) // latest month first
    .map(([key, label]) => ({ key, label }));
}

export function formatDateCompact(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const year = parts[0];
    const monthIdx = parseInt(parts[1], 10) - 1;
    const day = String(parseInt(parts[2], 10)).padStart(2, '0');
    const month = MONTH_NAMES_SHORT[monthIdx] || parts[1];
    return `${day} ${month} ${year}`;
  }
  return dateStr;
}

export function formatDateShortDDMMYY(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const day = String(parseInt(parts[2], 10)).padStart(2, '0');
    const monthIdx = parseInt(parts[1], 10) - 1;
    const month = MONTH_NAMES_SHORT[monthIdx] || parts[1];
    return `${day} ${month}`;
  }
  return dateStr;
}

// Status calculation based on percentage rules
export function getPerformanceStatus(
  percentage: number | null,
  isAbsent: boolean
): {
  status: 'Excellent' | 'Very Good' | 'Good' | 'Satisfactory' | 'Needs Improvement' | 'Absent';
  statusBadgeClass: string;
} {
  if (isAbsent || percentage === null) {
    return {
      status: 'Absent',
      statusBadgeClass: 'bg-rose-50 text-rose-700 border border-rose-200',
    };
  }
  if (percentage >= 90) {
    return {
      status: 'Excellent',
      statusBadgeClass: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
    };
  }
  if (percentage >= 80) {
    return {
      status: 'Very Good',
      statusBadgeClass: 'bg-blue-50 text-blue-700 border border-blue-200',
    };
  }
  if (percentage >= 70) {
    return {
      status: 'Good',
      statusBadgeClass: 'bg-teal-50 text-teal-700 border border-teal-200',
    };
  }
  if (percentage >= 60) {
    return {
      status: 'Satisfactory',
      statusBadgeClass: 'bg-amber-50 text-amber-700 border border-amber-200',
    };
  }
  return {
    status: 'Needs Improvement',
    statusBadgeClass: 'bg-rose-50 text-rose-700 border border-rose-200',
  };
}

// Generate the complete student progress report object
export function generateStudentReport(
  student: Student,
  allExams: Exam[],
  options?: {
    reportType?: ReportType;
    selectedMonth?: string;
    subjectName?: string;
  }
): StudentProgressReportData | null {
  if (!allExams || allExams.length === 0) {
    return null;
  }

  const reportType: ReportType = options?.reportType || 'complete';
  const selectedMonth = options?.selectedMonth;

  // Filter exams if monthly
  let targetExams = allExams;
  let selectedMonthLabel: string | undefined;

  if (reportType === 'monthly' && selectedMonth) {
    targetExams = allExams.filter((e) => e.date && e.date.startsWith(selectedMonth));
    if (selectedMonth.length >= 7) {
      const parts = selectedMonth.split('-');
      const year = parts[0];
      const monthIdx = parseInt(parts[1], 10) - 1;
      const mName = MONTH_NAMES_SHORT[monthIdx] || parts[1];
      selectedMonthLabel = `${mName} ${year}`;
    }
  }

  if (targetExams.length === 0) {
    // If no exams found for that specific month, fallback to empty representation or handle gracefully
    targetExams = allExams; // fallback so report still shows
  }

  // Sort exams strictly by date from oldest to newest (ascending)
  const sortedExams = [...targetExams].sort((a, b) => {
    const timeA = new Date(a.date).getTime();
    const timeB = new Date(b.date).getTime();
    if (timeA !== timeB) return timeA - timeB;
    return a.createdAt - b.createdAt;
  });

  const examRows: ExamReportRow[] = [];
  const attendedRows: {
    score: number;
    fullMarks: number;
    percentage: number;
    name: string;
    date: string;
    index: number;
  }[] = [];

  const chartData: {
    sl: number;
    label: string;
    date: string;
    score: number;
    fullMarks: number;
    percentage: number;
    isAbsent: boolean;
  }[] = [];

  sortedExams.forEach((exam, idx) => {
    const markEntry = exam.marks ? exam.marks[student.id] : undefined;

    // Check if student was absent
    const isAbsent =
      !markEntry ||
      (markEntry.cq === '' && markEntry.mcq === '') ||
      (markEntry.total === 0 && markEntry.cq === '' && markEntry.mcq === '');

    const fullMarks = exam.totalFullMarks || (exam.cqFullMarks || 0) + (exam.mcqFullMarks || 0) || 50;

    if (isAbsent) {
      const statusObj = getPerformanceStatus(null, true);
      examRows.push({
        sl: idx + 1,
        examId: exam.id,
        dateStr: formatDateCompact(exam.date),
        rawDate: exam.date,
        examName: exam.name,
        fullMarks,
        obtainedMarksStr: 'Absent',
        obtainedScore: null,
        percentageStr: '—',
        percentageNum: null,
        status: statusObj.status,
        statusBadgeClass: statusObj.statusBadgeClass,
        isAbsent: true,
      });

      chartData.push({
        sl: idx + 1,
        label: `E${idx + 1}`,
        date: formatDateShortDDMMYY(exam.date),
        score: 0,
        fullMarks,
        percentage: 0,
        isAbsent: true,
      });
    } else {
      const score = markEntry.total;
      const percentage =
        fullMarks > 0 ? Number(((score / fullMarks) * 100).toFixed(2)) : markEntry.percentage;

      attendedRows.push({
        score,
        fullMarks,
        percentage,
        name: exam.name,
        date: exam.date,
        index: idx + 1,
      });

      const statusObj = getPerformanceStatus(percentage, false);

      examRows.push({
        sl: idx + 1,
        examId: exam.id,
        dateStr: formatDateCompact(exam.date),
        rawDate: exam.date,
        examName: exam.name,
        fullMarks,
        obtainedMarksStr: String(score),
        obtainedScore: score,
        percentageStr: `${Math.round(percentage)}%`,
        percentageNum: percentage,
        status: statusObj.status,
        statusBadgeClass: statusObj.statusBadgeClass,
        isAbsent: false,
      });

      chartData.push({
        sl: idx + 1,
        label: `E${idx + 1}`,
        date: formatDateShortDDMMYY(exam.date),
        score,
        fullMarks,
        percentage,
        isAbsent: false,
      });
    }
  });

  const totalExams = examRows.length;
  const attendedExams = attendedRows.length;
  const absentExams = totalExams - attendedExams;
  const attendanceRate = totalExams > 0 ? Number(((attendedExams / totalExams) * 100).toFixed(2)) : 0;

  // Attended metrics
  const totalFullMarks = attendedRows.reduce((sum, r) => sum + r.fullMarks, 0);
  const totalObtainedMarks = attendedRows.reduce((sum, r) => sum + r.score, 0);
  const averageScore = attendedExams > 0 ? Number((totalObtainedMarks / attendedExams).toFixed(2)) : 0;
  const overallPercentage =
    totalFullMarks > 0 ? Number(((totalObtainedMarks / totalFullMarks) * 100).toFixed(2)) : 0;
  const overallGrade = calculateGrade(overallPercentage);

  // Overall status rating
  let overallStatus: 'Excellent' | 'Very Good' | 'Good' | 'Satisfactory' | 'Needs Improvement' = 'Satisfactory';
  if (overallPercentage >= 90) overallStatus = 'Excellent';
  else if (overallPercentage >= 80) overallStatus = 'Very Good';
  else if (overallPercentage >= 70) overallStatus = 'Good';
  else if (overallPercentage >= 60) overallStatus = 'Satisfactory';
  else overallStatus = 'Needs Improvement';

  // Highest and Lowest marks
  let highestScore = 0;
  let highestFullMarks = 50;
  let highestExamName = '';
  let lowestScore = 0;
  let lowestFullMarks = 50;
  let lowestExamName = '';

  if (attendedRows.length > 0) {
    const sortedByScore = [...attendedRows].sort((a, b) => b.score - a.score);
    highestScore = sortedByScore[0].score;
    highestFullMarks = sortedByScore[0].fullMarks;
    highestExamName = sortedByScore[0].name;

    const lowestItem = sortedByScore[sortedByScore.length - 1];
    lowestScore = lowestItem.score;
    lowestFullMarks = lowestItem.fullMarks;
    lowestExamName = lowestItem.name;
  }

  const highestScoreFormatted = attendedRows.length > 0 ? `${highestScore} / ${highestFullMarks}` : '—';
  const lowestScoreFormatted = attendedRows.length > 0 ? `${lowestScore} / ${lowestFullMarks}` : '—';

  const firstExamScore = attendedRows.length > 0 ? attendedRows[0].score : null;
  const latestExamScore =
    attendedRows.length > 0 ? attendedRows[attendedRows.length - 1].score : null;

  // Mathematical Trend Analysis (Linear Regression on attended exam percentages)
  let trend: 'Improving' | 'Stable' | 'Declining' = 'Stable';
  let trendLabelBn = 'স্থিতিশীল';

  if (attendedRows.length >= 2) {
    const n = attendedRows.length;
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumXX = 0;

    for (let i = 0; i < n; i++) {
      const x = i;
      const y = attendedRows[i].percentage;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
    }

    const denominator = n * sumXX - sumX * sumX;
    const slope = denominator !== 0 ? (n * sumXY - sumX * sumY) / denominator : 0;

    if (slope >= 0.7) {
      trend = 'Improving';
      trendLabelBn = 'উন্নতিশীল';
    } else if (slope <= -0.7) {
      trend = 'Declining';
      trendLabelBn = 'অবনতিশীল';
    } else {
      trend = 'Stable';
      trendLabelBn = 'স্থিতিশীল';
    }
  }

  // Dynamic Strengths derived strictly from actual data
  const strengths: string[] = [];
  if (attendanceRate >= 95) {
    strengths.push('সকল পরীক্ষায় নিয়মিত ও শতভাগ উপস্থিতি বজায় রেখেছে');
  } else if (attendanceRate >= 80) {
    strengths.push(`নিয়মিত পরীক্ষায় সক্রিয় অংশগ্রহণ (উপস্থিতির হার ${attendanceRate.toFixed(1)}%)`);
  } else {
    strengths.push('পরীক্ষাসমূহে স্বতঃস্ফূর্ত অংশগ্রহণ');
  }

  if (highestScore > 0 && highestExamName) {
    strengths.push(`${highestExamName}-এ সর্বোচ্চ ফলাফল অর্জন (${highestScore} / ${highestFullMarks})`);
  }

  if (trend === 'Improving') {
    strengths.push('সাম্প্রতিক পরীক্ষাসমূহে ধারাবাহিক উন্নতির স্পষ্ট প্রতিফলন');
  } else if (overallPercentage >= 80) {
    strengths.push('সামগ্রিক গড় ফলাফল অত্যন্ত প্রশংসনীয় ও ধারাবাহিক');
  } else if (overallPercentage >= 70) {
    strengths.push('অধিকাংশ পরীক্ষায় সন্তোষজনক নম্বর প্রাপ্তি');
  } else {
    strengths.push('নিয়মিত অনুশীলনের মাধ্যমে ভালো করার বিপুল সম্ভাবনা রয়েছে');
  }

  // Dynamic Areas for Improvement derived strictly from actual data
  const improvements: string[] = [];
  if (lowestScore > 0 && lowestExamName && lowestScore < highestScore) {
    improvements.push(`${lowestExamName}-এ তুলনামূলক কম নম্বর (${lowestScore} / ${lowestFullMarks}), বিশেষ রিভিশন প্রয়োজন`);
  }

  if (absentExams > 0) {
    improvements.push(`অনুপস্থিতি (${absentExams}টি পরীক্ষা) হ্রাস করে প্রতিটি পরীক্ষায় পূর্ণ উপস্থিতি নিশ্চিত করা`);
  }

  if (trend === 'Declining') {
    improvements.push('সাম্প্রতিক পরীক্ষার ফলাফলে কিছুটা ওঠানামা রয়েছে, নিয়মিত রিভিশন জরুরি');
  } else if (overallPercentage < 75) {
    improvements.push('দুর্বল অধ্যায়গুলোতে অতিরিক্ত সময় বরাদ্দ ও নিয়মিত মক টেস্ট অনুশীলন প্রয়োজন');
  } else {
    improvements.push('সৃজনশীল ও বহুনির্বাচনী অংশে নিখুঁত সময় ব্যবস্থাপনা ও পূর্ণ প্রস্তুতি বজায় রাখা');
  }

  // Academic Session
  const years = sortedExams.map((e) => e.date.substring(0, 4));
  const uniqueYears = Array.from(new Set(years));
  const academicSession = student.session || (uniqueYears.length > 0 ? uniqueYears.join('-') : '2026');

  // Report Date formatted: "22 Sep 2026"
  const today = new Date();
  const reportDateStr = formatDateCompact(today.toISOString().split('T')[0]);

  // Student ID formatted: use admin-assigned studentIdCode if present, or fallback
  const studentIdFormatted =
    student.studentIdCode || `CP/C-11/B-A ${String(student.roll).padStart(3, '0')}`;

  return {
    reportType,
    selectedMonth,
    selectedMonthLabel,
    student,
    studentIdFormatted,
    studentGroup: student.group || 'B-A',
    academicClass: student.academicClass || 'XII',
    subject: options?.subjectName || student.subject || 'ICT',
    academicSession,
    reportDateStr,
    totalExams,
    attendedExams,
    absentExams,
    attendanceRate,
    totalFullMarks,
    totalObtainedMarks,
    averageScore,
    overallPercentage,
    overallGrade,
    overallStatus,
    highestScore,
    highestFullMarks,
    highestScoreFormatted,
    highestExamName,
    lowestScore,
    lowestFullMarks,
    lowestScoreFormatted,
    lowestExamName,
    firstExamScore,
    latestExamScore,
    trend,
    trendLabelBn,
    strengths: strengths.slice(0, 4),
    improvements: improvements.slice(0, 3),
    examRows,
    chartData,
  };
}
