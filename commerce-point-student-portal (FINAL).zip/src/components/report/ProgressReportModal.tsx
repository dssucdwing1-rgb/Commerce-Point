import React, { useRef, useState } from 'react';
import {
  X,
  Printer,
  Download,
  ArrowLeft,
  Edit3,
  Check,
  AlertCircle,
  Loader2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { StudentProgressReportData } from './reportData';
import { StudentProgressReportView } from './StudentProgressReportView';
import { exportStudentProgressCardPdfFromElement } from '../../services/pdfExport';

interface ProgressReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportData: StudentProgressReportData | null;
  canEditRemark?: boolean;
  availableMonths?: { key: string; label: string }[];
  selectedReportType?: 'complete' | 'monthly';
  selectedMonth?: string;
  onReportTypeChange?: (type: 'complete' | 'monthly', month?: string) => void;
}

export const ProgressReportModal: React.FC<ProgressReportModalProps> = ({
  isOpen,
  onClose,
  reportData,
  canEditRemark = false,
  availableMonths = [],
  selectedReportType = 'complete',
  selectedMonth,
  onReportTypeChange,
}) => {
  const reportRef = useRef<HTMLDivElement | null>(null);

  const [teacherComment, setTeacherComment] = useState(
    'নিয়মিত অনুশীলন ও দুর্বল বিষয়গুলোতে অতিরিক্ত মনোযোগ দিলে আরও ভালো ফলাফল অর্জন করা সম্ভব।'
  );
  const [isEditingComment, setIsEditingComment] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [previewZoom, setPreviewZoom] = useState<'fit' | '100%'>('fit');

  if (!isOpen || !reportData) return null;

  // Build clean filename according to requirement: StudentName_Progress_Card_Year.pdf
  const getDownloadFilename = (): string => {
    const rawName = reportData.student.name.trim();
    const safeName = rawName.replace(/[\s/\\?%*:|"<>]/g, '_');
    const session = reportData.academicSession || '2026';
    const typePart = reportData.reportType === 'monthly' ? `Monthly_${reportData.selectedMonth || 'Card'}` : 'Progress_Card';
    const subPart = (reportData.subject || 'ICT').replace(/[\s/\\?%*:|"<>]/g, '_');
    return `${safeName}_${subPart}_${typePart}_${session}.pdf`;
  };

  // Handle PDF Generation via centralized high-quality engine
  const handleDownloadPdf = async () => {
    if (!reportRef.current) {
      setErrorMessage('Progress Card তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
      return;
    }

    try {
      setIsGeneratingPdf(true);
      setErrorMessage(null);
      setSuccessMessage('১ পৃষ্ঠার হাই-রেজোলিউশন ও ভেক্টর পিডিএফ প্রস্তুত করা হচ্ছে...');

      const fileName = getDownloadFilename();
      const title = `${reportData.student.name} — Progress Card`;
      await exportStudentProgressCardPdfFromElement(reportRef.current, fileName, title);

      setSuccessMessage('পিডিএফ প্রিভিউ খোলা হয়েছে। রিভিউ করে ডাউনলোড করুন।');
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      console.error('PDF Generation Error:', err);
      setErrorMessage('Progress Card তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Handle native browser print
  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="progress-report-modal"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-start p-2 sm:p-4"
    >
      {/* Sticky Top Control Toolbar (hidden in print) */}
      <div className="no-print sticky top-0 z-20 w-full max-w-4xl bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-slate-200 p-3 sm:p-3.5 mb-3 transition-all">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Left: Back button & Title */}
          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-start">
            <button
              type="button"
              id="report-back-btn"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>← Back</span>
            </button>

            <div>
              <h2 className="text-xs sm:text-sm font-extrabold text-slate-900 leading-tight">
                {reportData.student.name} — Academic Progress Card
              </h2>
              <p className="text-[10.5px] text-slate-500">
                ID: {reportData.studentIdFormatted} • Roll: {reportData.student.roll} • {reportData.totalExams} Exams (1-Page A4)
              </p>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
            {canEditRemark && (
              <button
                type="button"
                id="report-edit-remark-btn"
                onClick={() => setIsEditingComment(!isEditingComment)}
                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                  isEditingComment
                    ? 'bg-blue-50 border-blue-300 text-blue-800'
                    : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditingComment ? 'Done' : 'Edit Remark'}</span>
              </button>
            )}

            <button
              type="button"
              id="report-print-btn"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              type="button"
              id="report-download-pdf-btn"
              disabled={isGeneratingPdf}
              onClick={handleDownloadPdf}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-900 hover:bg-blue-950 active:scale-98 text-white text-xs font-extrabold shadow-sm transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>⬇ Download PDF</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Report Type Selector (Complete vs Monthly) */}
        {onReportTypeChange && (
          <div className="mt-2.5 pt-2.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                id="btn-report-complete"
                onClick={() => onReportTypeChange('complete')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedReportType === 'complete'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                📋 পূর্ণাঙ্গ প্রগ্রেস কার্ড (All Months)
              </button>
              <button
                type="button"
                id="btn-report-monthly"
                onClick={() => {
                  const defaultMonth = availableMonths.length > 0 ? availableMonths[0].key : undefined;
                  onReportTypeChange('monthly', defaultMonth);
                }}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedReportType === 'monthly'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                📅 মাসিক প্রগ্রেস কার্ড (Monthly)
              </button>
            </div>

            {selectedReportType === 'monthly' && (
              <div className="flex items-center gap-2">
                <label className="text-xs font-bold text-slate-700">মাস নির্বাচন:</label>
                <select
                  id="select-report-month"
                  value={selectedMonth || (availableMonths[0]?.key || '')}
                  onChange={(e) => onReportTypeChange('monthly', e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                  {availableMonths.map((m) => (
                    <option key={m.key} value={m.key}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}

        {/* Zoom toggle */}
        <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-2">
            <span>Preview Size:</span>
            <button
              type="button"
              onClick={() => setPreviewZoom(previewZoom === 'fit' ? '100%' : 'fit')}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer text-[10px]"
            >
              {previewZoom === 'fit' ? (
                <>
                  <ZoomIn className="w-3 h-3" /> <span>Actual Size (100%)</span>
                </>
              ) : (
                <>
                  <ZoomOut className="w-3 h-3" /> <span>Fit Window</span>
                </>
              )}
            </button>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            One-Page A4 Portrait (210 × 297 mm) • Single Page Only
          </span>
        </div>

        {/* Remark Edit Box (Teachers only) */}
        {canEditRemark && isEditingComment && (
          <div className="mt-2.5 p-2.5 bg-blue-50/70 rounded-lg border border-blue-200 space-y-1.5">
            <label className="block text-[11px] font-bold text-slate-800">
              Teacher's Remark (শিক্ষকের মন্তব্য):
            </label>
            <textarea
              rows={2}
              value={teacherComment}
              onChange={(e) => setTeacherComment(e.target.value)}
              className="w-full p-2 bg-white border border-blue-300 rounded text-xs text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-600"
              placeholder="শিক্ষার্থী সম্পর্কে সংক্ষিপ্ত মন্তব্য লিখুন..."
            />
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setIsEditingComment(false)}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-900 text-white rounded text-[11px] font-bold hover:bg-blue-950 cursor-pointer"
              >
                <Check className="w-3 h-3" />
                <span>Save</span>
              </button>
            </div>
          </div>
        )}

        {/* Feedback Banners */}
        {errorMessage && (
          <div className="mt-2 p-2 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-xs font-bold text-rose-700">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs font-bold text-emerald-800">
            <Check className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}
      </div>

      {/* One-Page Report Preview */}
      <div className="w-full overflow-x-auto flex justify-center pb-8">
        <div className="origin-top max-w-full">
          <StudentProgressReportView
            reportData={reportData}
            teacherComment={teacherComment}
            reportRef={reportRef}
          />
        </div>
      </div>
    </div>
  );
};
