import React from 'react';
import { StudentProgressReportData } from './reportData';
import { ReportTrendChart } from './ReportTrendChart';
import pdfStyles from '../../styles/pdfPrint.module.css';
import { PDF_COLORS, COMMERCE_POINT_LOGO_BASE64 } from '../../styles/pdfPrintStyles';
import {
  Trophy,
  ArrowDownCircle,
  Calendar,
  Percent,
  TrendingUp,
  Minus,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface StudentProgressReportViewProps {
  reportData: StudentProgressReportData;
  teacherComment: string;
  reportRef: React.RefObject<HTMLDivElement | null>;
}

export const StudentProgressReportView: React.FC<StudentProgressReportViewProps> = ({
  reportData,
  teacherComment,
  reportRef,
}) => {
  const {
    student,
    studentIdFormatted,
    studentGroup,
    academicClass,
    subject,
    academicSession,
    reportDateStr,
    totalExams,
    attendedExams,
    absentExams,
    attendanceRate,
    totalFullMarks,
    totalObtainedMarks,
    overallPercentage,
    overallGrade,
    overallStatus,
    highestScoreFormatted,
    lowestScoreFormatted,
    trend,
    trendLabelBn,
    strengths,
    improvements,
    examRows,
    chartData,
  } = reportData;

  const count = examRows.length;

  // Adaptive scaling based on total exam count to guarantee strictly 1 A4 Page
  const isUltraCompact = count > 18;
  const isCompact = count > 11;

  // Strict 'pt' units for table row padding and typography
  const tableRowPaddingPt = isUltraCompact ? '1.5pt 2.5pt' : isCompact ? '2.5pt 3.5pt' : '3.5pt 4.5pt';
  const tableFontSizePt = isUltraCompact ? '7.5pt' : isCompact ? '8pt' : '8.5pt';
  const sectionGapPt = isUltraCompact ? '3.5pt' : isCompact ? '5pt' : '6pt';

  // Circular indicator calculations (ViewBox 100x100)
  const circleRadius = 40;
  const strokeWidth = 5.5;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset =
    circumference - (Math.min(100, Math.max(0, overallPercentage)) / 100) * circumference;

  // Format percentage string cleanly (e.g. 50%, 81.17%, 99.5%, 100%)
  const formattedPct = Number.isInteger(overallPercentage)
    ? overallPercentage.toString()
    : overallPercentage.toFixed(2).replace(/\.?0+$/, '');
  const displayPercentageStr = `${formattedPct}%`;

  const progressStrokeColorHex =
    overallPercentage >= 80
      ? '#1e3a8a'
      : overallPercentage >= 70
      ? '#0f766e'
      : overallPercentage >= 60
      ? '#d97706'
      : '#e11d48';

  // Status badge styling with resolved opaque hex colors
  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'Excellent':
        return { backgroundColor: '#ecfdf5', color: '#065f46', borderColor: '#6ee7b7' };
      case 'Very Good':
        return { backgroundColor: '#eff6ff', color: '#1e40af', borderColor: '#93c5fd' };
      case 'Good':
        return { backgroundColor: '#f0fdfa', color: '#0f766e', borderColor: '#5eead4' };
      case 'Satisfactory':
        return { backgroundColor: '#fefce8', color: '#854d0e', borderColor: '#fef08a' };
      case 'Needs Improvement':
        return { backgroundColor: '#fff1f2', color: '#9f1239', borderColor: '#fecdd3' };
      case 'Absent':
        return { backgroundColor: '#fee2e2', color: '#991b1b', borderColor: '#fca5a5' };
      default:
        return { backgroundColor: '#f8fafc', color: '#334155', borderColor: '#cbd5e1' };
    }
  };

  return (
    <div className="flex flex-col items-center py-2 w-full">
      {/* ========================================================
          STRICTLY ONE-PAGE A4 PORTRAIT: 595.28pt x 841.89pt (210mm x 297mm)
          Using dedicated print-focused styling in 'pt' units
          ======================================================== */}
      <div
        ref={reportRef}
        id="one-page-progress-card"
        className={`print-page ${pdfStyles.pdfPagePortrait}`}
        style={{
          width: '595.28pt',
          minHeight: '841.89pt',
          maxHeight: '841.89pt',
          boxSizing: 'border-box',
          padding: '18pt 22pt',
          backgroundColor: '#ffffff',
          color: '#0f172a',
          fontFamily: "'Nikosh', 'Kalpurush', 'Noto Sans Bengali', sans-serif",
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          overflow: 'hidden',
          border: '0.75pt solid #cbd5e1',
          boxShadow: '0 4pt 12pt rgba(15, 23, 42, 0.08)',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: sectionGapPt, flex: 1, justifyContent: 'space-between' }}>
          {/* ========================================================
              1. HEADER (Official Academic Branding, PT Typography)
              ======================================================== */}
          <div style={{ borderBottom: '2pt solid #1e3a8a', paddingBottom: '6pt', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10pt' }}>
              <img
                src="/commerce-point-logo.svg"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = COMMERCE_POINT_LOGO_BASE64;
                }}
                alt="COMMERCE POINT Logo"
                style={{ width: '54pt', height: '54pt', objectFit: 'contain', flexShrink: 0 }}
              />
              <div>
                <h1 style={{ fontSize: '19.5pt', fontWeight: 900, color: '#0f172a', letterSpacing: '-0.25pt', lineHeight: '21pt', margin: 0, padding: 0 }}>
                  COMMERCE POINT
                </h1>
                <p style={{ fontSize: '9pt', fontWeight: 700, color: '#dc2626', letterSpacing: '0.1pt', margin: '1.5pt 0 0 0', lineHeight: '11.5pt' }}>
                  HSC Business Studies & ICT Academic Care
                </p>
                <p style={{ fontSize: '7.5pt', fontWeight: 600, color: '#475569', letterSpacing: 'normal', margin: '1pt 0 0 0', lineHeight: '10pt' }}>
                  শিক্ষা | মেধা | শৃঙ্খলা | সাফল্য
                </p>
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <h2 style={{ fontSize: '13pt', fontWeight: 900, color: '#1e3a8a', letterSpacing: '0.2pt', textTransform: 'uppercase', lineHeight: '15pt', margin: 0 }}>
                {reportData.reportType === 'monthly' ? 'MONTHLY PROGRESS CARD' : 'STUDENT PROGRESS CARD'}
              </h2>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '4pt', marginTop: '3pt' }}>
                <span style={{ fontSize: '7.5pt', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.2pt' }}>
                  {reportData.reportType === 'monthly' && reportData.selectedMonthLabel
                    ? reportData.selectedMonthLabel
                    : 'Academic Progress'}
                </span>
                <span style={{ padding: '2pt 6pt', borderRadius: '3pt', backgroundColor: '#1e3a8a', color: '#fde047', fontWeight: 800, fontSize: '8pt', lineHeight: '10pt', border: '0.75pt solid #1e40af' }}>
                  {subject}
                </span>
              </div>
            </div>
          </div>

          {/* ========================================================
              2. STUDENT INFORMATION (High-Fidelity Grid, PT Units)
              ======================================================== */}
          <div style={{ borderRadius: '3.5pt', border: '0.75pt solid #cbd5e1', overflow: 'hidden', backgroundColor: '#ffffff', fontSize: '8pt', lineHeight: '11pt' }}>
            <div style={{ backgroundColor: '#0f172a', color: '#ffffff', fontWeight: 800, padding: '2.5pt 6pt', textTransform: 'uppercase', letterSpacing: '0.3pt', fontSize: '7.5pt' }}>
              Student Information
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderBottom: '0.75pt solid #cbd5e1' }}>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#f1f5f9', padding: '2.5pt 5pt', fontWeight: 700, color: '#475569', borderRight: '0.75pt solid #cbd5e1' }}>
                Student Name
              </div>
              <div style={{ gridColumn: 'span 2', padding: '2.5pt 5pt', fontWeight: 800, color: '#0f172a', fontSize: '8.5pt', borderRight: '0.75pt solid #cbd5e1', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {student.name}
              </div>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#f1f5f9', padding: '2.5pt 5pt', fontWeight: 700, color: '#475569', borderRight: '0.75pt solid #cbd5e1' }}>
                Student ID
              </div>
              <div style={{ gridColumn: 'span 2', padding: '2.5pt 5pt', fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace', fontSize: '8pt', borderRight: '0.75pt solid #cbd5e1' }}>
                {studentIdFormatted}
              </div>
              <div style={{ gridColumn: 'span 1', padding: '2.5pt 5pt', fontWeight: 700, color: '#334155', backgroundColor: '#f8fafc', textAlign: 'right' }}>
                Roll: <strong style={{ color: '#0f172a', fontWeight: 800 }}>{student.roll}</strong>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)' }}>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#f1f5f9', padding: '2.5pt 5pt', fontWeight: 700, color: '#475569', borderRight: '0.75pt solid #cbd5e1' }}>
                Class
              </div>
              <div style={{ gridColumn: 'span 1', padding: '2.5pt 5pt', fontWeight: 600, color: '#1e293b', borderRight: '0.75pt solid #cbd5e1' }}>
                {academicClass}
              </div>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#f1f5f9', padding: '2.5pt 5pt', fontWeight: 700, color: '#475569', borderRight: '0.75pt solid #cbd5e1' }}>
                Group
              </div>
              <div style={{ gridColumn: 'span 1', padding: '2.5pt 5pt', fontWeight: 600, color: '#1e293b', borderRight: '0.75pt solid #cbd5e1' }}>
                {studentGroup}
              </div>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#1e3a8a', color: '#ffffff', padding: '2.5pt 5pt', fontWeight: 800, fontSize: '7pt', textTransform: 'uppercase', borderRight: '0.75pt solid #cbd5e1' }}>
                Subject
              </div>
              <div style={{ gridColumn: 'span 1', padding: '2.5pt 5pt', fontWeight: 800, color: '#1e3a8a', backgroundColor: '#fefce8', fontSize: '8pt', borderRight: '0.75pt solid #cbd5e1' }}>
                {subject}
              </div>
              <div style={{ gridColumn: 'span 1', backgroundColor: '#f1f5f9', padding: '2.5pt 5pt', fontWeight: 700, color: '#475569', borderRight: '0.75pt solid #cbd5e1' }}>
                Session
              </div>
              <div style={{ gridColumn: 'span 1', padding: '2.5pt 5pt', fontWeight: 600, color: '#1e293b' }}>
                {academicSession}
              </div>
            </div>
          </div>

          {/* ========================================================
              3. OVERALL PERFORMANCE SUMMARY + CIRCULAR INDICATOR
              ======================================================== */}
          <div style={{ borderRadius: '3.5pt', border: '0.75pt solid #cbd5e1', overflow: 'hidden', backgroundColor: '#f8fafc', padding: '5pt 6pt' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4pt' }}>
              <span style={{ fontSize: '7.5pt', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.2pt', color: '#0f172a' }}>
                Overall Performance Summary
              </span>
              <span style={{ fontSize: '7pt', fontWeight: 600, color: '#64748b' }}>
                Report Date: {reportDateStr}
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '5pt', alignItems: 'center' }}>
              {/* Left: 6 Statistical metric boxes */}
              <div style={{ gridColumn: 'span 9', display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '4pt', textAlign: 'center' }}>
                <div style={{ backgroundColor: '#ffffff', border: '0.75pt solid #cbd5e1', borderRadius: '3pt', padding: '3pt 2pt' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Total Exam</span>
                  <span style={{ fontSize: '11.5pt', fontWeight: 900, color: '#0f172a', lineHeight: '13pt', display: 'block' }}>{totalExams}</span>
                </div>
                <div style={{ backgroundColor: '#ecfdf5', border: '0.75pt solid #6ee7b7', borderRadius: '3pt', padding: '3pt 2pt' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#047857', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Attended</span>
                  <span style={{ fontSize: '11.5pt', fontWeight: 900, color: '#065f46', lineHeight: '13pt', display: 'block' }}>{attendedExams}</span>
                </div>
                <div style={{ backgroundColor: '#fee2e2', border: '0.75pt solid #fca5a5', borderRadius: '3pt', padding: '3pt 2pt' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#b91c1c', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Absent</span>
                  <span style={{ fontSize: '11.5pt', fontWeight: 900, color: '#991b1b', lineHeight: '13pt', display: 'block' }}>{absentExams}</span>
                </div>
                <div style={{ backgroundColor: '#ffffff', border: '0.75pt solid #cbd5e1', borderRadius: '3pt', padding: '3pt 2pt' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Total Marks</span>
                  <span style={{ fontSize: '11.5pt', fontWeight: 900, color: '#0f172a', lineHeight: '13pt', display: 'block' }}>{totalFullMarks}</span>
                </div>
                <div style={{ backgroundColor: '#eff6ff', border: '0.75pt solid #bfdbfe', borderRadius: '3pt', padding: '3pt 2pt' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#1d4ed8', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Obtained</span>
                  <span style={{ fontSize: '11.5pt', fontWeight: 900, color: '#1e3a8a', lineHeight: '13pt', display: 'block' }}>{totalObtainedMarks}</span>
                </div>
                <div style={{ backgroundColor: '#1e3a8a', border: '0.75pt solid #1e40af', borderRadius: '3pt', padding: '3pt 2pt', color: '#ffffff' }}>
                  <span style={{ fontSize: '6.5pt', fontWeight: 700, color: '#bfdbfe', textTransform: 'uppercase', display: 'block', lineHeight: '8pt' }}>Average</span>
                  <span style={{ fontSize: '10.5pt', fontWeight: 900, color: '#fde047', lineHeight: '13pt', display: 'block' }}>
                    {overallPercentage.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Right: Circular Performance Indicator */}
              <div style={{ gridColumn: 'span 3', display: 'flex', alignItems: 'center', justifyContent: 'center', borderLeft: '0.75pt solid #cbd5e1', paddingLeft: '5pt' }}>
                <div style={{ position: 'relative', width: '54pt', height: '54pt', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg
                    style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)', display: 'block' }}
                    viewBox="0 0 100 100"
                  >
                    <circle
                      cx="50"
                      cy="50"
                      r={circleRadius}
                      stroke="#e2e8f0"
                      strokeWidth={strokeWidth}
                      fill="transparent"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r={circleRadius}
                      stroke={progressStrokeColorHex}
                      strokeWidth={strokeWidth}
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      fill="transparent"
                    />
                  </svg>

                  <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', userSelect: 'none', pointerEvents: 'none' }}>
                    <span style={{ fontSize: '5.5pt', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', lineHeight: '7pt' }}>
                      Overall<br />Performance
                    </span>
                    <span style={{ fontWeight: 900, color: '#0f172a', lineHeight: '10pt', margin: '1pt 0', fontSize: '9pt' }}>
                      {displayPercentageStr}
                    </span>
                    <span
                      style={{
                        display: 'inline-block',
                        padding: '1pt 3pt',
                        borderRadius: '2pt',
                        fontSize: '5.5pt',
                        fontWeight: 800,
                        lineHeight: '7pt',
                        border: '0.75pt solid',
                        ...getStatusBadgeStyle(overallStatus),
                      }}
                    >
                      {overallStatus}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================
              4. MAIN EXAMINATION TABLE (Strict PT Sizing & Spacing)
              ======================================================== */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', minHeight: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5pt' }}>
              <span style={{ fontSize: '8pt', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.2pt', color: '#0f172a' }}>
                Examination-wise Performance
              </span>
              <span style={{ fontSize: '7pt', color: '#64748b', fontWeight: 600 }}>
                (Oldest → Newest Ascending Order)
              </span>
            </div>

            <div style={{ border: '0.75pt solid #cbd5e1', borderRadius: '3pt', overflow: 'hidden', backgroundColor: '#ffffff' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: tableFontSizePt }}>
                <thead>
                  <tr style={{ backgroundColor: '#0f172a', color: '#ffffff', fontWeight: 800, fontSize: '7.5pt', textTransform: 'uppercase', letterSpacing: '0.1pt' }}>
                    <th style={{ padding: '3pt 2pt', textAlign: 'center', width: '20pt', borderRight: '0.75pt solid #334155' }}>#</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'left', width: '54pt', borderRight: '0.75pt solid #334155' }}>Date</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'left', borderRight: '0.75pt solid #334155' }}>Exam / Chapter</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'right', width: '44pt', borderRight: '0.75pt solid #334155' }}>Full Marks</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'right', width: '44pt', borderRight: '0.75pt solid #334155' }}>Obtained</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'right', width: '32pt', borderRight: '0.75pt solid #334155' }}>%</th>
                    <th style={{ padding: '3pt 4pt', textAlign: 'center', width: '60pt' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {examRows.map((row, idx) => (
                    <tr
                      key={row.examId}
                      style={{
                        backgroundColor: row.isAbsent
                          ? '#fff1f2'
                          : idx % 2 === 0
                          ? '#f8fafc'
                          : '#ffffff',
                        borderBottom: '0.75pt solid #e2e8f0',
                      }}
                    >
                      <td style={{ padding: tableRowPaddingPt, textAlign: 'center', fontWeight: 700, color: '#64748b', borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle' }}>
                        {String(row.sl).padStart(2, '0')}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, fontWeight: 500, color: '#334155', whiteSpace: 'nowrap', borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle' }}>
                        {row.dateStr}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, fontWeight: 600, color: '#0f172a', borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle', wordBreak: 'break-word', lineHeight: '10pt' }}>
                        {row.examName}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, textAlign: 'right', fontWeight: 500, color: '#475569', borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle' }}>
                        {row.fullMarks}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, textAlign: 'right', fontWeight: 800, borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle' }}>
                        {row.isAbsent ? (
                          <span style={{ color: '#dc2626', fontWeight: 800 }}>Absent</span>
                        ) : (
                          <span style={{ color: '#1e3a8a', fontWeight: 900 }}>{row.obtainedMarksStr}</span>
                        )}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, textAlign: 'right', fontWeight: 700, color: '#0f172a', borderRight: '0.75pt solid #cbd5e1', verticalAlign: 'middle' }}>
                        {row.isAbsent ? '—' : row.percentageStr}
                      </td>
                      <td style={{ padding: tableRowPaddingPt, textAlign: 'center', whiteSpace: 'nowrap', verticalAlign: 'middle' }}>
                        <span
                          style={{
                            display: 'inline-block',
                            padding: '1pt 4pt',
                            borderRadius: '2pt',
                            fontSize: '6.5pt',
                            fontWeight: 800,
                            lineHeight: '8pt',
                            border: '0.75pt solid',
                            ...getStatusBadgeStyle(row.status),
                          }}
                        >
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* ========================================================
              5. PERFORMANCE TREND + QUICK STATISTICS (PT Sizing)
              ======================================================== */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '5pt' }}>
            {/* Left 7 cols: Line chart */}
            <div style={{ gridColumn: 'span 7', backgroundColor: '#ffffff', borderRadius: '3pt', border: '0.75pt solid #cbd5e1', padding: '4.5pt' }}>
              <ReportTrendChart data={chartData} compactMode={isCompact} />
            </div>

            {/* Right 5 cols: Quick Statistics + Trend Indicator */}
            <div style={{ gridColumn: 'span 5', backgroundColor: '#ffffff', borderRadius: '3pt', border: '0.75pt solid #cbd5e1', padding: '4.5pt', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '3pt', marginBottom: '3pt' }}>
                  <span style={{ width: '4pt', height: '4pt', borderRadius: '50%', backgroundColor: '#1e3a8a', display: 'inline-block' }}></span>
                  <span style={{ fontSize: '7.5pt', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.2pt', color: '#0f172a' }}>
                    Quick Statistics
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '3.5pt', fontSize: '7.5pt' }}>
                  <div style={{ backgroundColor: '#f8fafc', border: '0.75pt solid #e2e8f0', borderRadius: '2.5pt', padding: '3pt 4pt' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '2pt', color: '#64748b', fontWeight: 700, fontSize: '6.5pt' }}>
                      <Trophy style={{ width: '8pt', height: '8pt', color: '#d97706', flexShrink: 0 }} />
                      <span>Highest Mark</span>
                    </div>
                    <div style={{ fontSize: '10pt', fontWeight: 900, color: '#0f172a', marginTop: '1pt' }}>
                      {highestScoreFormatted}
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#f8fafc', border: '0.75pt solid #e2e8f0', borderRadius: '2.5pt', padding: '3pt 4pt' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '2pt', color: '#64748b', fontWeight: 700, fontSize: '6.5pt' }}>
                      <ArrowDownCircle style={{ width: '8pt', height: '8pt', color: '#94a3b8', flexShrink: 0 }} />
                      <span>Lowest Mark</span>
                    </div>
                    <div style={{ fontSize: '10pt', fontWeight: 900, color: '#0f172a', marginTop: '1pt' }}>
                      {lowestScoreFormatted}
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#f8fafc', border: '0.75pt solid #e2e8f0', borderRadius: '2.5pt', padding: '3pt 4pt' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '2pt', color: '#64748b', fontWeight: 700, fontSize: '6.5pt' }}>
                      <Calendar style={{ width: '8pt', height: '8pt', color: '#059669', flexShrink: 0 }} />
                      <span>Attendance</span>
                    </div>
                    <div style={{ fontSize: '10pt', fontWeight: 900, color: '#047857', marginTop: '1pt' }}>
                      {attendanceRate.toFixed(1)}%
                    </div>
                  </div>

                  <div style={{ backgroundColor: '#f8fafc', border: '0.75pt solid #e2e8f0', borderRadius: '2.5pt', padding: '3pt 4pt' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '2pt', color: '#64748b', fontWeight: 700, fontSize: '6.5pt' }}>
                      <Percent style={{ width: '8pt', height: '8pt', color: '#1e40af', flexShrink: 0 }} />
                      <span>Average</span>
                    </div>
                    <div style={{ fontSize: '10pt', fontWeight: 900, color: '#1e3a8a', marginTop: '1pt' }}>
                      {overallPercentage.toFixed(1)}%
                    </div>
                  </div>
                </div>
              </div>

              {/* Performance Trend Badge */}
              <div style={{ marginTop: '3pt', paddingTop: '3pt', borderTop: '0.75pt solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '7pt' }}>
                <span style={{ fontWeight: 700, color: '#475569' }}>Performance Trend:</span>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '2pt',
                    padding: '1.5pt 4pt',
                    borderRadius: '2pt',
                    fontWeight: 800,
                    fontSize: '6.5pt',
                    border: '0.75pt solid',
                    ...(trend === 'Improving'
                      ? { backgroundColor: '#ecfdf5', color: '#065f46', borderColor: '#6ee7b7' }
                      : trend === 'Declining'
                      ? { backgroundColor: '#fee2e2', color: '#991b1b', borderColor: '#fca5a5' }
                      : { backgroundColor: '#eff6ff', color: '#1e40af', borderColor: '#93c5fd' }),
                  }}
                >
                  {trend === 'Improving' ? (
                    <TrendingUp style={{ width: '7pt', height: '7pt', flexShrink: 0 }} />
                  ) : trend === 'Declining' ? (
                    <TrendingDown style={{ width: '7pt', height: '7pt', flexShrink: 0 }} />
                  ) : (
                    <Minus style={{ width: '7pt', height: '7pt', flexShrink: 0 }} />
                  )}
                  <span style={{ lineHeight: '8pt' }}>
                    {trend} ({trendLabelBn})
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* ========================================================
              6. STRENGTHS + AREAS FOR IMPROVEMENT
              ======================================================== */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '5pt', fontSize: '7.5pt' }}>
            {/* Strengths */}
            <div style={{ borderRadius: '3pt', border: '0.75pt solid #6ee7b7', backgroundColor: '#ecfdf5', padding: '4pt 6pt' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '3pt', color: '#065f46', fontWeight: 800, textTransform: 'uppercase', marginBottom: '2pt', fontSize: '7.5pt' }}>
                <CheckCircle2 style={{ width: '8pt', height: '8pt', color: '#059669', flexShrink: 0 }} />
                <span>✓ Strengths (সবল দিকসমূহ)</span>
              </div>
              <ul style={{ margin: 0, padding: 0, listStyle: 'none', color: '#0f172a', lineHeight: '10.5pt' }}>
                {strengths.map((str, idx) => (
                  <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '3pt', marginBottom: '1pt' }}>
                    <span style={{ color: '#059669', fontWeight: 800, flexShrink: 0, marginTop: '0.5pt' }}>•</span>
                    <span style={{ fontWeight: 500, fontSize: '7.5pt' }}>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Areas for Improvement */}
            <div style={{ borderRadius: '3pt', border: '0.75pt solid #fde047', backgroundColor: '#fefce8', padding: '4pt 6pt' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '3pt', color: '#854d0e', fontWeight: 800, textTransform: 'uppercase', marginBottom: '2pt', fontSize: '7.5pt' }}>
                <AlertTriangle style={{ width: '8pt', height: '8pt', color: '#d97706', flexShrink: 0 }} />
                <span>⚠ Areas for Improvement (উন্নতির ক্ষেত্র)</span>
              </div>
              <ul style={{ margin: 0, padding: 0, listStyle: 'none', color: '#0f172a', lineHeight: '10.5pt' }}>
                {improvements.map((imp, idx) => (
                  <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '3pt', marginBottom: '1pt' }}>
                    <span style={{ color: '#d97706', fontWeight: 800, flexShrink: 0, marginTop: '0.5pt' }}>•</span>
                    <span style={{ fontWeight: 500, fontSize: '7.5pt' }}>{imp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* ========================================================
              7. TEACHER'S REMARK + SIGNATURE
              ======================================================== */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: '5pt', alignItems: 'center', fontSize: '7.5pt' }}>
            {/* Teacher's Remark */}
            <div style={{ gridColumn: 'span 7', borderRadius: '3pt', border: '0.75pt solid #cbd5e1', backgroundColor: '#f8fafc', padding: '4pt 6pt', textAlign: 'left' }}>
              <span style={{ fontSize: '7.5pt', fontWeight: 800, textTransform: 'uppercase', color: '#0f172a', marginRight: '3pt' }}>
                Teacher's Remark:
              </span>
              <span style={{ fontSize: '7.5pt', color: '#1e293b', fontWeight: 500, lineHeight: '10.5pt', wordBreak: 'break-word' }}>
                “{teacherComment}”
              </span>
            </div>

            {/* Signature row (Dedicated Non-Breaking Teacher Signature Block) */}
            <div style={{ gridColumn: 'span 5', borderRadius: '3pt', border: '0.75pt solid #e2e8f0', backgroundColor: '#ffffff', padding: '3.5pt 5pt', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', fontSize: '7pt', lineHeight: '9.5pt', pageBreakBefore: 'avoid', breakBefore: 'avoid' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: '#475569', marginBottom: '2pt' }}>
                <span>তারিখ: <strong style={{ color: '#0f172a', fontWeight: 700 }}>{reportDateStr}</strong></span>
                <span>সেশন: <strong style={{ color: '#0f172a', fontWeight: 700 }}>২০২৬</strong></span>
              </div>
              <div style={{ marginTop: '4pt', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '6pt' }}>
                <div style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ borderTop: '0.75pt dotted #475569', marginBottom: '2pt' }}></div>
                  <span style={{ fontWeight: 700, color: '#0f172a', fontSize: '6.8pt', display: 'block' }}>শ্রেণি শিক্ষকের স্বাক্ষর</span>
                </div>
                <div style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ borderTop: '0.75pt dotted #475569', marginBottom: '2pt' }}></div>
                  <span style={{ fontWeight: 700, color: '#0f172a', fontSize: '6.8pt', display: 'block' }}>পরিচালক / প্রধান শিক্ষকের স্বাক্ষর</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================
            8. FOOTER (Strict PT Sizing)
            ======================================================== */}
        <div style={{ paddingTop: '3pt', borderTop: '0.75pt solid #cbd5e1', marginTop: '2pt', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '7pt', color: '#475569', fontWeight: 600 }}>
          <div>
            <strong style={{ color: '#0f172a', fontWeight: 800 }}>COMMERCE POINT</strong> | ICT Coaching & Academic Support
          </div>
          <div style={{ color: '#334155', fontWeight: 600, letterSpacing: 'normal', lineHeight: '9pt', fontSize: '7.5pt' }}>
            “নিয়মিত অনুশীলন, সঠিক পরিকল্পনা, নিশ্চিত সফলতা”
          </div>
          <div style={{ fontWeight: 800, color: '#0f172a', backgroundColor: '#f1f5f9', padding: '1pt 4pt', borderRadius: '2pt', fontSize: '7pt' }}>
            Page 1 of 1
          </div>
        </div>
      </div>
    </div>
  );
};

