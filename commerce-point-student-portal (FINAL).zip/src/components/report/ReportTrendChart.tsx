import React from 'react';

interface ReportTrendChartProps {
  data: {
    sl: number;
    label: string;
    date: string;
    score: number;
    fullMarks: number;
    percentage: number;
    isAbsent: boolean;
  }[];
  compactMode?: boolean;
}

export const ReportTrendChart: React.FC<ReportTrendChartProps> = ({ data, compactMode = false }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-20 flex items-center justify-center text-[10px] text-slate-400 border border-slate-200 rounded-lg bg-slate-50">
        No exam trend data available
      </div>
    );
  }

  // Dimensions
  const svgWidth = 460;
  const svgHeight = compactMode ? 95 : 110;
  const padLeft = 28;
  const padRight = 18;
  const padTop = 16;
  const padBottom = 20;

  const chartW = svgWidth - padLeft - padRight;
  const chartH = svgHeight - padTop - padBottom;

  // Maximum value for scale
  const maxScore = Math.max(
    ...data.map((d) => (d.isAbsent ? 0 : d.score)),
    ...data.map((d) => d.fullMarks || 50),
    40
  );
  const yMax = Math.ceil(maxScore / 10) * 10;
  const yMid = Math.round(yMax / 2);
  const yTicks = [0, yMid, yMax];

  const n = data.length;
  const points = data.map((d, i) => {
    const x = n === 1 ? padLeft + chartW / 2 : padLeft + (i / (n - 1)) * chartW;
    const yVal = d.isAbsent ? 0 : d.score;
    const y = padTop + chartH - (yVal / yMax) * chartH;
    return { ...d, x, y, index: i };
  });

  const attendedPoints = points.filter((p) => !p.isAbsent);
  const polylinePoints = attendedPoints.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

  // Smooth Area path
  let areaPath = '';
  if (attendedPoints.length > 1) {
    const firstP = attendedPoints[0];
    const lastP = attendedPoints[attendedPoints.length - 1];
    const bottomY = padTop + chartH;
    areaPath = `M ${firstP.x.toFixed(1)},${bottomY} L ${polylinePoints.replace(/ /g, ' L ')} L ${lastP.x.toFixed(1)},${bottomY} Z`;
  }

  return (
    <div className="w-full h-full flex flex-col justify-between">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-blue-700 inline-block"></span>
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-800">
            Performance Trend (Marks Over Time)
          </span>
        </div>
        <span className="text-[8.5px] text-slate-500 font-semibold">
          Y: Marks • X: Exam Date
        </span>
      </div>

      <div className="w-full overflow-hidden bg-slate-50/60 rounded border border-slate-200/80 p-1">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto block select-none"
        >
          <defs>
            <linearGradient id="trendCardGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines and Y labels */}
          {yTicks.map((val) => {
            const y = padTop + chartH - (val / yMax) * chartH;
            return (
              <g key={val}>
                <line
                  x1={padLeft}
                  y1={y}
                  x2={svgWidth - padRight}
                  y2={y}
                  stroke="#cbd5e1"
                  strokeWidth="0.75"
                  strokeDasharray={val === 0 ? 'none' : '2 2'}
                />
                <text
                  x={padLeft - 4}
                  y={y + 3}
                  textAnchor="end"
                  fontSize="8"
                  fill="#64748b"
                  fontWeight="700"
                  fontFamily="'Inter', 'Kalpurush', system-ui, -apple-system, sans-serif"
                >
                  {val}
                </text>
              </g>
            );
          })}

          {/* Area fill */}
          {areaPath && <path d={areaPath} fill="url(#trendCardGradient)" />}

          {/* Trend Polyline */}
          {attendedPoints.length > 1 && (
            <polyline
              fill="none"
              stroke="#1e3a8a"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={polylinePoints}
            />
          )}

          {/* Points & Data labels */}
          {points.map((p) => {
            if (p.isAbsent) {
              const baselineY = padTop + chartH;
              return (
                <g key={`pt-${p.index}`}>
                  <circle
                    cx={p.x}
                    cy={baselineY}
                    r="2.5"
                    fill="#ffffff"
                    stroke="#e11d48"
                    strokeWidth="1.5"
                  />
                  <text
                    x={p.x}
                    y={baselineY - 4}
                    textAnchor="middle"
                    fontSize="7"
                    fill="#e11d48"
                    fontWeight="700"
                  >
                    Abs
                  </text>
                  <text
                    x={p.x}
                    y={padTop + chartH + 11}
                    textAnchor="middle"
                    fontSize={n > 12 ? '6.5' : '7.5'}
                    fill="#64748b"
                    fontWeight="600"
                  >
                    {p.date}
                  </text>
                </g>
              );
            }

            return (
              <g key={`pt-${p.index}`}>
                {/* Score badge text */}
                <text
                  x={p.x}
                  y={p.y - 4}
                  textAnchor="middle"
                  fontSize={n > 12 ? '7' : '8'}
                  fontWeight="800"
                  fill="#1e3a8a"
                  fontFamily="'Inter', 'Kalpurush', system-ui, -apple-system, sans-serif"
                >
                  {p.score}
                </text>

                {/* Point circle */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={n > 14 ? '2.5' : '3'}
                  fill="#ffffff"
                  stroke="#1e3a8a"
                  strokeWidth="1.8"
                />

                {/* X-axis date label */}
                <text
                  x={p.x}
                  y={padTop + chartH + 11}
                  textAnchor="middle"
                  fontSize={n > 12 ? '6.5' : '7.5'}
                  fill="#475569"
                  fontWeight="600"
                  fontFamily="'Inter', 'Kalpurush', system-ui, -apple-system, sans-serif"
                >
                  {p.date}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};
