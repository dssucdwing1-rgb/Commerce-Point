import { useState, useEffect, useMemo } from 'react';
import { NavPage, Exam, Student, AuthSession, Subject, Batch, BATCHES, getBatchById } from './types';
import {
  loadExams,
  addExam,
  updateExam,
  deleteExam,
  loadStudents,
  addStudent,
  removeStudent,
  updateStudent,
  generateSuggestedStudentId,
  loadSubjects,
  addSubject,
  updateSubject,
  deleteSubject,
  getActiveSubjectId,
  setActiveSubjectId,
  getActiveBatchId,
  setActiveBatchId,
} from './services/storage';
import { syncAndInitializeAccounts } from './services/authService';
import { logoutUser, mapSupabaseUserToAuthSession, buildAuthSessionWithRLS } from './services/supabaseAuth';
import {
  fetchLoggedInStudentRecord,
  fetchLoggedInStudentExamResults,
  mapDatabaseRowToStudent,
  isolateStudentExams,
  fetchAdminStudentsList,
  fetchRealtimeStudents,
  fetchRealtimeExamResults,
  writeWholeExamToSupabase,
  subscribeToSupabaseRealtime,
} from './services/supabaseDataService';
import { supabase } from './supabase';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomePage } from './components/HomePage';
import { ExamEntryPage } from './components/ExamEntryPage';
import { StudentProgressPage } from './components/StudentProgressPage';
import { AllResultsPage } from './components/AllResultsPage';
import { MonthlyResultsPage } from './components/monthly/MonthlyResultsPage';
import { ExamDetailModal } from './components/ExamDetailModal';
import { ConfirmDialog } from './components/ConfirmDialog';
import { ManageStudentsModal } from './components/ManageStudentsModal';
import { ManageSubjectsModal } from './components/ManageSubjectsModal';
import { AdminAccountModal } from './components/AdminAccountModal';
import { LoginPage } from './components/auth/LoginPage';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { StudentPortal } from './components/student/StudentPortal';
import { StaffDashboard } from './components/staff/StaffDashboard';
import { AuditReportModal } from './components/AuditReportModal';
import { ManageStaffModal } from './components/staff/ManageStaffModal';
import { checkStaffIsActive } from './services/staffService';
import { logoutUser } from './services/supabaseAuth';

export default function App() {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [currentPage, setCurrentPage] = useState<NavPage>('home');
  const [exams, setExams] = useState<Exam[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>(() => loadSubjects());
  const [activeSubjectId, setActiveSubjectIdState] = useState<string>(() => getActiveSubjectId());
  const [activeBatchId, setActiveBatchIdState] = useState<string>(() => getActiveBatchId());
  const [isManageStudentsOpen, setIsManageStudentsOpen] = useState<boolean>(false);
  const [manageStudentsTab, setManageStudentsTab] = useState<'students' | 'add' | 'accounts'>('students');
  const [isStaffManagementOpen, setIsStaffManagementOpen] = useState<boolean>(false);
  const [isManageSubjectsOpen, setIsManageSubjectsOpen] = useState<boolean>(false);
  const [isAdminAccountOpen, setIsAdminAccountOpen] = useState<boolean>(false);
  const [isAuditReportOpen, setIsAuditReportOpen] = useState<boolean>(false);
  const [activeModalExam, setActiveModalExam] = useState<Exam | null>(null);
  const [editingExam, setEditingExam] = useState<Exam | null>(null);
  const [examToDelete, setExamToDelete] = useState<Exam | null>(null);

  // Active Subject
  const currentSubject = useMemo(() => {
    return (
      subjects.find((s) => s.id === activeSubjectId) ||
      subjects.find((s) => s.id === 'ict') ||
      subjects[0] || {
        id: 'ict',
        name: 'ICT',
        code: 'ICT-101',
        isActive: true,
        order: 1,
      }
    );
  }, [subjects, activeSubjectId]);

  // Active Batch Object
  const activeBatch = useMemo(() => getBatchById(activeBatchId), [activeBatchId]);

  // Students counts by batch for badges
  const studentsCountByBatch = useMemo(() => {
    const counts: Record<string, number> = { 'class-11-a': 0, 'class-12-a': 0, 'class-12-b': 0 };
    students.forEach((s) => {
      const bId = s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
      counts[bId] = (counts[bId] || 0) + 1;
    });
    return counts;
  }, [students]);

  // Students belonging strictly to the currently active batch
  const batchStudents = useMemo(() => {
    return students.filter((s) => {
      const bId = s.batchId || (s.academicClass === 'XII' ? (s.group === 'B-B' ? 'class-12-b' : 'class-12-a') : 'class-11-a');
      return bId === activeBatchId;
    });
  }, [students, activeBatchId]);

  // Exams belonging strictly to the currently active batch
  const batchExams = useMemo(() => {
    return exams.filter((e) => (e.batchId || 'class-11-a') === activeBatchId);
  }, [exams, activeBatchId]);

  // Active Subject Exams for the active batch
  const currentSubjectExams = useMemo(() => {
    return batchExams.filter((e) => (e.subjectId || 'ict') === currentSubject.id);
  }, [batchExams, currentSubject.id]);

  // Load exams & students from local storage on mount & sync accounts
  useEffect(() => {
    // Load initial offline fallback cache
    const loadedExams = loadExams();
    const loadedStudents = loadStudents();
    const loadedSubjects = loadSubjects();
    setExams(loadedExams);
    setStudents(loadedStudents);
    setSubjects(loadedSubjects);

    // Direct Supabase real-time data sync on mount (retaining localStorage solely as offline fallback)
    fetchRealtimeStudents()
      .then((liveStudents) => {
        if (liveStudents && liveStudents.length > 0) {
          setStudents(liveStudents);
        }
        return fetchRealtimeExamResults(liveStudents);
      })
      .then((liveExams) => {
        if (liveExams && liveExams.length > 0) {
          setExams(liveExams);
        }
      })
      .catch((err) => {
        console.warn('Initial Supabase real-time sync fallback:', err);
      });

    // Initialize & sync student accounts
    syncAndInitializeAccounts().then(() => {
      // Re-read students in case studentIdCodes were generated/updated
      setStudents(loadStudents());
    });

    // Exclusively query Supabase Auth session on mount
    supabase.auth.getSession().then(async ({ data: { session: sbSession }, error }) => {
      if (error || !sbSession?.user) {
        setSession(null);
      } else {
        const sessionWithRLS = await buildAuthSessionWithRLS(sbSession.user, sbSession.access_token);
        if (sessionWithRLS.user.role === 'staff') {
          const staffIdent = sessionWithRLS.user.username || sessionWithRLS.user.id;
          const activeCheck = await checkStaffIsActive(staffIdent);
          if (!activeCheck.isActive) {
            await logoutUser();
            setSession(null);
            alert('আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।');
            return;
          }
        }
        setSession(sessionWithRLS);
      }
    });

    // Supabase auth state change listener
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, sbSession) => {
      if (event === 'SIGNED_OUT' || !sbSession?.user) {
        setSession(null);
        try {
          window.history.pushState(null, '', window.location.pathname);
          window.history.replaceState(null, '', window.location.pathname);
        } catch {
          // ignore
        }
      } else {
        const sessionWithRLS = await buildAuthSessionWithRLS(sbSession.user, sbSession.access_token);
        if (sessionWithRLS.user.role === 'staff') {
          const staffIdent = sessionWithRLS.user.username || sessionWithRLS.user.id;
          const activeCheck = await checkStaffIsActive(staffIdent);
          if (!activeCheck.isActive) {
            await logoutUser();
            setSession(null);
            alert('আপনার অ্যাকাউন্টটি সাময়িকভাবে নিষ্ক্রিয় করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।');
            return;
          }
        }
        setSession(sessionWithRLS);
      }
    });

    // Browser Back button guard: Prevents accessing protected pages if logged out
    const handlePopState = async () => {
      const { data: { session: sbSession } } = await supabase.auth.getSession();
      if (!sbSession?.user) {
        setSession(null);
        try {
          window.history.pushState(null, '', window.location.pathname);
        } catch {
          // ignore
        }
      }
    };
    window.addEventListener('popstate', handlePopState);

    return () => {
      authListener?.subscription.unsubscribe();
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // ==========================================================
  // RLS-aware Data Fetching Lifecycle:
  // 1. When a Student logs in:
  //    - Fetch the logged-in student's record from `students` using supabase.from('students').select('*').single()
  //    - Restrict their view strictly to their own data, progress, and exam results (exam_results).
  //    - Prevent the student from switching to other students' profiles or seeing any other student's detailed results.
  // 2. When the Admin logs in:
  //    - Full access remains available across all classes, batches, student lists, and results entry.
  // ==========================================================
  useEffect(() => {
    if (!session) return;

    let isCancelled = false;

    if (session.user.role === 'student') {
      const loadStudentRLSData = async () => {
        // 1. Fetch the logged-in student's record from `students` using supabase.from('students').select('*').single()
        const { data: dbStudentRecord } = await fetchLoggedInStudentRecord();
        const baseStudent = session.user.student || {
          id: session.user.id,
          name: session.user.name,
          roll: 1,
          studentIdCode: session.user.customStudentId || '',
        };
        const currentStudent = mapDatabaseRowToStudent(dbStudentRecord, baseStudent);

        // Update session user with the verified student record if needed
        if (dbStudentRecord && !isCancelled) {
          setSession((prev) => {
            if (!prev || prev.user.role !== 'student') return prev;
            return {
              ...prev,
              user: {
                ...prev.user,
                id: currentStudent.id,
                name: currentStudent.name,
                customStudentId: currentStudent.studentIdCode,
                batchId: currentStudent.batchId,
                student: currentStudent,
              },
            };
          });
        }

        // 2. Fetch logged-in student's exam results strictly from `exam_results` table under RLS
        const { data: dbExamResults } = await fetchLoggedInStudentExamResults();
        const baseExams = loadExams();
        const studentIsolatedExams = isolateStudentExams(dbExamResults, currentStudent, baseExams);

        if (!isCancelled) {
          // Strictly restrict exams state to only this student's exam results
          setExams(studentIsolatedExams);
          // Strictly restrict students state to only this student's profile (preventing profile switching or peer leaks)
          setStudents([currentStudent]);
        }
      };

      loadStudentRLSData();
    } else if (session.user.role === 'admin' || session.user.role === 'staff') {
      // Admin and Staff: Direct real-time data sync from Supabase tables
      // Students: supabase.from('students').select('*')
      // Exam Results: supabase.from('exam_results').select('*')
      fetchRealtimeStudents()
        .then((liveStudents) => {
          if (!isCancelled && liveStudents.length > 0) {
            setStudents(liveStudents);
          }
          return fetchRealtimeExamResults(liveStudents);
        })
        .then((liveExams) => {
          if (!isCancelled && liveExams.length > 0) {
            setExams(liveExams);
          }
        })
        .catch((err) => {
          console.warn('Realtime Supabase fetch error, retained offline cache:', err);
        });

      // Realtime subscription for live updates across sessions/devices
      const unsubscribe = subscribeToSupabaseRealtime(async () => {
        if (isCancelled) return;
        try {
          const freshStudents = await fetchRealtimeStudents();
          if (!isCancelled && freshStudents.length > 0) {
            setStudents(freshStudents);
          }
          const freshExams = await fetchRealtimeExamResults(freshStudents);
          if (!isCancelled && freshExams.length > 0) {
            setExams(freshExams);
          }
        } catch {
          // ignore
        }
      });

      return () => {
        isCancelled = true;
        unsubscribe();
      };
    }

    return () => {
      isCancelled = true;
    };
  }, [session?.user?.id, session?.user?.role]);

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.warn('Logout error:', err);
    } finally {
      setSession(null);
      setCurrentPage('home');
      try {
        window.history.pushState(null, '', window.location.pathname);
        window.history.replaceState(null, '', window.location.pathname);
      } catch {
        // ignore
      }
    }
  };

  const handleSelectBatch = (batchId: string) => {
    setActiveBatchIdState(batchId);
    setActiveBatchId(batchId);
  };

  const handleSelectSubject = (subId: string) => {
    setActiveSubjectIdState(subId);
    setActiveSubjectId(subId);
  };

  const handleAddSubject = (name: string, code: string) => {
    const updated = addSubject(name, code);
    setSubjects(updated.subjects);
  };

  const handleUpdateSubject = (id: string, name: string, code: string, isActive?: boolean) => {
    const updated = updateSubject(id, { name, code, isActive });
    setSubjects(updated.subjects);
  };

  const handleDeleteSubject = (id: string) => {
    const updated = deleteSubject(id);
    setSubjects(updated);
    if (activeSubjectId === id) {
      handleSelectSubject('ict');
    }
  };

  // Student management handlers
  const handleAddStudent = (
    name: string,
    roll?: number,
    studentIdCode?: string,
    academicClass?: string,
    group?: string,
    subject?: string,
    session?: string,
    assignedSubjectIds?: string[],
    batchId?: string
  ) => {
    const targetBatchId = batchId || activeBatchId;
    const batchInfo = getBatchById(targetBatchId);
    const res = addStudent({
      name,
      roll,
      studentIdCode: studentIdCode || generateSuggestedStudentId(roll || 1, academicClass || batchInfo.academicClass, group || batchInfo.group),
      batchId: targetBatchId,
      academicClass: academicClass || batchInfo.academicClass,
      group: group || batchInfo.group,
      subject,
      session,
      assignedSubjectIds,
    });
    setStudents(res.students);
  };

  const handleRemoveStudent = (id: string) => {
    const updated = removeStudent(id);
    setStudents(updated);
  };

  const handleUpdateStudent = (
    id: string,
    name: string,
    roll: number,
    studentIdCode?: string,
    academicClass?: string,
    group?: string,
    subject?: string,
    session?: string,
    changedBy?: string,
    changeReason?: string,
    assignedSubjectIds?: string[],
    batchId?: string
  ) => {
    const res = updateStudent(
      id,
      {
        name,
        roll,
        studentIdCode: studentIdCode || '',
        batchId: batchId || activeBatchId,
        academicClass,
        group,
        subject,
        session,
        changeReason,
        assignedSubjectIds,
      },
      undefined,
      undefined,
      changedBy || 'Admin'
    );
    setStudents(res.students);
  };

  // Handler for saving an exam (new or edited)
  const handleSaveExam = async (exam: Exam) => {
    const examToSave: Exam = {
      ...exam,
      batchId: exam.batchId || activeBatchId,
    };
    if (editingExam) {
      const updated = updateExam(examToSave);
      setExams(updated);
      setEditingExam(null);
    } else {
      const updated = addExam(examToSave, activeBatchId);
      setExams(updated);
    }

    // Direct Supabase Write: Any marks entry or modification writes directly to Supabase exam_results table
    try {
      await writeWholeExamToSupabase(examToSave, students);
    } catch (err) {
      console.warn('Real-time Supabase exam write fallback:', err);
    }

    setCurrentPage('progress');
  };

  // Handler for editing an exam
  const handleEditExam = (exam: Exam) => {
    setActiveModalExam(null);
    setEditingExam(exam);
    setCurrentPage('entry');
  };

  // Handler for cancelling edit
  const handleCancelEdit = () => {
    setEditingExam(null);
    setCurrentPage('results');
  };

  // Delete initiation
  const handlePromptDeleteExam = (exam: Exam) => {
    setExamToDelete(exam);
  };

  // Delete confirmation
  const handleConfirmDelete = () => {
    if (examToDelete) {
      const updated = deleteExam(examToDelete.id);
      setExams(updated);
      if (activeModalExam?.id === examToDelete.id) {
        setActiveModalExam(null);
      }
      setExamToDelete(null);
    }
  };

  // ==========================================================
  // Protected Route: Unauthenticated users are redirected to LoginPage
  // Authenticated students are directed to StudentPortal
  // Authenticated admins/teachers are directed to Admin Dashboard
  // ==========================================================
  return (
    <ProtectedRoute session={session} onLoginSuccess={(newSession) => setSession(newSession)}>
      {session && session.user.role === 'student' ? (
        <StudentPortal
          session={session}
          allExams={exams}
          subjects={subjects}
          allStudents={students}
          onLogout={handleLogout}
        />
      ) : session && session.user.role === 'staff' ? (
        <StaffDashboard
          session={session}
          students={students}
          exams={exams}
          subjects={subjects}
          activeBatchId={activeBatchId}
          onSelectBatch={handleSelectBatch}
          onSaveExam={async (updatedExam) => {
            const exists = exams.some((e) => e.id === updatedExam.id);
            const updatedList = exists
              ? exams.map((e) => (e.id === updatedExam.id ? updatedExam : e))
              : [updatedExam, ...exams];
            setExams(updatedList);
            if (exists) {
              updateExam(updatedExam);
            } else {
              addExam(updatedExam, updatedExam.batchId);
            }
            // Direct Supabase Write
            try {
              await writeWholeExamToSupabase(updatedExam, students);
            } catch (err) {
              console.warn('Staff onSaveExam Supabase write error:', err);
            }
          }}
          onLogout={handleLogout}
        />
      ) : session ? (
        <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Main Responsive App Frame with max-width 1400px */}
      <div className="w-full max-w-[1400px] mx-auto min-h-screen bg-slate-50 flex flex-col shadow-sm border-x border-slate-200/80">
        {/* Header with Admin info, Subject info, Batch Selector & Logout */}
        <Header
          studentsCount={batchStudents.length}
          currentSubject={currentSubject}
          activeBatchId={activeBatchId}
          onSelectBatch={handleSelectBatch}
          studentsCountByBatch={studentsCountByBatch}
          onManageStudents={(tab) => {
            setManageStudentsTab(tab || 'students');
            setIsManageStudentsOpen(true);
          }}
          onOpenStaffManagement={() => setIsStaffManagementOpen(true)}
          onOpenAdminAccount={() => setIsAdminAccountOpen(true)}
          onOpenManageSubjects={() => setIsManageSubjectsOpen(true)}
          onOpenAuditReport={() => setIsAuditReportOpen(true)}
          onNavigate={(page) => {
            if (page === 'entry') setEditingExam(null);
            setCurrentPage(page);
          }}
          currentPage={currentPage}
          currentUser={session.user}
          onLogout={handleLogout}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full px-3.5 sm:px-6 lg:px-8 pt-4 pb-24 overflow-y-auto">
          {currentPage === 'home' && (
            <HomePage
              exams={currentSubjectExams}
              students={batchStudents}
              subjects={subjects}
              activeSubjectId={activeSubjectId}
              activeBatchId={activeBatchId}
              onSelectBatch={handleSelectBatch}
              studentsCountByBatch={studentsCountByBatch}
              allExamsForCounts={batchExams}
              isAdmin={session.user.role === 'admin'}
              onSelectSubject={handleSelectSubject}
              onManageSubjects={() => setIsManageSubjectsOpen(true)}
              onNavigate={(page) => {
                if (page === 'entry') setEditingExam(null);
                setCurrentPage(page);
              }}
              onSelectExam={(exam) => setActiveModalExam(exam)}
              onManageStudents={() => setIsManageStudentsOpen(true)}
              onOpenStaffManagement={() => setIsStaffManagementOpen(true)}
              onOpenAdminAccount={() => setIsAdminAccountOpen(true)}
            />
          )}

          {currentPage === 'entry' && (
            <ExamEntryPage
              editingExam={editingExam}
              students={batchStudents}
              currentSubject={currentSubject}
              onSaveExam={handleSaveExam}
              onCancelEdit={handleCancelEdit}
            />
          )}

          {currentPage === 'monthly' && (
            <MonthlyResultsPage
              exams={batchExams}
              students={batchStudents}
              subjects={subjects}
              onSelectExam={(exam) => setActiveModalExam(exam)}
              onEditExam={handleEditExam}
              onDeleteExam={handlePromptDeleteExam}
              onNavigateToEntry={() => {
                setEditingExam(null);
                setCurrentPage('entry');
              }}
            />
          )}

          {currentPage === 'progress' && (
            <StudentProgressPage
              exams={currentSubjectExams}
              students={batchStudents}
              currentUser={session?.user}
              currentSubject={currentSubject}
            />
          )}

          {currentPage === 'results' && (
            <AllResultsPage
              exams={currentSubjectExams}
              students={batchStudents}
              currentUser={session?.user}
              currentSubject={currentSubject}
              onOpenExam={(exam) => setActiveModalExam(exam)}
              onEditExam={handleEditExam}
              onDeleteExam={handlePromptDeleteExam}
              onNewExam={() => {
                setEditingExam(null);
                setCurrentPage('entry');
              }}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <BottomNav
          currentPage={currentPage}
          onSelectPage={(page) => {
            if (page === 'entry' && currentPage !== 'entry') {
              // start fresh entry unless intentionally editing
            }
            setCurrentPage(page);
          }}
        />
      </div>

      {/* Full Exam Details Modal */}
      <ExamDetailModal
        exam={activeModalExam}
        students={
          activeModalExam
            ? students.filter(
                (s) =>
                  (s.batchId ||
                    (s.academicClass === 'XII'
                      ? s.group === 'B-B'
                        ? 'class-12-b'
                        : 'class-12-a'
                      : 'class-11-a')) === (activeModalExam.batchId || 'class-11-a')
              )
            : batchStudents
        }
        subjects={subjects}
        onClose={() => setActiveModalExam(null)}
        onEdit={handleEditExam}
        onDelete={handlePromptDeleteExam}
      />

      {/* Manage Students Modal (Add / Edit / Remove / Subject Enrollments / Login Accounts) */}
      <ManageStudentsModal
        isOpen={isManageStudentsOpen}
        onClose={() => setIsManageStudentsOpen(false)}
        students={students}
        subjects={subjects}
        exams={exams}
        activeBatchId={activeBatchId}
        initialTab={manageStudentsTab}
        onAddStudent={handleAddStudent}
        onUpdateStudent={handleUpdateStudent}
        onRemoveStudent={handleRemoveStudent}
        onOpenAdminAccount={() => setIsAdminAccountOpen(true)}
        onRefreshDatabase={() => {
          setStudents(loadStudents());
          setExams(loadExams());
        }}
      />

      {/* Manage Staff Modal (Staff List, Add Staff, Activate/Deactivate, Delete) */}
      <ManageStaffModal
        isOpen={isStaffManagementOpen}
        onClose={() => setIsStaffManagementOpen(false)}
      />

      {/* Manage Subjects Modal (Add / Edit / Activate Subjects) */}
      <ManageSubjectsModal
        isOpen={isManageSubjectsOpen}
        onClose={() => setIsManageSubjectsOpen(false)}
        subjects={subjects}
        exams={exams}
        onAddSubject={handleAddSubject}
        onUpdateSubject={handleUpdateSubject}
        onDeleteSubject={handleDeleteSubject}
      />

      {/* Admin / Teacher Account & Password Modal */}
      <AdminAccountModal
        isOpen={isAdminAccountOpen}
        onClose={() => setIsAdminAccountOpen(false)}
        currentUser={session?.user}
        onProfileUpdated={(updatedUser) => {
          setSession((prev) => (prev ? { ...prev, user: updatedUser } : null));
        }}
      />

      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        isOpen={!!examToDelete}
        title="পরীক্ষাটি মুছে ফেলতে চান?"
        message={`আপনি কি নিশ্চিত যে "${examToDelete?.name}" পরীক্ষার সমস্ত ফলাফল স্থায়ীভাবে মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা যাবে না।`}
        confirmText="হ্যাঁ, মুছে ফেলুন"
        cancelText="না, বাতিল"
        onConfirm={handleConfirmDelete}
        onCancel={() => setExamToDelete(null)}
      />
        </div>
      ) : null}
    </ProtectedRoute>
  );
}
