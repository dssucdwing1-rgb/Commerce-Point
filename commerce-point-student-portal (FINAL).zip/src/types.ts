export interface StudentIdChangeRecord {
  previousId: string;
  newId: string;
  changedAt: number;
  changedBy: string;
  reason?: string;
}

export interface Batch {
  id: string; // 'class-11-a' | 'class-12-a' | 'class-12-b'
  batchKey: string; // 'class11_batch_a' | 'class12_batch_a' | 'class12_batch_b'
  name: string; // 'একাদশ শ্রেণি — ব্যাচ এ'
  shortName: string; // 'একাদশ (ব্যাচ এ)'
  academicClass: string; // 'XI' | 'XII'
  group: string; // 'B-A' | 'B-B'
  classNameBengali: string; // 'একাদশ শ্রেণি' | 'দ্বাদশ শ্রেণি'
  batchNameBengali: string; // 'ব্যাচ এ' | 'ব্যাচ বি'
  session: string; // '2026'
  order: number;
}

export const BATCHES: Batch[] = [
  {
    id: 'class-11-a',
    batchKey: 'class11_batch_a',
    name: 'একাদশ শ্রেণি — ব্যাচ এ',
    shortName: 'একাদশ (ব্যাচ এ)',
    academicClass: 'XI',
    group: 'B-A',
    classNameBengali: 'একাদশ শ্রেণি',
    batchNameBengali: 'ব্যাচ এ',
    session: '2026',
    order: 1,
  },
  {
    id: 'class-12-a',
    batchKey: 'class12_batch_a',
    name: 'দ্বাদশ শ্রেণি — ব্যাচ এ',
    shortName: 'দ্বাদশ (ব্যাচ এ)',
    academicClass: 'XII',
    group: 'B-A',
    classNameBengali: 'দ্বাদশ শ্রেণি',
    batchNameBengali: 'ব্যাচ এ',
    session: '2026',
    order: 2,
  },
  {
    id: 'class-12-b',
    batchKey: 'class12_batch_b',
    name: 'দ্বাদশ শ্রেণি — ব্যাচ বি',
    shortName: 'দ্বাদশ (ব্যাচ বি)',
    academicClass: 'XII',
    group: 'B-B',
    classNameBengali: 'দ্বাদশ শ্রেণি',
    batchNameBengali: 'ব্যাচ বি',
    session: '2026',
    order: 3,
  },
];

export const DEFAULT_BATCH_ID = 'class-11-a';

export function getBatchById(id?: string): Batch {
  if (!id) return BATCHES[0];
  if (id === 'class12_batch_a' || id === 'class-12-a') return BATCHES[1];
  if (id === 'class12_batch_b' || id === 'class-12-b') return BATCHES[2];
  if (id === 'class11_batch_a' || id === 'class-11-a') return BATCHES[0];
  return BATCHES.find((b) => b.id === id || b.batchKey === id) || BATCHES[0];
}

export function getBatchByClassAndGroup(academicClass?: string, group?: string): Batch {
  const normClass = (academicClass || '').toUpperCase();
  const isTwelve = normClass.includes('12') || normClass.includes('XII') || normClass.includes('দ্বাদশ');
  const isGroupB = (group || '').toUpperCase().includes('B-B') || (group || '').includes('বি');
  if (isTwelve) {
    return isGroupB ? BATCHES[2] : BATCHES[1];
  }
  return BATCHES[0];
}

export interface Subject {
  id: string; // e.g. 'ict', 'bangla', 'english', 'accounting', 'marketing', 'management', 'economics'
  name: string; // e.g. 'ICT', 'Bangla', 'English', 'Accounting', 'Marketing', 'Management', 'Economics'
  code: string; // e.g. 'ICT', 'BAN', 'ENG', 'ACC', 'MKT', 'MGT', 'ECO'
  bengaliName?: string;
  isActive: boolean;
  isDefault?: boolean;
  order?: number;
}

export interface Student {
  id: string; // unique immutable internal primary ID (never changed upon student ID edit)
  roll: number;
  name: string;
  studentIdCode: string; // Admin-controlled Unique Student ID, e.g. "CP/C-11/B-A 001"
  batchId?: string; // 'class-11-a' | 'class-12-a' | 'class-12-b'
  academicClass?: string; // e.g. "XI" or "XII"
  group?: string; // e.g. "B-A", "B-B"
  subject?: string; // legacy single subject string
  assignedSubjectIds?: string[]; // Array of subject IDs student is enrolled in, e.g. ['ict', 'bangla']
  session?: string; // e.g. "2026"
  mobile?: string;
  email?: string;
  idHistory?: StudentIdChangeRecord[];
}

export type UserRole = 'admin' | 'teacher' | 'student' | 'staff';

export interface StaffMember {
  id: string; // uuid
  name: string;
  email: string;
  phone?: string;
  is_active: boolean;
  created_at?: string | number;
  updated_at?: string | number;
}

export interface StudentAccount {
  studentId: string; // references Student.id
  customStudentId: string; // e.g. "CP-001"
  username: string; // e.g. "CP-001"
  passwordHash: string;
  salt: string;
  status: 'active' | 'inactive';
  createdAt: number;
  updatedAt: number;
}

export interface AuthUser {
  id: string;
  name: string;
  role: UserRole;
  username?: string;
  customStudentId?: string; // "CP-001"
  batchId?: string;
  student?: Student;
}

export interface AuthSession {
  user: AuthUser;
  token: string;
  rememberMe: boolean;
  loggedInAt: number;
}

export type StudentNavPage = 'dashboard' | 'results' | 'monthly' | 'profile';

export interface MonthOption {
  year: number;
  month: number; // 1-12
  key: string; // "2026-09"
  label: string; // "September 2026"
  bengaliLabel: string; // "সেপ্টেম্বর ২০২৬"
  examCount: number;
}

export interface StudentMarkEntry {
  studentId: string;
  studentName: string;
  cq: number | '';
  mcq: number | '';
  total: number;
  percentage: number;
  grade: string;
}

export interface Exam {
  id: string;
  batchId?: string; // 'class-11-a' | 'class-12-a' | 'class-12-b'
  subjectId?: string; // e.g. 'ict', 'bangla' (defaults to 'ict' if empty)
  date: string; // YYYY-MM-DD
  name: string;
  cqFullMarks: number;
  mcqFullMarks: number;
  totalFullMarks: number;
  marks: Record<string, StudentMarkEntry>; // keyed by studentId
  average: number;
  averagePercentage: number;
  createdAt: number;
}

export type NavPage = 'home' | 'entry' | 'monthly' | 'results' | 'progress';
